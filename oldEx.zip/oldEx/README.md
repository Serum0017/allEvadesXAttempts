If replit.nix ever deletes itself:
{ pkgs }: {
    deps = [
        pkgs.nodejs-16_x
        pkgs.nodePackages.typescript-language-server
    ];
    env = {
        LD_LIBRARY_PATH = pkgs.lib.makeLibraryPath [pkgs.libuuid];
    };
}



# Evades X (new)
Joke Project - Client-Sided Game - Speedrunned in one day - by ZeroTix
(except it became a huge game now)

## Explanation
#### There can be multiple maps. Each map can contain multiple zones. Each Zone can contain different music and they each have their own unique color. Maps will typically have 10 zones. Inside zones, there can be subzones. Subzones are mostly just a name for noncollidable obstacles with an opaque color that affect the player. Examples of subzones are Streams and Gravity Pulling.

## Modern Obstacle Ideas
- **DONE**   Obstacle (Circle/Rect) - You can collide with it
- **DONE** Bouncy Obstacles (Circle/Rect) - They bounce you away
- Switch/Beat Obstacles (Circle/Rect) - They turn on and off based on a beat
- Non-Respawn Obstacle (Rect) - Noncollidable, players cant touch each other to respawn, they must use a respawn point 
- **DONE** Lava (Rect) - It kills you  
- Moving Lava (Rect) - Lava moving to multiple points
- **DONE** Rotating Lava (Rect) - Rotates a certain speed and kills players
- **DONE** Fast/Streams SubZone (Rect) - Noncollidable, players inside will be faster
- Gate (Rect) - A gate that can be opened via Switch
- Switch/Button (Rect) - Pressing this button can trigger events like opening gates and closing gates
- Barrier (Circle) - Circular barrier that makes any players fully inside, invincible
- Barrier (Rect) - Rectangular Barrier
- Moving Barrier - Self explanatory
- Timer (Rect) - A type of button that sets a timer on your screen can do events like opening a gate for X seconds
- **DONE** Directional (Up/Down/Right/Left) Gravity SubZone(Rect) - Makes the player go in that direction while they are in it

## Modern Enemy Ideas
- **DONE** Square Enemy - The hitbox is a Square
- Gravity Enemy - They can't kill you but they attempt to pull you in
- **DONE** Teleport Enemy - The position changes every X seconds with a preview in realtime of it
- **DONE** Switch Enemy - Switch every X seconds (killable to not killable)

## Bugs
- Machining/Chaining through lava
- Clipping thru walls at high speeds (not really fixable but still)
## When will ZeroTix Notice This?
- set at 7/25 :)
- noticed AT 7/29