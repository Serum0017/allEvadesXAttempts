// old webhook code
const { Webhook } = require('discord-webhook-node');
const normalWebhook = new Webhook("https://discord.com/api/webhooks/924136767911772160/ypZyOQx0YNLeLeaZk5NTAci_4DbFy2ml_3T0dc0F4A5OyKJOtRlfDDg2dS6qXyM7NVK3");
const hardWebhook = new Webhook("https://discord.com/api/webhooks/924136860119359498/9ajRqB88yx8SPt2AnH1Skza4_BSLONiyM3ORvD6ryzEHrnHs1Rp1aQumKcnQ9Wp0Puyy");

let difficultyEmotes = {
  "Peaceful": "<:peaceful:923064510930092082>",
  "Moderate": "<:moderate:923064411353129021>",
  "Difficult": "<:difficult:923064411340558377>",
  "Hardcore": "<:hardcore:923064411822886922>",
  "Exausting": "<:exausting:923064411038580817>",
  "Relentless": "<:relentless:923064411525111848>",
  "Agonizing": "<:agonizing:922658786647343135>",
  "Terrorizing": "<:terrorizing:922658817739747338>",
  "Cataclysmic": "<:cataclysmic:922660115688063016>"
};

function capFirst(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}
// zero colors for haloween map:
/*
bgColor: '#cf7238',
tileColor: '#de661b',
 */
const {adjectives, nouns} = require('./randomstuff.js');
// setInterval(() => {
//   let randAdj = adjectives[Math.floor(adjectives.length * Math.random())];
//   let randNoun = nouns[Math.floor(nouns.length * Math.random())];
//   let username = randAdj + randNoun + Math.floor(Math.random() * 1000);
//   let randInt = Math.random()
//   if (randInt < 0.3){
//     if (randInt < 0.08){
//       username = "haha0201";
//     }
//     else if (randInt < 0.14){
//       username = "ZeroTix";
//     }
//     else if (randInt < 0.21){
//       username = "Serum";
//     }
//     else if (randInt < 0.24){
//       username = "Piger";
//     }
//     else if (randInt < 0.27){
//       username = "Strat";
//     }
//     else{
//       username = "KDG"
//     }
//   }
//   let mapInitial = "Planet of ";
//   let randInt2 = Math.random();
//   if (randInt2 < 0.05){
//     mapInitial = "Galaxy of ";
//   }
//   randAdj = adjectives[Math.floor(adjectives.length * Math.random())];
//   randNoun = nouns[Math.floor(nouns.length * Math.random())];
//   let d = "";
//   let difficultyInt = Math.random();
//   difficultyInt = difficultyInt ** 2.5;
//   if (difficultyInt < 0.2){
//     d = "Peaceful";
//   }
//   else if (difficultyInt < 0.4){
//     d = "Moderate";
//   }
//   else if (difficultyInt < 0.6){
//     d = "Difficult";
//   }
//   else if (difficultyInt < 0.7){
//     d = "Hardcore";
//   }
//   else if (difficultyInt < 0.8){
//     d = "Exausting";
//   }
//   else if (difficultyInt < 0.9){
//     d = "Relentless";
//   }
//   else if (difficultyInt < 0.933){
//     d = "Agonizing";
//   }
//   else if (difficultyInt < 0.966){
//     d = "Terrorizing";
//   }
//   else{
//     d = "Cataclysmic";
//   }
//   let seconds = Math.floor(Math.random() * 60);
//   let milliseconds = Math.floor(Math.random() * 100);
//   let minutes = Math.floor(Math.random() * 10) + 3;
//   if (mapInitial == "Galaxy of "){
//     minutes *= (Math.random() * 10) + 12;
//     minutes = Math.round(minutes);
//   }
//   if (seconds < 10){
//     seconds = "0"+seconds;
//   }
//   if (milliseconds < 10){
//     milliseconds = "0"+milliseconds;
//   }
//   let time = minutes+":"+seconds+"."+milliseconds;
//   if (d == "Agonizing" || d == "Terrorizing" || d == "Cataclysmic"){
//     hardWebhook.send(`**${username}** has soloed **${mapInitial + capFirst(randAdj) + " " + capFirst(randNoun)}** in **${time}!!!** [${difficultyEmotes[d]}]`);
//   }
//   else{
//     normalWebhook.send(`**${username}** has soloed **${mapInitial + capFirst(randAdj) + " " + capFirst(randNoun)}** in **${time}.** [${difficultyEmotes[d]}]`);
//   }
  


// }, 3000)






// OLD MAPS

// const safes = [
//   new Safe(0, 0, 250, 1500),
//   new Safe(1750, 0, 250, 1500),
// ]

// const texts = [
//   new Text(115, -25, 'Enemy Showcase', false),
//   new Text(115, -75, 'Properties in [] are replacable and () are for clarification', false),
//   new Text(300, 125, 'Normal Enemy: ([x], [y], [w], [h], {[type (normal)], [amount], [radius], [speed]})', true),
//   new Text(300, 150, 'Example of Normal Enemy: new Spawner(250, 0, 750, 300, { type: normal, amount: 10, radius: 35, speed: 120 })', true),
//   new Text(1800, 125, 'Square Enemy: ([x], [y], [w], [h], {[type (square)], [amount], [size], [speed]})', true),
//   new Text(300, 475, 'Tp Enemy: ([x], [y], [w], [h], {[type (tp)], [amount], [radius], [speed], [time (to create clone in seconds)]})', true),
//   new Text(1815, 475, 'Switch Enemy: ([x], [y], [w], [h], {[type (switch)], [amount], [radius], [speed], [time (to switch in seconds)]})', true),
//   new Text(150, 775, 'Dasher Enemy: ([x], [y], [w], [h], {[type (dasher)], [amount], [radius], [speed]})', true),
//   new Text(1700, 775, 'Gravity Aura Enemy: ([x], [y], [w], [h], {[type (gaura)], [amount], [radius], [speed], [auraStrength (can be - or +)]})', true),
//   new Text(300, 1075, 'Turning Enemy: ([x], [y], [w], [h], {[type (turning)], [amount], [radius], [speed], [turnDir (turn speed)]})', true),
//   new Text(1700, 1075, 'Enemygrav Enemy: ([x], [y], [w], [h], {[type (enemygrav)], [amount], [radius], [speed], [auraStrength (pull strength)]})', true),
// ]

// const obstacles = [
//   new NormalObstacle(100,300,1800,50),
//   new NormalObstacle(100,600,1800,50),
//   new NormalObstacle(100,900,1800,50),
//   new NormalObstacle(100,1200,1800,50),
//   new StoryDisplay(250,0,100,100),
//   new StoryDisplay(1650,0,100,100),
//   new StoryDisplay(250,350,100,100),
//   new StoryDisplay(1650,350,100,100),
//   new StoryDisplay(250,650,100,100),
//   new StoryDisplay(1650,650,100,100),
//   new StoryDisplay(250,950,100,100),
//   new StoryDisplay(1650,950,100,100),
//   new StoryDisplay(250,1250,100,100),
//   new StoryDisplay(1650,1250,100,100),
// ]

// const spawns = [
//   new Spawner(250, 0, 750, 300, { type: 'normal', amount: 10, radius: 35, speed: 120 }),
//   new Spawner(1000, 0, 750, 300, { type: 'square', amount: 10, size: 35, speed: 120 }),
//   new Spawner(250, 350, 750, 250, { type: 'tp', amount: 6, time: 0.8, radius: 20, speed: 100 }),
//   new Spawner(1000, 350, 750, 250, { type: 'switch', amount: 4, radius: 30, speed: 100, time: 1 }),
//   new Spawner(250, 650, 750, 250, { type: 'dasher', amount: 10, radius: 20, speed: 125 }),
//   new Spawner(1000, 650, 750, 250, { type: 'gaura', amount: 3, radius: 80, speed: 100, auraStrength: -2, }),
//   new Spawner(1000, 650, 750, 250, { type: 'gaura', amount: 3, radius: 80, speed: 100, auraStrength: 2, }),
//   new Spawner(250, 950, 750, 250, { type: 'turning', amount: 10, radius: 20, speed: 125, changeDir: 5 }),
//   new Spawner(1000, 950, 750, 250, { type: 'enemygrav', amount: 1, radius: 25, speed: 100, auraStrength: 5, }),
//   new Spawner(1000, 950, 750, 250, { type: 'normal', amount: 10, radius: 35, speed: 120 }),
// ]

/*
const spawns = [
  // was originally normal enemies
  new Spawner(250, 0, 200, 350/2, { type: 'gaura', amount: 2, radius: 80, speed: 100, auraStrength: -3, }),
  new Spawner(250, 350/2, 200, 350, { type: 'gaura', amount: 2, radius: 80, speed: 100, auraStrength: 3, }),
  new Spawner(1150, 0, 100, 300, { type: 'normal', amount: 3, radius: 40, speed: 100 }),
  new Spawner(500, 0, 200, 350, { type: 'square', amount: 3, size: 60, speed: 100 }),
  new Spawner(750, 0, 200, 350, { type: 'switch', amount: 3, radius: 30, speed: 100, time: 1 }),
  new Spawner(1000, 0, 200, 350, { type: 'tp', amount: 3, radius: 30, speed: 100, time: 2 }),
  new Spawner(1800, 0, 700, 500, { type: 'square', amount: 5, size: 40, speed: 150 }),
  new Spawner(1800, 0, 700, 500, { type: 'tp', amount: 3, time: 0.75, radius: 35, speed: 300 }),
  new Spawner(1800 + 350, 750, 200, 200, { type: 'switch', amount: 1, radius: 99, speed: 0, time: 0.9 }),
  new Spawner(2600, 50, 150, 200, { type: 'dasher', amount: 10, radius: 20, speed: 125 }),
  new Spawner(1200, 300, 50, 50, { type: 'dasher', amount: 3, radius: 10, speed: 100 }),
  new Spawner(600, 550, 1400, 450, { type: 'square', amount: 6, size: 75, speed: 100 }),
  new Spawner(0, 550, 550, 450, { type: 'square', amount: 1, size: 200, speed: 175 }),
  new Spawner(2900, 0, 1100, 300, { type: 'normal', amount: 9, radius: 32, speed: 150 }),
  new Spawner(2900, 300, 1100, 300, { type: 'square', amount: 8, size: 70, speed: 175 }),
  new Spawner(2900, 600, 1100, 300, { type: 'switch', amount: 10, radius: 40, speed: 125 }),
  new Spawner(2900, 900, 1100, 300, { type: 'tp', amount: 16, time: 0.5, radius: 10, speed: 100 }),
  new Spawner(2900, 1200, 1100, 300, { type: 'dasher', amount: 6, radius: 15, speed: 225 }),
  new Spawner(300, 1700, 3600, 300, { type: 'gaura', amount: 5, radius: 40, speed: 250, auraStrength: -5, }),
];
*/
/*
const obstacles = [
  new MovingObstacle(150, 150, [[0,550],[400,550],[400,850],[0,850]],300,0),
  new MovingObstacle(150, 150, [[0,550],[0,850],[400,850],[400,550]],300,1),
  new NormalObstacle(262, 362, 75, 75, 30),
  new NormalObstacle(262, 362, 75, 75, 30), // Normal at beginning is back :D
  new BouncyObstacle(462, 362, 75, 75, 30),
  new CircularNormalObstacle(700, 400, 35),
  new CircularBouncyObstacle(900, 400, 35, 30),
  new Lava(1050, 362, 75, 75),
  new RotatingLava(1200, 375, 75, 15, 90),
  new GravObstacle(1300, 0, 200, 150, 'down', 5000),
  new GravObstacle(1300, 150, 200, 150, 'right', 5000),
  new GravObstacle(1500, 0, 200, 150, 'left', 5000),
  new GravObstacle(1500, 150, 200, 150, 'up', 5000),
  new NormalObstacle(0, 500, 1750, 50),
  new NormalObstacle(1750, 50, 50, 500),
  new NormalObstacle(2500, 0, 50, 1000),
  new NormalObstacle(250, 1000, 2300, 50),
  new NormalObstacle(1800, 500, 300, 50),
  // Conveyor + enemies Section
  // we have from (600,550) to (1800,1000)
  new GravObstacle(600, 550, 200, 150, 'right', 1250),
  new GravObstacle(800, 550, 200, 150, 'up', 1250),
  new GravObstacle(1000, 550, 200, 150, 'down', 1250),
  new GravObstacle(1200, 550, 200, 150, 'left', 1250),
  new GravObstacle(1400, 550, 200, 150, 'right', 1250),
  new GravObstacle(1600, 550, 200, 150, 'up', 1250),
  new GravObstacle(1800, 550, 200, 150, 'down', 1250),

  new GravObstacle(600, 700, 200, 150, 'down', 1250),
  new GravObstacle(800, 700, 200, 150, 'left', 1250),
  new GravObstacle(1000, 700, 200, 150, 'right', 1250),
  new GravObstacle(1200, 700, 200, 150, 'up', 1250),
  new GravObstacle(1400, 700, 200, 150, 'down', 1250),
  new GravObstacle(1600, 700, 200, 150, 'left', 1250),
  new GravObstacle(1800, 700, 200, 150, 'right', 1250),

  new GravObstacle(600, 850, 200, 150, 'left', 1250),
  new GravObstacle(800, 850, 200, 150, 'right', 1250),
  new GravObstacle(1000, 850, 200, 150, 'up', 1250),
  new GravObstacle(1200, 850, 200, 150, 'down', 1250),
  new GravObstacle(1400, 850, 200, 150, 'left', 1250),
  new GravObstacle(1600, 850, 200, 150, 'right', 1250),
  new GravObstacle(1800, 850, 200, 150, 'up', 1250),

  new NormalObstacle(550, 550, 50, 400),
  new NormalObstacle(2000, 600, 24, 400),

  new NormalObstacle(1800 + 400, 500, 300, 50),
  new Lava(1800 + 275, 550, 25, 150),
  new Lava(1800 + 300, 635, 250, 15),
  new RotatingLava(1800 + 550, 650, 150, 10, 90, 0),
  new RotatingLava(1800 + 550, 800, 150, 10, -90, 0),
  new RotatingLava(1800 + 550, 950, 150, 10, 90, 0),
  new Lava(1800 + 300 + 240, 635, 10, 250),
  new Lava(1800 + 350, 750, 10, 250),
  new SpeedObstacle(0, 450, 1750, 50),

  // Haha-inspired lava section
  new RotatingLava(300, 1500, 350, 10, 180, 0),
  new RotatingLava(500, 1500, 350, 10, -180, 0),
  new RotatingLava(700, 1500, 350, 10, 180, 0),
  new RotatingLava(900, 1500, 350, 10, -180, 0),
  new RotatingLava(300, 1200, 350, 10, 180, 0),
  new RotatingLava(500, 1200, 350, 10, -180, 0),
  new RotatingLava(700, 1200, 350, 10, 180, 0),
  new RotatingLava(900, 1200, 350, 10, -180, 0),

  new RotatingLava(1400, 1250, 500, 10, -90, 0),
  new RotatingLava(1400, 1250, 500, 10, -90, 15),
  new RotatingLava(1400, 1250, 500, 10, -90, 30),
  new RotatingLava(1400, 1250, 500, 10, -90, 45),
  new RotatingLava(1400, 1250, 500, 10, -90, 105),
  new RotatingLava(1400, 1250, 500, 10, -90, 120),
  new RotatingLava(1400, 1250, 500, 10, -90, 135),

  new RotatingLava(2000, 1250, 500, 10, 60, 90),
  new RotatingLava(2000, 1250, 500, 10, -60, 90),

  new Lava(2200, 1450, 150, 50),
  new Lava(2200, 1050, 150, 50),

  new BonusOrb(2225, 1225),

  // Tp to lava section
  new Tp(250, 0, 50, 50, 2000, 1500),

  // Conveyor Section
  new GravObstacle(2600, 0, 250, 1500, 'up', 5250),
  new Tp(2850, 350, 50, 1150, 2500, 1500),
  new NormalObstacle(2850, 50, 50, 300),
  new Tp(2550, 0, 50, 1400, 2500, 1500),
  // Obstacles on track
  new Tp(2750, 1200, 100, 50, 2500, 1500),
  new Tp(2600, 1050, 100, 50, 2500, 1500),
  new Tp(2750, 900, 100, 50, 2500, 1500),
  new Tp(2600, 750, 100, 50, 2500, 1500),
  new Tp(2750, 600, 100, 50, 2500, 1500),
  new Tp(2700, 450, 150, 50, 2500, 1500),
  new Tp(2600, 250, 150, 50, 2500, 1500),
  new Tp(2600, 0, 200, 50, 2500, 1500),
  new BonusOrb(2850, 0),

  // Bouncy Section
  new NormalObstacle(0, 1500, 3900, 200),
  new SpeedObstacle(300, 1700, 3600, 300),
  new GravObstacle(300, 1700, 3600, 300, 'left', 8000),
  new BouncyObstacle(300, 1700, 3600, 50, 100),
  new BouncyObstacle(300, 1950, 3600, 50, 100),

  new CircularBouncyObstacle(350, 1750, 45, 80),
  new CircularBouncyObstacle(350, 1950, 45, 80),

  new CircularBouncyObstacle(600, 1750, 45, 80),
  new CircularBouncyObstacle(600, 1850, 45, 80),

  new CircularBouncyObstacle(900, 1850, 45, 80),
  new CircularBouncyObstacle(900, 1950, 45, 80),

  new CircularBouncyObstacle(900, 1850, 15, 80),
  new CircularBouncyObstacle(900, 1950, 15, 80),
  new CircularBouncyObstacle(1100, 1800, 15, 80),
  new CircularBouncyObstacle(1100, 1900, 15, 80),

  new CircularBouncyObstacle(1300, 1750, 15, 80),
  new CircularBouncyObstacle(1300, 1850, 15, 80),
  new CircularBouncyObstacle(1300, 1950, 15, 80),
  new CircularBouncyObstacle(1500, 1800, 15, 80),
  new CircularBouncyObstacle(1500, 1900, 15, 80),

  new BouncyObstacle(1800, 1750, 50, 40, 80),
  new BouncyObstacle(1800, 1900, 50, 40, 80),

  new BouncyObstacle(2100, 1810, 50, 40, 80),
  new BouncyObstacle(2100, 1850, 50, 40, 80),
  new BouncyObstacle(2100, 1900, 50, 40, 80),

  new BouncyObstacle(2400, 1750, 50, 40, 80),
  new BouncyObstacle(2400, 1800, 50, 40, 80),
  new BouncyObstacle(2400, 1850, 50, 40, 80),

  new BouncyObstacle(2700, 1750, 50, 40, 80),
  new BouncyObstacle(2700, 1800, 50, 40, 80),
  new BouncyObstacle(2700, 1900, 50, 40, 80),

  new BouncyObstacle(3000, 1750, 50, 40, 80),
  new BouncyObstacle(3000, 1850, 50, 40, 80),
  new BouncyObstacle(3000, 1900, 50, 40, 80),

  new BouncyObstacle(3300, 1850, 100, 100, 40),
  new CircularBouncyObstacle(3600, 1800, 50, 40),
];
*/
/*
const texts = [
  new Text(100, -25, 'Sandbox'),
  new Text(2750, 1450, 'Hold Down Arrow Key'),
  new Text(150, 1850, 'Finish!'),
]
*/
/*
const safes = [
  new Safe(1250, 1050, 100, 450),
  new Safe(0, 0, 250, 450),
  new Safe(1700, 0, 50, 450),
  new Safe(1750, 0, 50, 50),
  new Safe(2100, 500, 100, 50),
  new Safe(2350, 1450, 250, 50),
  new Safe(3900, 1500, 100, 500),
  new Safe(0, 1700, 300, 300),
]
*/


// const spawns = [
// ];

// const obstacles = [
// 	new GravObstacle(0, 0, 300, 300, 'up', 7000),
// 	new NormalObstacle(200, 0, 100, 1000),
//   new RotatingLava(-50, 300, 300, 10, 180, 0),
//   new RotatingLava(-50, 500, 300, 10, -180, 0),
//   new RotatingLava(-50, 700, 300, 10, 180, 0),
//   new RotatingLava(-50, 900, 300, 10, -180, 0),
//   new RotatingLava(200, 700, 600, 10, -90, 0),
//   new RotatingLava(200, 700, 600, 10, -90, 30),
//   new RotatingLava(200, 700, 600, 10, -90, 60),
//   new RotatingLava(200, 700, 600, 10, -90, 90),
//   new RotatingLava(200, 700, 600, 10, -90, 15),
//   new RotatingLava(200, 700, 600, 10, -90, 45),
//   new RotatingLava(200, 700, 600, 10, -90, 75),
//   new Lava(0, 1100, 500, 100),
//   new Lava(400, 1000, 100, 100),
//   new Lava(500, 950, 100, 100),
//   new Lava(600, 850, 100, 100),
//   new Lava(700, 550, 100, 300),
//   new Lava(400, 550, 100, 300),
//   new Lava(500, 650, 100, 100),
//   new Lava(600, 450, 100, 100),
//   new Lava(400, 350, 200, 100),
//   new Lava(400, 100, 100, 250),
//   new Lava(550, 0, 50, 50),
//   new RotatingLava(550, 200, 600, 10, 90, 75),
//   new RotatingLava(550, 200, 600, 10, -90, 75),
//   new RotatingLava(650, 600, 600, 10, 90, 75),


// ];

// const texts = [
// 	new Text(100, -25, 'Sandbox'),
// ]

// const safes = [
//   new Safe(650, 50, 50, 50),
//   new Safe(950, 50, 50, 50),
//   new Safe(950, 350, 50, 50),

// ]




// DELETED ENEMY grav update simulate on server

  enemy.forEach((e) => {
  // enemygrav aura
  if (e.type === 'enemygrav'){
      enemy.forEach((f) => {
        // e = gravAura enemy[i], f = enemy[j]
        let dx = f.x - e.x;
        let dy = f.y - e.y;
        let force = 0;
        if(dx > 0 || dy > 0){
          force = 1/((Math.sqrt(dx**2 + dy**2))**2);
        }
        //f.x = e.x;
        //f.y = e.y;
        let angle = Math.atan2(dy, dx);
        f.xv -= Math.cos(angle) * Math.min(force * 1000000 * e.auraStrength,0.3 * e.auraStrength) * (1 / updateRate) * 60;
        f.yv -= Math.sin(angle) * Math.min(force * 1000000 * e.auraStrength,0.3 * e.auraStrength) * (1 / updateRate) * 60;
      });
    }
    e.simulate(1 / updateRate);
  });




//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====



// HAHA MAP (1000 x 7500 (?))
texts.push(new Text(100, -25, 'Welcome to.. HELL'));
obstacles.push(new NormalObstacle(0, 100, 600, 100));
obstacles.push(new NormalObstacle(0, 1010, 1000, 10));
obstacles.push(new NormalObstacle(0, 1130, 1000, 10));
obstacles.push(new NormalObstacle(0, 1250, 1000, 10));
obstacles.push(new NormalObstacle(0, 1370, 1000, 10));
obstacles.push(new NormalObstacle(0, 1490, 1000, 10));

obstacles.push(new NormalObstacle(100, 1000, 1000, 500));

obstacles.push(new Tp(0, 200, 900, 35, 950, 282));
obstacles.push(new Tp(50, 320, 950, 50, 950, 282));
obstacles.push(new Lava(50, 370, 950, 30, 950, 282));
obstacles.push(new Lava(0, 525, 950, 75, 950, 282));

obstacles.push(new GravObstacle(0, 235, 900, 100, "down", 1000));
obstacles.push(new GravObstacle(0, 400, 940, 125, "left", 2450));

//w, h, points = [[50,50]], speed = 30, currentPoint
obstacles.push(new MovingLavaObstacle(50, 50, [[900,475],[0,475]], 500, 0));
obstacles.push(new MovingLavaObstacle(50, 50, [[900,400],[0,400]], 500, 1));
safes.push(new Safe(400, 400, 150, 175));

/*obstacles.push(new MovingLavaObstacle(250,250, [[0,600],[750,600],[750,750],[0,750]], 200, 0));
obstacles.push(new MovingLavaObstacle(250,250, [[0,600],[750,600],[750,750],[0,750]], 200, 1));
obstacles.push(new MovingLavaObstacle(250,250, [[0,600],[750,600],[750,750],[0,750]], 200, 2));
obstacles.push(new MovingLavaObstacle(250,250, [[0,600],[750,600],[750,750],[0,750]], 200, 3));*/
obstacles.push(new MovingLavaObstacle(200, 100, [[0,600],[0,1400]], 400, 0));
obstacles.push(new MovingLavaObstacle(100, 100, [[200, 600],[200,900]], 400, 0));
obstacles.push(new MovingLavaObstacle(100, 100, [[300,600],[300,900]], 400, 1));
obstacles.push(new MovingLavaObstacle(100, 100, [[400, 600],[400,900]], 400, 0));
obstacles.push(new MovingLavaObstacle(100, 100, [[500,600],[500,900]], 400, 1));
obstacles.push(new MovingLavaObstacle(100, 100, [[600, 600],[600,900]], 400, 0));
obstacles.push(new MovingLavaObstacle(100, 100, [[700,600],[700,900]], 400, 1));
obstacles.push(new MovingLavaObstacle(100, 100, [[800, 600],[800,900]], 400, 0));
obstacles.push(new MovingLavaObstacle(100, 100, [[900,600],[900,900]], 400, 1));

obstacles.push(new Lava(700, 600, 100, 300));
obstacles.push(new Lava(400, 700, 100, 300));
obstacles.push(new Lava(0, 600, 200, 300));

safes.push(new Safe(0, 0, 150, 100));
safes.push(new Safe(775, 0, 75, 50));
safes.push(new Safe(0, 700, 100, 900));

obstacles.push(new NormalObstacle(550, 50, 50, 50));
obstacles.push(new NormalObstacle(600, 50, 25, 25));
obstacles.push(new NormalObstacle(675, 0, 50, 100));
obstacles.push(new NormalObstacle(775, 50, 75, 100));
obstacles.push(new NormalObstacle(600, 150, 300, 50));
obstacles.push(new RotatingLava(200, 0, 100, 10, -270, 0));
obstacles.push(new RotatingLava(200, 90, 100, 10, 270, 0));
obstacles.push(new RotatingLava(250, 0, 100, 10, -270, 90));
obstacles.push(new RotatingLava(250, 90, 100, 10, 270, 90));
obstacles.push(new RotatingLava(300, 0, 100, 10, -270, 0));
obstacles.push(new RotatingLava(300, 90, 100, 10, 270, 0));
obstacles.push(new RotatingLava(350, 0, 100, 10, -270, 0));
obstacles.push(new RotatingLava(350, 90, 100, 10, 270, 0));
obstacles.push(new RotatingLava(400, 0, 100, 10, -270, 90));
obstacles.push(new RotatingLava(400, 90, 100, 10, 270, 90));
obstacles.push(new RotatingLava(600, 0, 200, 10, 100, 90));
obstacles.push(new RotatingLava(600, 0, 200, 10, -100, 90));
obstacles.push(new RotatingLava(850, 70, 150, 10, 360, 0));

// Zone 2

texts.push(new Text(175, 1525, 'It only gets worse.'));







//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====
//=====

//ZEROTIX MAP (1750 x 7500)

texts.push(new Text(100, -25, 'Planet of AEDSHEYOBPMBSP!@#('));


// obstacles.push(new NormalObstacle(100, 1000, 1000, 500));


// First part/section
obstacles.push(new NormalObstacle(0, 250, 675, 50));

safes.push(new Safe(675, 250, 75, 50));

// obstacles.push(new NormalObstacle(550, 50, 50, 50));
// obstacles.push(new NormalObstacle(600, 50, 25, 25));
// obstacles.push(new NormalObstacle(675, 0, 50, 100));
// obstacles.push(new NormalObstacle(775, 50, 75, 100));
// obstacles.push(new NormalObstacle(600, 150, 350, 50));

obstacles.push(new RotatingLava(200, 60, 100, 10, -240, 0));
obstacles.push(new RotatingLava(200, 180, 100, 10, 240, 0));
obstacles.push(new RotatingLava(300, 60, 100, 10,  240, 0));
obstacles.push(new RotatingLava(300, 180, 100, 10, -240, 0));

obstacles.push(new NormalObstacle(450, 50, 50, 200));
safes.push(new Safe(450, 0, 50, 50));

obstacles.push(new RotatingLava(500, 125, 250, 10, 110, 0));
obstacles.push(new RotatingLava(500, 125, 250, 10, 110, 180));

obstacles.push(new RotatingLava(500, 125, 250, 10, 110, 270));
obstacles.push(new RotatingLava(500, 125, 250, 10, 110, 90));
// theyre rly easy tho, we can buff second part,
// really? idk but the 2nd trick kinda inconsistent; 1 sec
// ?? idk i just wanna nerf 1st and 2nd obstacle because it seems too hard in comparison
// obstacles.push(new RotatingLava(500, 125, 250, 10, 720, 270));
obstacles.push(new Lava(750, 0, 20, 600));
obstacles.push(new Lava(650, 300, 20, 225));
obstacles.push(new Lava(550, 300, 20, 300));
obstacles.push(new Lava(550, 600, 220, 20));
obstacles.push(new Lava(100, 500, 450, 20));
obstacles.push(new RotatingLava(650, 250, 15, 350, 100, 0));
obstacles.push(new Tp(570, 300, 80, 50, 525, 375))
// HOW DO I ADD TELEPORTER HELP only 6 params, 4 basic and tpx and tpy
safes.push(new Safe(500, 300, 50, 200));
// obstacles.push(new RotatingLava(0, 300, 10, 100, 100, 0));
// obstacles.push(new RotatingLava(0, 400, 10, 100, -100, 0));// its a new Tp(params)
// obstacles.push(new RotatingLava(100, 300, 10, 100, 100, 0));
// obstacles.push(new RotatingLava(100, 400, 10, 100, -100, 0));
obstacles.push(new RotatingLava(190, 300, 10, 100, 100, 0));
obstacles.push(new RotatingLava(190, 400, 10, 100, -100, 0));
obstacles.push(new RotatingLava(300, 300, 10, 100, 100, 0));
obstacles.push(new RotatingLava(300, 400, 10, 100, -100, 0));
obstacles.push(new RotatingLava(410, 300, 10, 100, 100, 0));
obstacles.push(new RotatingLava(410, 400, 10, 100, -100, 0));



// Safes

safes.push(new Safe(775, 0, 75, 50));

safes.push(new Safe(0, 300, 100, 220));
safes.push(new Safe(0, 520, 350, 75))

obstacles.push(new NormalObstacle(350, 520, 20, 850));
obstacles.push(new RotatingLava(600, 600, 15, 400, -175, 0));
obstacles.push(new RotatingLava(600, 800, 15, 400, 175, 180));
obstacles.push(new RotatingLava(600, 1000, 15, 400, -175, 0));

obstacles.push(new RotatingLava(500, 1300, 15, 200, -175, 90));
obstacles.push(new RotatingLava(700, 1300, 15, 200, 175, 90));

obstacles.push(new RotatingLava(100, 600, 10, 200, 180, 90));
obstacles.push(new RotatingLava(250, 600, 10, 200, 180, 0));
obstacles.push(new RotatingLava(100, 750, 10, 200, -180, 90));
obstacles.push(new RotatingLava(250, 750, 10, 200, -180, 0));

obstacles.push(new RotatingLava(100, 900, 10, 200, 180, 90));
obstacles.push(new RotatingLava(250, 900, 10, 200, 180, 0));
obstacles.push(new RotatingLava(100, 1050, 10, 200, -180, 90));
obstacles.push(new RotatingLava(250, 1050, 10, 200, -180, 0));

obstacles.push(new RotatingLava(100, 1200, 10, 200, 180, 90));
obstacles.push(new RotatingLava(250, 1200, 10, 200, 180, 0));

obstacles.push(new Lava(0, 675, 250, 50));
obstacles.push(new Lava(100, 825, 250, 50));
obstacles.push(new Lava(0, 975, 250, 50));
obstacles.push(new Lava(100, 1125, 250, 50));
obstacles.push(new Lava(0, 1275, 250, 50));

obstacles.push(new NormalObstacle(0, 1480, 870, 20));
obstacles.push(new Lava(850, 520, 20, 980));

safes.push(new Safe(750, 300, 100, 300));

obstacles.push(new RotatingLava(1300, -350, 40, 1000, 150, 0));

obstacles.push(new Lava(850, 100, 20, 600));

obstacles.push(new Lava(850, 850, 20, 300));

obstacles.push(new Lava(1550, 0, 20, 400));
obstacles.push(new Lava(1000, 100, 20, 300));
obstacles.push(new Lava(1550, 500, 20, 150));
obstacles.push(new Lava(1000, 500, 20, 150));
obstacles.push(new Lava(1000, 650, 570, 20));
obstacles.push(new BonusOrb(975, 400));
obstacles.push(new BonusOrb(1525, 400));
obstacles.push(new BonusOrb(975, 450));
obstacles.push(new BonusOrb(1525, 450));

safes.push(new Safe(850, 700, 900, 100));

// from haha's map
//1100 800
map.obstacles.push(new RotatingLava(1100, 800, 500, 20, -150, 90));
map.obstacles.push(new RotatingLava(1550, 800, 500, 20, 150, 90));
map.obstacles.push(new RotatingLava(1100, 1050, 500, 20, -150, 0));
map.obstacles.push(new RotatingLava(1550, 1050, 500, 20, 150, 0));

// obstacles.push(new GravObstacle(0, 235, 900, 100, "down", 1000));
// obstacles.push(new GravObstacle(0, 400, 940, 125, "left", 2450));

// //w, h, points = [[50,50]], speed = 30, currentPoint
// obstacles.push(new MovingLavaObstacle(50, 50, [[900, 475], [0, 475]], 500, 0));
// obstacles.push(new MovingLavaObstacle(50, 50, [[900, 400], [0, 400]], 500, 1));
// safes.push(new Safe(400, 400, 150, 175));

// /*obstacles.push(new MovingLavaObstacle(250,250, [[0,600],[750,600],[750,750],[0,750]], 200, 0));
// obstacles.push(new MovingLavaObstacle(250,250, [[0,600],[750,600],[750,750],[0,750]], 200, 1));
// obstacles.push(new MovingLavaObstacle(250,250, [[0,600],[750,600],[750,750],[0,750]], 200, 2));
// obstacles.push(new MovingLavaObstacle(250,250, [[0,600],[750,600],[750,750],[0,750]], 200, 3));*/
// obstacles.push(new MovingLavaObstacle(200, 100, [[0, 600], [0, 1400]], 400, 0));
// obstacles.push(new MovingLavaObstacle(100, 100, [[200, 600], [200, 900]], 400, 0));
// obstacles.push(new MovingLavaObstacle(100, 100, [[300, 600], [300, 900]], 400, 1));
// obstacles.push(new MovingLavaObstacle(100, 100, [[400, 600], [400, 900]], 400, 0));
// obstacles.push(new MovingLavaObstacle(100, 100, [[500, 600], [500, 900]], 400, 1));
// obstacles.push(new MovingLavaObstacle(100, 100, [[600, 600], [600, 900]], 400, 0));
// obstacles.push(new MovingLavaObstacle(100, 100, [[700, 600], [700, 900]], 400, 1));
// obstacles.push(new MovingLavaObstacle(100, 100, [[800, 600], [800, 900]], 400, 0));
// obstacles.push(new MovingLavaObstacle(100, 100, [[900, 600], [900, 900]], 400, 1));

// obstacles.push(new Lava(700, 600, 100, 300));
// obstacles.push(new Lava(400, 700, 100, 300));
// obstacles.push(new Lava(0, 600, 200, 300));




/*

// probably better if we find a way to see every file in maps/ and import it
const Maps = {
	Hub: require('./maps/hub.js'),
	Hub2: require('./maps/hub2.js')
};


module.exports = Maps;

*/