module.exports = class Text {
	constructor(x, y, text, story=false, size=30, angle=0) {
		this.size = size;
		this.x = x;
		this.y = y;
		this.text = text;
    	this.story = story;
		this.angle = angle;//angle*180/Math.PI;
	}
	pack() {
		return {
			x: this.x,
			y: this.y,
			angle: this.angle,
			text: this.text,
			size: this.size,
      		story: this.story,
		}
	}
}