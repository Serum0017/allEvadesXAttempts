const Maps = {
	Hub: require('./maps/hub.js'),
  PoPB: require('./maps/popb.js'), // planet of peaceful beginnings
  PoDD: require("./maps/podd.js"), // planet of deadly descent
  PoDC: require("./maps/podc.js"), // planet of difficulty chart
  PoLS: require("./maps/pols.js"), // planet of lost sanity
  SB: require('./maps/sandbox.js'),
  PoSC: require('./maps/posc.js'), // planet of simple challenges
  Winroom: require("./maps/winroom.js"), //Winroom
  PoSS: require('./maps/poss.js'), // Planet of Slight Sadness
  GoAT: require("./maps/goat.js"), // Galaxy of Arduous Trials,
  PoS: require('./maps/pos.js'), //Planet of Safezones,
  CoMET: require("./maps/comet.js"), // comet of mini extra tests hard
  CoMETHard: require("./maps/comet hard.js"),
  PoWHG: require('./maps/powhg.js'),
  PoSA: require("./maps/posa.js"), // planet of speed abuse :D
  Stellar: require('./maps/stellar.js'), // sub area/ sub hub
  MoBD: require('./maps/mobd.js'), // moon of bouncy delights
  cbip: require("./maps/cbip.js"),
  PoPP: require('./maps/popp.js'), // planet of perilous platforming
  PoTH: require('./maps/poth.js'), // planet of turret hell :D
  PoUC: require('./maps/pouc.js'), // planet of unmoving challenges
  PoVV: require('./maps/povv.js'), // planet of le vibing vault D:
  PoIE: require('./maps/poie.js'), // planet of inescapable enemies
  PoSR: require('./maps/posr.js'), // planet of speedy racing
  Minigames: require('./maps/minigames.js'),
  Minigames2: require('./maps/mg2.js'),
  Minigames3: require('./maps/mg3.js'),
  ZMT: require('./maps/test.js'),
  PoV: require('./maps/pov.js'), // planet of versatility
	PoIA: require('./maps/poia.js'),
  "PoDD:R": require("./maps/poddr.js"),
    //idea: planet of tests and trials omnipresent (basically hard posc)
    PoTT: require('./maps/pott.js'),// planet of traditional terrors, another basic map
	PoT: require('./maps/pot.js'), // planet of titans!
    PoBIS: require('./maps/pobis.js'), // planet of bear induced suffering (made by ʕっ•ᴥ•ʔっ); gonna be put in uni 2
    PoED: require('./maps/poed.js'),// planet of dexterity; gonna be moved to uni 2/3
    PoTHM: require('./maps/pothm.js'),// planet of the hazy maze. uni 2 unique planet
    PoSaRR: require('./maps/posarr.js'),
    PoM: require('./maps/pom.js'), // planet of misdirection; basically exploring other redirs
    PoGA: require('./maps/poga.js'), // planet of gun abuse made bcoz i was bored
    PoG: require('./maps/pog.js'), // planet of golfing idk
	PoE: require('./maps/poe.js'), // planet of everything (sandbox map aka 2nd hub),
    PoERM: require('./maps/poerm.js'), // planet of eternal rightwards motion; just a geom dash level lol
	PoMDC: require('./maps/pomdc.js'), // planet of mixed difficulty chart xd
	PoTS: require('./maps/pots.js'), // planet of true stealth
    Oldhub: require('./maps/oldhub.js'), // :D
    Po3D: require('./maps/po3d.js'), // 3d map stuff
	PoC: require('./maps/poc.js'), // planet of claustrophobia
	PoSE: require("./maps/pose.js"), // planet of system error
    PoI: require("./maps/poi.js"), // planet of inspiration
    PoSPD: require("./maps/pospd.js"), // planet of speed
    PoCA: require("./maps/poca.js"), // planet of conveyor abuse
    PoSH: require("./maps/posh.js"), // planet of slight hurdles
    Oldposc: require("./maps/oldposc.js"),
    Oldpoqt: require("./maps/oldpoqt.js"),
    Somewhatoldposc: require("./maps/somewhatoldposc.js"),
    PoQT: require("./maps/poqt.js"), // planet of quick thinking (serum's masterpiece)
    PoQTF: require("./maps/poqtf.js"), // planet of quick thinking finale. Would be too laggy to put in the same map.
	PoPO: require('./maps/popo.js'),  // planet of peaceful origins
    // these planets will be part of Serum's universe 2 minigame gauntlet
    PoTOS: require('./maps/potos.js'),  // planet of trials of survival
    PoTD: require('./maps/potd.js'),  // planet of trials of survival
    PoLC: require('./maps/polc.js'),  // planet of looking cool
    //PoST: require('./maps/post.js'),
    LMAO: require('./maps/lmao.js'), // hub with all obs uncommented
    // goodbye old eX
};

module.exports = Maps;
