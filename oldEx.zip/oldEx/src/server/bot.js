const Discord = require('discord.js');
const Intents = Discord.Intents;
const Account = require('./models/account.js');
const client = new Discord.Client({ intents: [
	Intents.FLAGS.GUILDS, Intents.FLAGS.DIRECT_MESSAGES,
	Intents.FLAGS.GUILD_MESSAGES,
]});

client.on('ready', () => {
    console.log(`Logged in as ${client.user.tag}`);
});

client.on('messageCreate', async (message) => {
    const splitMessage = message.content.split(' ');
	// command tag - ex (todo: allow for /slash commands)
    if (splitMessage[0].toLowerCase() === 'ex') {
        const command = splitMessage[1];
        if (!command) return;
        if (command.toLowerCase() === 'hello') {
            await message.reply('Hello! I am the official Evades X discord bot.');
        }
		if (command.toLowerCase() === 'ping') {
			await message.reply('pong');
		}
        if (command.toLowerCase() === 'accounts') {
            const data = await Account.find(); 
			// future optimization -> is to have a cache version of 
			// the actual account model to limit the need
			// of having to request all the accounts
			// particularly for commands that constantly interact
			// with a user such as getting info about specific user
            if (data) {
                await message.reply(
                    `There are ${
                        data.length
                    } accounts in the Evades X Database!\n\`\`\`${data
                        .map((a) => a.username)
                        .toString()
                        .replaceAll(',', ', ')}\`\`\``
                );
            }
        }
        if (command.toLowerCase() === 'players') {
            const playerCount = Object.keys(global.players).length;
            await message.reply(
                `There are ${playerCount} total players playing Evades X right now!${
                    playerCount > 0
                        ? `\n\`\`\`${Object.values(global.players)
                              .map((player) => player.name)
                              .toString()
                              .replaceAll(',', ', ')}\`\`\``
                        : ''
                }`
            );
        }
    }
});

client.on('interactionCreate', async (interaction) => {
    console.log(interaction);
});	

client.login(process.env.discord_bot_token);

module.exports = client;
