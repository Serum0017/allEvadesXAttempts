const SAT = require('sat');

class Normal {
	constructor(spawn) {
		this.type = spawn.data.type;
		this.radius = spawn.data.radius;
		this.speed = spawn.data.speed;
		this.isLava = spawn.data.isLava || false;
		this.x = Math.round(Math.random() * (spawn.w - this.radius) + spawn.x + this.radius);
		this.y = Math.round(Math.random() * (spawn.h - this.radius) + spawn.y + this.radius);
		this.angle = Math.random() * Math.PI * 2;
		this.xv = Math.cos(this.angle) * this.speed;
		this.yv = Math.sin(this.angle) * this.speed;
		this.bound = { x: spawn.x, y: spawn.y, w: spawn.w, h: spawn.h }
        this.life = spawn.data.life;
	}
	simulate(dt) {
		this.x += this.xv * dt;

		if (this.x + this.radius >= this.bound.x + this.bound.w) {
			this.xv = -this.xv;
			this.x = (this.bound.x + this.bound.w) * 2 - this.x - this.radius * 2;
		}
		else if (this.x - this.radius <= this.bound.x) {
			this.xv = -this.xv;
			this.x = this.bound.x * 2 - this.x + this.radius * 2;
		}
		this.y += this.yv * dt;
		if (this.y + this.radius >= this.bound.y + this.bound.h) {
			this.yv = -this.yv;
			this.y = (this.bound.y + this.bound.h) * 2 - this.y - this.radius * 2;
		}
		else if (this.y - this.radius <= this.bound.y) {
			this.yv = -this.yv;
			this.y = this.bound.y * 2 - this.y + this.radius * 2;
		}
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
			isLava: this.isLava,
		}
	}
}

class Toxic extends Normal {
    constructor(spawn) {
        super(spawn);
	}
}

class FollowAxis extends Normal {
    constructor(spawn) {
        super(spawn);
        // only follows within bound
        this.axis = spawn.data.axis;
        if(spawn.data.x){
            this.x = spawn.data.x;
        }
        if(spawn.data.y){
            this.y = spawn.data.y;
        }
	}
    simulate(dt, players) {
        const closest = {
            dist: 1000000,
            id: -1
        }
        let id = 0;
        for (const playerId of Object.keys(players)) {
            const p = players[playerId];
            if(this.intersectingCircleRect(p,this.bound,true)){
                const distX = p.x-this.x;
                const distY = p.y-this.y;
                const dist = distX**2+distY**2;
                if(dist < closest.dist){
                    closest.dist = dist;
                    closest.id = playerId;
                }
            }
        }
        if(closest.id !== -1){
            if(this.axis){
                // follow x axis
                this.x = players[closest.id].x;
            } else {
                // follow y axis
                this.y = players[closest.id].y;
            }    
        }
    }
    intersectingCircleRect(circle, rect, genCircleSat=false) {
    	const distX = Math.abs(circle.x - rect.x - rect.w / 2);
    	const distY = Math.abs(circle.y - rect.y - rect.h / 2);
    	if (distX < rect.w / 2 + circle.radius && distY < rect.h / 2 + circle.radius) {
    		let circleSat;
    		if (genCircleSat) {
    			circleSat = new SAT.Circle(new SAT.Vector(circle.x, circle.y), circle.radius);
    		} else {
    			circleSat = circle.sat;
    		}
    		const res = new SAT.Response();
    		const boxSat = new SAT.Box(new SAT.Vector(rect.x, rect.y), rect.w, rect.h).toPolygon();
    		const collision = SAT.testPolygonCircle(boxSat, circleSat, res);
    		if (collision) {
    			return true;
    		}
    	}
    	return false;
    }
    pack() {
		return {
			...super.pack(),
            axis: this.axis,
		}
	}
}

class NoKill extends Normal {
	constructor(spawn) {
        super(spawn);
	}
}

// enemy that speeds up the further it is away from the center of its bounding box or a specified point
class PointAccel extends Normal {
	constructor(spawn) {
        super(spawn);
        this.baseSpeed = spawn.data.speed;
        this.accelFactor = spawn.data.accelFactor;
        this.accelPower = spawn.data.accelPower||1;
        this.centerPoint = spawn.data.centerPoint||{x: this.bound.x+this.bound.w/2, y: this.bound.y+this.bound.h/2};
	}
	simulate(dt) {
        let dist2center = Math.sqrt((this.centerPoint.x-this.x)**2+(this.centerPoint.y-this.y)**2);
        this.speed = this.baseSpeed * Math.pow(dist2center/200, this.accelPower);
		this.xv = Math.cos(Math.atan2(this.yv,this.xv)) * this.speed;
		this.yv = Math.sin(Math.atan2(this.yv,this.xv)) * this.speed;
		super.simulate(dt);
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,// almost done btw
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
            accelFactor: this.accelFactor,
            accelPower: this.accelPower,
            centerPoint: this.centerPoint,
            baseSpeed: this.baseSpeed,
		}
	}
}

class Oscillating extends Normal {
	constructor(spawn) {
        super(spawn);
        this.pointSpeed = spawn.data.pointSpeed;
        if(this.pointSpeed === undefined){
            this.pointSpeed = 0;
        }
        this.currentPoint = spawn.data.currentPoint;
        if(this.currentPoint === undefined){
            this.currentPoint = 0;
        }
        if(spawn.data.points !== undefined){
            this.points = spawn.data.points;
        } else {
            this.points = [];
            let pointsNumber = spawn.data.pointsNumber;
            if(pointsNumber < 2 || pointsNumber === undefined){
                pointsNumber = 2;
            }
            for(let i = 0; i < pointsNumber; i++){
                const angle = Math.random()*Math.PI*2;
                this.points.push({x:this.bound.x+Math.random()*this.bound.w,y:this.bound.y+Math.random()*this.bound.h,xv:Math.cos(angle)*this.pointSpeed,yv:Math.sin(angle)*this.pointSpeed,speed:this.pointSpeed});
            }
        }
	}
	simulate(dt) {
        for(let i = 0; i < this.points.length; i++){
            const p = this.points[i];
            p.x += p.xv * dt;
            if (p.x >= this.bound.x + this.bound.w) {
                p.xv = -p.xv;
                p.x =
                    (this.bound.x + this.bound.w) * 2 - p.x;
            } else if (p.x <= this.bound.x) {
                p.xv = -p.xv;
                p.x = this.bound.x * 2 - p.x;
            }
            p.y += p.yv * dt;
            if (p.y >= this.bound.y + this.bound.h) {
                p.yv = -p.yv;
                p.y =
                    (this.bound.y + this.bound.h) * 2 - p.y;
            } else if (p.y <= this.bound.y) {
                p.yv = -p.yv;
                p.y = this.bound.y * 2 - p.y;
            }
        }
        this.simulateOscillatingEnemy(dt);
	}
    simulateOscillatingEnemy(dt) {
        let nextPointIndex = this.currentPoint + 1;
        if (nextPointIndex >= this.points.length) {
            nextPointIndex = 0;
        }
        this.pointTo = this.points[nextPointIndex];
        this.pointOn = this.points[this.currentPoint];
        this.angle = Math.atan2(
            this.pointTo.y - this.y,
            this.pointTo.x - this.x
        );
        this.xv = Math.cos(this.angle) * this.speed;
        this.yv = Math.sin(this.angle) * this.speed;
        this.x += this.xv * dt;
        this.y += this.yv * dt;
        let timeRemain = 0;
        let over = false;
        if (Math.abs(this.yv) > Math.abs(this.xv)) {
            if (this.pointTo.y > this.pointOn.y) {
                if (this.y > this.pointTo.y) {
                    over = true;
                }
            } else {
                if (this.y < this.pointTo.y) {
                    over = true;
                }
            }
        } else {
            if (this.pointTo.x > this.pointOn.x) {
                if (this.x > this.pointTo.x) {
                    over = true;
                }
            } else {
                if (this.x < this.pointTo.x) {
                    over = true;
                }
            }
        }
        if (over == true) {
            this.currentPoint++;
            if (this.currentPoint > this.points.length - 1) {
                this.currentPoint = 0;
            }
            timeRemain = Math.sqrt(
                Math.pow(this.y - this.pointTo.y, 2) +
                    Math.pow(this.x - this.pointTo.x, 2)
            );
            this.x = this.pointTo.x;
            this.y = this.pointTo.y;
            timeRemain /= this.speed;
    
            this.simulateOscillatingEnemy(timeRemain);
        }
    }
	pack() {
		return {
			type: this.type,
			radius: this.radius,// almost done btw
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
            points: this.points,
            currentPoint: this.currentPoint
            //pointSpeed: this.pointSpeed
		}
	}
}



// opposes bullets by reflecting them
class ReflectBullet extends Normal {
	constructor(spawn) {
        super(spawn);
        this.health = spawn.data.hp-1;
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
            health: this.health,
		}
	}
}

class EnemyObstacle extends Normal {
	constructor(spawn) {
        super(spawn);
        this.toKill = spawn.data.toKill||false;
        // deep copy
        this.obstacle = JSON.parse(JSON.stringify(spawn.data.obstacle));
        //this.obstacle.pack = spawn.data.obstacle.pack;
        //this.obstacle.simulate = spawn.data.obstacle.simulate;
        let otherFunctions = this.getAllMethodNames(spawn.data.obstacle);
        // dynamically getting all functions (including helper functions)
        for(let otherfunc of otherFunctions){
            if(!["constructor","__defineGetter__","__defineSetter__","hasOwnProperty","__lookupGetter__","__lookupSetter__","isPrototypeOf","propertyIsEnumerable","toString","valueOf","__proto__","toLocaleString"].includes(otherfunc)){
                this.obstacle[otherfunc] = spawn.data.obstacle[otherfunc];
            }
        }
        this.parentOffset = {x: 0, y: 0};
        this.boundRadius = this.radius;
        this.type = 'enemyobstacle';
        if(spawn.data.boundRadius){
            this.boundRadius = spawn.data.boundRadius;
        } else {
            if(this.obstacle.w && this.obstacle.h){
                this.boundRadius = Math.max(this.obstacle.w/2,this.obstacle.h/2);
            } else if(this.obstacle.r || this.obstacle.radius){
                this.boundRadius = this.obstacle.radius || this.obstacle.r;
            } else if(this.obstacle.points && this.obstacle.type.startsWith('poly')){
                let minX = 0;
                let minY = 0;
                let maxX = 0;
                let maxY = 0;
                for(let p of this.obstacle.points){
                   if(p.x < minX){
                       minX = p.x;
                   }
                   if(p.y < minY){
                       minY = p.y;
                   }
                   if(p.x > maxX){
                       maxX = p.x;
                   }
                   if(p.y > minY){
                       maxY = p.y;
                   }
                } 
                let xBound = maxX-minX;
                let yBound = maxY-minY;
                this.boundRadius = Math.max(xBound,yBound)/2;
            }   
        }
        this.boundRadius = Math.min(this.boundRadius,Math.max(0,Math.min(this.bound.w,this.bound.h)/2-1));
        if (spawn.data.offset){
            this.parentOffset = spawn.data.offset;
        } else {
            if(this.obstacle.type.includes('rotat')){// rotate and rotating ;-;
                this.parentOffset = {x: this.obstacle.pivotX-this.obstacle.x, y: this.obstacle.pivotY-this.obstacle.y};
            } else if(this.obstacle.w && this.obstacle.h){
                this.parentOffset = {x: this.obstacle.w/2, y: this.obstacle.h/2};
            } else if(this.obstacle.points && this.obstacle.type.startsWith('poly')){
                let minX = 0;
                let minY = 0;
                let maxX = 0;
                let maxY = 0;
                for(let p of this.obstacle.points){
                   if(p.x < minX){
                       minX = p.x;
                   }
                   if(p.y < minY){
                       minY = p.y;
                   }
                   if(p.x > maxX){
                       maxX = p.x;
                   }
                   if(p.y > minY){
                       maxY = p.y;
                   }
                }
                this.parentOffset = {x: (maxX-minX)/2, y: (maxY-minY)/2}
            }
        }
	}
    getAllMethodNames(obj) {
        let methods = [];
        while (obj = Reflect.getPrototypeOf(obj)) {
            let keys = Reflect.ownKeys(obj)
            keys.forEach((k) => methods.push(k));
        }
        return methods;
    }
	simulate(dt, obstacles) {
        const actualRadius = this.radius;
        this.radius = this.boundRadius;
		super.simulate(dt);
        this.radius = actualRadius;
        for(let o of obstacles){
            if(o.enemyChildId === this.obstacleParentId){
                // this can desync in some cases; will prolly fix later
                if(o.type.startsWith('poly')){
                    if(!this.originalPoints){
                        this.originalPoints = o.points;
                    }
                    /*for(let p = 0; p < o.points.length; p++){
                        o.points[p][0] = this.originalPoints[p][0] + this.x - this.parentOffset.x;
                        o.points[p][1] = this.originalPoints[p][1] + this.y - this.parentOffset.y;
                    }*/
                } else {
                    o.x = this.x - this.parentOffset.x;
                    o.y = this.y - this.parentOffset.y;   
                }
                break;
            }
        }
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
            boundRadius: this.boundRadius,
            parentOffset: this.parentOffset,
            obstacleParentId: this.obstacleParentId,
            originalPoints: this.originalPoints, // poly pts
            toKill: this.toKill,
		}
	}
}

// inherits the behavior of all of the enemytypes.
// different from parent because u cant have 2 behaviors at the same time
class ComboEnemy extends Normal {
	constructor(spawn) {
        super(spawn);
        this.type = 'combo';
        // this.normalEnemy = new Normal(spawn);
        // console.log(this.normalEnemy);
        // console.log(this.normalEnemy.simulate.toString())
        //this.normalEnemy.simulate = () => {console.log(this)};
        for(let key in spawn.data){
            this[key] = JSON.parse(JSON.stringify(spawn.data[key]));
        }
        this.enemyTypes = spawn.data.enemyTypes||['normal'];

        this.counter = 0;
        this.packFunctionNames = [];
        this.simulateFunctionNames = [];
        
        for(let i = 0; i < this.enemyTypes.length; i++){
            // new Normal(spawn)
            const copyEnemy = eval(enemyTypes(this.enemyTypes[i]).replaceAll('this', JSON.stringify(spawn)));
            for(let key in copyEnemy){
                this[key] = copyEnemy[key];
            }
            
            // dynamically getting all functions
            let otherFunctions = this.getAllMethodNames(copyEnemy);
            for(let otherfunc of otherFunctions){
                if(!["constructor","__defineGetter__","__defineSetter__","hasOwnProperty","__lookupGetter__","__lookupSetter__","isPrototypeOf","propertyIsEnumerable","toString","valueOf","__proto__","toLocaleString","pack","simulate"].includes(otherfunc)){
                    this[otherfunc] = copyEnemy[otherfunc];
                } else if(otherfunc === 'pack'){// deep copies
                    const fnName = 'pack' + this.counter.toString();
                    eval(`this["${fnName}"] = function ` + copyEnemy[otherfunc].toString().replaceAll('super.simulate', 'this.simulateNormal').replace('simulate', `${fnName}`));
                    this.packFunctionNames.push(fnName);
                    this.counter++;
                } else if(otherfunc === 'simulate'){
                    const fnName = 'sim' + this.counter.toString();
                    eval(`this["${fnName}"] = function ` + copyEnemy[otherfunc].toString().replaceAll('super.simulate', 'this.simulateNormal').replace('simulate', `${fnName}`));
                    this.simulateFunctionNames.push(fnName);
                    this.counter++;
                }
            }
        }
	}
	simulate(dt, enemy, obstacles) {
		for(let fn of this.simulateFunctionNames){
            this[fn](dt, enemy, obstacles);
        }
	}
    simulateNormal(dt) {
		this.x += this.xv * dt;

		if (this.x + this.radius >= this.bound.x + this.bound.w) {
			this.xv = -this.xv;
			this.x = (this.bound.x + this.bound.w) * 2 - this.x - this.radius * 2;
		}
		else if (this.x - this.radius <= this.bound.x) {
			this.xv = -this.xv;
			this.x = this.bound.x * 2 - this.x + this.radius * 2;
		}
		this.y += this.yv * dt;
		if (this.y + this.radius >= this.bound.y + this.bound.h) {
			this.yv = -this.yv;
			this.y = (this.bound.y + this.bound.h) * 2 - this.y - this.radius * 2;
		}
		else if (this.y - this.radius <= this.bound.y) {
			this.yv = -this.yv;
			this.y = this.bound.y * 2 - this.y + this.radius * 2;
		}
	}
    getAllMethodNames(obj) {
        let methods = [];
        while (obj = Reflect.getPrototypeOf(obj)) {
            let keys = Reflect.ownKeys(obj)
            keys.forEach((k) => {if(!methods.includes(k)){methods.push(k)}});
        }
        return methods;
    }
	pack() {
        // unify all the packs
        let pack = {};
        for(let fn of this.packFunctionNames){
            let thisPack = this[fn]();
            for(let key in thisPack){
                pack[key] = thisPack[key];
            }
        }
        pack.enemyTypes = this.enemyTypes;
        return pack;
	}
}

// duels only, or else it's unfair that the more time u take the harder it is
class Accelerating extends Normal {
	constructor(spawn) {
        super(spawn);
		this.accelAmount = spawn.data.accelAmount;
	}
	simulate(dt) {
        if(this.xv > 0){
            this.xv += this.accelAmount*dt;
        } else {
            this.xv -= this.accelAmount*dt;
        }
        if(this.yv > 0){
            this.yv += this.accelAmount*dt;
        } else {
            this.yv -= this.accelAmount*dt;
        }
		super.simulate(dt);
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
            accelAmount: this.accelAmount,
		}
	}
}

class Turret {
  constructor(spawn) {
		this.type = spawn.data.type;
		this.radius = spawn.data.radius;
		this.speed = spawn.data.speed;
	  // needs { x, y, shootSpeed,  offset, pRadius, pSpeed, startOffset, shootDirections? }
		this.x = spawn.data.x;
      //console.log(spawn.data.x,spawn.data.y);
    if(this.x === undefined){
      this.x = Math.round(Math.random() * (spawn.w - this.radius) + spawn.x + this.radius);
    }
		this.y = spawn.data.y;
    if(this.y === undefined){
      this.y = Math.round(Math.random() * (spawn.h - this.radius) + spawn.y + this.radius);
    }
		this.angle = Math.random() * Math.PI * 2;
		this.xv = Math.cos(this.angle) * this.speed;
		this.yv = Math.sin(this.angle) * this.speed;
		this.bound = { x: spawn.x, y: spawn.y, w: spawn.w, h: spawn.h }
    this.shootSpeed = spawn.data.shootSpeed;
    this.timer = 0;//this.shootSpeed;
    this.offset = spawn.data.offset;
    if(this.offset !== undefined){
      this.timer += this.offset;
    }
    this.pRadius = spawn.data.pRadius;
    this.pSpeed = spawn.data.pSpeed;
    this.projectiles = [];
    this.shootDirections = spawn.data.shootDirections.map(sd => sd*Math.PI/180);
    this.csd = spawn.data.startOffset;//csd = current shoot distance
    if (this.csd === undefined) {
      this.csd = 0;
    }
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
      shootSpeed: this.shootSpeed,
      timer: this.timer,
      pRadius: this.pRadius,
      pSpeed: this.pSpeed,
      projectiles: this.projectiles,
      shootDirections: this.shootDirections,
      csd: this.csd,
		}
	}
	simulate(dt) {
    // normal simulation
		this.x += this.xv * dt;

		if (this.x + this.radius >= this.bound.x + this.bound.w) {
			this.xv = -this.xv;
			this.x = (this.bound.x + this.bound.w) * 2 - this.x - this.radius * 2;
		}
		else if (this.x - this.radius <= this.bound.x) {
			this.xv = -this.xv;
			this.x = this.bound.x * 2 - this.x + this.radius * 2;
		}
		this.y += this.yv * dt;
		if (this.y + this.radius >= this.bound.y + this.bound.h) {
			this.yv = -this.yv;
			this.y = (this.bound.y + this.bound.h) * 2 - this.y - this.radius * 2;
		}
		else if (this.y - this.radius <= this.bound.y) {
			this.yv = -this.yv;
			this.y = this.bound.y * 2 - this.y + this.radius * 2;
		}

    // spawning a new bullet if neccesary
    this.timer -= dt;
    if(this.timer <= 0){
      this.timer += this.shootSpeed;
      // creating a new projectile
      if(this.shootDirections[this.csd] !== 'none') {
        this.projectiles.push({x: this.x, y: this.y, angle: this.shootDirections[this.csd]});
      }
      this.csd++;
      if(this.csd >= this.shootDirections.length){
        this.csd = 0;
      }
    }
    // simulating projectiles
    for(let p in this.projectiles){
      this.projectiles[p].x += Math.cos(this.projectiles[p].angle) * this.pSpeed * dt;
      this.projectiles[p].y += Math.sin(this.projectiles[p].angle) * this.pSpeed * dt;

      // checking collisions to kill bullets outside of bounds
      let dead = false;
      if (this.projectiles[p].x + this.pRadius >= this.bound.x + this.bound.w) {
        dead = true;
      }
      else if (this.projectiles[p].x - this.pRadius <= this.bound.x) {
        dead = true;
      }
      if (this.projectiles[p].y + this.pRadius >= this.bound.y + this.bound.h) {
        dead = true;
      }
      else if (this.projectiles[p].y - this.pRadius <= this.bound.y) {
        dead = true;
      }
      if(dead){
        // take out the projectile on the array
        this.projectiles.splice(p,1);
      }
    }
	}
}

class Flower extends Normal {
	constructor(spawn) {
		super(spawn);
        this.layers = spawn.data.layers;
        this.rotateSpeed = spawn.data.rotateSpeed;
        this.clonesRadius = spawn.data.clonesRadius;
        this.clonesDistance = spawn.data.clonesDistance;
        this.growingMultiple = spawn.data.growingMultiple;
        this.growingSpeed = spawn.data.growingSpeed;
        // this.clonesX = [];
        // this.clonesY = [];
        // this.clonesAngle = [];
        this.clones = [
            /*{
            angle: 1.2,
            x: 100,
            y: 100,
            layer: 0
            }*/
        ];
        // this.clonesLayer = [];
        // this.clonesGrowing = [];
        this.clonesEffect = spawn.data.clonesEffect;
        this.effectMagnitude = spawn.data.effectMagnitude;
        let initialClonesAngle = Math.random()*2*Math.PI;
        for(let j = 0; j < this.layers; j++){
            for(let i = 0; i < spawn.data.clonesNumber; i++){
                this.clones.push({
                    angle: (initialClonesAngle + 2*Math.PI/spawn.data.clonesNumber*i) % 360,
                    x: this.x,
                    y: this.y,
                    layer: j
                })
                if(this.growingMultiple != undefined){
                    if(spawn.data.syncGrowing === true){
                        if(Math.random() > 0.5){
                            this.clones[this.clones.length-1].growing = {state: true, radius: this.clonesRadius}
                        } else {
                            this.clones[this.clones.length-1].growing = {state: false, radius: this.clonesRadius}
                        }
                    } else {
                        if(Math.random() > 0.5){
                            this.clones[this.clones.length-1].growing = {state: true, radius: this.clonesRadius + (Math.random()*this.growingMultiple*this.clonesRadius-1)}
                        } else {
                            this.clones[this.clones.length-1].growing = {state: false, radius: this.clonesRadius + (Math.random()*this.growingMultiple*this.clonesRadius-1)}
                        }
                    }
                }
            }
            initialClonesAngle = Math.random()*2*Math.PI;
        }
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
            rotateSpeed: this.rotateSpeed,
            clonesRadius: this.clonesRadius,
            // clonesAngle: this.clonesAngle,
            // clonesX: this.clonesX,
            // clonesY: this.clonesY,
            clonesDistance: this.clonesDistance,
            layers: this.layers,
            // clonesLayer: this.clonesLayer,
            clonesEffect: this.clonesEffect,
            effectMagnitude: this.effectMagnitude,
            growingMultiple: this.growingMultiple,
            growingSpeed: this.growingSpeed,
            // clonesGrowing: this.clonesGrowing,
            clones: this.clones
		}
	}
	simulate(dt) {
		super.simulate(dt);
        for(let clone of this.clones){
            clone.angle += this.rotateSpeed * dt;
            clone.x = this.x + Math.cos(clone.angle) * this.clonesDistance * (clone.layer+1);
            clone.y = this.y + Math.sin(clone.angle) * this.clonesDistance * (clone.layer+1);
            if(this.growingMultiple != undefined){
                if (clone.growing.state) {
                    clone.growing.radius += this.growingSpeed * dt;
                    if (clone.growing.radius > this.growingMultiple*this.clonesRadius) {
                        clone.growing.state = false;
                        let overGrowth = clone.growing.radius - this.growingMultiple*this.clonesRadius;
                        clone.growing.radius -= overGrowth * 2;
                    }
                } else {
                    clone.growing.radius -= this.growingSpeed * dt;
                    if (clone.growing.radius < this.clonesRadius) {
                        clone.growing.state = true;
                        let underGrowth = this.clonesRadius - clone.growing.radius;
                        clone.growing.radius += underGrowth * 2;
                    }
                }
            }
        }
	}
}

// those blue central core enemies
class E2Dasher extends Normal {
  constructor(spawn) {
        spawn.data.speed = spawn.data.firstSpeed;
        super(spawn);
        let go = spawn.data.dashOffset||0;
        let ro = spawn.data.randomDashOffset||0;
        this.dashTimer = go + Math.random()*ro;
        this.dashDistance = 0;
        this.friction = spawn.data.friction||1;
        this.firstCooldown = spawn.data.firstCooldown;
        this.firstSpeed = spawn.data.firstSpeed;
        this.secondCooldown = spawn.data.secondCooldown;
        this.secondSpeed = spawn.data.secondSpeed;
        this.coolType = false;
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
            dashDistance: this.dashDistance,
            friction: this.friction,
            firstCooldown: this.firstCooldown,
            firstSpeed: this.firstSpeed,
            secondCooldown: this.secondCooldown,
            secondSpeed: this.secondSpeed,
            coolType: this.coolType,
            dashTimer: this.dashTimer,
		}
	}
	simulate(dt) {
        this.x += this.xv * dt * this.dashDistance;
        this.y += this.yv * dt * this.dashDistance;
        if (this.x + this.radius >= this.bound.x + this.bound.w) {
			this.xv = -this.xv;
			this.x = (this.bound.x + this.bound.w) * 2 - this.x - this.radius * 2;
		}
		else if (this.x - this.radius <= this.bound.x) {
			this.xv = -this.xv;
			this.x = this.bound.x * 2 - this.x + this.radius * 2;
		}
		if (this.y + this.radius >= this.bound.y + this.bound.h) {
			this.yv = -this.yv;
			this.y = (this.bound.y + this.bound.h) * 2 - this.y - this.radius * 2;
		}
		else if (this.y - this.radius <= this.bound.y) {
			this.yv = -this.yv;
			this.y = this.bound.y * 2 - this.y + this.radius * 2;
		}

        // simulating dash
        if (this.dashTimer <= 3/4*this.secondCooldown) {
            this.dashDistance *= this.friction;
        }
        this.dashTimer -= dt;
        if (this.dashTimer <= 0) {
            if (this.coolType) {
                this.dashDistance = this.firstSpeed;
                this.dashTimer = this.firstCooldown;
            }
            else {
                this.dashDistance = this.secondSpeed;
                this.dashTimer = this.secondCooldown;
            }
            this.coolType = !this.coolType;
        }
	}
}

// changes OTHER enemies' radii
class RadiusChange extends Normal {
  constructor(spawn) {
		super(spawn);
        // how much to add/ multiply other enemies' radii; setting multiply to 1 and add to 0 won't do anything
        this.addRadius = spawn.data.addRadius;
        this.multiplyRadius = spawn.data.multiplyRadius;
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
            addRadius: this.addRadius,
            multiplyRadius: this.multiplyRadius,
		}
	}
	simulate(dt,enemy) {
        for (let j = 0; j < enemy.length; j++) {
            if(enemy[j].type == 'rchange') continue;
            if(Math.sqrt((enemy[j].x - this.x)**2+(enemy[j].y - this.y)**2) < this.radius+enemy[j].radius && enemy[j].baseRadius === undefined){
                enemy[j].baseRadius = enemy[j].radius;
                enemy[j].radius = enemy[j].radius*this.multiplyRadius+this.addRadius;
            }
        }
		super.simulate(dt)
	}
}

class RotateAroundParent extends Normal {
  constructor(spawn) {
		super(spawn);
        if(spawn.data.startAngle != undefined){
            this.rotateAngle = spawn.data.startAngle;
        } else {
            this.rotateAngle = Math.random()*Math.PI*2;
        }
        this.rotateSpeed = spawn.data.rotateSpeed;
        this.rotateDist = spawn.data.rotateDist;
        // we can't just use normal childId bc it will snap 2 point ;-;
        this.chId = spawn.data.childId||spawn.data.chId;
        delete this.childId;
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
            rotateAngle: this.rotateAngle,
            rotateSpeed: this.rotateSpeed,
            rotateDist: this.rotateDist,
            chId: this.chId,
		}
	}
	simulate(dt,enemy) {
        if(this.childId){
            delete this.childId;
        }
        if(this.chId){
            this.rotateAngle += dt*this.rotateSpeed;
            for(let e of enemy){
                
                if(e.parentId && e.parentId == this.chId && this.pushIndex == e.pushIndex){
                    this.x = e.x + Math.cos(this.rotateAngle)*this.rotateDist;
                    this.y = e.y + Math.sin(this.rotateAngle)*this.rotateDist;
                }
            }
        }
	}
}

// enemy that repels from other enemies :>
class Repel extends Normal {
  constructor(spawn) {
		super(spawn);
        this.repelAmount = -spawn.data.repelAmount;
        this.repelPower = spawn.data.repelPower;
        this.minDistance = spawn.data.minDistance||Infinity;
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
            repelAmount: this.repelAmount,
            repelPower: this.repelPower,
            minDistance: this.minDistance
		}
	}
	simulate(dt,enemy) {
        for(let e of enemy){
            if(e === this) continue;
            const edist = Math.sqrt((e.x-this.x)**2+(e.y-this.y)**2);
            if(edist < this.minDistance){
                //const eangle = (Math.atan2(e.y-this.y,e.x-this.x) + Math.PI / 2) % (Math.PI*2);
                let dx = e.x-this.x;
                let dy = e.y-this.y;
                const eangle = Math.atan2(dy, dx);
                this.angle = eangle;
                //this.xv -= Math.cos(eangle) * this.speed;
                //this.yv -= Math.sin(eangle) * this.speed;
                this.xv += Math.cos(eangle) * this.repelAmount * 100/Math.pow(edist,this.repelPower);
                this.yv += Math.sin(eangle) * this.repelAmount * 100/Math.pow(edist,this.repelPower);
                // capping at this.speed
                const curSpeed = Math.sqrt(this.xv**2+this.yv**2);
                const spRatio = this.speed/curSpeed;
                this.xv *= spRatio;
                this.yv *= spRatio;
            }
        }
		super.simulate(dt)
	}
}

function intersectingCircle(circle1, circle2) {
    const c1R = circle1.radius ?? circle1.r;
    const c2R = circle2.radius ?? circle2.r;
    return (
        (circle1.x - circle2.x) * (circle1.x - circle2.x) +
            (circle1.y - circle2.y) * (circle1.y - circle2.y) <
        (c1R+c2R) * (c1R+c2R)
    );
}

class TpPlayer extends Normal {
  constructor(spawn) {
		super(spawn);
        this.type = 'tpplayer';
        this.other = {};
        this.other.radius = spawn.data.radius;
		this.other.speed = spawn.data.speed;
		this.other.x = Math.round(Math.random() * (spawn.w - this.radius) + spawn.x + this.radius);
		this.other.y = Math.round(Math.random() * (spawn.h - this.radius) + spawn.y + this.radius);
		this.other.angle = Math.random() * Math.PI * 2;
		this.other.xv = Math.cos(this.angle) * this.speed;
		this.other.yv = Math.sin(this.angle) * this.speed;
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
            other: this.other,
		}
	}
	simulate(dt) {
        // simulating other
        this.other.x += this.other.xv * dt;

		if (this.other.x + this.other.radius >= this.bound.x + this.bound.w) {
			this.other.xv = -this.other.xv;
			this.other.x = (this.bound.x + this.bound.w) * 2 - this.other.x - this.other.radius * 2;
		}
		else if (this.other.x - this.other.radius <= this.bound.x) {
			this.other.xv = -this.other.xv;
			this.other.x = this.bound.x * 2 - this.other.x + this.other.radius * 2;
		}
		this.other.y += this.other.yv * dt;
		if (this.other.y + this.other.radius >= this.bound.y + this.bound.h) {
			this.other.yv = -this.other.yv;
			this.other.y = (this.bound.y + this.bound.h) * 2 - this.other.y - this.other.radius * 2;
		}
		else if (this.other.y - this.other.radius <= this.bound.y) {
			this.other.yv = -this.other.yv;
			this.other.y = this.bound.y * 2 - this.other.y + this.other.radius * 2;
		}
		super.simulate(dt)
	}
}

class Sticky extends Normal {
  constructor(spawn) {
		super(spawn);
        this.stickToPlayer = spawn.data.stickToPlayer;
        this.stickToEnemy = spawn.data.stickToEnemy;
        this.stickParent = null;
        this.stickOffset = {x: 0, y: 0};
        
        // if we want to get bounded by the enemy before sticking
        this.toBoundStick = spawn.data.toBoundBeforeStick;

        // this.stickAll = spawn.data.toStickToAllEnemies;
        // if(this.stickAll === undefined){
        //     this.stickAll = true;
        // }

        // only applies if stickall is false
        // this.stickTypeArray = spawn.data.stickTypes||[];
        // // making O(1) instead of O(n) access using object
        // this.stickTypes = {};

        // for(let i = 0; i < this.stickTypeArray.length; i++){
        //     this.stickTypes[this.stickTypeArray[i]] = true;
        // }

        this.stickFollowers = {};

        this.uniqueStickId = Math.random();

        this.toKill = spawn.data.toKill;
        if(this.toKill === undefined){
            this.toKill = true;
        }
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
            stickToPlayer: this.stickToPlayer,
            stickToEnemy: this.stickToEnemy,
            //stickParent: this.stickParent,
            stickOffset: this.stickOffset,
            toBoundStick: this.toBoundStick,
            //stickAll: this.stickAll,
            //stickTypes: this.stickTypes,
            //stickFollowers: this.stickFollowers,
            uniqueStickId: this.uniqueStickId,
            toKill: this.toKill
		}
	}
	simulate(dt, enemy) {
        // if(this.stickToEnemy){
        //     for(let e = 0; e < enemy.length; e++){
        //         // if(this.stickAll === false && this.stickTypes[enemy[e].type] === undefined){
        //         //     continue;
        //         // }
        //         if(intersectingCircle(enemy[e], this) && this.uniqueStickId !== enemy[e].uniqueStickId && this.stickFollowers[e] === undefined){
        //             if(!this.stickParent){
        //                 this.stickParent = enemy[e];
        //                 this.stickParentId = e;
        //                 if(this.toBoundStick === true){
        //                     const angle = Math.atan2(this.y - enemy[e].y, this.x - enemy[e].x);
        //                     this.x = enemy[e].x + Math.cos(angle) * this.radius;
        //                     this.y = enemy[e].y + Math.sin(angle) * this.radius;
        //                 }
        //                 this.stickOffset = {x: this.x - enemy[e].x, y: this.y - enemy[e].y};
                        
                        
        //                 if(this.stickParent.stickParentIds === undefined){
        //                     this.stickParent.stickParentIds = {};
        //                 }
        //                 this.stickParent.stickParentIds[this.uniqueStickId] = true;

        //                 this.speed = 0;
        //                 if(this.stickParent.type === 'sticky'){
        //                     this.type = 'normal';
        //                     this.simulate = new Normal({data: {}}).simulate;
        //                     return;
        //                 }
        //                 //this.bound = {x: -1E99, y: -1E99, w: 2E99, h: 2E99};
        //             } else if(enemy[e].x !== this.stickParent.x || enemy[e].y !== this.stickParent.y) {
        //                 if(this.toBoundStick === true){
        //                     const angle = Math.atan2(enemy[e].y - this.y, enemy[e].x - this.x);
        //                     enemy[e].x = this.x + Math.cos(angle) * this.radius;
        //                     enemy[e].y = this.y + Math.sin(angle) * this.radius;
        //                 }
                        
        //                 this.stickFollowers[e] = {enemy: enemy[e], offsetX: enemy[e].x - this.x, offsetY: enemy[e].y - this.y};
                        
                        
        //                 if(this.stickFollowers[e].enemy.stickFollowerIds === undefined){
        //                     this.stickFollowers[e].enemy.stickFollowerIds = {};
        //                 }
        //                 this.stickFollowers[e].enemy.stickFollowerIds[this.uniqueStickId] = true;
        //                 this.stickFollowers[e].enemy.speed = 0;
        //                 if(this.stickFollowers[e].type === 'sticky'){
        //                     this.stickFollowers[e].type = 'normal';
        //                     this.stickFollowers[e].simulate = new Normal({data: {}}).simulate;
        //                     return;
        //                 }
        //                 //this.stickFollowers[e].enemy.bound = {x: -1E99, y: -1E99, w: 2E99, h: 2E99};
        //             }
        //         }
        //     }
        // }

        if(this.stickToEnemy){
            for(let e = 0; e < enemy.length; e++){
                if(intersectingCircle(enemy[e], this) && this.uniqueStickId !== enemy[e].uniqueStickId && this.stickFollowers[e] === undefined){
                    if(!this.stickParent){
                        this.stickParent = enemy[e];
                        if(this.toBoundStick === true){
                            const angle = Math.atan2(this.y - enemy[e].y, this.x - enemy[e].x);
                            this.x = enemy[e].x + Math.cos(angle) * this.radius;
                            this.y = enemy[e].y + Math.sin(angle) * this.radius;
                        }
                        this.stickOffset = {x: this.x - enemy[e].x, y: this.y - enemy[e].y};

                        if(this.stickParent.stickParentIds === undefined){
                            this.stickParent.stickParentIds = {};
                        }
                        this.stickParent.stickParentIds[this.uniqueStickId] = true;
                        
                        this.speed = 0;
                        if(enemy[e].type === 'sticky'){
                            this.type = 'normal';
                            const norm = new Normal({data: {}});
                            this.simulate = norm.simulate;
                            this.pack = norm.pack;
                            return;
                        }
                        //this.bound = {x: -1E99, y: -1E99, w: 2E99, h: 2E99};
                    } else if(enemy[e].x !== this.stickParent.x || enemy[e].y !== this.stickParent.y) {
                        this.stickFollowers[e] = {enemy: enemy[e], offsetX: enemy[e].x - this.x, offsetY: enemy[e].y - this.y};
                        if(this.toBoundStick === true){
                            const angle = Math.atan2(enemy[e].y - this.y, enemy[e].x - this.x);
                            enemy[e].x = this.x + Math.cos(angle) * this.radius;
                            enemy[e].y = this.y + Math.sin(angle) * this.radius;
                        }

                        if(this.stickFollowers[e].enemy.stickFollowerIds === undefined){
                            this.stickFollowers[e].enemy.stickFollowerIds = {};
                        }
                        this.stickFollowers[e].enemy.stickFollowerIds[this.uniqueStickId] = true;
                        
                        this.stickFollowers[e].enemy.speed = 0;
                        if(enemy[e].type === 'sticky'){
                            enemy[e].type = 'normal';
                            const norm = new Normal({data: {}});
                            enemy[e].simulate = norm.simulate;
                            enemy[e].pack = norm.pack;
                            return;
                        }
                        //this.stickFollowers[e].enemy.bound = {x: -1E99, y: -1E99, w: 2E99, h: 2E99};
                    }
                }
            }
        }
        
        // make enemies stick
        if(this.stickParent){
            this.x = this.stickParent.x + this.stickOffset.x;
            this.y = this.stickParent.y + this.stickOffset.y;
        }
        
        if(Object.keys(this.stickFollowers).length !== 0){
            for(let key in this.stickFollowers){
                const followerData = this.stickFollowers[key];
                followerData.enemy.x = this.x + followerData.offsetX;
                followerData.enemy.y = this.y + followerData.offsetY;
            }
        }

        super.simulate(dt);
	}
}

class KillEnemy extends Normal {
  constructor(spawn) {
		super(spawn);
        this.toKillParent = spawn.data.canKillParent;
        if(this.toKillParent === undefined){
            this.toKillParent = false;
        }
      
        this.killAll = spawn.data.killAll;
        this.killTypes = spawn.data.killTypes||[];
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
            toKillParent: this.toKillParent,
            killAll: this.killAll,
            killTypes: this.killTypes
		}
	}
	simulate(dt, enemy) {
        enemy.forEach((ene, ind) => {
            // no battle royale
            if(ene.type === 'killenemy'){
                return;
            }
            if(this.killAll === false && !this.killTypes.includes(ene.type)){
                return;
            }
            if(intersectingCircle(ene,this)){
                if(this.toKillParent === true || ene.parentId !== this.childId || ene.childId === undefined){
                    enemy.splice(ind, 1);
                }
            }
        })
        super.simulate(dt);
	}
}

class ForceMove extends Normal {
  constructor(spawn) {
		super(spawn);
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
		}
	}
	simulate(dt) {
		super.simulate(dt)
	}
}

class ForceStop extends Normal {
  constructor(spawn) {
		super(spawn);
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
		}
	}
	simulate(dt) {
		super.simulate(dt)
	}
}

class Shh extends Normal {
  constructor(spawn) {
		super(spawn);
        this.impostor = false;
        this.impostorChance = spawn.data.ic;
        if(this.impostorChance == undefined){
          this.impostorChance = 0.25;
        }
        if(Math.random() < this.impostorChance){
          this.impostor = true;
        }
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
      impostor: this.impostor,
		}
	}
	simulate(dt) {
		super.simulate(dt)
	}
}

class Oval extends Normal {
  constructor(spawn) {
		super(spawn);
        this.r1 = spawn.data.radius;
        this.r2 = spawn.data.radius2;
	}
	pack() {
		return {
			type: this.type,
			radius: this.r1,// for the system; im not actually gonna be using this in any calculations xd
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
            r1: this.r1,
            r2: this.r2,
		}
	}
	simulate(dt) {
		this.x += this.xv * dt;

		if (this.x + this.r1 >= this.bound.x + this.bound.w) {
			this.xv = -this.xv;
			this.x = (this.bound.x + this.bound.w) * 2 - this.x - this.r1 * 2;
		}
		else if (this.x - this.r1 <= this.bound.x) {
			this.xv = -this.xv;
			this.x = this.bound.x * 2 - this.x + this.r1 * 2;
		}
		this.y += this.yv * dt;
		if (this.y + this.r2 >= this.bound.y + this.bound.h) {
			this.yv = -this.yv;
			this.y = (this.bound.y + this.bound.h) * 2 - this.y - this.r2 * 2;
		}
		else if (this.y - this.r2 <= this.bound.y) {
			this.yv = -this.yv;
			this.y = this.bound.y * 2 - this.y + this.r2 * 2;
		}
	}
}

class GrowingOval extends Oval {
  constructor(spawn) {
		super(spawn);
        this.growSpeedX = spawn.data.growSpeedX;
        this.growSpeedY = spawn.data.growSpeedY;
        this.maxX = spawn.data.maxX;
        this.maxY = spawn.data.maxY;
        this.minX = spawn.data.minX;
        this.minY = spawn.data.minY;
        this.growingX = spawn.data.growingX;// growing at the start
        this.growingY = spawn.data.growingY;
        if(spawn.data.radiusOffset) {
            this.r1 += spawn.data.radiusOffset*Math.random();
            this.r2 += spawn.data.radiusOffset*Math.random();
        } 
	}
	pack() {
		return {
			...super.pack(),
            growSpeedX: this.growSpeedX,
            growSpeedY: this.growSpeedY,
            maxX: this.maxX,
            minY: this.minY,
            minX: this.minX,
            maxY: this.maxY,
            growingX: this.growingX,
            growingY: this.growingY,
		}
	}
	simulate(dt) {
        if (this.growingX) {
			this.r1 += this.growSpeedX * dt;
			if (this.r1 > this.maxX) {
				this.growingX = false;
				let overGrowth = this.r1 - this.maxX;
				this.r1 -= overGrowth * 2;
			}
		} else {
			this.r1 -= this.growSpeedX * dt;
			if (this.r1 < this.minX) {
				this.growingX = true;
				let underGrowth = this.r1 - this.minX;
				this.r1 -= underGrowth * 2;
			}
		}
        if (this.growingY) {
			this.r2 += this.growSpeedY * dt;
            if (this.r2 > this.maxY) {
				this.growingY = false;
				let overGrowth = this.r2 - this.maxY;
				this.r2 -= overGrowth * 2;
			}
		} else {
			this.r2 -= this.growSpeedY * dt;
            if (this.r2 < this.minY) {
				this.growingY = true;
				let underGrowth = this.r2 - this.minY;
				this.r2 -= underGrowth * 2;
			}
		}
		super.simulate(dt);
	}
}

class Outline extends Normal {
  constructor(spawn) {
    super(spawn);
  }
    pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
		}
	}
	simulate(dt) {
        super.simulate(dt);
    }
}

class Fire extends Normal {
  constructor(spawn) {
    super(spawn);
    this.maxTime = spawn.data.maxTime;
    this.timer = Math.random()*spawn.data.maxTime;
    this.fire = [];
    this.fireAmount = spawn.data.fireAmount;
    this.fireDistance = spawn.data.fireDistance;
    this.fireLife = spawn.data.fireLife;
    this.pauseTime = spawn.data.pauseTime || 0.5;
  }
    pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
            maxTime: this.maxTime,
            timer: this.timer,
            fire: this.fire,
            fireAmount: this.fireAmount,
            fireDistance: this.fireDistance,
            fireLife: this.fireLife,
            pauseTime: this.pauseTime,
		}
	}
	simulate(dt) {
        // siming if we're not pausing
        if(this.timer > this.pauseTime){
            super.simulate(dt);   
        }
        // spawning new fire if neccesary
        this.timer -= dt;
        if(this.timer <= 0){
            for(let i = 0; i < this.fireAmount; i++){
                super.simulate(this.fireDistance*(i+1)/this.fireAmount);
                this.fire.push({x: this.x, y: this.y, life: this.fireLife, radius: this.radius})
                super.simulate(-this.fireDistance*(i+1)/this.fireAmount);
            }
            this.timer += this.maxTime;
        }

        // simulating fire
        this.fire.forEach((fire, index) => {
            fire.life -= dt;
            if(fire.life < 0){
                this.fire.splice(index, 1);
            }
        })
    }
}

class SelfCollide extends Normal {
  constructor(spawn) {
    super(spawn);
  }
    pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
		}
	}
	simulate(dt, enemies) {
        for(let e in enemies){
            let dist = Math.sqrt((enemies[e].x-this.x)**2+(enemies[e].y-this.y)**2);
            if(dist < this.radius + enemies[e].radius && dist != 0 && enemies[e].type != 'spawn'){
                //colliding
                let angle = Math.atan2(enemies[e].y-this.y,enemies[e].x-this.x);
                let magnitude = 50000/dist * dt;
                this.xv -= Math.cos(angle) * magnitude;
                this.yv -= Math.sin(angle) * magnitude;
                if(this.xv > this.speed){
                    this.xv = this.speed;
                } else if(this.xv < -this.speed){
                    this.xv = -this.speed;
                }
                if(this.yv > this.speed){
                    this.yv = this.speed;
                } else if(this.yv < -this.speed){
                    this.yv = -this.speed;
                }
                enemies[e].xv += Math.cos(angle) * magnitude;
                enemies[e].yv += Math.sin(angle) * magnitude;
            }
        }
        super.simulate(dt);
    }
}

class Wind extends Normal {
  constructor(spawn) {
    super(spawn);
    this.strength = spawn.data.strength;
  }
    pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
            strength: this.strength,
		}
	}
	simulate(dt) {
        super.simulate(dt);
    }
}

// 95% boilerplate btw; for ur own sanity pls ask serum how this works rather than trying to figure it out urself
class Spawn extends Normal {
  constructor(spawn) {
    super(spawn);
    this.spawnTimer = spawn.data.spawnTimer;
    this.spawnIndex = spawn.data.spawnIndex || 0;
    this.timeIndex = spawn.data.timeIndex || 0;
    this.shootIndex = spawn.data.shootIndex || 0;
    if(spawn.data.spawnTimer === undefined){
        this.spawnTimer = Array.isArray(spawn.data.spawnTime) ? spawn.data.spawnTime[this.timeIndex] : spawn.data.spawnTime;
    }
    if(Array.isArray(spawn.data.spawnTime)){
        this.spawnTime = spawn.data.spawnTime;
    } else {
        this.spawnTime = spawn.data.spawnTime||this.spawnTimer;
    }
    let spawnprs;
    if(Array.isArray(spawn.data.spawnParams)){
        this.spawnParams = [];
        for(let i in spawn.data.spawnParams){
            spawnprs = spawn.data.spawnParams[i];   
            let sp;
            if(spawnprs.bound){
                sp = new Spawner(spawnprs.bound.x||this.bound.x,spawnprs.bound.y||this.bound.y,spawnprs.bound.w||this.bound.w,spawnprs.bound.h||this.bound.h, spawnprs);
            } else {
                sp = new Spawner(this.bound.x,this.bound.y,this.bound.w,this.bound.h, spawnprs);
            }
            this.spawnParams[i] = sp.spawn();
            Object.assign(this.spawnParams[i], spawnprs)
        }
    } else {
        spawnprs = spawn.data.spawnParams;
        let sp;
        if(spawnprs.bound){
            sp = new Spawner(spawnprs.bound.x||this.bound.x,spawnprs.bound.y||this.bound.y,spawnprs.bound.w||this.bound.w,spawnprs.bound.h||this.bound.h, spawnprs);
        } else {
            sp = new Spawner(this.bound.x,this.bound.y,this.bound.w,this.bound.h, spawnprs);
        }
        this.spawnParams = sp.spawn();
        Object.assign(this.spawnParams, spawnprs)
    }
    if(spawn.data.shootAngles){
      this.shootAngles = spawn.data.shootAngles.map(a => a*Math.PI/180);  
    }
    this.seed = Math.floor(Math.random()*100000000);
    this.color = spawn.data.color||'#490794';
    if(spawn.data.x){
        this.x = spawn.data.x;
    }
    if(spawn.data.y){
        this.y = spawn.data.y;
    }
    if(spawn.data.angle){
        this.angle = spawn.data.angle;
        this.xv = Math.cos(this.angle)*this.speed;
        this.yv = Math.sin(this.angle)*this.speed;
    }
    // this also adds with the existing speed somehow lol
    if(spawn.data.xv){
        this.xv = spawn.data.xv;
    }
    if(spawn.data.yv){
        this.yv = spawn.data.yv;
    }
      this.spawnPushIndex = 0;
  }
    pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
            bound: this.bound,
			spawnTime: this.spawnTime,
            spawnTimer: this.spawnTimer,
            spawnParams: this.spawnParams,
            shootAngles: this.shootAngles,
            shootIndex: this.shootIndex,
            seed: this.seed,
            color: this.color,
            spawnIndex: this.spawnIndex,
            timeIndex: this.timeIndex,
            spawnPushIndex: this.spawnPushIndex,
		}
	}
	simulate(dt, enemy, obstacles) {
        /*this.spawnTimer -= dt;
        if(this.spawnTimer <= 0){
            if(this.shootAngles){
                this.spawnTimer += this.spawnTime;
                this.shootIndex++;
                if(this.shootIndex >= this.shootAngles.length){
                    this.shootIndex = 0;
                }   
            }
        }*/
        super.simulate(dt);
        this.spawnTimer -= dt;
        if(this.spawnTimer <= 0){
            if(Array.isArray(this.spawnTime)){
                this.timeIndex++;
                if(this.timeIndex >= this.spawnTime.length){
                    this.timeIndex = 0;
                }
                this.spawnTimer += this.spawnTime[this.timeIndex];
            } else {
                this.spawnTimer += this.spawnTime;
            }
            this.seed = Math.sin(this.seed++) * 10000 - Math.floor(Math.sin(this.seed++) * 10000);
            let angle = (this.seed*10)%(Math.PI*2);
            if(this.shootAngles){
                angle = this.shootAngles[this.shootIndex];
                this.shootIndex++;
                if(this.shootIndex >= this.shootAngles.length){
                    this.shootIndex = 0;
                }
            }
            this.spawnIndex++;
            if(this.spawnIndex >= this.spawnParams.length){
                this.spawnIndex = 0;
            }
            if(angle != 'none'){
                let sp;
                if(Array.isArray(this.spawnParams)){
                    sp = new Spawner(
                        (this.spawnParams[this.spawnIndex].bound||this.bound).x,
                        (this.spawnParams[this.spawnIndex].bound||this.bound).y,
                        (this.spawnParams[this.spawnIndex].bound||this.bound).w,
                        (this.spawnParams[this.spawnIndex].bound||this.bound).h,
                        this.spawnParams[this.spawnIndex]
                    );
                } else {
                    sp = new Spawner(
                        (this.spawnParams.bound||this.bound).x,
                        (this.spawnParams.bound||this.bound).y,
                        (this.spawnParams.bound||this.bound).w,
                        (this.spawnParams.bound||this.bound).h,
                        this.spawnParams
                    );   
                }
                enemy.push(sp.spawn(true, this.spawnPushIndex));
                this.spawnPushIndex++;
                for(let en = 0; en < enemy.length; en++){
                    delete enemy[en].parentIdEnemy;
                }
                let extraspawnprs = JSON.parse(JSON.stringify(this.spawnParams));
                if(Array.isArray(this.spawnParams)){
                    extraspawnprs = JSON.parse(JSON.stringify(this.spawnParams[this.spawnIndex]));
                }
                if(extraspawnprs.x){
                    enemy[enemy.length-1].x = extraspawnprs.x;
                }
                if(extraspawnprs.y){
                    enemy[enemy.length-1].y = extraspawnprs.y;
                }
                enemy[enemy.length-1].angle = angle;
                if(extraspawnprs.angle){
                    enemy[enemy.length-1].angle = extraspawnprs.angle;
                }
                enemy[enemy.length-1].xv = Math.cos(angle)*enemy[enemy.length-1].speed;
                enemy[enemy.length-1].yv = Math.sin(angle)*enemy[enemy.length-1].speed;
                if(extraspawnprs.xv){
                    enemy[enemy.length-1].xv = extraspawnprs.xv;
                }
                if(extraspawnprs.yv){
                    enemy[enemy.length-1].yv = extraspawnprs.yv;
                }
                if(extraspawnprs.bound){
                    enemy[enemy.length-1].bound = extraspawnprs.bound;
                }
                if(enemy[enemy.length-1].type === 'enemyobstacle'){
                    return enemy[enemy.length-1].obstacle;
                }
            }
        }
        /*if(this.ready){
            for(let en in enemy){
                // if colliding with enemy
                if((this.x-enemy[en].x)**2+(this.y-enemy[en].y)**2 < this.radius+enemy[en].radius && enemy[en].type == 'split' && enemy[en].isSplit){
                    let angle = Math.random()*2*Math.PI;
                    let speed = this.speed/2+enemy[en].speed/2;
                    enemy.push(new Split({
                        type: 'split',
                        radius: this.radius/2+enemy[en].radius/2,
                        speed: speed,
                        x: this.x/2+enemy[en].x/2,
                        y: this.y/2+enemy[en].y/2,
                        angle: angle,
                        xv: Math.cos(angle)*speed,
                        yv: Math.sin(angle)*speed,
                        bound: this.bound,
                        life: this.splitLife,
                    }));
                    
                    angle = Math.random()*2*Math.PI;
                    speed = this.speed/2+enemy[en].speed/2;
                    enemy.push(new Split({
                        type: 'split',
                        radius: this.radius/2+enemy[en].radius/2,
                        speed: speed,
                        x: this.x/2+enemy[en].x/2,
                        y: this.y/2+enemy[en].y/2,
                        angle: angle,
                        xv: Math.cos(angle)*speed,
                        yv: Math.sin(angle)*speed,
                        bound: this.bound,
                        life: this.splitLife,
                    }));
                    this.ready = false
                }
            }
        }
        this.splitTimer -= dt;
        if (this.splitTimer < 0){
            this.splitTimer += this.splitTime;
            this.ready = true;
        }
        if(this.life != undefined){
            this.life -= dt;
            if(this.life == 0){
                delete enemy[this];
            }
        }
        super.simulate(dt);
        this.enemyToHome = undefined;
        let dist = 1000000;
        for(let en in enemies){
            let d = (this.split.x-enemies[en].x)**2+(this.split.y-enemies[en].y)**2;
            if(d < dist && enemies[en].type == 'split' && enemies[en].isSplit && enemies[en].home){
                dist = d;
                this.enemyToHome = en;
            }
        }
        if(this.home){
            // home towards normal
            if(this.enemyToHome != undefined){
                this.split.angle = Math.atan2(this.split.y-enemies[this.enemyToHome].y,this.split.x-enemies[this.enemyToHome].x);
            this.angle = Math.atan2(enemies[this.enemyToHome].y-this.split.y,enemies[this.enemyToHome].x-this.split.x);
            } else {
                this.split.angle = Math.atan2(this.split.y-this.y,this.split.x-this.x);
                this.angle = Math.atan2(this.y-this.split.y,this.x-this.split.x);   
            }
            // directly homing for now; change to interpolating homing?
            this.split.xv = -Math.cos(this.split.angle) * this.split.speed/3;
            this.split.yv = -Math.sin(this.split.angle) * this.split.speed/3;
            this.xv = -Math.cos(this.angle) * this.speed/3;
            this.yv = -Math.sin(this.angle) * this.speed/3;
        }
        this.splitTimer-=dt;
        if(!this.isSplit){// not split
            if(this.splitTimer < 0){
                this.splitTimer += this.splitTime;
                this.radius = this.baseRadius / Math.sqrt(2);
                this.split = {
                    type: this.type,
        			radius: this.radius,
        			speed: this.speed,
        			x: this.x,
        			y: this.y,
        			angle: this.angle,
        			xv: this.xv,
        			yv: this.yv,
                    bound: this.bound,
                }
                //this.split.speed *= 1.5;
                this.split.xv = Math.sin(this.split.angle-Math.PI) * this.split.speed;
                this.split.yv = Math.cos(this.split.angle-Math.PI) * this.split.speed;
                this.isSplit = true;
            } else {
                this.radius = Math.max(this.baseRadius/Math.sqrt(2),this.baseRadius*(this.splitTime-this.splitTimer)/this.splitTime);
            }
        } else { // split
            if(this.splitTimer < 0){
                this.home = true;
            }
            // simulating split
            this.split.x += this.split.xv * dt;

    		if (this.split.x + this.split.radius >= this.split.bound.x + this.split.bound.w) {
    			this.split.xv = -this.split.xv;
    			this.split.x = (this.split.bound.x + this.split.bound.w) * 2 - this.split.x - this.split.radius * 2;
    		}
    		else if (this.split.x - this.split.radius <= this.split.bound.x) {
    			this.split.xv = -this.split.xv;
    			this.split.x = this.split.bound.x * 2 - this.split.x + this.split.radius * 2;
    		}
    		this.split.y += this.split.yv * dt;
    		if (this.split.y + this.split.radius >= this.split.bound.y + this.split.bound.h) {
    			this.split.yv = -this.split.yv;
    			this.split.y = (this.split.bound.y + this.split.bound.h) * 2 - this.split.y - this.split.radius * 2;
    		}
    		else if (this.split.y - this.split.radius <= this.split.bound.y) {
    			this.split.yv = -this.split.yv;
    			this.split.y = this.split.bound.y * 2 - this.split.y + this.split.radius * 2;
    		}

            if(this.home && Math.sqrt((this.split.x - this.x)**2+(this.split.y - this.y)**2) < 1+Math.abs(this.split.speed*dt)){
                this.split = {};
                this.home = false;
                this.radius = this.baseRadius/Math.sqrt(2);
                this.splitTimer = this.splitTime;
                this.isSplit = false;
                this.xv *= 3;
                this.yv *= 3;
            } 

            // checking splitting with other enemies
            for(let e in enemies){
                if(enemies[e].type == 'split' && enemies[e].isSplit){
                    // making other enemy's split false and transferring the other enemy's split to this
                    if(enemies[e].home && Math.sqrt((this.split.x - enemies[e].x)**2+(this.split.y - enemies[e].y)**2) < 1+Math.abs(this.split.speed*dt)){
                        this.split = {
                            type: enemies[e].split.type,
                			radius: enemies[e].split.radius,
                			speed: enemies[e].split.speed,
                			x: enemies[e].split.x,
                			y: enemies[e].split.y,
                			angle: enemies[e].split.angle,
                			xv: enemies[e].split.xv,
                			yv: enemies[e].split.yv,
                            bound: enemies[e].split.bound,
                        }
                        enemies[e].split = {};
                        enemies[e].home = false;
                        enemies[e].radius = this.baseRadius/Math.sqrt(2);
                        enemies[e].splitTimer = this.splitTime;
                        enemies[e].isSplit = false;
                        enemies[e].xv *= 3;
                        enemies[e].yv *= 3;
                    }   
                }
            }
        }
        super.simulate(dt);*/
    }
}

class Slower extends Normal {
  constructor(spawn) {
    super(spawn);
    this.speedMult = spawn.data.speedMult;
  }
    pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
            speedMult: this.speedMult,
            baseRadius: this.baseRadius,
		}
	}
	simulate(dt) {
        super.simulate(dt);
    }
}

class Jumping extends Normal {
  constructor(spawn) {
    super(spawn);
    this.jumping = false;
    this.maxTimer = spawn.data.groundedTime;
    this.vz = 0;
    this.z = 0;
    this.gravity = spawn.data.gravity || 8;
    this.baseRadius = spawn.data.radius;
    this.jumpHeight = spawn.data.jumpHeight;
    this.timer = Math.random()*this.maxTimer;
  }
    pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
            jumping: this.jumping,
            timer: this.timer,
            vz: this.vz,
            z: this.z,
            gravity: this.gravity,
            baseRadius: this.baseRadius,
            maxTimer: this.maxTimer,
            jumpHeight: this.jumpHeight,
		}
	}
	simulate(dt) {
        if(this.jumping){
            super.simulate(dt*this.z/10);
            this.vz -= this.gravity*dt;
            this.z += this.vz*dt;
            this.radius = this.baseRadius+this.z;
            if(this.z < 0){
                this.z = 0;
                this.jumping = false;
            }
        } else {
            this.timer+=dt;
            if(this.timer >= this.maxTimer){
                this.timer = 0;
                this.jumping = true;
                this.vz = this.jumpHeight;
            }
        }
    }
}

class Bomb extends Normal {
  constructor(spawn) {
    super(spawn);
    this.bombs = [];
    this.bombNumber = spawn.data.bombNumber;
    this.bombSpeed = spawn.data.bombSpeed;
    this.bombRadius = spawn.data.bombRadius;
    this.bombLife = spawn.data.bombLife;
    this.bombDecay = spawn.data.bombDecay || 0.98;// should be > 0.90 usually
  }
    pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
            bombs: this.bombs,
            bombNumber: this.bombNumber,
            bombSpeed: this.bombSpeed,
            bombRadius: this.bombRadius,
            bombLife: this.bombLife,
            bombDecay: this.bombDecay,
		}
	}
	simulate(dt) {
        let toBomb = false;
        this.x += this.xv * dt;

		if (this.x + this.radius >= this.bound.x + this.bound.w) {
			this.xv = -this.xv;
			this.x = (this.bound.x + this.bound.w) * 2 - this.x - this.radius * 2;
            toBomb = true;
		}
		else if (this.x - this.radius <= this.bound.x) {
			this.xv = -this.xv;
			this.x = this.bound.x * 2 - this.x + this.radius * 2;
            toBomb = true;
		}
        
		this.y += this.yv * dt;
        
		if (this.y + this.radius >= this.bound.y + this.bound.h) {
			this.yv = -this.yv;
			this.y = (this.bound.y + this.bound.h) * 2 - this.y - this.radius * 2;
            toBomb = true;
		}
		else if (this.y - this.radius <= this.bound.y) {
			this.yv = -this.yv;
			this.y = this.bound.y * 2 - this.y + this.radius * 2;
            toBomb = true;
		}

        if(toBomb){
            for(let i = 0; i < this.bombNumber; i++){
                let angle = Math.random()*Math.PI*2;
                let vmult = Math.random();
                // eventually have all of these tied to a param
                this.bombs.push({x: this.x, y: this.y, xv: Math.cos(angle)*this.bombSpeed*vmult, yv: Math.sin(angle)*this.bombSpeed*vmult, life: this.bombLife, radius: this.bombRadius})
            }
        }

        // simulating and updating bomb fragments
        this.bombs.forEach((bomb, index) => {
            bomb.xv *= this.bombDecay;
            bomb.yv *= this.bombDecay;
            bomb.life -= dt;
            if(bomb.life < 0){
                this.bombs.splice(index, 1);
            }
            bomb.x += bomb.xv * dt;
    		bomb.y += bomb.yv * dt;
            if (bomb.x + bomb.radius >= this.bound.x + this.bound.w) {
    			bomb.xv = -bomb.xv;
    			bomb.x = (this.bound.x + this.bound.w) * 2 - bomb.x - bomb.radius * 2;
    		}
    		else if (bomb.x - bomb.radius <= this.bound.x) {
    			bomb.xv = -bomb.xv;
    			bomb.x = this.bound.x * 2 - bomb.x + bomb.radius * 2;
    		}
            
    		if (bomb.y + bomb.radius >= this.bound.y + this.bound.h) {
    			bomb.yv = -bomb.yv;
    			bomb.y = (this.bound.y + this.bound.h) * 2 - bomb.y - bomb.radius * 2;
    		}
    		else if (bomb.y - bomb.radius <= this.bound.y) {
    			bomb.yv = -bomb.yv;
    			bomb.y = this.bound.y * 2 - bomb.y + bomb.radius * 2;
    		}
        })
    }
}

class Wavy extends Normal {
  constructor(spawn) {
    super(spawn);
    this.dir = 1;
    this.xv = Math.random() < 0.5 ? -1 : 1;
    this.yv = 0;
    this.timer = 0;
    this.maxTimer = spawn.data.maxTimer || 0.4;
  }
    pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
            y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
            dir: this.dir,
            timer: this.timer,
            maxTimer: this.maxTimer,
		}
	}
	simulate(dt) {
        this.timer -= dt;
        if (this.timer < 0) {
            this.timer = this.maxTimer;
            this.dir *= -1;
        }
        this.angle = Math.atan2(this.yv, this.xv);
        this.angle += this.dir * dt * 2;
        this.xv = Math.cos(this.angle) * this.speed;
        this.yv = Math.sin(this.angle) * this.speed;

        this.x += this.xv * dt;

		if (this.x + this.radius >= this.bound.x + this.bound.w) {
			this.xv = -this.xv;
			this.x = (this.bound.x + this.bound.w) * 2 - this.x - this.radius * 2;
		}
		else if (this.x - this.radius <= this.bound.x) {
			this.xv = -this.xv;
			this.x = this.bound.x * 2 - this.x + this.radius * 2;
		}
        
		this.y += this.yv * dt;
        
		if (this.y + this.radius >= this.bound.y + this.bound.h) {
			this.yv = -this.yv;
			this.y = (this.bound.y + this.bound.h) * 2 - this.y - this.radius * 2;
		}
		else if (this.y - this.radius <= this.bound.y) {
			this.yv = -this.yv;
			this.y = this.bound.y * 2 - this.y + this.radius * 2;
		}
    }
}

class GravAura extends Normal {
	constructor(spawn) {
		super(spawn);
        this.auraStrength = spawn.data.auraStrength;
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
			auraStrength: this.auraStrength,
		}
	}
	simulate(dt) {
		super.simulate(dt)
	}
}

class Growing extends Normal {
	constructor(spawn) {
		super(spawn);
        this.minRadius = spawn.data.minRadius;
        this.maxRadius = spawn.data.maxRadius;
        this.growSpeed = spawn.data.growSpeed;
        this.growing = spawn.data.startGrowing;
        this.bounceAmount = spawn.data.bounceAmount;
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
			minRadius: this.minRadius,
            maxRadius: this.maxRadius,
            growSpeed: this.growSpeed,
            growing: this.growing,
            bounceAmount: this.bounceAmount,
		}
	}
	simulate(dt) {
        if(this.growing){
            this.radius += dt*this.growSpeed;
            if(this.radius > this.maxRadius){
                this.growing = false;
                let overGrowth = this.radius - this.maxRadius;
                this.radius -= overGrowth;
            }
        } else {
            this.radius -= dt*this.growSpeed;
            if(this.radius < this.minRadius){
                this.growing = true;
                let underGrowth = this.minRadius - this.radius;
                this.radius += underGrowth;
            }
        }
		super.simulate(dt)
	}
}

class Memory extends Normal {
	constructor(spawn) {
		super(spawn);
        this.time = spawn.data.timeOn;
        this.timeOff = spawn.data.timeOff;
        this.type = 'memory';
        this.timer = Math.random()*spawn.data.timeOn*spawn.data.range;
        this.on = false;
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
			time: this.time,
      timeOff: this.timeOff,
      timer: this.timer,
      on: this.on,
		}
	}
	simulate(dt) {
    this.timer -= dt;
    if(this.timer < 0){
      this.on = !this.on;
      if(this.on){
        this.timer += this.time;
      } else {
        this.timer += this.timeOff;
      }
    }
    if(this.on){
      this.x += this.xv * dt * this.timer/this.time;
      if (this.x + this.radius >= this.bound.x + this.bound.w) {
        this.xv = -this.xv;
        this.x = (this.bound.x + this.bound.w) * 2 - this.x - this.radius * 2;
      }
      else if (this.x - this.radius <= this.bound.x) {
        this.xv = -this.xv;
        this.x = this.bound.x * 2 - this.x + this.radius * 2;
      }
      this.y += this.yv * dt * this.timer/this.time;
      if (this.y + this.radius >= this.bound.y + this.bound.h) {
        this.yv = -this.yv;
        this.y = (this.bound.y + this.bound.h) * 2 - this.y - this.radius * 2;
      }
      else if (this.y - this.radius <= this.bound.y) {
        this.yv = -this.yv;
        this.y = this.bound.y * 2 - this.y + this.radius * 2;
      }
    }
	}
}

class Flashlight extends Normal {
	constructor(spawn) {
		super(spawn);
        this.flashlightSize = spawn.data.flashlightSize;
        this.flashlightAngle = spawn.data.flashlightAngle*Math.PI/180;
    	this.flashlightDir = 0;
    	if (spawn.data.flashlightDir != undefined) {
    		this.flashlightDir = spawn.data.flashlightDir * Math.PI/180;
    	}
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
			flashlightSize: this.flashlightSize,
      flashlightAngle: this.flashlightAngle,
			flashlightDir: this.flashlightDir,
		}
	}
	simulate(dt) {
		super.simulate(dt);
	}
}

class Boomerang extends Normal {
	constructor(spawn) {
		super(spawn);
        this.throwCooldown = spawn.data.throwCooldown || 3;
        this.shootAngles = spawn.data.shootAngles || false;// non-mandatory prop that tells where the boomer is gonna shoot in radians in an array format :D
        
        // converting from degrees (input) to radians (what we do the math with)
        if(Array.isArray(this.shootAngles)){
            for(let i = 0; i < this.shootAngles.length; i++){
                this.shootAngles[i] *= Math.PI/180;
            }
        }
        this.throwAngle = this.shootAngles != false ? this.shootAngles[0] : Math.random()*Math.PI*2;
        this.throwTimer = this.throwCooldown;
        this.boomerangSpeed = spawn.data.boomerangSpeed;
        this.boomerangRadius = spawn.data.boomerangRadius;
        // this.boomerangAmount?? will spit out more than one boomer every interval?
        this.shootIndex = 0;
        this.boomerangs = [];
        if(spawn.data.x) this.x = spawn.data.x;
        if(spawn.data.y) this.y = spawn.data.y;
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
            throwCooldown: this.throwCooldown,
            throwAngle: this.throwAngle,
            throwTimer: this.throwTimer,
            boomerangSpeed: this.boomerangSpeed,
            boomerangRadius: this.boomerangRadius,
            boomerangs: this.boomerangs,
            shootAngles: this.shootAngles,
            shootIndex: this.shootIndex,
		}
	}
	simulate(dt) {
        this.throwTimer -= dt;
        if(this.throwTimer <= 0){
            this.throwTimer += this.throwCooldown;
            
            this.boomerangs.push({
                x: this.x,
                y: this.y,
                angle: this.throwAngle,
                xv: this.boomerangSpeed * Math.cos(this.throwAngle),
                yv: this.boomerangSpeed * Math.sin(this.throwAngle),
                radius: this.boomerangRadius,
                mergeTimer: 0.5,
            });
            
            if(this.shootAngles){
                this.shootIndex++;
                if(this.shootIndex > this.shootAngles.length-1){
                    this.shootIndex = 0;
                }
                this.throwAngle = this.shootAngles[this.shootIndex];
            } else {
                this.throwAngle = Math.sin(this.throwAngle++) * 10000 - Math.floor(Math.sin(this.throwAngle++) * 10000);  
            }
        }
        this.boomerangs.forEach((boomerang,i) => {
            boomerang.x += boomerang.xv * dt;
            boomerang.y += boomerang.yv * dt;
            boomerang.mergeTimer -= dt;

            // wall bounding
            if (boomerang.x + boomerang.radius >= this.bound.x + this.bound.w) {
    			boomerang.xv = -boomerang.xv;
    			boomerang.x = (this.bound.x + this.bound.w) * 2 - boomerang.x - boomerang.radius * 2;
    		}
    		else if (boomerang.x - boomerang.radius <= this.bound.x) {
    			boomerang.xv = -boomerang.xv;
    			boomerang.x = this.bound.x * 2 - boomerang.x + boomerang.radius * 2;
    		}
    		
    		if (boomerang.y + boomerang.radius >= this.bound.y + this.bound.h) {
    			boomerang.yv = -boomerang.yv;
    			boomerang.y = (this.bound.y + this.bound.h) * 2 - boomerang.y - boomerang.radius * 2;
    		}
    		else if (boomerang.y - boomerang.radius <= this.bound.y) {
    			boomerang.yv = -boomerang.yv;
    			boomerang.y = this.bound.y * 2 - boomerang.y + boomerang.radius * 2;
    		}
            // collision
            if(Math.sqrt((boomerang.x - this.x)**2+(boomerang.y - this.y)**2) < Math.max(10, this.radius - this.boomerangRadius) && boomerang.mergeTimer <= 0){
                this.boomerangs.splice(i,1);
            }

            // homing
            const dX = this.x - boomerang.x;
            const dY = this.y - boomerang.y;
            const targetAngle = Math.atan2(dY, dX);
            const dif = targetAngle - boomerang.angle;
            const angleDif = Math.atan2(Math.sin(dif), Math.cos(dif));
            const angleIncrement = 0.04;
            if (Math.abs(angleDif) >= angleIncrement) {
                if (angleDif < 0) {
                    boomerang.angle -= angleIncrement * (20 / 30)
                } else {
                    boomerang.angle += angleIncrement * (20 / 30)
                }
            }

            boomerang.xv = Math.cos(boomerang.angle) * this.boomerangSpeed;
            boomerang.yv = Math.sin(boomerang.angle) * this.boomerangSpeed;
        })
        super.simulate(dt);
	}
}

class Rain {
	constructor(spawn) {
		this.type = spawn.data.type;
		this.radius = spawn.data.radius;
		this.speed = spawn.data.speed;
		this.x = Math.round(Math.random() * (spawn.w - this.radius) + spawn.x + this.radius);
		this.y = Math.round(Math.random() * (spawn.h - this.radius) + spawn.y + this.radius);
		if (spawn.data.direction === 'horizontal') {
			if (Math.random() < 0.5) {
				this.angle = 0;
			} else {
				this.angle = Math.PI;
			}
		} else if (spawn.data.direction === 'vertical') {
			if (Math.random() < .5) {
				this.angle = 1 / 2 * Math.PI;
			} else {
				this.angle = 3 / 2 * Math.PI;
			}
		} else {
			this.angle = Math.random() * Math.PI * 2;
		}
        this.direction = spawn.data.direction;
		this.xv = Math.cos(this.angle) * this.speed;
		this.yv = Math.sin(this.angle) * this.speed;
		this.bound = { x: spawn.x, y: spawn.y, w: spawn.w, h: spawn.h }
		if (spawn.data.toWarp != undefined) {
			this.toWarp = spawn.data.toWarp;
		} else {
			this.toWarp = false;
        }

		this.waitTimer = spawn.data.waitTimer;
		this.timer = spawn.data.waitTimer;
		this.toWait = false;
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
			waitTimer: this.waitTimer,
			timer: this.timer,
			toWait: this.toWait,
			toWarp: this.toWarp,
            direction: this.direction,
		}
	}
	simulate(dt) {
		// if (this.toWait) {
  //     this.timer += dt;
  //     if (this.timer >= this.waitTimer) {
  //       this.timer -= this.waitTimer;
  //       this.toWait = !this.toWait;
  //       this.x += this.xv * dt;
		// 	  this.y += this.yv * dt;
  //     }
		// } else {
  //     this.x += this.xv * dt;
		// 	this.y += this.yv * dt;
		// }
  //   if(this.toWarp){
  //     if (this.x + this.radius >= this.bound.x + this.bound.w) {
  //       this.x = this.bound.x * 2 + this.radius * 2;
  //       this.toWait = true;
  //     }
  //     else if (this.x - this.radius <= this.bound.x) {
  //       this.x = (this.bound.x + this.bound.w) * 2 - this.radius * 2;
  //       this.toWait = true;
  //     }
  //     if (this.y + this.radius >= this.bound.y + this.bound.h) {
  //       this.y = this.bound.y * 2 + this.radius * 2;
  //       this.toWait = true;
  //     }
  //     else if (this.y - this.radius <= this.bound.y) {
  //       this.y = (this.bound.y + this.bound.h) * 2 - this.radius * 2;
  //       this.toWait = true;
  //     }
  //   } else{
  //     if (this.x + this.radius >= this.bound.x + this.bound.w) {
  //       this.x = (this.bound.x + this.bound.w) * 2 - this.radius * 2;
  //       this.toWait = true;
  //     }
  //     else if (this.x - this.radius <= this.bound.x) {
  //       this.xv = -this.xv;
  //       this.x = this.bound.x * 2 - this.x + this.radius * 2;
  //       this.toWait = true;
  //     }
  //     if (this.y + this.radius >= this.bound.y + this.bound.h) {
  //       this.yv = -this.yv;
  //       this.y = (this.bound.y + this.bound.h) * 2 - this.y - this.radius * 2;
  //       this.toWait = true;
  //     }
  //     else if (this.y - this.radius <= this.bound.y) {
  //       this.yv = -this.yv;
  //       this.y = this.bound.y * 2 - this.y + this.radius * 2;
  //       this.toWait = true;
  //     }
  //   }
  // }
        if (this.toWait) {
            this.timer += dt;
            if (this.timer >= this.waitTimer) {
                let timeRemain = this.timer - this.waitTimer;
                this.timer = 0;
                this.toWait = !this.toWait;
                this.simulate(timeRemain);
            }
        } else {
            this.x += this.xv * dt;
            this.y += this.yv * dt;
        }
        if (this.toWarp) {
            if(this.toWait){
                return;
            }
            if(this.direction === 'horizontal'){
                if (this.x + this.radius >= this.bound.x + this.bound.w) {
                    this.x = this.radius + this.bound.x;
                    this.toWait = true;
                } else if (this.x - this.radius <= this.bound.x) {
                    this.x = this.bound.x + this.bound.w - this.radius;
                    this.toWait = true;
                }
            } else {
                if (this.y + this.radius >= this.bound.y + this.bound.h) {
                    this.y = this.bound.y + this.radius;
                    this.toWait = true;
                } else if (this.y - this.radius <= this.bound.y) {
                    this.y = this.bound.y + this.bound.h - this.radius;
                    this.toWait = true;
                }
            }
        } else {
            if(this.direction === 'horizontal'){
                if (this.x + this.radius >= this.bound.x + this.bound.w) {
                    this.xv = -this.xv;
                    this.x =
                        (this.bound.x + this.bound.w) * 2 -
                        this.x -
                        this.radius * 2;
                    this.toWait = true;
                } else if (this.x - this.radius <= this.bound.x) {
                    this.xv = -this.xv;
                    this.x = this.bound.x * 2 - this.x + this.radius * 2;
                    this.toWait = true;
                }
            } else {
                if (this.y + this.radius >= this.bound.y + this.bound.h) {
                    this.yv = -this.yv;
                    this.y =
                        (this.bound.y + this.bound.h) * 2 -
                        this.y -
                        this.radius * 2;
                    this.toWait = true;
                } else if (this.y - this.radius <= this.bound.y) {
                    this.yv = -this.yv;
                    this.y = this.bound.y * 2 - this.y + this.radius * 2;
                    this.toWait = true;
                }
            }
        }
	}
}

class EnemyGrav extends Normal {
	constructor(spawn) {
		super(spawn);
		this.auraStrength = spawn.data.auraStrength;
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
			auraStrength: this.auraStrength,
		}
	}
	simulate(dt, enemy) {
        for(let e of enemy){
            if(this.intersectingCircle(e, this)){
                const dx = e.x-this.x;
                const dy = e.y-this.y;
                if(dx === 0 && dy === 0){
                    continue;
                }
                const angle = Math.atan2(dy,dx);
                const vel = Math.sqrt(e.xv**2+e.yv**2);
                e.xv = Math.cos(angle)*vel//*this.auraStrength+e.xv*(1-this.auraStrength);
                e.yv = Math.sin(angle)*vel//*this.auraStrength+e.yv*(1-this.auraStrength);
            }
        }

        super.simulate(dt);
	}
    intersectingCircle(circle1, circle2) {
	    const c1R = circle1.radius ?? circle1.r;
    	const c2R = circle2.radius ?? circle2.r;
        return (
            (circle1.x - circle2.x) * (circle1.x - circle2.x) +
                (circle1.y - circle2.y) * (circle1.y - circle2.y) <
            (c1R+c2R) * (c1R+c2R)
        );
    }
}

class Dasher {
	constructor(spawn) {
		this.type = spawn.data.type;
		this.radius = spawn.data.radius;
		this.speed = spawn.data.speed;
		this.x = Math.round(Math.random() * (spawn.w - this.radius) + spawn.x + this.radius);
		this.y = Math.round(Math.random() * (spawn.h - this.radius) + spawn.y + this.radius);
		this.angle = Math.random() * Math.PI * 2;
		this.xv = Math.cos(this.angle) * this.speed;
		this.yv = Math.sin(this.angle) * this.speed;
		this.bound = { x: spawn.x, y: spawn.y, w: spawn.w, h: spawn.h }
		this.time = Math.random() * 2000;
		this.baseRadius = this.radius;
	}
	simulate(dt) { // dt -> seconds
		this.time += dt * 1000;

		this.radius = this.baseRadius * (1 + (Math.sin(this.time / 500) + 1)) / 2;
		this.x += this.xv * dt * (Math.cos(this.time / 500) + 1);

		if (this.x + this.radius >= this.bound.x + this.bound.w) {
			this.xv = -this.xv;
			this.x = (this.bound.x + this.bound.w) * 2 - this.x - this.radius * 2;
		}
		else if (this.x - this.radius <= this.bound.x) {
			this.xv = -this.xv;
			this.x = this.bound.x * 2 - this.x + this.radius * 2;
		}
		this.y += this.yv * dt * (Math.cos(this.time / 500) + 1);
		if (this.y + this.radius >= this.bound.y + this.bound.h) {
			this.yv = -this.yv;
			this.y = (this.bound.y + this.bound.h) * 2 - this.y - this.radius * 2;
		}
		else if (this.y - this.radius <= this.bound.y) {
			this.yv = -this.yv;
			this.y = this.bound.y * 2 - this.y + this.radius * 2;
		}
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
			time: this.time,
			baseRadius: this.baseRadius
		}
	}
}

class Turning {
	constructor(spawn) {
		this.type = spawn.data.type;
		this.radius = spawn.data.radius;
		this.speed = spawn.data.speed;
		this.bound = { x: spawn.x, y: spawn.y, w: spawn.w, h: spawn.h }
		this.x = Math.round(Math.random() * (spawn.w - spawn.data.radius) + spawn.x + spawn.data.radius);
		this.y = Math.round(Math.random() * (spawn.h - spawn.data.radius) + spawn.y + spawn.data.radius);
		this.angle = Math.random() * Math.PI * 2;
		this.xv = Math.cos(this.angle) * spawn.data.speed;
		this.yv = Math.sin(this.angle) * spawn.data.speed;
        if(spawn.data.changeDir == undefined){
          this.changeDir = 3;
        } else {
          this.changeDir = spawn.data.changeDir;
        }	
	}
	simulate(dt) {
		this.angle = Math.atan2(this.yv, this.xv);
		this.angle += dt * this.changeDir;
		this.xv = Math.cos(this.angle) * this.speed;
		this.yv = Math.sin(this.angle) * this.speed;
		this.x += this.xv * dt;

		if (this.x + this.radius >= this.bound.x + this.bound.w) {
			this.xv = -this.xv;
			this.x = (this.bound.x + this.bound.w) * 2 - this.x - this.radius * 2;
			this.changeDir = -this.changeDir;
		}
		else if (this.x - this.radius <= this.bound.x) {
			this.xv = -this.xv;
			this.x = this.bound.x * 2 - this.x + this.radius * 2;
			this.changeDir = -this.changeDir;
		}
		this.y += this.yv * dt;
		if (this.y + this.radius >= this.bound.y + this.bound.h) {
			this.yv = -this.yv;
			this.y = (this.bound.y + this.bound.h) * 2 - this.y - this.radius * 2;
			this.changeDir = -this.changeDir;
		}
		else if (this.y - this.radius <= this.bound.y) {
			this.yv = -this.yv;
			this.y = this.bound.y * 2 - this.y + this.radius * 2;
			this.changeDir = -this.changeDir;
		}
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
			angle: this.angle,
			changeDir: this.changeDir,
		}
	}
}


class Square {
	constructor(spawn) {
		this.type = spawn.data.type;
		this.size = spawn.data.size;
		this.radius = this.size / 2;
		this.speed = spawn.data.speed;
		this.x = Math.round(Math.random() * (spawn.w - this.radius) + spawn.x + this.radius);
		this.y = Math.round(Math.random() * (spawn.h - this.radius) + spawn.y + this.radius);
		this.angle = Math.random() * Math.PI * 2;
		this.xv = Math.cos(this.angle) * this.speed;
		this.yv = Math.sin(this.angle) * this.speed;
		this.bound = { x: spawn.x, y: spawn.y, w: spawn.w, h: spawn.h }
	}
	simulate(dt) {
		this.x += this.xv * dt;

		if (this.x + this.radius >= this.bound.x + this.bound.w) {
			this.xv = -this.xv;
			this.x = (this.bound.x + this.bound.w) * 2 - this.x - this.radius * 2;
		}
		else if (this.x - this.radius <= this.bound.x) {
			this.xv = -this.xv;
			this.x = this.bound.x * 2 - this.x + this.radius * 2;
		}
		this.y += this.yv * dt;
		if (this.y + this.radius >= this.bound.y + this.bound.h) {
			this.yv = -this.yv;
			this.y = (this.bound.y + this.bound.h) * 2 - this.y - this.radius * 2;
		}
		else if (this.y - this.radius <= this.bound.y) {
			this.yv = -this.yv;
			this.y = this.bound.y * 2 - this.y + this.radius * 2;
		}
	}
	pack() {
		return {
			type: this.type,
			size: this.size,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
		}
	}
}

let polygonColors = {};

function generateRandomColor() {
  var letters = '0123456789ABCDEF';
  var color = '#';
  for (var i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
}

class Polygon {
	constructor(spawn) {
		this.type = spawn.data.type;
		this.size = spawn.data.size;
        this.sides = spawn.data.sides;
		this.radius = Math.sqrt((this.size * Math.sin(0))**2+(this.size * Math.cos(0))**2);
		this.speed = spawn.data.speed;
		this.angle = Math.random() * Math.PI * 2;
		this.xv = Math.cos(this.angle) * this.speed;
		this.yv = Math.sin(this.angle) * this.speed;
		this.bound = { x: spawn.x, y: spawn.y, w: spawn.w, h: spawn.h }
        this.rotateSpeed = spawn.data.rotateSpeed;
        this.rotateAngle = spawn.data.startAngle;
        if(!polygonColors[this.sides]){
            polygonColors[this.sides] = generateRandomColor();
        }
        this.color = polygonColors[this.sides];
        if(!this.rotateSpeed){
            this.rotateSpeed = 0;
        }
        if(!this.rotateAngle){
            this.rotateAngle = 0;
        }
        this.points = [];        
        for (let i = 0; i <= this.sides; i++) {
                this.points.push([- this.size * Math.sin(i * 2 * Math.PI / this.sides + this.rotateAngle),-this.size * Math.cos(i * 2 * Math.PI / this.sides + this.rotateAngle)]);
        }
        this.x = Math.round(Math.random() * (spawn.w - this.radius) + spawn.x + this.radius);
		this.y = Math.round(Math.random() * (spawn.h - this.radius) + spawn.y + this.radius);
	}
	simulate(dt) {
        // rotation
        if(this.rotateSpeed !== 0){
            this.rotateAngle += this.rotateSpeed * dt;
            this.points = [];        
            for (let i = 0; i <= this.sides; i++) {
                    this.points.push([-this.size * Math.sin(i * 2 * Math.PI / this.sides + this.rotateAngle),-this.size * Math.cos(i * 2 * Math.PI / this.sides + this.rotateAngle)]);
            }
        }
        
		this.x += this.xv * dt;

		if (this.x + this.radius >= this.bound.x + this.bound.w) {
			this.xv = -this.xv;
			this.x = (this.bound.x + this.bound.w) * 2 - this.x - this.radius * 2;
		}
		else if (this.x - this.radius <= this.bound.x) {
			this.xv = -this.xv;
			this.x = this.bound.x * 2 - this.x + this.radius * 2;
		}
		this.y += this.yv * dt;
		if (this.y + this.radius >= this.bound.y + this.bound.h) {
			this.yv = -this.yv;
			this.y = (this.bound.y + this.bound.h) * 2 - this.y - this.radius * 2;
		}
		else if (this.y - this.radius <= this.bound.y) {
			this.yv = -this.yv;
			this.y = this.bound.y * 2 - this.y + this.radius * 2;
		}
	}
	pack() {
		return {
			type: this.type,
			size: this.size,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
            sides: this.sides,
            points: this.points,
            rotateSpeed: this.rotateSpeed,
            rotateAngle: this.rotateAngle,
            color: this.color,
		}
	}
}

// just a circular moving obs or something to parent other enemies to for movement :>
class MovingEnemy {
	constructor(spawn) {
		// console.log('spawn', spawn)
		this.type = 'enemymove';
		this.currentPoint = spawn.data.currentPoint;
		this.points = spawn.data.points;
		this.speed = spawn.data.speed;
		this.radius = spawn.data.radius;
		this.x = this.points[spawn.data.currentPoint][0];
		this.y = this.points[spawn.data.currentPoint][1];
		this.angle = 0;
		this.xv = this.speed;
		this.yv = 0;
	}
	simulate(dt) {
		let nextPointIndex = this.currentPoint + 1;
		if (nextPointIndex >= this.points.length) {
			nextPointIndex = 0;
		}
		let nextPoint = this.points[nextPointIndex];
		let currentPoint = this.points[this.currentPoint];
		this.pointTo = { x: nextPoint[0], y: nextPoint[1] };
		this.pointOn = { x: currentPoint[0], y: currentPoint[1] };
		this.angle = Math.atan2(this.pointTo.y - this.pointOn.y, this.pointTo.x - this.pointOn.x);
		this.xv = Math.cos(this.angle) * this.speed;
		this.yv = Math.sin(this.angle) * this.speed;
		this.x += this.xv * dt;
		this.y += this.yv * dt;
		let timeRemain = 0;
		let over = false;
		if (Math.abs(this.yv) > Math.abs(this.xv)) {
			if (this.pointTo.y > this.pointOn.y) {
				if (this.y > this.pointTo.y) {
					over = true;
				}
			}
			else {
				if (this.y < this.pointTo.y) {
					over = true;
				}
			}
		}
		else {
			if (this.pointTo.x > this.pointOn.x) {
				if (this.x > this.pointTo.x) {
					over = true;
				}
			}
			else {
				if (this.x < this.pointTo.x) {
					over = true;
				}
			}
		}
		if (over == true) {
			this.currentPoint++;
			if (this.currentPoint > this.points.length - 1) {
				this.currentPoint = 0;
			}
			timeRemain = Math.sqrt(Math.pow(this.y - this.pointTo.y, 2) + Math.pow(this.x - this.pointTo.x, 2));
			this.x = this.pointTo.x;
			this.y = this.pointTo.y;
			timeRemain /= this.speed;
			this.pointOn = this.points[this.state];

			this.simulate(timeRemain)
		}
	}
	pack() {
		return {
			x: this.x,
			y: this.y,
			radius: this.radius,
			type: this.type,
			points: this.points,
			speed: this.speed,
			currentPoint: this.currentPoint,
            bound: {x: 0, y: 0, w: 0, h: 0}// enemy won't be bounded
		}
	}
}

class SwitchAccel extends Normal {
	constructor(spawn) {
		super(spawn);
        this.firstSpeed = spawn.data.firstSpeed;
        this.secondSpeed = spawn.data.secondSpeed;
        if(this.firstSpeed > this.secondSpeed){
            let storageFirst = this.firstSpeed;
            this.firstSpeed = this.secondSpeed;
            this.secondSpeed = storageFirst;
        }
        this.speed = spawn.data.startingSpeed||this.firstSpeed + Math.random()*(this.secondSpeed-this.firstSpeed);
        this.accelAmount = spawn.data.accelAmount;
        this.normalized = {
            xv: Math.cos(this.angle),
            yv: Math.sin(this.angle),
        }
        // false = down, true = start increasing speed
        this.startingDirection = spawn.data.startingDirection||false;
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
			firstSpeed: this.speed,
            secondspeed: this.secondSpeed,
            accelAmount: this.accelAmount,
            startingDirection: this.startingDirection,
		}
	}
	simulate(dt) {
        if(this.startingDirection === true){
            this.speed += dt*this.accelAmount;
            if(this.speed >= this.secondSpeed){
                this.startingDirection = false;
                const excess = this.speed-this.secondSpeed;
                this.speed = this.secondSpeed-excess;
            }
        } else {
            this.speed -= dt*this.accelAmount;
            if(this.speed <= this.firstSpeed){
                this.startingDirection = true;
                const excess = this.firstSpeed-this.speed;
                this.speed = this.firstSpeed+excess;
            }
        }
        
        this.xv = this.normalized.xv*this.speed;
        this.yv = this.normalized.yv*this.speed;

        let touchedBound = false;
        this.x += this.xv * dt;
		if (this.x + this.radius >= this.bound.x + this.bound.w) {
            this.xv = -this.xv;
            this.x =
                (this.bound.x + this.bound.w) * 2 -
                this.x -
                this.radius * 2;
            touchedBound = true;
        } else if (this.x - this.radius <= this.bound.x) {
            this.xv = -this.xv;
            this.x = this.bound.x * 2 - this.x + this.radius * 2;
            touchedBound = true;
        }
        this.y += this.yv * dt;
        if (this.y + this.radius >= this.bound.y + this.bound.h) {
            this.yv = -this.yv;
            this.y =
                (this.bound.y + this.bound.h) * 2 -
                this.y -
                this.radius * 2;
            touchedBound = true;
        } else if (this.y - this.radius <= this.bound.y) {
            this.yv = -this.yv;
            this.y = this.bound.y * 2 - this.y + this.radius * 2;
            touchedBound = true;
        }
        if(touchedBound === true){
            this.angle = Math.atan2(this.yv, this.xv);
            this.normalized = {
                xv: Math.cos(this.angle),
                yv: Math.sin(this.angle),
            }
        }
	}
}

class Switch extends Normal {
	constructor(spawn) {
		super(spawn);
		this.currentSwitch = false;
		if (Math.random() < 0.5) {
			this.currentSwitch = true;
		}
		if (spawn.data.defaultSwitch != undefined) {
			this.currentSwitch = spawn.data.defaultSwitch;
		}
		this.switchTime = spawn.data.time;
		this.switchTimer = 0;
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
			switchTime: this.switchTime,
			switchTimer: this.switchTimer,
			currentSwitch: this.currentSwitch,
		}
	}
	simulate(dt) {
		this.switchTimer += dt;
		if (this.switchTimer >= this.switchTime) {
			this.switchTimer -= this.switchTime;
			this.currentSwitch = !this.currentSwitch;
		}

		this.x += this.xv * dt;

		if (this.x + this.radius >= this.bound.x + this.bound.w) {
			this.xv = -this.xv;
			this.x = (this.bound.x + this.bound.w) * 2 - this.x - this.radius * 2;
		}
		else if (this.x - this.radius <= this.bound.x) {
			this.xv = -this.xv;
			this.x = this.bound.x * 2 - this.x + this.radius * 2;
		}
		this.y += this.yv * dt;
		if (this.y + this.radius >= this.bound.y + this.bound.h) {
			this.yv = -this.yv;
			this.y = (this.bound.y + this.bound.h) * 2 - this.y - this.radius * 2;
		}
		else if (this.y - this.radius <= this.bound.y) {
			this.yv = -this.yv;
			this.y = this.bound.y * 2 - this.y + this.radius * 2;
		}
	}
}

class TP extends Normal {
	constructor(spawn) {
		super(spawn);
		this.teleportTime = spawn.data.time;
		this.teleportTimer = 0;
		this.previewX = this.x;
		this.previewY = this.y;
	}
	simulate(dt) {
		this.teleportTimer += dt;
		if (this.teleportTimer >= this.teleportTime) {
			this.teleportTimer -= this.teleportTime;
			this.x = this.previewX;
			this.y = this.previewY;
		}

		this.previewX += this.xv * dt;

		if (this.previewX + this.radius >= this.bound.x + this.bound.w) {
			this.xv = -this.xv;
			this.previewX = (this.bound.x + this.bound.w) * 2 - this.previewX - this.radius * 2;
		}
		else if (this.previewX - this.radius <= this.bound.x) {
			this.xv = -this.xv;
			this.previewX = this.bound.x * 2 - this.previewX + this.radius * 2;
		}
		this.previewY += this.yv * dt;
		if (this.previewY + this.radius >= this.bound.y + this.bound.h) {
			this.yv = -this.yv;
			this.previewY = (this.bound.y + this.bound.h) * 2 - this.previewY - this.radius * 2;
		}
		else if (this.previewY - this.radius <= this.bound.y) {
			this.yv = -this.yv;
			this.previewY = this.bound.y * 2 - this.previewY + this.radius * 2;
		}
	}
	pack() {
		return {
			type: this.type,
			radius: this.radius,
			speed: this.speed,
			x: this.x,
			y: this.y,
			angle: this.angle,
			xv: this.xv,
			yv: this.yv,
			bound: this.bound,
			previewX: this.previewX,
			previewY: this.previewY,
			teleportTimer: this.teleportTimer,
			teleportTime: this.teleportTime,
		}
	}
}

const enemyTypes = require('./enemyTypes.js');

class Spawner {
	constructor(x, y, w, h, spawnOptions) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.data = spawnOptions;
	}
	spawn(dontDelete, pushIndex=0) {
        // keep track
        let enemy;
        enemy = eval(enemyTypes(this.data.type));
        if(!dontDelete){
            delete enemy.x;
            delete enemy.y;
            delete enemy.angle;
            delete enemy.xv;
            delete enemy.yv;   
        }
        // parent id is the id for child id; child id is what parent id to parent to
        if(this.data.parentId > -1){
            enemy.parentId = this.data.parentId;
            const po = this.data.pushIndexOffset||0;
            enemy.pushIndex = pushIndex+po;
        }
        if(this.data.childId > -1){
            if(this.data.type !== 'rotatearoundparent'){
                enemy.childId = this.data.childId;
            }
            const po = this.data.pushIndexOffset||0;
            enemy.pushIndex = pushIndex+po;
        }
        if(this.data.switchChildId){
            enemy.switchChildId = this.data.switchChildId;
            enemy.switchChildIndex = 0;
            enemy.switchChildTimer = enemy.switchChildId[0][1];
        }
        if(this.data.switchParentId){
            enemy.switchParentId = this.data.switchParentId;
            enemy.switchParentIndex = 0;
            enemy.switchParentTimer = enemy.switchParentId[0][1];
        }
        if(this.data.simulateBound){
            enemy.simulateBound = this.data.simulateBound;
        }
        if(this.data.x){
            enemy.x = this.data.x;
        }
        if(this.data.y){
            enemy.y = this.data.y;
        }
        return enemy;
	}
}

module.exports = { 
    Normal,
    Square,
    Switch,
    TP,
    Dasher, 
    GravAura, 
    Turning, 
    EnemyGrav, 
    Rain, 
    Flashlight,
    Memory,
    Flower, 
    Shh,
    Turret,
    Growing,
    Accelerating,
    Wind,
    Polygon,
    Wavy,
    Bomb,
    Jumping,
    Outline,
    Slower,
    SelfCollide,
    Spawn,
    Fire,
    Boomerang,
    Oval,
    GrowingOval,
    E2Dasher,
    RadiusChange,
    TpPlayer,
    ForceMove,
    ForceStop,
    NoKill,
    PointAccel,
    RotateAroundParent,
    Repel,
    MovingEnemy,
    EnemyObstacle,
    Toxic,
    FollowAxis,
    ComboEnemy,
    ReflectBullet,
    Sticky,
    KillEnemy,
    Oscillating,
    SwitchAccel
}