	const Discord = require('discord.js');
const Canvas = require('canvas');

const normalWebhook = new Discord.WebhookClient({
    url: 'https://discord.com/api/webhooks/924136767911772160/ypZyOQx0YNLeLeaZk5NTAci_4DbFy2ml_3T0dc0F4A5OyKJOtRlfDDg2dS6qXyM7NVK3'
});
const hardWebhook = new Discord.WebhookClient({
    url: 'https://discord.com/api/webhooks/924136860119359498/9ajRqB88yx8SPt2AnH1Skza4_BSLONiyM3ORvD6ryzEHrnHs1Rp1aQumKcnQ9Wp0Puyy'
});


const peacefulImgLoad = Canvas.loadImage('https://media.discordapp.net/attachments/845356415680774146/928350973775192135/canvas-preview.png');

let difficultyImages = {
  "Peaceful": {
    load: Canvas.loadImage('https://media.discordapp.net/attachments/921945583365791825/928387592335015966/image.jpg'),
    img: null
  },
  "Moderate": {
    load: Canvas.loadImage('https://media.discordapp.net/attachments/921945583365791825/928389046206611536/modbgblur.jpg'),
    img: null
  },
  "Difficult": {
    load: Canvas.loadImage('https://media.discordapp.net/attachments/921945583365791825/928420012820135956/difficultbg2.jpg'),
    img: null
  },
  "Hardcore": {
    load: Canvas.loadImage('https://media.discordapp.net/attachments/921945583365791825/928392421778268160/hardcorebgblur.jpg'),
    img: null
  },
  "Exhausting": {
    load: Canvas.loadImage('https://media.discordapp.net/attachments/921945583365791825/928400553594208266/exhaustingbgblur.jpg'),
    img: null
  },
  "Relentless": {
    load: Canvas.loadImage('https://media.discordapp.net/attachments/921945583365791825/928409225917521930/relentlessbg2.jpg'),
    img: null
  },
  "Agonizing": {
    load: Canvas.loadImage('https://media.discordapp.net/attachments/921945583365791825/928402154622976060/agonizingbg.jpg'),
    img: null
  },
  "Terrorizing": {
    load: Canvas.loadImage('https://media.discordapp.net/attachments/921945583365791825/928402820430979163/terrorizingBg.jpg'),
    img: null
  },
  "Cataclysmic": {
    load: Canvas.loadImage('https://media.discordapp.net/attachments/921945583365791825/928403587845996614/catabg.jpg'),
    img: null
  },
  
}
for(let i of Object.keys(difficultyImages)){
  difficultyImages[i].load.then((e) => {
    difficultyImages[i].img = e;
    //console.log(i + " has been loaded!")
  }).catch((err) => {
    //console.log(i + " could not be loaded: "+err)
  })
}

//https://media.discordapp.net/attachments/921945583365791825/928387592335015966/image.jpg

let difficultyEmotes = {
    "Peaceful": "<:peaceful:926677284088315964>",
    "Moderate": "<:moderate:926677403156246568>",
    "Difficult": "<:difficult:926696408487182336>",
    "Hardcore": "<:hardcore:926696564276219965>",
    "Exausting": "<:exhausting:926696771881664532>",
    "Relentless": "<:relentless:926696771755855934>",
    "Agonizing": "<:agonizing:922658786647343135>",
    "Terrorizing": "<:terrorizing:922658817739747338>",
    "Cataclysmic": "<:cataclysmic:922660115688063016>"
};
let difficultyColors = {
    "Peaceful": "#6cd95b",
    "Moderate": "#58ccb3",
    "Difficult": "#0a77bf",
    "Hardcore": "#3528e0",
    "Exhausting": "#8248d4",
    "Relentless": "#e32d8b",
    "Agonizing": "#ff5736",
    "Terrorizing": "#fc3a3a",
    "Cataclysmic": "#c95d5d"
}


function sendMessageFunction(player, map, time, difficulty, webhook, solo, legit) {
    return new Promise(resolve => {
        const canvas = Canvas.createCanvas(800, 400);
        const ctx = canvas.getContext('2d');
        // make color of background the difficulty color
        //im doing something more epic this is just a placeholder for now so wins can be logged
        ctx.drawImage(difficultyImages[difficulty].img, 0, 0, canvas.width, canvas.height);
        ctx.fillStyle = "black";
        ctx.textAlign = "center";
        ctx.lineWidth = 6;
        ctx.fillStyle = difficultyColors[difficulty];
        ctx.strokeStyle = "black";
        ctx.font = "bold 20px Tahoma, Verdana, Segoe, sans-serif";
        //placeholder
        ctx.strokeText(`= ${difficulty} =`, 400, 20);
        ctx.fillText(`= ${difficulty} =`, 400, 20);
        ctx.font = "bold 50px Tahoma";
        ctx.strokeText(`${player}`, 400, 130)
        ctx.fillText(`${player}`, 400, 130)
        ctx.font = "bold 25px Tahoma";
        ctx.strokeText("has beaten", 400, 165);
        ctx.fillText("has beaten", 400, 165);
        ctx.font = "bold 30px Tahoma";
        ctx.strokeText(`${map}`, 400, 200);
        ctx.fillText(`${map}`, 400, 200);
        ctx.font = "bold 40px Tahoma";
        ctx.strokeText(`${time}`, 400, 305);
        ctx.fillText(`${time}`, 400, 305);

        if (solo){
          ctx.strokeText(`SOLO`, 90, 50);
          ctx.fillText(`SOLO`, 90, 50);
        }
        if (!legit){
          ctx.fillStyle = "red";
          ctx.strokeText(`NOT LEGIT`, 140, 380);
          ctx.fillText(`NOT LEGIT`, 140, 380);
        }
        
        ctx.textAlign = "right";
        ctx.font = "bold 20px Tahoma";
        ctx.lineWidth = 4;
        ctx.fillStyle = difficultyColors[difficulty];
        ctx.strokeText(`16x`, 785, 385);
        ctx.fillText(`16x`, 785, 385);


        const attachment = new Discord.MessageAttachment(canvas.toBuffer(), 'winner.png');
        webhook.send({
            "files": [attachment]
        });
        resolve();
    });
}

async function sendMessage(player, map, time, difficulty, webhook, solo, legit) {
    await sendMessageFunction(player, map, time, difficulty, webhook, solo, legit);
}


module.exports = { sendMessage, difficultyColors, normalWebhook, hardWebhook};