const { TransObstacle, NormalObstacle, BouncyObstacle,
  CircularNormalObstacle, CircularBouncyObstacle,
  Lava, RotatingLava, SpeedObstacle, GravObstacle,
  Checkpoint, Tp, MovingObstacle, StoryDisplay, MovingLavaObstacle, Pusher,Winpad, Booster, WallBooster, SpeedTrap, RotatingTp, SizePlayer } = require("./obstacle.js");
// contains every obstacle in existence 
module.exports = function stringToObject(str) {
	return eval(str);
}