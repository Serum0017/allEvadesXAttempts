const WebSocket = require('ws');
const express = require('express');
const path = require('path');
const axios = require('axios');
const url = require('url');
const Account = require('./models/account.js');

module.exports = function setupServer() {
    const wss = new WebSocket.Server({
        noServer: true,
    });
    const app = express();
    const PORT = process.env.PORT || 6969;
    const server = app.listen(PORT, () =>
        console.log(`Server started on Port ${PORT}`)
    );
    // fetch('./physics.js').then((e) => {
    //     console.log(e);
    // });
    app.use(express.static('src/client'));
    app.get('/', (request, result) => {
        result.sendFile(path.join(__dirname, '../client/index.html'));
    });
    app.get('/shared/:fileName', (request, result) => {
        result.sendFile(
            path.join(__dirname, String('../shared/' + request.params.fileName))
        );
    });
    app.get('/accounts', (request, result) => {
        Account.find()
            .then((dbResult) => {
                result.send(dbResult);
            })
            .catch((err) => console.log(err));
    });
	app.get('/sounds/:fileName', (request, result) => {
        console.log(request.params.fileName);
        result.sendFile(
            path.join(__dirname, String('../client/sounds/' + request.params.fileName))
        );
		// result.redirect('https://x-sounds.zerotixdev.repl.co/sounds/' + request.params.fileName)
	})
	// app.get('/gfx/:fileName', (request, result) => {
		
	// 	// console.log('https://evade.zerotixdev.repl.co/gfx/' + request.params.fileName)
	// 	result.redirect('https://evade.zerotixdev.repl.co/gfx/' + request.params.fileName)
	// })
    app.get('/editor', (request, result) => {
        result.redirect('https://x-editor.zerotixdev.repl.co');
    });
    app.get('/auth/discord', async (request, res) => {
        const { code } = request.query;
        if (code) {
            try {
                const formData = new url.URLSearchParams({
                    client_id: process.env.discord_client_id,
                    client_secret: process.env.discord_client_secret,
                    grant_type: 'authorization_code',
                    code: code.toString(),
                    redirect_uri:
                        'https://evade.zerotixdev.repl.co/auth/discord/',
                });
                // console.log(formData);
                const response = await axios.post(
                    'https://discord.com/api/v9/oauth2/token',
                    formData.toString(),
                    {
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                    }
                );
                const { access_token } = response.data;
                console.log('access token', access_token);
                const site = await axios.get(
                    'https://discord.com/api/v9/users/@me',
                    {
                        headers: {
                            Authorization: `Bearer ${access_token}`,
                        },
                    }
                );
                console.log(site.data, 'site');
                // const name = site.data.username + '#' + site.data.discriminator;
                res.redirect(
                    `https://evade.zerotixdev.repl.co/?name=${site.data.username}&disc=${site.data.discriminator}`
                );
            } catch (err) {
                // console.log(err);
                res.sendStatus(400);
            }
        }
    });
    // app.get('/editor', (request, result) => {
    // 	result.redirect('/editor/index.html');
    // })
    // app.get('/editor/:fileName', (request, result) => {
    // 	result.sendFile(path.join(__dirname, String('../editor/' + (request.params.fileName === '' ? 'index.html': request.params.fileName))));
    // });
    // https://discord.com/api/oauth2/authorize?client_id=948564964275261451&redirect_uri=https%3A%2F%2Fevade.zerotixdev.repl.co%2Fauth%2Fdiscord%2F&response_type=code&scope=identify%20email
    server.on('upgrade', (request, socket, head) => {
        wss.handleUpgrade(request, socket, head, (socket) => {
            wss.emit('connection', socket, request);
        });
    });
    return wss;
};
