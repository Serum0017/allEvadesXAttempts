const { Normal, Square, Switch, TP, Dasher, GravAura, Turning, EnemyGrav, Rain, Flashlight, Memory, Flower, Shh, Turret, Growing, Accelerating, Wind, Polygon, Wavy, Bomb, Jumping, Outline, Slower, SelfCollide, Spawn, Fire, Boomerang, Oval, GrowingOval, E2Dasher, RadiusChange, TpPlayer, ForceMove, ForceStop, NoKill, PointAccel, Repel, RotateAroundParent, MovingEnemy, EnemyObstacle, Toxic, FollowAxis, ComboEnemy, ReflectBullet, KillEnemy, Sticky, Oscillating, SwitchAccel } = require('./enemy.js');

const enemyTypes = require('./enemyTypes.js');

module.exports = class Spawner {
	constructor(x, y, w, h, spawnOptions) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.data = spawnOptions;
		// { type, radius, speed, amount }
	}
	spawn(enemy, map) {
		for (let i = 0; i < this.data.amount; i++) {
            enemy.push(eval(enemyTypes(this.data.type, this)));
            // parent id is the id for child id; child id is what parent id to parent to
            // pushIndex is the number for which the enemy is pushed out of its respective spawner so that we can have 2 spawners with 10 enemies not be paired up onto the last enemy
            if(this.data.parentId && this.data.parentId > 0){
                enemy[enemy.length-1].parentId = this.data.parentId;
                const po = this.data.pushIndexOffset||0;
                enemy[enemy.length-1].pushIndex = i+po;
            }
            if(this.data.childId && this.data.childId > 0){
                if(this.data.type !== 'rotatearoundparent'){
                    enemy[enemy.length-1].childId = this.data.childId;    
                }
                const po = this.data.pushIndexOffset||0;
                enemy[enemy.length-1].pushIndex = i+po;
            }
            if(this.data.switchChildId){
                enemy[enemy.length-1].switchChildId = this.data.switchChildId;
                enemy[enemy.length-1].switchChildIndex = 0;
                enemy[enemy.length-1].switchChildTimer = enemy[enemy.length-1].switchChildId[0][1];
            }
            if(this.data.switchParentId){
                enemy[enemy.length-1].switchParentId = this.data.switchParentId;
                enemy[enemy.length-1].switchParentIndex = 0;
                enemy[enemy.length-1].switchParentTimer = enemy[enemy.length-1].switchParentId[0][1];
            }
            if(this.data.simulateBound){
                enemy[enemy.length-1].simulateBound = this.data.simulateBound;
            }
            if(this.data.x){
                enemy[enemy.length-1].x = this.data.x;
            }
            if(this.data.y){
                enemy[enemy.length-1].y = this.data.y;
            }
		}
	}
}