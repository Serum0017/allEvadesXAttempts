module.exports = class ThreeDPlayer {
	constructor(player, map) {
        Object.assign(this,player);
        let otherFunctions = this.getAllMethodNames(player);
        // dynamically getting all functions
        for(let f of otherFunctions){
            if(!["constructor","__defineGetter__","__defineSetter__","hasOwnProperty","__lookupGetter__","__lookupSetter__","isPrototypeOf","propertyIsEnumerable","toString","valueOf","__proto__","toLocaleString"].includes(f) && this[f] === undefined){
                this[f] = player[f];
            }
        }
        this.z = map.playerSpawn.z||0
		// technically z is the opposite (y is x, x is z)
        this.clientZ = this.z;
        this.jumpForce = map.jumpForce||200;
        this.threeDgravity = map.gravity||30;
        this.spawn.z = map.playerSpawn.z||0;
        this.is3D = true;
	}
    getAllMethodNames(obj) {
        let methods = [];
        while (obj = Reflect.getPrototypeOf(obj)) {
            let keys = Reflect.ownKeys(obj)
            keys.forEach((k) => methods.push(k));
        }
        return methods;
    }
    respawn() {
		this.dead = false;
		this.clientX = this.spawn.x;
		this.clientY = this.spawn.y;
        this.clientZ = this.spawn.z;
	}
	tp(x, y, z) {
		this.clientX = x;
		this.clientY = y;
        this.clientZ = z;
		this.dead = false;
	}
	update() {
		this.x = this.clientX;
		this.y = this.clientY;
        this.z = this.clientZ;
	}
	setData(data) {
        this.clientX = data[0];
        this.clientY = data[1];
        this.clientZ = data[2];
	}
	pack() {
		return {
			x: Math.round(this.x * 10) / 10,
			y: Math.round(this.y * 10) / 10,
            z: Math.round(this.z * 10) / 10,
			fric: this.fric,
			radius: this.radius,
			name: this.name,
			speed: this.speed,
			dead: this.dead,
			spawn: this.spawn,
			dev: this.dev,
			god: this.god,
            powerups: this.powerups,
            clones: this.clones,
            ship: this.ship,
            tagged: this.tagged,
			deathTimer: this.deathTimer,
            bullets: this.bullets,
			ping: this.ping,
            jumpForce: this.jumpForce,
            threeDgravity: this.threeDgravity,
		}
	}
}