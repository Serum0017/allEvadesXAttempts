class NormalObstacle3D {
	constructor(x, y, z, w, h, d) {
		this.x = x;
		this.y = y;
        this.z = z;
		this.w = w;
		this.h = h;
        this.d = d;
		this.type = 'normal3D';
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
            z: this.z,
			w: this.w,
			h: this.h,
            d: this.d,
			type: this.type,
		}
	}
}

class Lava3D {
	constructor(x, y, z, w, h, d, collidable=true) {
		this.x = x;
		this.y = y;
        this.z = z;
		this.w = w;
		this.h = h;
        this.d = d;
		this.type = 'lava3D';
        this.collidable = collidable;
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
            z: this.z,
			w: this.w,
			h: this.h,
            d: this.d,
			type: this.type,
            collidable: this.collidable,
		}
	}
}

class Winpad3D {
	constructor(x, y, z, w, h, d) {
		this.x = x;
		this.y = y;
        this.z = z;
		this.w = w;
		this.h = h;
        this.d = d;
		this.type = "winpad3D";
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
            z: this.z,
			w: this.w,
			h: this.h,
            d: this.d,
			type: this.type,
		}
	}
}

module.exports = {
	NormalObstacle3D,
    Lava3D,
    Winpad3D
};