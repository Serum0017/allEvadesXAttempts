
module.exports = (type, data) => {
    switch(type) {
        case 'normal':
            return 'new Normal(this)'
        case 'square':
            return 'new Square(this)'
        case 'switch':
            return 'new Switch(this)'
        case 'tp':
            return 'new TP(this)'
        case 'dasher':
            return 'new Dasher(this)'
        case 'e2dasher':
            return 'new E2Dasher(this)'
        case 'gaura':
            return 'new GravAura(this)'
        case 'turning':
            return 'new Turning(this)'
        case 'enemygrav':
            return 'new EnemyGrav(this)'
        case 'rain':
            return 'new Rain(this)'
        case 'flashlight':
            return 'new Flashlight(this)'
        case 'memory':
            return 'new Memory(this)'
        case 'flower':
            return 'new Flower(this)'
        case 'shh':
            return 'new Shh(this)'
        case 'turret':
            return 'new Turret(this)'
        case 'growing':
            return 'new Growing(this)'
        case 'accelerating':
            return 'new Accelerating(this)'
        case 'wind':
            return 'new Wind(this)'
        case 'polygon':
            return 'new Polygon(this)'
        case 'wavy':
            return 'new Wavy(this)'
        case 'bomb':
            return 'new Bomb(this)'
        case 'jump':
            return 'new Jumping(this)'
        case 'outline':
            return 'new Outline(this)'
        case 'slower':
            return 'new Slower(this)'
        case 'selfcollide':
            return 'new SelfCollide(this)'
        case 'spawn':
            return 'new Spawn(this)'
        case 'boomerang':
            return 'new Boomerang(this)'
        case 'oval':
            return 'new Oval(this)'
        case 'growingoval':
            return 'new GrowingOval(this)'
        case 'repel':
            return 'new Repel(this)'
        case 'rotatearoundparent':
            return 'new RotateAroundParent(this)'
        case 'enemymove':
            return 'new MovingEnemy(this)'
        case 'enemyobstacle':
            return 'new EnemyObstacle(this)'
        case 'toxic':
            return 'new Toxic(this)'
        case 'fire':
            return 'new Fire(this)'
        case 'tpplayer':
            return 'new TpPlayer(this)'
        case 'followaxis':
            return 'new FollowAxis(this)'
        case 'pointaccel':
            return 'new PointAccel(this)'
        case 'combo':
            return 'new ComboEnemy(this)'
        case 'reflectbullet':
            return 'new ReflectBullet(this)'
        case 'sticky':
            return 'new Sticky(this)'
        case 'killenemy':
            return 'new KillEnemy(this)'
        case 'oscillating':
            return 'new Oscillating(this)'
        case 'switchaccel':
            return 'new SwitchAccel(this)'
        default:
            return 'new Normal(this)'
    }
}