const Obstacles = require("./obstacle.js");
const Spawner = require('./spawner.js');
const Safe = require('./safe.js');
const Text = require('./text.js');

module.exports = function parseAddedObstacles(obstacles) {
	try {
        const d = obstacles.replaceAll("\/","");
		const data = JSON.parse(d);
		
		let obs = '';
		for (const ob of data) {
            let props = [];
            let obsName = ''
			if(ob.type == 'normal'){
                obsName = 'NormalObstacle';
                props = [ob.x,ob.y,ob.w,ob.h];
                if(ob.canJump == false){
                    props.push(false);
                }
            } else if(ob.type == 'lava'){
                obsName = 'Lava';
                props = [ob.x,ob.y,ob.w,ob.h,/*ob.canCollide || false*/ true];
            } else if(ob.type == 'size'){
                obsName = 'SizePlayer';
                props = [ob.x,ob.y,ob.w,ob.h,ob.size];
            } else if(ob.type == 'vinette'){
                obsName = 'VinetteIncrease';
                props = [ob.x,ob.y,ob.w,ob.h,ob.ir,ob.or,ob.o];
            } else if(ob.type == 'check'){
                obsName = 'Checkpoint';
                props = [ob.x,ob.y,ob.w,ob.h];
            } else if(ob.type == 'tp'){
                obsName = 'Tp';
                props = [ob.x,ob.y,ob.w,ob.h,ob.tpx,ob.tpy];
                if(ob.bgColor != undefined && ob.tileColor != undefined) {
                    props.push("'"+ob.bgColor+"'")
                    props.push("'"+ob.tileColor+"'");
                    props.push(true);
                }
            } else if(ob.type == 'circle-tp'){
                obsName = 'CircularTpObstacle';
                props = [ob.x,ob.y,ob.r,ob.tpx,ob.tpy];
            } else if(ob.type == 'color'){
                obsName = 'ColorChange';
                props = [ob.x,ob.y,ob.w,ob.h,"'"+ob.bgColor+"'","'"+ob.tileColor+"'"];
            } else if(ob.type == 'zombie'){
                obsName = 'ZombieMaker';
                props = [ob.x,ob.y,ob.w,ob.h,ob.timeBetween,ob.dist];
            } else if(ob.type == 'switchgrav'){
                obsName = 'SwitchGrav';
                props = [ob.x,ob.y,ob.w,ob.h,JSON.stringify(ob.dirs)];
            } else if(ob.type == 'revive'){
                // transposing to safe
                obs += `safes.push(new Safe(${ob.x},${ob.y},${ob.w},${ob.h}))\n`
                //obsName = 'Revive';
                //props = [ob.x,ob.y,ob.w,ob.h];
            } else if(ob.type == 'idit'){
                obsName = 'IDIT';
                props = [ob.x,ob.y,ob.w,ob.h, ob.spinRadius/100, ob.speed];
            } else if(ob.type == 'invpu'){
                obsName = 'InvincibilityPowerup';
                props = [ob.x,ob.y,ob.w,ob.h,ob.amount];
            } else if(ob.type == 'golf'){
                obsName = 'Golf';
                props = [ob.x,ob.y,ob.w,ob.h,ob.speed,ob.friction];
            }else if(ob.type == 'bounce'){
                obsName = 'BouncyObstacle';
                props = [ob.x,ob.y,ob.w,ob.h,ob.effect];
            } else if(ob.type == 'grav' || ob.type == 'platformer'){
                // if either are positive, it's positive. if not, it's negative
                let forceSign = Math.abs(ob.x) == ob.x || Math.abs(ob.y) == ob.y;
                let direction = 'right';
                /*if(ob.dir.x > 0){
                    direction = 'right';
                } else*/ if(ob.dir.x < 0){
                    direction = 'left';
                }
                if(ob.dir.y > 0){
                    direction = 'down';
                } else if(ob.dir.y < 0){
                    direction = 'up';
                }
                if(ob.type == 'grav'){
                    obsName = 'GravObstacle';
                    props = [ob.x,ob.y,ob.w,ob.h,"'"+direction+"'",ob.force];
                } else {
                    obsName = 'PlatformerGrav';
                    props = [ob.x,ob.y,ob.w,ob.h,"'"+direction+"'",ob.jumpHeight,ob.force];
                }
            } else if(ob.type == 'coin'){
                obsName = 'Coin';
                props = [ob.x,ob.y,ob.w,ob.h];
            } else if(ob.type == 'coindoor'){
                obsName = 'CoinDoor';
                props = [ob.x,ob.y,ob.w,ob.h,ob.coins];
            } else if(ob.type == 'raxis'){
                obsName = 'RestrictAxis';
                props = [ob.x,ob.y,ob.w,ob.h,ob.rx,ob.ry];
            } else if(ob.type == 'circle-normal' && ob.radius != undefined){
                obsName = 'CircularNormalObstacle';
                props = [ob.x,ob.y,ob.radius];
            } else if(ob.type == 'circle-bounce'){
                obsName = 'CircularBouncyObstacle';
                props = [ob.x,ob.y,ob.r||ob.radius,ob.effect];
            } else if(ob.type == 'growinglavacircle'){
                obsName = 'GrowingCircleLavaObstacle';
                props = [ob.x,ob.y,ob.minWidth,ob.maxWidth,ob.growSpeed*2,ob.growing];
            } else if(ob.type == 'growingcircle'){
                obsName = 'GrowingCircleObstacle';
                props = [ob.x,ob.y,ob.minWidth,ob.maxWidth,ob.growSpeed*2,ob.growing];
            } else if(ob.type == 'winpad'){
                obsName = 'Winpad';
                props = [ob.x,ob.y,ob.w,ob.h];
            } else if(ob.type == 'breakable'){
                obsName = 'BreakableObstacle';
                props = [ob.x, ob.y, ob.w, ob.h, ob.maxStrength, ob.timer, ob.regenTime];
            } else if(ob.type == 'rotate-lava' || ob.type == 'rotate-tp' || ob.type == 'rotate-normal'){
                if(ob.type == 'rotate-lava'){
                    obsName = 'RotatingLava';
                    props = [ob.x, ob.y, ob.w, ob.h, ob.rotateSpeed, ob.angle%(Math.PI*2), ob.pivotX, ob.pivotY, ob.distToPivot,/* ob.canCollide || false*/ true];
                } else if(ob.type == 'rotate-normal'){
                    obsName = 'RotatingNormal';
                    props = [ob.x, ob.y, ob.w, ob.h, ob.rotateSpeed, ob.angle%(Math.PI*2), ob.pivotX, ob.pivotY, ob.distToPivot];
                } else if(ob.type == 'revpu'){
                    obsName = 'RevivePowerup';
                    props = [ob.x, ob.y, ob.w, ob.h, ob.amount];
                } else {
                    obsName = 'RotatingTp';
                    props = [ob.x, ob.y, ob.w, ob.h, ob.rotateSpeed, ob.angle%(Math.PI*2), ob.tpx, ob.tpy, ob.pivotX, ob.pivotY, ob.distToPivot, /*ob.canCollide || false*/ true];
                }
                //{"x":575,"y":2855,"w":248,"h":10,"type":"rotate-lava","angle":-34731.25,"rotateSpeed":-150,"pivotX":575,"pivotY":2855,"distToPivot":0}
                //x, y, w, h, spd, angle=0, pivotX, pivotY, distToPivot, canCollide
            } else if(ob.type == 'growinglava'){
                obsName = 'GrowingLavaObstacle';
                props = [ob.x/*-ob.w/2*/, ob.y/*-ob.h/2*/, ob.minWidth, ob.maxWidth, ob.growSpeed*2, ob.growing || false]
            } else if(ob.type == 'growing'){
                obsName = 'GrowingObstacle';
                props = [ob.x/*-ob.w/2*/, ob.y/*-ob.h/2*/, ob.minWidth, ob.maxWidth, ob.growSpeed, ob.growing || false];
            } else if(ob.type == 'lavamove'){
                obsName = 'MovingLavaObstacle'
                props = [ob.w, ob.h, JSON.stringify(ob.points), ob.speed, ob.currentPoint, /*ob.collidable || false*/ true];
            } else if(ob.type == 'move'){
                obsName = 'MovingObstacle'
                props = [ob.w, ob.h, JSON.stringify(ob.points), ob.speed, ob.currentPoint, /*ob.collidable || false*/ true];
            } else if(ob.type == 'tpmove'){
                obsName = 'MovingTpObstacle';
                props = [ob.w, ob.h, JSON.stringify(ob.points), ob.speed, ob.currentPoint, ob.tpx, ob.tpy];
            } else if(ob.type == 'clone'){
                obsName = 'Clone';
                props = [ob.x, ob.y, ob.w, ob.h, ob.offsetX, ob.offsetY];
            }else if(ob.type == 'redirect'){
                obsName = 'Redirect';
                props = [ob.x, ob.y, ob.w, ob.h, "`"+ob.url+"`", "`"+ob.cookie+"`"];
            } else if(ob.type == 'drpu'){
                obsName = 'DragonPowerup';
                props = [ob.x, ob.y, ob.w, ob.h, ob.state];
            } else if(ob.type == 'tornado'){
                obsName = 'Tornado';
                props = [ob.x,ob.y,ob.w, ob.h, ob.spinRadius];
            } else if(ob.type == 'timetrap'){
                obsName = 'TimeTrap';
                props = [ob.x,ob.y,ob.w, ob.h, ob.maxTime];
            } else if(ob.type == 'cookie'){
                obsName = 'CookieCheck';
                props = [ob.x,ob.y,ob.w, ob.h, "`"+ob.cookie+"`", "`"+ob.value+"`"];
            } else if(ob.type == 'musicchange'){
                obsName = 'MusicChange';
                props = [ob.x,ob.y,ob.w, ob.h, "'"+ob.musicPath+"'"];
            } else if(ob.type == 'gun'){
                obsName = 'Gun';
                props = [ob.x, ob.y, ob.w, ob.h, ob.state, "'"+ob.gunType+"'", ob.fireCooldown, ob.speed, ob.radius, ob.life];
            }  else if(ob.type == 'speed'){
                obsName = 'SpeedObstacle';
                props = [ob.x,ob.y,ob.w, ob.h, ob.speedInc];
            } else if(ob.type == 'zoom'){
                obsName = 'Zoom';
                props = [ob.x,ob.y,ob.w,ob.h,ob.zoom];
            } else if(ob.type == 'circle-lava' && ob.radius != undefined){
                obsName = 'CircularLavaObstacle';
                props = [ob.x,ob.y,ob.radius];
            } else if(ob.type == 'switch'){
                obsName = 'SwitchObstacle';
                props = [ob.x,ob.y,ob.w,ob.h,ob.offTime, ob.onTime, ob.state, ob.timer];
            } else if(ob.type == 'switchlava' || (ob.type === false && ob.offTime != undefined)){
                obsName = 'SwitchLava';
                props = [ob.x,ob.y,ob.w,ob.h,ob.offTime, ob.onTime, ob.state, ob.timer];
            } else if(ob.type == 'boostpad'){
                obsName = 'BoostPad';
                props = [ob.x,ob.y,ob.w,ob.h,ob.speed];
            } else if(ob.type == 'typing'){
                obsName = 'Typing';
                props = [ob.x,ob.y,ob.w,ob.h,"'"+ob.text+"'"];
            } else if(ob.type == 'deadmove'){
                obsName = 'DeadMove';
                props = [ob.x,ob.y,ob.w,ob.h,ob.decayTime];
            } else if(ob.type == 'circle-coin'){
                obsName = 'CircularCoin';
                props = [ob.x,ob.y,ob.radius];
            } else if(ob.type == 'circle-hollow'){
                obsName = 'CircularHollowObstacle';
                props = [ob.x,ob.y,ob.radius,ob.innerRadius];
            } else if(ob.type == 'snap'){
                obsName = 'SnapGrid';
                props = [ob.x,ob.y,ob.w,ob.h,ob.snapX, ob.snapY, ob.snapDistance, ob.snapWait];
            } else if(ob.type == 'ship'){
                obsName = 'Ship';
                props = [ob.x,ob.y,ob.w,ob.h,ob.state];
            } else if(ob.type == 'poly'){
                obsName = 'Polygon';
                props = [JSON.stringify(ob.points),"'"+ob.type+"'"];
            } else if(ob.difficulty != undefined) {
                obsName = 'Portal';
                props = [ob.x, ob.y, Math.min(ob.w,ob.h), "'"+ob.name+"'", "'"+ob.acronym+"'", "'"+ob.difficulty+"'", ob.difficultyNumber/*, musicPath*/]
            }

            // formatting
            if(obsName != undefined && props.length > 0){
                obs += `obstacles.push(new ${obsName}(`;
                for(let i = 0; i < props.length; i++){
                    if(i == 0){
                        obs += `${props[i]}`
                    } else {
                        obs += `,${props[i]}`   
                    }
                }
                obs += '))\n';
            } else if(ob.type != 'revive') {
                obs += `// invalid: ${JSON.stringify(ob)}\n`;
            }
		}
 		return obs;
	} catch (err) {
		console.error('Map Parsing Error: ', err)
		return undefined;
	}
}