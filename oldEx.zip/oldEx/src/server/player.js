const ThreeDPlayer = require('./3dplayer.js');

module.exports = class Player {
    constructor(name, id, map, guest) {
        this.guest = guest;
        this.radius = 24.5//24.5;
        this.x = map.playerSpawn.x;
        this.y = map.playerSpawn.y;
        this.spawn = { x: this.x, y: this.y };
        this.name = name;
        this.map = map.name;
        this.id = id;
        // this.speed = 215;
        this.speed = 430;
        // this.speed = 700;
        this.fric = 0.4;
        //0.6
        // this.fric = 0;
        this.clientX = this.x;
        this.clientY = this.y;
        this.dead = false;
        this.dev = true;
        this.god = false;
        this.zone = 0;
        this.deathTimer = undefined;
        this.bullets = [];
        this.ping = 0;
        this.is3D = false;
        this.powerups = {
            inv: 0,
            gun: {
                state: false,
                angle: 0,
                currentCooldown: 0.3,
                maxCooldown: 0.3,
                speed: 300,
                radius: 30,
                life: 3,
                effectTime: 3,
                type: 'normal',
            },
            dragon: {
                state: false,
                hp: 10,
                angle: 0,
            },
            amogus: false,
            grapple: {
                direction: 0,
                state: false,
                grappling: false,
                length: 0,
                x: 0,
                y: 0,
            },
        };
        this.clones = [];
        this.ship = false;
        this.tagged = false;
        this.deathchange = false;
        this.dimensions = map.dimensions || 2;
        if (map.dimensions === 3) {
            return new ThreeDPlayer(this, map);
        }
    }
    differencePack(other) {
        if (!other) {
            return this.pack();
        }
        const pack = this.pack();
        const diffPack = {};
        for (const key of Object.keys(pack)) {
            if (pack[key] === other[key]) {
                continue;
            }
            diffPack[key] = pack[key];
        }
        return diffPack;
    }
    changeSpawn(check) {
        this.spawn = check;
    }
    tp(x, y) {
        //console.log(`tp to (${x}, ${y})`)
        this.clientX = x;
        this.clientY = y;
        this.dead = false;
    }
    respawn() {
        this.dead = false;
        this.clientX = this.spawn.x;
        this.clientY = this.spawn.y;
    }
    die() {
        this.dead = true;
    }
    updatePowerups(powerups) {
        this.powerups = powerups;
    }
    updateBullets(bullets, ping) {
        this.bullets = bullets;
        // fixed
        // let dt = ping;// it crashes lol
        // this.bullets.forEach((bullet) => {
        // 	 bullet.life -= dt;
        // 	//
        //               bullet.x += dt*bullet.speed*Math.cos(bullet.angle);
        // 		if (bullet.type === 'pvp') {
        // 			if (bullet.x + bullet.radius >= 1000) {
        // 				bullet.x = (1000 * 2) - bullet.x - bullet.radius * 2
        // 				bullet.angle = Math.atan2(Math.sin(bullet.angle), -Math.cos(bullet.angle))
        // 			} else if (bullet.x - bullet.radius <= 0) {
        // 				bullet.x = (0 * 2) - bullet.x + bullet.radius * 2
        // 				bullet.angle = Math.atan2(Math.sin(bullet.angle), -Math.cos(bullet.angle))
        // 			}
        // 		}
        //               bullet.y += dt*bullet.speed*Math.sin(bullet.angle);
        // 		if (bullet.type === 'pvp') {
        // 			if (bullet.y + bullet.radius >= 1000) {
        // 				bullet.y = (1000 * 2) - bullet.y - bullet.radius * 2;
        // 				bullet.angle = Math.atan2(-Math.sin(bullet.angle), Math.cos(bullet.angle));
        // 			} else if (bullet.y - bullet.radius <= 0) {
        // 				bullet.y = (0 * 2) - bullet.y + bullet.radius * 2;
        // 				bullet.angle = Math.atan2(-Math.sin(bullet.angle), Math.cos(bullet.angle));
        // 			}
        // 		}
        // })
        // console.log(this.bullets)
    }
    update() {
        this.x = this.clientX;
        this.y = this.clientY;
    }
    setData(data) {
        // if (!this.dead) {
        this.clientX = data[0];
        this.clientY = data[1];
        // }
    }
    setCloneData(data) {
        this.clones[data[2]] = {};
        this.clones[data[2]].x = data[0];
        this.clones[data[2]].y = data[1];
        this.clones[data[2]].radius = 24.5;
        this.clones[data[2]].name = this.name;
        this.clones[data[2]].parentId = this.id;
    }
    pack() {
        return {
            x: Math.round(this.x * 10) / 10,
            y: Math.round(this.y * 10) / 10,
            fric: this.fric,
            radius: this.radius,
            name: this.name,
            speed: this.speed,
            dead: this.dead,
            spawn: this.spawn,
            dev: this.dev,
            god: this.god,
            powerups: this.powerups,
            clones: this.clones,
            ship: this.ship,
            tagged: this.tagged,
            deathTimer: this.deathTimer,
            bullets: this.bullets,
            ping: this.ping,
            guest: this.guest,
        };
    }
};
