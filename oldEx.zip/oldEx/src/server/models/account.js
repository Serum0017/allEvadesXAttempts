const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const accountSchema = new Schema(
    {
        username: { type: String, required: true },
        password: { type: String, required: true },
        dateCreated: { type: Number, required: true },
		// { coins, net_worth, total_coins, planet_points, }
		// (no universe req storage, can be automated with using universe requirements)
    },
    { timestamps: true }
);

const Account = mongoose.model('Account', accountSchema);

module.exports = Account;
