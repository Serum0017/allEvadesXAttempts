module.exports = class Safe {
	constructor(x, y, w, h, renderAbove=false) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
        this.renderAbove = renderAbove;
	}
	pack() {
		return {
			x: this.x,
			y: this.y, 
			w: this.w,
			h: this.h,
            renderAbove: this.renderAbove,
		}
	}
}