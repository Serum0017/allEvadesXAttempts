var SAT = require('sat');

class NormalObstacle {
	constructor(x, y, w, h, canJump=true, angle=0) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'normal';
        this.canJump = Boolean(canJump);
		if (angle % 360 !== 0) {
			return new RotatingNormal(x, y, w, h, 0, angle);
			// console.log('shouldnt be called')
		}
	}
	simulate(dt) {   }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            canJump: this.canJump,
		}
	}
}

class DirNormal {
	constructor(x, y, w, h, dir='up') {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'dirnormal';
		this.active = false;
		this.activeTimer = 0;
		this.dir = dir;
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			active: this.active,
			activeTimer: this.activeTimer,
			dir: this.dir,
		}
	}
}

class PushboxResetButton {
	constructor(x, y, w, h, resetId=0) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.resetId = resetId;
		this.type = 'pushboxreset';
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			resetId: this.resetId,
		}
	}
}

class MorphButton {
	constructor(x, y, w, h, id=0) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.morphId = id;
		this.type = 'morphbutton';
		this.active = true;
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			morphId: this.morphId,
			type: this.type,
			active: this.active,
		}
	}
}

class MorphButtonTimed extends MorphButton {
	constructor(x, y, w, h, id=0, time=5) {
		super(x, y, w, h, id);
		this.time = time;
		this.timer = time;
		this.type = 'morphbuttontimed';
	}
	simulate(dt) {}
		pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			morphId: this.morphId,
			type: this.type,
			active: this.active,
			time: this.time,
			timer: this.timer,
		}
	}
}

// resets movings to a certain point
class MorphMoveReset extends MorphButton {
	constructor(x, y, w, h, id=0, movingPoint) {
		super(x, y, w, h, id);
        this.resetPoint = movingPoint;
		this.type = 'morphmovereset';
	}
	simulate(dt) {}
		pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			morphId: this.morphId,
			type: this.type,
			active: this.active,
			time: this.time,
			timer: this.timer,
            resetPoint: this.resetPoint,
		}
	}
}

class MorphObstacle {
	constructor(x, y, w, h, morphId, active=false) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.morphId = morphId;
		this.active = active;
		this.type = 'morphnormal';
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			active: this.active,
			morphId: this.morphId,
		}
	}
}

class RoundedCorners {
	constructor(x, y, w, h, roundRadius) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'roundedcorners';
        this.circles = [
            {x: this.x+roundRadius, y: this.y+roundRadius, radius: roundRadius},
            {x: this.x+this.w-roundRadius, y: this.y+roundRadius, radius: roundRadius},
            {x: this.x+roundRadius, y: this.y+this.h-roundRadius, radius: roundRadius},
            {x: this.x+this.w-roundRadius, y: this.y+this.h-roundRadius, radius: roundRadius},
        ];
        this.rects = [
            {x: this.x+roundRadius, y: this.y, w: this.w-roundRadius*2, h: this.h},
            {x: this.x, y: this.y+roundRadius, w: this.w, h: this.h-roundRadius*2}
        ]
        this.roundRadius = roundRadius;
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            circles: this.circles,
            rects: this.rects,
            roundRadius: this.roundRadius,
		}
	}
}

class RoundedLava {
	constructor(x, y, w, h, roundRadius) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'roundedlava';
        this.circles = [
            {x: this.x+roundRadius, y: this.y+roundRadius, radius: roundRadius},
            {x: this.x+this.w-roundRadius, y: this.y+roundRadius, radius: roundRadius},
            {x: this.x+roundRadius, y: this.y+this.h-roundRadius, radius: roundRadius},
            {x: this.x+this.w-roundRadius, y: this.y+this.h-roundRadius, radius: roundRadius},
        ];
        this.rects = [
            {x: this.x+roundRadius, y: this.y, w: this.w-roundRadius*2, h: this.h},
            {x: this.x, y: this.y+roundRadius, w: this.w, h: this.h-roundRadius*2}
        ]
        this.roundRadius = roundRadius;
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            circles: this.circles,
            rects: this.rects,
            roundRadius: this.roundRadius,
		}
	}
}

class Block {
	constructor(x, y, w, h, color='#000000') {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.color = color;
		this.type = 'block';
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			color: this.color,
			type: this.type,
		}
	}
}

class Demo {
	constructor(posArray) {
        this.posArray = JSON.parse(posArray);
		this.x = this.posArray[0].x;
		this.y = this.posArray[0].y;
        this.ind = 0;
        this.type = 'demo';
	}
	simulate(dt) {
        // this is player based and doesn't affect gameplay so its fine
        /*this.ind++;
        if(this.ind >= this.posArray.length){
            this.ind = 0;
        }
        this.x = this.posArray[this.ind].x;
        this.y = this.posArray[this.ind].y;*/
    }
	pack() {
		return {
			x: this.x,
			y: this.y,
			posArray: this.posArray,
			type: this.type,
            ind: this.ind
		}
	}
}

class AmogusPowerup {
	constructor(x, y, w, h, state = true) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.state = state;
		this.type = 'ampu';
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			state: this.state,
			type: this.type,
		}
	}
}

class DrawingCanvas {
	constructor(x, y, w, h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'playerdraw';
        this.lines = [];
        this.timer = 0;
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            lines: this.lines,
            timer: this.timer,
		}
	}
}

class ResetCoins {
	constructor(x, y, w, h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'resetcoins';
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
		}
	}
}

class GrapplePowerup {
	constructor(x, y, w, h, state = true, onlyGrappleTograpplePoints=true) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.state = state;
		this.type = 'grpu';
        this.grapplePoints = onlyGrappleTograpplePoints;
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			state: this.state,
			type: this.type,
            grapplePoints: this.grapplePoints,
		}
	}
}

class GrapplePoint {
	constructor(x, y) {
		this.x = x;
		this.y = y;
		this.type = 'grapplepoint';
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			type: this.type,
		}
	}
}

///add,{"type":"gupu","state":true}
class GunslingerPowerup {
	constructor(x, y, w, h, state=true) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.state = state;
		this.type = 'gupu';
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			state: this.state,
			type: this.type,
		}
	}
}

// while COMPLETELY in hole, ur not affected by physics :D (applies 1 frame later)
// also we can have circular holes + polygonal holes but ill make those later since more complex >-<
class Hole {
	constructor(x, y, w, h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'hole';
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
		}
	}
}

// players collide w/ eachother while in zone (bounded by sats)
class PlayerCollide {
	constructor(x, y, w, h, bounciness) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'playercollide';
        this.bounciness = bounciness;
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            bounciness: this.bounciness
		}
	}
}

// permenantly executes an event when pressed. Other types of buttons can have different behaviors but this is the basic one for now
class Button {
	constructor(x, y, w, h, id) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
        this.id = id;
		this.type = 'button';
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            id: this.id,
            active: true,
		}
	}
}

// button that's activated when an enemy steps on it
class EnemyButton {
	constructor(x, y, w, h, id) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
        this.id = id;
		this.type = 'enemybutton';
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            id: this.id,
            active: true,
		}
	}
}

// button that's activated only when a pushable box is put on it
class BoxButton {
	constructor(x, y, w, h, id) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
        this.id = id;
		this.type = 'bbutton';
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            id: this.id,
            active: true,
		}
	}
}

// button that only activates if >= minpeople are on it and then activates again after delay. Works client sided.
class CrowdButton {
	constructor(x, y, w, h, id, minPlayers, delay) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.minPlayers = minPlayers;
        this.delay = delay;
        this.id = id;
        this.type = 'crowdbutton';
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			minPlayers: this.minPlayers,
            delay: this.delay,
            id: this.id,
            active: false,
            type: this.type,
		}
	}
}

// button that can be pressed and unpressed an infinite amount of times. Good for puzzles :D
// for other uses such as prompting players to go a certain way, refer to the normal button
class ReusableButton {
	constructor(x, y, w, h, id) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
        this.id = id;
		this.type = 'rbutton';
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            id: this.id,
            active: false,
            lastPressed: false,
		}
	}
}

// triggers every x seconds, reguardless of if the button is presssed or not.
// it is also invisible :>
class TimeButton {
	constructor(time, id) {
        this.id = id;
        this.time = time;
        this.timer = time;
		this.type = 'tbutton';
	}
	simulate(dt) {
        this.timer -= dt;
        if(this.timer < 0){
            this.timer += this.time;   
        }
    }
	pack() {
		return {
			type: this.type,
            id: this.id,
            time: this.time,
            timer: this.timer,
		}
	}
}

// activates once again after time has passed. Intended use is for a timetrap substitute, which closes a door again after x seconds have passed
class TimeTrapButton {
	constructor(x, y, w, h, time, id) {
        this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
        this.id = id;
		this.type = 'ttbutton';
        this.time = time;
        this.timer = time;
	}
	simulate(dt) {}
	pack() {
		return {
            x: this.x,
            y: this.y,
            w: this.w,
            h: this.h,
			type: this.type,
            id: this.id,
            time: this.time,
            timer: this.timer,
            active: false,
		}
	}
}

// opens when button is pressed
class Door {
	constructor(x, y, w, h, id, active=true) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
        this.id = id;
		this.type = 'door';
        this.active = active||false;
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            id: this.id,
            active: this.active
		}
	}
}

class LavaDoor {
	constructor(x, y, w, h, id, active) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
        this.id = id;
		this.type = 'lavadoor';
        this.active = active||false;
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            id: this.id,
            active: this.active
		}
	}
}

class Camera {
	constructor(x, y, radius, triggerX, triggerY, triggerW, triggerH) {
		this.x = x;
		this.y = y;
		this.radius = radius;
		this.triggerX = triggerX;
		this.triggerY = triggerY;
		this.triggerW = triggerW;
		this.triggerH = triggerH;	
		this.type = 'camera';
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			radius: this.radius,
			triggerX: this.triggerX,
			triggerY: this.triggerY,
			triggerW: this.triggerW,
			triggerH: this.triggerH,
			type: this.type,
		}
	}
}

class CircularDoor {
	constructor(x, y, radius, id, active) {
		this.x = x;
		this.y = y;
		this.radius = radius;
        this.r = radius;
        this.id = id;
		this.type = 'circle-door';
        this.active = active||false;
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			radius: this.radius,
            r: this.radius,
			type: this.type,
            id: this.id,
            active: this.active
		}
	}
}

// this is just a custom rectangular obs; other obs will be available in the future for like polygons and shit
class Custom {
	constructor(x, y, w, h, params, simulate, collidable, onCollision, render) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
        this.type = 'custom';
        //console.log(this);
        // params will be in the form of [{name:smth,value:smth else}] which are init params
        // init params and dt can be referenced anywhere in the evals. to reference the player u can do player that will run client side :D
        for(let i in params){
            this[`${params[i].name}`] = params[i].value;
        }
        // simulation to happen while not interacting with the player
        if(!simulate){
            this.sim = ''
        } else {
            this.sim = simulate;
        }
        this.collidable = collidable || false;// bool for if we should bound the player outside the obs

        // what happens if player comes in contact w/ obstacle in string format
        if(!onCollision){
            this.onCollision = ''
        } else {
            this.onCollision = onCollision;
        }

        // how the obs renders client side. use ctx to draw stuff and pos.x or y to draw relative to the player
        if(!render){
            this.render = ''
        } else {
            this.render = render;
        }
	}
	simulate(dt) {
        try{
            // simulate will use server side this and will be adapted client side w/ like a replaceall lol
            this.serverSided = true;
            eval(this.sim);
        }catch(e){
            console.log("server side error in custom obstacle: " + e);
        }
    }
	pack() {
		return {
			...this,// temporary for testing
            type: this.type,
            serverSided: false,
		}
	}
}

class CameraChange {
	constructor(x, y, w, h, camx, camy, canReturn) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'camerachange';
        this.cameraX = camx;
        this.cameraY = camy;
        this.canReturn = canReturn;
        if(this.canReturn === undefined){
            this.canReturn = true;
        }
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            cameraX: this.cameraX,
            cameraY: this.cameraY,
            canReturn: this.canReturn,
		}
	}
}

class Deathcure {
	constructor(x, y, w, h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'cure';
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
		}
	}
}

class Deathmark {
	constructor(x, y, w, h, time=5) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'mark';
        this.time = time;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			time: this.time,
		}
	}
}

class EnemyEffector {
	constructor(x, y, w, h, multiply, enemyParamToEffect) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'enemyeffect';
        this.multiply = multiply;
        this.effectParam = enemyParamToEffect;
        // obstacle that effects enemies when they run over it.
        // can be any param that an enemy has
        // u can add/ multiply with params
	}
	simulate(dt, enemy, obsid) {
        for(let ene of enemy){
            if(ene[this.effectParam] != undefined && !isNaN(ene[this.effectParam]) && this.intersectingCircleRect(ene,this)){
                if(!ene.effectorIds){
                    ene.effectorIds = [];
                }
                ene.effectorIds.push(obsid);
                ene[this.effectParam] *= this.multiply;
            }
        }
    }
    intersectingCircleRect(circle, rect) {
    	const distX = Math.abs(circle.x - rect.x - rect.w / 2);
    	const distY = Math.abs(circle.y - rect.y - rect.h / 2);
    	if (distX < rect.w / 2 + circle.radius && distY < rect.h / 2 + circle.radius) {
    		let circleSat;
    		if (circle.sat) {
                circleSat = circle.sat;
    		} else {
    			circleSat = new SAT.Circle(new SAT.Vector(circle.x, circle.y), circle.radius);
    		}
    		const res = new SAT.Response();
    		const boxSat = new SAT.Box(new SAT.Vector(rect.x, rect.y), rect.w, rect.h).toPolygon();
    		const collision = SAT.testPolygonCircle(boxSat, circleSat, res);
    		if (collision) {
    			return true;
    		}
    	}
    	return false;
    }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            multiply: this.multiply,
            effectParam: this.effectParam,
		}
	}
}

function pointCircleCollide(po, pos, r) {
    if (!Array.isArray(po)) {
        return false;
    }
    const [x, y] = po;
    return (x - pos.x) * (x - pos.x) + (y - pos.y) * (y - pos.y) <= r * r;
}

function rectOverlaps(ax1,ax2,ay1,ay2,bx1,bx2,by1,by2) {
	// no horizontal overlap
    if(ax1 > bx2 || ax2 < bx1) return false;

	// no vertical overlap
    if(ay1 > by2 || by1 > ay2) return false;

	return true;
}

const tmp = [0, 0];

function lineCircleCollide(a, b, circle, radius, nearest) {
    // dont add nearest param when using dis fyunction

    // basic optimization by making square bounding boxes
    if(!rectOverlaps(
        circle.x-radius,
        circle.x+radius,
        circle.y-radius,
        circle.y+radius,
        Math.min(a[0],b[0]),
        Math.max(a[0],b[0]),
        Math.min(a[1],b[1]),
        Math.max(a[1],b[1]),
    )){
        return false;
    }

    if (pointCircleCollide(a, circle, radius)) {
        if (nearest) {
            nearest[0] = a[0];
            nearest[1] = a[1];
        }
        return true;
    }
    if (pointCircleCollide(b, circle, radius)) {
        if (nearest) {
            nearest[0] = b[0];
            nearest[1] = b[1];
        }
        return true;
    }

    let x1 = a[0],
        y1 = a[1],
        x2 = b[0],
        y2 = b[1],
        cx = circle.x,
        cy = circle.y;

    let dx = x2 - x1;
    let dy = y2 - y1;

    let lcx = cx - x1;
    let lcy = cy - y1;
    // projection
    let dLen2 = dx * dx + dy * dy;
    let px = dx;
    let py = dy;
    if (dLen2 > 0) {
        let dp = (lcx * dx + lcy * dy) / dLen2;
        px *= dp;
        py *= dp;
    }

    if (!nearest) nearest = tmp;
    nearest[0] = x1 + px;
    nearest[1] = y1 + py;

    let pLen2 = px * px + py * py;

    return (
        pointCircleCollide(nearest, circle, radius) &&
        pLen2 <= dLen2 &&
        px * dx + py * dy >= 0
    );
}

// basically just reflects enemies off of it. I might make polygons, circles, and hollow cirlces at a later time.
class EnemyWall {
	constructor(x, y, w, h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
        this.type = 'enemywall';
	}
	simulate(dt, enemy) {
        for (let ene of enemy) {
            const intersecting = this.returnIntersectingCircleRect(ene, this, true)
            if (intersecting !== false) {
                let r = {
                    x: ene.xv - 2 * (ene.xv*intersecting.overlapN.x+ene.yv*intersecting.overlapN.y) * intersecting.overlapN.x,
                    y: ene.yv - 2 * (ene.xv*intersecting.overlapN.x+ene.yv*intersecting.overlapN.y) * intersecting.overlapN.y,
                }
                const magnitude = Math.sqrt(r.x**2+r.y**2);
                r.x /= magnitude;
                r.y /= magnitude;
                ene.xv = ene.speed * r.x;
                ene.yv = ene.speed * r.y;
                ene.x += intersecting.overlapV.x;
                ene.y += intersecting.overlapV.y;
            }
        }
    }
    returnIntersectingCircleRect(circle, rect) {
    	const distX = Math.abs(circle.x - rect.x - rect.w / 2);
    	const distY = Math.abs(circle.y - rect.y - rect.h / 2);
    	if (distX < rect.w / 2 + circle.radius && distY < rect.h / 2 + circle.radius) {
    		let circleSat;
    		if (circle.sat) {
                circleSat = circle.sat;
    		} else {
    			circleSat = new SAT.Circle(new SAT.Vector(circle.x, circle.y), circle.radius);
    		}
    		const res = new SAT.Response();
    		const boxSat = new SAT.Box(new SAT.Vector(rect.x, rect.y), rect.w, rect.h).toPolygon();
    		const collision = SAT.testPolygonCircle(boxSat, circleSat, res);
    		if (collision) {
    			return res;
    		}
    	}
    	return false;
    }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
		}
	}
}

class EnemyPolyWall {
	constructor(points = []) {
		this.points = points;
		this.type = 'poly-enemywall';
        this.seed = Math.floor(Math.random()*10000);
	}
	simulate(dt, enemy) {
        for (let ene of enemy) {
            const intersecting = this.returnBoundPlayerPolygon(ene, this);
            if (intersecting !== false) {
                let r = {
                    x: ene.xv - 2 * (ene.xv*intersecting.overlapN.x+ene.yv*intersecting.overlapN.y) * intersecting.overlapN.x,
                    y: ene.yv - 2 * (ene.xv*intersecting.overlapN.x+ene.yv*intersecting.overlapN.y) * intersecting.overlapN.y,
                }
                const magnitude = Math.sqrt(r.x**2+r.y**2);
                r.x /= magnitude;
                r.y /= magnitude;
                ene.xv = ene.speed * r.x;
                ene.yv = ene.speed * r.y;
                ene.x += intersecting.overlapV.x;
                ene.y += intersecting.overlapV.y;
            }
        }
    }
    returnBoundPlayerPolygon(player, polygon) {
        let touching = false;
        let OnSafe = false;
        for (let i = 0; i < polygon.points.length; i++) {
            if (i === 0) {
                if (
                    lineCircleCollide(
                        polygon.points[polygon.points.length - 1],
                        polygon.points[0],
                        player,
                        player.radius
                    )
                ) {
                    touching = true;
                    break;
                }
            } else if (i === polygon.points.length) {
                if (
                    lineCircleCollide(
                        polygon.points[i],
                        polygon.points[0],
                        player,
                        player.radius
                    )
                ) {
                    touching = true;
                    break;
                }
            } else {
                if (
                    lineCircleCollide(
                        polygon.points[i - 1],
                        polygon.points[i],
                        player,
                        player.radius
                    )
                ) {
                    touching = true;
                    break;
                }
            }
        }
        if (!touching && polygon.type != 'poly-safe') {
            return false;
        }
        const polySat = new SAT.Polygon(new SAT.Vector(0, 0), [
            ...polygon.points.map(([x, y]) => new SAT.Vector(x, y)),
        ]);
        const res = new SAT.Response();
        const playersat =
            player.sat ||
            new SAT.Circle(new SAT.Vector(player.x, player.y), player.radius);
        const collision = SAT.testPolygonCircle(polySat, playersat, res);
        if (collision) {
            return res;
        } else {
            return false;
        }
    }
	pack() {
		return {
			points: this.points,
			type: this.type,
		}
	}
}

class EnemyPolyTp {
	constructor(points = [], tpx, tpy) {
		this.points = points;
		this.type = 'poly-enemytp';
        this.tpx = tpx;
        this.tpy = tpy;
        this.seed = Math.floor(Math.random()*10000);
	}
	simulate(dt, enemy) {
        for(let ene of enemy){
            if(this.boundPlayerPolygon(ene,this)){
                ene.x = this.tpx;
                ene.y = this.tpy;
                ene.angle = Math.PI*this.seed/10000;
                ene.xv = Math.cos(ene.angle) * ene.speed;
                ene.yv = Math.sin(ene.angle) * ene.speed;
                this.seed = Math.sin(this.seed++) * 10000 - Math.floor(Math.sin(this.seed++) * 10000);
            }
        }
    }
    boundPlayerPolygon(player, polygon) {
        let touching = false;
        let OnSafe = false;
        for (let i = 0; i < polygon.points.length; i++) {
            if (i === 0) {
                if (
                    lineCircleCollide(
                        polygon.points[polygon.points.length - 1],
                        polygon.points[0],
                        player,
                        player.radius
                    )
                ) {
                    touching = true;
                    break;
                }
            } else if (i === polygon.points.length) {
                if (
                    lineCircleCollide(
                        polygon.points[i],
                        polygon.points[0],
                        player,
                        player.radius
                    )
                ) {
                    touching = true;
                    break;
                }
            } else {
                if (
                    lineCircleCollide(
                        polygon.points[i - 1],
                        polygon.points[i],
                        player,
                        player.radius
                    )
                ) {
                    touching = true;
                    break;
                }
            }
        }
        if (!touching && polygon.type != 'poly-safe') {
            return false;
        }
        const polySat = new SAT.Polygon(new SAT.Vector(0, 0), [
            ...polygon.points.map(([x, y]) => new SAT.Vector(x, y)),
        ]);
        const res = new SAT.Response();
        const playersat =
            player.sat ||
            new SAT.Circle(new SAT.Vector(player.x, player.y), player.radius);
        const collision = SAT.testPolygonCircle(polySat, playersat, res);
        if (collision) {
            return true;
        } else {
            return false;
        }
    }
	pack() {
		return {
			points: this.points,
			type: this.type,
            tpx: this.tpx,
            tpy: this.tpy,
            seed: this.seed,
		}
	}
}

class EnemyTp {
	constructor(x, y, w, h, tpx, tpy) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
        this.tpx = tpx;
        this.tpy = tpy;
        this.type = 'enemytp';
        this.seed = Math.floor(Math.random()*10000);
	}
	simulate(dt, enemy) {
        for(let ene of enemy){
            if(this.intersectingCircleRect(ene,this)){
                ene.x = this.tpx;
                ene.y = this.tpy;
                ene.angle = Math.PI*this.seed/10000;
                ene.xv = Math.cos(ene.angle) * ene.speed;
                ene.yv = Math.sin(ene.angle) * ene.speed;
                this.seed = Math.sin(this.seed++) * 10000 - Math.floor(Math.sin(this.seed++) * 10000);
            }
        }
    }
    intersectingCircleRect(circle, rect) {
    	const distX = Math.abs(circle.x - rect.x - rect.w / 2);
    	const distY = Math.abs(circle.y - rect.y - rect.h / 2);
    	if (distX < rect.w / 2 + circle.radius && distY < rect.h / 2 + circle.radius) {
    		let circleSat;
    		if (circle.sat) {
                circleSat = circle.sat;
    		} else {
    			circleSat = new SAT.Circle(new SAT.Vector(circle.x, circle.y), circle.radius);
    		}
    		const res = new SAT.Response();
    		const boxSat = new SAT.Box(new SAT.Vector(rect.x, rect.y), rect.w, rect.h).toPolygon();
    		const collision = SAT.testPolygonCircle(boxSat, circleSat, res);
    		if (collision) {
    			return true;
    		}
    	}
    	return false;
    }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            tpx: this.tpx,
            tpy: this.tpy,
            seed: this.seed,
		}
	}
}

class CircularHollowSliceEnemyWall {
	constructor(x, y, r, startAngle, endAngle, innerRadius, rotateSpeed=0) {
		this.x = x;
		this.y = y;
		this.radius = r;
        this.rotateSpeed = rotateSpeed*Math.PI/180;
        if(rotateSpeed != 0) {
            this.toRotate = true;
        } else {
            this.toRotate = false;
        }
		this.type = 'circle-hollow-slice-enemywall';
        this.startAngle = startAngle*Math.PI/180;
        this.endAngle = endAngle*Math.PI/180;
        this.innerRadius = innerRadius;
        this.startPolygon = new Polygon([
            [this.x+Math.cos(this.startAngle)*this.innerRadius,this.y+Math.sin(this.startAngle)*this.innerRadius],
            [this.x+Math.cos(this.startAngle)*this.radius,this.y+Math.sin(this.startAngle)*this.radius],
        ], 'poly')
        this.endPolygon = new Polygon([
            [this.x+Math.cos(this.endAngle)*this.innerRadius,this.y+Math.sin(this.endAngle)*this.innerRadius],
            [this.x+Math.cos(this.endAngle)*this.radius,this.y+Math.sin(this.endAngle)*this.radius],
        ], 'poly')
	}
	simulate(dt, enemy) {
        if(this.toRotate){
            this.startAngle += this.rotateSpeed*dt;
            this.endAngle += this.rotateSpeed*dt;
            this.startPolygon.points = [
                [
                    this.x + Math.cos(this.startAngle) * this.innerRadius,
                    this.y + Math.sin(this.startAngle) * this.innerRadius,
                ],
                [
                    this.x + Math.cos(this.startAngle) * this.radius,
                    this.y + Math.sin(this.startAngle) * this.radius,
                ],
            ];
            this.endPolygon.points = [
                [
                    this.x + Math.cos(this.endAngle) * this.innerRadius,
                    this.y + Math.sin(this.endAngle) * this.innerRadius,
                ],
                [
                    this.x + Math.cos(this.endAngle) * this.radius,
                    this.y + Math.sin(this.endAngle) * this.radius,
                ],
            ];
        }
        
        for (let ene of enemy) {
            const distX = ene.x - this.x;
            const distY = ene.y - this.y;
            const mag = Math.sqrt(distX * distX + distY * distY) || 1;
            const normal = { x: distX / mag, y: distY / mag };
            const lastX = ene.x;
            const lastY = ene.y;
            const angle = Math.atan2(
                ene.y - this.y,
                ene.x - this.x
            );
    
            const sat1 = this.returnBoundPlayerPolygon(ene, this.startPolygon);
            const sat2 = this.returnBoundPlayerPolygon(ene, this.endPolygon);
            if(sat1 !== false){
                ene.x += sat1.overlapV.x;
                ene.y += sat1.overlapV.y;
            } 
            else if(sat2 !== false){
                ene.x += sat2.overlapV.x;
                ene.y += sat2.overlapV.y;
            }
            
            if (
                this.checkAngleBetween(
                    angle,
                    this.startAngle,
                    this.endAngle
                )
            ) {
                if (
                    mag > this.innerRadius - ene.radius &&
                    mag < this.radius + ene.radius
                ) {
                    // checking if ur inside or outside
                    const outsideDist = Math.abs(
                        distX * distX +
                            distY * distY -
                            (ene.radius + this.radius) *
                                (ene.radius + this.radius)
                    );
                    const insideDist = Math.abs(
                        distX * distX +
                            distY * distY -
                            (this.radius - ene.radius) ** 2
                    );
                    if (insideDist < outsideDist && this.innerRadius > ene.radius) {
                        // we're inside; just invert the push
                        ene.x =
                            this.x +
                            (this.innerRadius - ene.radius) *
                                normal.x;
                        ene.y =
                            this.y +
                            (this.innerRadius - ene.radius) *
                                normal.y;
                    } else {
                        ene.x =
                            this.x +
                            (this.radius + ene.radius) * normal.x;
                        ene.y =
                            this.y +
                            (this.radius + ene.radius) * normal.y;
                    }
                }
            }
    
            if(ene.x !== lastX || ene.y !== lastY){
                // getting a normalized vector
                const dX = ene.x-lastX;
                const dY = ene.y-lastY;
                const pushMagnitude = Math.sqrt(dX**2+dY**2);
                const vec = {
                    x: dX/pushMagnitude,
                    y: dY/pushMagnitude,
                };
                // reflecting over that vector
                let r = {
                    x: ene.xv - 2 * (ene.xv*vec.x+ene.yv*vec.y) * vec.x,
                    y: ene.yv - 2 * (ene.xv*vec.x+ene.yv*vec.y) * vec.y,
                }
                const magnitude = Math.sqrt(r.x**2+r.y**2);
                r.x /= magnitude;
                r.y /= magnitude;
                ene.xv = ene.speed * r.x;
                ene.yv = ene.speed * r.y;
            }
        }
    }
    returnBoundPlayerPolygon(player, polygon) {
        let touching = false;
        let OnSafe = false;
        for (let i = 0; i < polygon.points.length; i++) {
            if (i === 0) {
                if (
                    lineCircleCollide(
                        polygon.points[polygon.points.length - 1],
                        polygon.points[0],
                        player,
                        player.radius
                    )
                ) {
                    touching = true;
                    break;
                }
            } else if (i === polygon.points.length) {
                if (
                    lineCircleCollide(
                        polygon.points[i],
                        polygon.points[0],
                        player,
                        player.radius
                    )
                ) {
                    touching = true;
                    break;
                }
            } else {
                if (
                    lineCircleCollide(
                        polygon.points[i - 1],
                        polygon.points[i],
                        player,
                        player.radius
                    )
                ) {
                    touching = true;
                    break;
                }
            }
        }
        if (!touching && polygon.type != 'poly-safe') {
            return false;
        }
        const polySat = new SAT.Polygon(new SAT.Vector(0, 0), [
            ...polygon.points.map(([x, y]) => new SAT.Vector(x, y)),
        ]);
        const res = new SAT.Response();
        const playersat =
            player.sat ||
            new SAT.Circle(new SAT.Vector(player.x, player.y), player.radius);
        const collision = SAT.testPolygonCircle(polySat, playersat, res);
        if (collision) {
            return res;
        } else {
            return false;
        }
    }
    checkAngleBetween(n, a, b) {
        // in radians
        n *= 180 / Math.PI;
        a *= 180 / Math.PI;
        b *= 180 / Math.PI;
        n = (360 + (n % 360)) % 360;
        a = (3600000 + a) % 360;
        b = (3600000 + b) % 360;
    
        if (a < b) return a <= n && n <= b;
        return a <= n || n <= b;
    }
	pack() {
		return {
			x: this.x,
			y: this.y,
			radius: this.radius,
			type: this.type,
            startAngle: this.startAngle,
            endAngle: this.endAngle,
            startPolygon: this.startPolygon,
            endPolygon: this.endPolygon,
            innerRadius: this.innerRadius,
            toRotate: this.toRotate,
            rotateSpeed: this.rotateSpeed,
		}
	}
}

class CircularHollowSliceEnemyTp {
	constructor(x, y, r, startAngle, endAngle, innerRadius, tpx, tpy, rotateSpeed=0) {
		this.x = x;
		this.y = y;
		this.radius = r;
        this.rotateSpeed = rotateSpeed*Math.PI/180;
        if(rotateSpeed != 0) {
            this.toRotate = true;
        } else {
            this.toRotate = false;
        }
		this.type = 'circle-hollow-slice-enemytp';
        this.startAngle = startAngle*Math.PI/180;
        this.endAngle = endAngle*Math.PI/180;
        this.innerRadius = innerRadius;
        this.startPolygon = new Polygon([
            [this.x+Math.cos(this.startAngle)*this.innerRadius,this.y+Math.sin(this.startAngle)*this.innerRadius],
            [this.x+Math.cos(this.startAngle)*this.radius,this.y+Math.sin(this.startAngle)*this.radius],
        ], 'poly')
        this.endPolygon = new Polygon([
            [this.x+Math.cos(this.endAngle)*this.innerRadius,this.y+Math.sin(this.endAngle)*this.innerRadius],
            [this.x+Math.cos(this.endAngle)*this.radius,this.y+Math.sin(this.endAngle)*this.radius],
        ], 'poly')
        this.tpx = tpx;
        this.tpy = tpy;
        this.seed = Math.floor(Math.random()*10000);
	}
	simulate(dt, enemy) {
        if(this.toRotate){
            this.startAngle += this.rotateSpeed*dt;
            this.endAngle += this.rotateSpeed*dt;
            this.startPolygon.points = [
                [
                    this.x + Math.cos(this.startAngle) * this.innerRadius,
                    this.y + Math.sin(this.startAngle) * this.innerRadius,
                ],
                [
                    this.x + Math.cos(this.startAngle) * this.radius,
                    this.y + Math.sin(this.startAngle) * this.radius,
                ],
            ];
            this.endPolygon.points = [
                [
                    this.x + Math.cos(this.endAngle) * this.innerRadius,
                    this.y + Math.sin(this.endAngle) * this.innerRadius,
                ],
                [
                    this.x + Math.cos(this.endAngle) * this.radius,
                    this.y + Math.sin(this.endAngle) * this.radius,
                ],
            ];
        }
        
        for (let ene of enemy) {
            const distX = ene.x - this.x;
            const distY = ene.y - this.y;
            const mag = Math.sqrt(distX * distX + distY * distY) || 1;
            const normal = { x: distX / mag, y: distY / mag };
            const lastX = ene.x;
            const lastY = ene.y;
            const angle = Math.atan2(
                ene.y - this.y,
                ene.x - this.x
            );
            let colliding = false;
            if (
                this.checkAngleBetween(
                    angle,
                    this.startAngle,
                    this.endAngle
                )
            ) {
                if (
                    mag > this.innerRadius - ene.radius &&
                    mag < this.radius + ene.radius
                ) {
                    colliding = true;
                }
            }

            // 2: bounding players in the edges by polygon
            const sat1 = this.returnBoundPlayerPolygon(ene, this.startPolygon);
            const sat2 = this.returnBoundPlayerPolygon(ene, this.endPolygon);
            if(sat1 !== false || sat2 !== false){
                colliding = true;
            }

            if(colliding){
                ene.x = this.tpx;
                ene.y = this.tpy;
                ene.angle = Math.PI*this.seed/10000;
                ene.xv = Math.cos(ene.angle)*ene.speed;
                ene.yv = Math.sin(ene.angle)*ene.speed;
                this.seed = Math.sin(this.seed++) * 10000 - Math.floor(Math.sin(this.seed++) * 10000);
            }
        }
    }
    returnBoundPlayerPolygon(player, polygon) {
        let touching = false;
        let OnSafe = false;
        for (let i = 0; i < polygon.points.length; i++) {
            if (i === 0) {
                if (
                    lineCircleCollide(
                        polygon.points[polygon.points.length - 1],
                        polygon.points[0],
                        player,
                        player.radius
                    )
                ) {
                    touching = true;
                    break;
                }
            } else if (i === polygon.points.length) {
                if (
                    lineCircleCollide(
                        polygon.points[i],
                        polygon.points[0],
                        player,
                        player.radius
                    )
                ) {
                    touching = true;
                    break;
                }
            } else {
                if (
                    lineCircleCollide(
                        polygon.points[i - 1],
                        polygon.points[i],
                        player,
                        player.radius
                    )
                ) {
                    touching = true;
                    break;
                }
            }
        }
        if (!touching && polygon.type != 'poly-safe') {
            return false;
        }
        const polySat = new SAT.Polygon(new SAT.Vector(0, 0), [
            ...polygon.points.map(([x, y]) => new SAT.Vector(x, y)),
        ]);
        const res = new SAT.Response();
        const playersat =
            player.sat ||
            new SAT.Circle(new SAT.Vector(player.x, player.y), player.radius);
        const collision = SAT.testPolygonCircle(polySat, playersat, res);
        if (collision) {
            return res;
        } else {
            return false;
        }
    }
    checkAngleBetween(n, a, b) {
        // in radians
        n *= 180 / Math.PI;
        a *= 180 / Math.PI;
        b *= 180 / Math.PI;
        n = (360 + (n % 360)) % 360;
        a = (3600000 + a) % 360;
        b = (3600000 + b) % 360;
    
        if (a < b) return a <= n && n <= b;
        return a <= n || n <= b;
    }
	pack() {
		return {
			x: this.x,
			y: this.y,
			radius: this.radius,
			type: this.type,
            startAngle: this.startAngle,
            endAngle: this.endAngle,
            startPolygon: this.startPolygon,
            endPolygon: this.endPolygon,
            innerRadius: this.innerRadius,
            toRotate: this.toRotate,
            rotateSpeed: this.rotateSpeed,
            tpx: this.tpx,
            tpy: this.tpy,
            seed: this.seed,
		}
	}
}

///add,{"type":"raxis","rx":true,"ry":false}
class RestrictAxis {
	constructor(x, y, w, h, rx, ry) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'raxis';
        this.rx = rx || false;
        this.ry = ry || false;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			rx: this.rx,
            ry: this.ry,
		}
	}
}

class FallingArrow {
	constructor(x, y, w, h, arrows) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'farrow';
        this.arrows = arrows; //notes;
        this.active = true;
        // notes will be in the form of an array with subs of [direction, time since start, speed]
        // [['left',2,120],['up',3,100]]
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			notes: this.notes,
            active: this.active,
            arrows: this.arrows,
		}
	}
}

///add,{"type":"zoom","zoom":0.8}
class Zoom {
	constructor(x, y, w, h, zoom) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'zoom';
        this.zoom = zoom;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            zoom: this.zoom,
		}
	}
}
///add,{"type":"golf","speed":3,"friction":0.98}
class Golf {
	constructor(x, y, w, h, speed, friction) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'golf';
        this.speed = speed;
        this.friction = friction;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            speed: this.speed,
            friction: this.friction,
		}
	}
}

class CircularSnap {
	constructor(x, y, radius) {
		this.x = x;
		this.y = y;
		this.radius = radius;
		this.type = 'circlesnap';
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			type: this.type,
            radius: this.radius,
		}
	}
}
///add,{"type":"spring","friction":0.02,"springs":[{"x": 3175, "y": 1925, "strength": 100}]}
class Spring {
	constructor(x, y, w, h, springs, friction) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'spring';
        this.springs = springs;
        this.friction = friction == undefined ? 0.02 : friction; // how much the velocity is dampened every dt; if its < 0 then it will gain velocity :rofl: (0-1 range)
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            springs: this.springs,
            friction: this.friction,
		}
	}
}

class FullDeath {
	constructor(x, y, w, h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'fulldeath';
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
		}
	}
}


class ZMode {
	constructor(x, y, w, h, state=true) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'z-mode';
		this.state = state;
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			state: this.state,
		}
	}
}

class CircularPushbox {
	constructor(x, y, r, weight, resetId=-1) {
		this.x = x;
		this.y = y;
		this.r = r;
		this.type = 'circularpushbox';
		this.weight = weight;
		this.initX = x;
		this.initY = y;
		this.resetId = resetId;
		this.pusherId = Math.random();
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			r: this.r,
			type: this.type,
			weight: this.weight,
			initX: this.initX,
			initY: this.initY,
			pusherId: this.pusherId,
			resetId: this.resetId,
		}
	}
}

class Pushbox {
	// weight is 1-100
	constructor(x, y, w, h, weight, resetId=-1) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'pushbox';
		this.weight = weight;
		this.initX = x;
		this.initY = y;
		this.resetId = resetId;
        this.pusherId = Math.random();
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			weight: this.weight,
			initX: this.initX,
			initY: this.initY,
            pusherId: this.pusherId,
			resetId: this.resetId,
		}
	}
}

class Raycasting {
	constructor(x, y, w, h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'raycasting';
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
		}
	}
}
///add,{"type":"cookie","cookie":"beentoe2","value":"true"}
///add,{"type":"redirect","url":"https://evade2.herokuapp.com/","cookie":"beentoe2=true"}
class Redirect {
	constructor(x, y, w, h, url, cookietoset) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'redirect';
        this.url = url;
        this.cookie = cookietoset;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            url: this.url,
            cookie: this.cookie,
		}
	}
}
///add,{"type":"typing","text":"Type me!","active":true,"currentChar":0}
class Typing {
	constructor(x, y, w, h, text) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'typing';
        this.text = text;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            text: this.text,
            active: true,
            currentChar: 0,
		}
	}
}
class Mashing {
	constructor(x, y, w, h, amount) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'mashing';
        this.amount = amount||100;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            amount: this.amount,
            active: true,
            currentNum: 0,
		}
	}
}

class CookieCheck {
	constructor(x, y, w, h, cookie, value) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'cookie';
        this.cookie = cookie;
        this.value = value;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            cookie: this.cookie,
            value: this.value,
		}
	}
}
// /add,{"type":"deadmove","decayTime":5,"maxDecayTime":5}
class DeadMove {
	constructor(x, y, w, h, decayTime) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'deadmove';
        this.decayTime = decayTime;
        this.maxDecayTime = decayTime;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            decayTime: this.decayTime,
            maxDecayTime: this.maxDecayTime
		}
	}
}

class Ship {
	constructor(x, y, w, h, state, shipAngle=Math.PI/2) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'ship';
        this.state = state;
        this.shipAngle = shipAngle;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            state: this.state,
            shipAngle: this.shipAngle,
		}
	}
}

class Revive {
	constructor(x, y, w, h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'revive';
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
		}
	}
}
///add,{"type":"clone","offsetX":0,"offsetY":-300}
class Clone {
	constructor(x, y, w, h, offsetX, offsetY) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'clone';
        this.offsetX = offsetX;
        this.offsetY = offsetY;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            offsetX: this.offsetX,
            offsetY: this.offsetY,
		}
	}
}

///add,{"type":"draw","addedPoints":[],"offsetX":200,"offsetY":25,"distanceBetween":50,"obsToAdd":{"type":"lava","w":50,"h":50},"touchingPlayer":false}
class DrawObstacle {
	constructor(x, y, w, h, offsetX, offsetY, distanceBetween, obsToAdd) {// params will b implemented later ;c
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'draw';
        this.addedPoints = [];
        this.offsetX = offsetX;
        this.offsetY = offsetY;
        this.distanceBetween = distanceBetween;
        this.obsToAdd = obsToAdd;
        this.touchingPlayer = false;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            offsetX: this.offsetX,
            offsetY: this.offsetY,
            distanceBetween: this.distanceBetween,
            addedPoints: this.addedPoints,
            obsToAdd: this.obsToAdd,
            touchingPlayer: this.touchingPlayer,
		}
	}
}
///add,{"type":"idit","spinRadius":20000,"speed":"5"}
class IDIT {
	constructor(x, y, w, h, spinRadius, speed) {
		this.x = x;
		this.y = y;
        this.w = w;
        this.h = h;
        this.spinRadius = spinRadius*100||5000;
        this.speed = speed||10;
		this.type = 'idit';
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
            w: this.w,
            h: this.h,
			type: this.type,
            spinRadius: this.spinRadius,
            speed: this.speed,
		}
	}
}
///add,{"type":"gun","gunType":"normal","state":true,"fireCooldown":0.2,"speed":280,"radius":18,"life":6}
///add,{"type":"gun","gunType":"push","state":true,"fireCooldown":0.2,"speed":280,"radius":80,"life":6}
///add,{"type":"gun","gunType":"stun","state":true,"fireCooldown":0.2,"speed":0,"radius":30,"life":10006}
///add,{"type":"gun","gunType":"none","state":false,"fireCooldown":.8,"speed":300,"radius":24,"life":6,"w":0,"h":0}
class Gun {
	constructor(x, y, w, h, state, gunType, fireCooldown, speed, radius, life, effectTime=3) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'gun';
        this.gunType = gunType;
        this.fireCooldown = fireCooldown;
        this.speed = speed;
        this.radius = radius;
        this.state = state;
        this.life = life;
        this.effectTime = effectTime || 3;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            state: this.state,
            gunType: this.gunType,
            fireCooldown: this.fireCooldown,
            speed: this.speed,
            radius: this.radius,
            life: this.life,
            effectTime: this.effectTime
		}
	}
}
///add,{"type":"circle-bounce","radius":60,"effect":20}
///add,{"type":"tp","tpx":1950,"tpy":2825}
///add,[{"type":"size","size":12}]
///add,{"type":"breakable","maxStrength":30,"currentStrength":"30","time":0.02,"timer":0.02,"regenTime":10000}
///add,{"type":"grav","force":7600,"dir":{"x":7600,"y":0},"direction":"right"}
///add,{"type":"platformer","force":4800,"dir":{"x":0,"y":4800},"direction":"down","jumpHeight":600}
class BreakableObstacle {
	constructor(x, y, w, h, strength, time, regenTime = 10) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'breakable';
        this.maxStrength = strength;
        this.currentStrength = strength;
        this.time = time;
        this.timer = time;
        this.regenTime = regenTime;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            maxStrength: this.maxStrength,
            currentStrength: this.currentStrength,
            time: this.time,
            timer: this.timer,
            regenTime: this.regenTime,
		}
	}
}

class BouncyBreakable {
	constructor(x, y, w, h, strength, effect, regenTime = 10) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'bouncybreakable';
        this.maxStrength = strength;
        this.currentStrength = strength;
        this.regenTime = regenTime;
        this.effect = effect;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            currentStrength: this.currentStrength,
            maxStrength: this.maxStrength,
            regenTime: this.regenTime,
            effect: this.effect
		}
	}
}

class Particles {
	constructor(x, y, w, h, spawnRate, particleSpeed, particleSize, particleColor, particleLifespan, toDecay, offsetX,offsetY) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'particles';
        this.spawnRate = spawnRate;
        this.particleSpeed = particleSpeed;
        this.particleSize = particleSize;
        this.particleColor = particleColor;
        this.particles = [];
        this.time = spawnRate;
        this.particleLifespan = particleLifespan;
        this.toDecay = toDecay;
        this.offsetX = offsetX;
        this.offsetY = offsetY;
        if(toDecay === undefined){
            toDecay = false;
        }
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            spawnRate: this.spawnRate,
            particleSpeed: this.particleSpeed,
            particleSize: this.particleSize,
            particleColor: this.particleColor,
            particles: this.particles,
            time: this.time,
            particleLifespan: this.particleLifespan,
            toDecay: this.toDecay,
            offsetX: this.offsetX,
            offsetY: this.offsetY,
		}
	}
}
///add,{"type":"snap","snapX":true,snapY:false,"snapDistance":25,"snapWait":0.4}
class SnapGrid {
	constructor(x, y, w, h, snapX, snapY, snapDistance, snapWait) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.snapDistance = snapDistance;
		this.snapWait = snapWait;
		this.snapX = snapX;
		this.snapY = snapY;
		this.type = 'snap';
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			snapDistance: this.snapDistance,
			snapWait: this.snapWait,
			snapX: this.snapX,
			snapY: this.snapY,
		}
	}
}

class Filter {
	constructor(x, y, w, h, filter) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.filter = filter;
		this.type = 'filter';
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			filter: this.filter,
		}
	}
}
///add,{"type":"coindoor","coins":3,"currentCoins":3}
class CoinDoor {
	constructor(x, y, w, h, coins) {// coins = required coins
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.coins = coins;
        this.currentCoins = coins;
		this.type = 'coindoor';
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			coins: this.coins,
            currentCoins: this.currentCoins,
		}
	}
}

class Tornado {
	constructor(x, y, w, h, spinRadius) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'tornado';
		this.spinRadius = spinRadius;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			spinRadius: this.spinRadius,
		}
	}
}
class VinetteIncrease {
	constructor(x, y, w, h, innerRadius, outerRadius, opacity, vinetteColor) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'vinette';
		this.ir = innerRadius;
		this.or = outerRadius;
		this.o = opacity;
        if(typeof vinetteColor === 'string' || vinetteColor instanceof String){
            if(vinetteColor.startsWith('#')){
                this.vc = this.hexToRGB(vinetteColor);
            }   
        }
        this.vc = vinetteColor||{r: 0, g: 0, b: 0};
        // ONLY object with {r:?,g:?,b:?} values works
        // NOTHING Else >:c dont try and put a hex value in this dont do it u dumbass
	}
	simulate(dt) { }
    hexToRGB(color){
        var aRgbHex = color.match(/.{1,2}/g);
        return {r: parseInt(aRgbHex[0], 16), g: parseInt(aRgbHex[1], 16), b: parseInt(aRgbHex[2], 16)}
    }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			ir: this.ir,
			or: this.or,
			o: this.o,
            vc: this.vc,
		}
	}
}

class SizePlayer {
	constructor(x, y, w, h, size) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.size = size;
		this.type = "size";
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			size: this.size,
		}
	}
}
///add,{"type":"slip","slipSpeed":8}
class Slip {
	constructor(x, y, w, h, slipSpeed) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = "slip";
		if (slipSpeed === undefined) {
			this.slipSpeed = 2;
		} else {
			this.slipSpeed = slipSpeed;
		}
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			slipSpeed: this.slipSpeed,
		}
	}
}
///add,{"type":"zombie","timer":2,"timeBetween":3,"type":"zombie","dist":300}
class ZombieMaker {
	constructor(x, y, w, h, timeBetween, distanceFromPlayer) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
        this.timer = timeBetween;
        this.timeBetween = timeBetween;
		this.type = "zombie";
        this.dist = distanceFromPlayer;
	}
	simulate(dt) {}// client sided
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			timeBetween: this.timeBetween,
            timer: this.timer,
            dist: this.dist,
		}
	}
}
///add,{"type":"speedtrap","minSpeed":1}
class SpeedTrap {
	constructor(x, y, w, h, minSpeed, maxSpeed) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
        this.maxSpeed = maxSpeed;
		this.minSpeed = minSpeed;
		this.type = "speedtrap";
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			minSpeed: this.minSpeed,
            maxSpeed: this.maxSpeed,
		}
	}
}
///add,{"type":"musicchange","musicPath":"/sounds/Ravenhead.mp3"}
class MusicChange {
	constructor(x, y, w, h, musicPath, volume=1, startTime=0) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
        this.musicPath = musicPath;
		this.type = "musicchange";
        this.volume = volume;
        this.startTime = startTime;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			musicPath: this.musicPath,
            volume: this.volume,
            startTime: this.startTime,
		}
	}
}

class MovingSpeedTrap {
	constructor(w, h, points = [[50, 50]], speed = 30, currentPoint=0, minSpeed, maxSpeed, tpx, tpy) {
		this.w = w;
		this.h = h;
        this.maxSpeed = maxSpeed;
		this.minSpeed = minSpeed;
		this.type = "movingspeedtrap";
        this.currentPoint = currentPoint;
		this.points = points;
		this.speed = speed;
		this.x = this.points[currentPoint][0];
		this.y = this.points[currentPoint][1];
        this.tpx = tpx;
        this.tpy = tpy;

        let pointOn = this.points[this.currentPoint];
        this.pointOn = {x: pointOn[0], y: pointOn[1]};
        
        let nextPointIndex = this.currentPoint + 1;
        if (nextPointIndex >= this.points.length) {
            nextPointIndex = 0;
        }
        
        let nextPoint = this.points[nextPointIndex];
        this.pointTo = { x: nextPoint[0], y: nextPoint[1] };
        let angle = Math.atan2(this.pointTo.y - this.pointOn.y, this.pointTo.x - this.pointOn.x);
        this.xv = Math.cos(angle) * this.speed;
        this.yv = Math.sin(angle) * this.speed;
	}
	simulate(dt) {
        this.x += this.xv * dt;
	    this.y += this.yv * dt;
    	let over = false;
    	if (Math.abs(this.yv) > Math.abs(this.xv)) {
    		if (this.pointTo.y > this.pointOn.y) {
    			if (this.y > this.pointTo.y) {
    				over = true;
    			}
    		}
    		else {
    			if (this.y < this.pointTo.y) {
    				over = true;
    			}
    		}
    	}
    	else {
    		if (this.pointTo.x > this.pointOn.x) {
    			if (this.x > this.pointTo.x) {
    				over = true;
    			}
    		}
    		else {
    			if (this.x < this.pointTo.x) {
    				over = true;
    			}
    		}
    	}
    	if (over === true) {
    		this.currentPoint++;
    		if (this.currentPoint > this.points.length - 1) {
    			this.currentPoint = 0;
    		}
    
            let timeRemain = Math.sqrt(Math.pow(this.y - this.pointTo.y, 2) + Math.pow(this.x - this.pointTo.x, 2))/this.speed;
            
    		let pointOn = this.points[this.currentPoint];
            this.pointOn = {x: pointOn[0], y: pointOn[1]};
    
            this.x = this.pointOn.x;
    		this.y = this.pointOn.y;
    
            let nextPointIndex = this.currentPoint + 1;
    	    if (nextPointIndex >= this.points.length) {
        		nextPointIndex = 0;
        	}
        	let nextPoint = this.points[nextPointIndex];
        	this.pointTo = { x: nextPoint[0], y: nextPoint[1] };
    
            let angle = Math.atan2(this.pointTo.y - this.pointOn.y, this.pointTo.x - this.pointOn.x);
    	    this.xv = Math.cos(angle) * this.speed;
        	this.yv = Math.sin(angle) * this.speed;
    		this.simulate(timeRemain);
    	}
    }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			minSpeed: this.minSpeed,
            maxSpeed: this.maxSpeed,
            points: this.points,
			speed: this.speed,
			currentPoint: this.currentPoint,
            tpx: this.tpx,
            tpy: this.tpy,
		}
	}
}
///add,{"type":"timetrap","maxTime":10,"time":0}
class TimeTrap {
	constructor(x, y, w, h, maxTime, cooldownMult=3, trapType='death', trapParams=[]) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.maxTime = maxTime;
        this.time = 0;
		this.type = "timetrap";
        this.cdmult = cooldownMult;
        // trap types:
        // death (default)
        // speed
        // size
        // normal
        // tp
        // safe
        // morph
        // conveyor?
        this.trapType = trapType;
        if(this.trapType === 'tp'){
            this.tpx = trapParams[0];
            this.tpy = trapParams[1];
        } else if(this.trapType === 'size'){
            this.radiusMult = trapParams;
        } else if(this.trapType === 'speed'){
            this.speedMult = trapParams;
        } else if(this.trapType === 'conveyor'){
            this.force = trapParams[0];//force;
		    this.dir = { x: 0, y: 0 };
    		let direction = trapParams[1];//dir;
    		if (dir == null) {
    			direction = 'up';
    		}
    		this.direction = direction;
    		if (direction === 'down') {
    			this.dir.y = this.force;
    		}
    		if (direction === 'up') {
    			this.dir.y = -this.force;
    		}
    		if (direction === 'left') {
    			this.dir.x = -this.force;
    		}
    		if (direction === 'right') {
    			this.dir.x = this.force;
    		}
        } else if(this.trapType === 'morph'){
            this.morphId = trapParams;
        }
	}
	simulate(dt) { }
	pack() {
        let pack = {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			time: this.time,
            maxTime: this.maxTime,
            cdmult: this.cdmult,
            trapType: this.trapType,
		}

        if(this.trapType === 'tp'){
            pack.tpx = this.tpx;
            pack.tpy = this.tpy;
        } else if(this.trapType === 'size'){
            pack.radiusMult = this.radiusMult;
        } else if(this.trapType === 'speed'){
            pack.speedMult = this.speedMult;
        } else if(this.trapType === 'conveyor'){
            pack.force = this.force;//force;
		    pack.dir = this.dir;
        } else if(this.trapType === 'morph'){
            pack.morphId = this.morphId;
        }

        return pack;
	}
}

class TpTrap extends TimeTrap {
    constructor(x, y, w, h, maxTime, tpx, tpy, cooldownMult=3) {
		super(x,y,w,h,maxTime,cooldownMult);
		this.type = "tptrap";
        this.tpx = tpx;
        this.tpy = tpy;
	}
    pack() {
		return {
			...super.pack(),
            tpx: this.tpx,
            tpy: this.tpy,
		}
	}
}

///add,{"type":"growing","minWidth":50,"maxWidth":100,"growSpeed":45,"growing":true}
class GrowingObstacle {
	constructor(x, y, minWidth, maxWidth, growSpeed, growing = true) {
		this.x = x;
		this.y = y;
		this.w = minWidth;
		this.h = minWidth;
		this.minWidth = minWidth;
		this.maxWidth = maxWidth;
		this.growSpeed = growSpeed;
		this.growing = growing;
		this.type = "growing";
	}
	simulate(dt) {
		if (this.growing) {
			this.w += this.growSpeed * dt;
			this.h += this.growSpeed * dt;
			this.x -= this.growSpeed * dt / 2;
			this.y -= this.growSpeed * dt / 2;
			if (this.w > this.maxWidth) {
				this.growing = false;
				let overGrowth = this.w - this.maxWidth;
				this.w -= overGrowth * 2;
				this.h -= overGrowth * 2;
				this.x += overGrowth;
				this.y += overGrowth;
			}
		} else {
			this.w -= this.growSpeed * dt;
			this.h -= this.growSpeed * dt;
			this.x += this.growSpeed * dt / 2;
			this.y += this.growSpeed * dt / 2;
			if (this.w < this.minWidth) {
				this.growing = true;
				let underGrowth = this.minWidth - this.w;
				this.w += underGrowth * 2;
				this.h += underGrowth * 2;
				this.x -= underGrowth;
				this.y -= underGrowth;
			}
		}
	}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			minWidth: this.minWidth,
			maxWidth: this.maxWidth,
			growSpeed: this.growSpeed,
			growing: this.growing
		}
	}
}
///add,{"type":"growinglava","minWidth":1,"maxWidth":400,"growSpeed":100,"growing":true}
class GrowingLavaObstacle {
	constructor(x, y, minWidth, maxWidth, growSpeed, growing = true) {
		this.x = x;
		this.y = y;
		this.w = minWidth;
		this.h = minWidth;
		this.minWidth = minWidth;
		this.maxWidth = maxWidth;
		this.growSpeed = growSpeed;
		this.growing = growing;
		this.type = "growinglava";
	}
	simulate(dt) {
		if (this.growing) {
			this.w += this.growSpeed * dt;
			this.h += this.growSpeed * dt;
			this.x -= this.growSpeed * dt / 2;
			this.y -= this.growSpeed * dt / 2;
			if (this.w > this.maxWidth) {
				this.growing = false;
				let overGrowth = this.w - this.maxWidth;
				this.w -= overGrowth * 2;
				this.h -= overGrowth * 2;
				this.x += overGrowth;
				this.y += overGrowth;
			}
		} else {
			this.w -= this.growSpeed * dt;
			this.h -= this.growSpeed * dt;
			this.x += this.growSpeed * dt / 2;
			this.y += this.growSpeed * dt / 2;
			if (this.w < this.minWidth) {
				this.growing = true;
				let underGrowth = this.minWidth - this.w;
				this.w += underGrowth * 2;
				this.h += underGrowth * 2;
				this.x -= underGrowth;
				this.y -= underGrowth;
			}
		}
	}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			minWidth: this.minWidth,
			maxWidth: this.maxWidth,
			growSpeed: this.growSpeed,
			growing: this.growing
		}
	}
}
///add,{"type":"growingcircle","r":40,"minWidth":25,"maxWidth":50,"growSpeed":38,"growing":true}
class GrowingCircleObstacle {
	constructor(x, y, minWidth, maxWidth, growSpeed, growing = true) {
		this.x = x;
		this.y = y;
		this.r = minWidth;
		this.minWidth = minWidth;
		this.maxWidth = maxWidth;
		this.growSpeed = growSpeed / 2;
		this.growing = growing;
		this.type = "growingcircle";
	}
	simulate(dt) {
		if (this.growing) {
			this.r += this.growSpeed * dt;
			if (this.r > this.maxWidth) {
				this.growing = false;
				let overGrowth = this.r - this.maxWidth;
				this.r -= overGrowth * 2;
			}
		} else {
			this.r -= this.growSpeed * dt;
			if (this.r < this.minWidth) {
				this.growing = true;
				let underGrowth = this.minWidth - this.r;
				this.r += underGrowth * 2;
			}
		}
	}
	pack() {
		return {
			x: this.x,
			y: this.y,
			r: this.r,
			type: this.type,
			minWidth: this.minWidth,
			maxWidth: this.maxWidth,
			growSpeed: this.growSpeed,
			growing: this.growing
		}
	}
}
///add,{"type":"circle-tp","r":180,"tpx":500,"tpy":500}
class CircularTpObstacle {
	constructor(x, y, r, tpx, tpy) {
		this.x = x;
		this.y = y;
		this.r = r;
		this.tpx = tpx;
		this.tpy = tpy;
		this.type = 'circle-tp';
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			r: this.r,
			tpx: this.tpx,
			tpy: this.tpy,
			type: this.type,
		}
	}
}

// 50 persec/
// o
// then deg/sec
// 200deg/sec
class Sentry {
	constructor(x, y, r, lw=300, lh=50, speed=180, rest=0) {
		this.x = x;
		this.y = y;
		this.r = r;
        this.laser = {
            x: this.x, // how do i offset lol help
            y: this.y, // what do u do for rendering? literally just copy it here
            w: lw,
            h: lh,
        }
		// lol server way off
		// had a lot of code 
		// 
        this.laser.pivotX = this.laser.x + this.laser.w/2;
        this.laser.pivotY = this.laser.y + this.laser.h/2;
        this.laser.distToPivot = Math.sqrt(Math.pow(this.laser.pivotX - (this.laser.x + this.laser.w/2), 2) + Math.pow(this.laser.pivotY - (this.laser.y + this.laser.h/2), 2));
        this.speed = speed;
		this.angle = 0;
		this.rest = rest;
		this.type = 'circle-sentry';
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			r: this.r,
			angle: this.angle,
			type: this.type,
            speed: this.speed,
            laser: this.laser,
			rest: this.rest,
		}
	}
}

class TurretSentry {
	constructor(x, y, r, bulletRadius=25, shootSpeed=1, interpolateSpeed=180, restAngle=0, bulletLife=3, bulletSpeed=100) {
		this.x = x;
		this.y = y;
		this.r = r;
        this.bulletRadius = bulletRadius;
        this.shootSpeed = shootSpeed;
        this.interpolateSpeed = interpolateSpeed*Math.PI/180;
		this.angle = 0;
		this.restAngle = restAngle;
		this.type = 'circle-turret-sentry';
        this.life = bulletLife;
        this.bulletSpeed = bulletSpeed;
        // renders big rectangle preview for where its gonna shoot
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			r: this.r,
			bulletRadius: this.bulletRadius,
            shootSpeed: this.shootSpeed,
            interpolateSpeed: this.interpolateSpeed,
            angle: this.angle,
            restAngle: this.restAngle,
            type: this.type,
            bulletLife: this.life,
            bulletSpeed: this.bulletSpeed,
		}
	}
}


class CircularLavaObstacle {
	constructor(x, y, r) {
		this.x = x;
		this.y = y;
		this.r = r;
		this.type = 'circle-lava';
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			r: this.r,
			type: this.type,
		}
	}
}

class CircularSafeObstacle {
	constructor(x, y, r) {
		this.x = x;
		this.y = y;
		this.r = r;
		this.type = 'circle-safe';
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			r: this.r,
			type: this.type,
		}
	}
}

///add,{"type":"growinglavacircle","radius":40,"minWidth":30,"maxWidth":80,"growSpeed":30,"growing":true}
class GrowingCircleLavaObstacle {
	constructor(x, y, minWidth, maxWidth, growSpeed, growing = true) {
		this.x = x;
		this.y = y;
		this.r = minWidth;
		this.minWidth = minWidth;
		this.maxWidth = maxWidth;
		this.growSpeed = growSpeed / 2;
		this.growing = growing;
		this.type = "growinglavacircle";
	}
	simulate(dt) {
		if (this.growing) {
			this.r += this.growSpeed * dt;
			if (this.r > this.maxWidth) {
				this.growing = false;
				let overGrowth = this.r - this.maxWidth;
				this.r -= overGrowth * 2;
			}
		} else {
			this.r -= this.growSpeed * dt;
			if (this.r < this.minWidth) {
				this.growing = true;
				let underGrowth = this.minWidth - this.r;
				this.r += underGrowth * 2;
			}
		}
	}
	pack() {
		return {
			x: this.x,
			y: this.y,
			r: this.r,
			type: this.type,
			minWidth: this.minWidth,
			maxWidth: this.maxWidth,
			growSpeed: this.growSpeed,
			growing: this.growing
		}
	}
}

class Booster {
	constructor(x, y, w, h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = "boost";
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
		}
	}
}
class BoostPad {
	constructor(x, y, w, h, speed) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.speed = speed;
		this.type = "boostpad";
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			speed: this.speed,
			type: this.type,
		}
	}
}
///add,{"type":"coin","collected":false}
class Coin {
	constructor(x, y, w, h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = "coin";
        this.collected = false;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            collected: this.collected,
		}
	}
}

///add,{"type":"circle-coin","radius":25}
class CircularCoin {
	constructor(x, y, r) {
		this.x = x;
		this.y = y;
		this.radius = r;
		this.type = "circle-coin";
        this.collected = false;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			radius: this.radius,
			type: this.type,
            collected: this.collected,
		}
	}
}

class Bonus {
	constructor(x, y, w, h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = "bonus";
        this.collected = false;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            collected: this.collected,
		}
	}
}

class CircularBonus {
	constructor(x, y, r) {
		this.x = x;
		this.y = y;
		this.radius = r;
		this.type = "circle-bonus";
        this.collected = false;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			radius: this.radius,
			type: this.type,
            collected: this.collected,
		}
	}
}

class WallBooster {
	constructor(x, y, w, h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = "wallboost";
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
		}
	}
}

class Winpad {
	constructor(x, y, w, h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = "winpad";
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
		}
	}
}

class Zone {
	constructor(x, y, w, h, data='0') {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.value = data;
		this.type = 'zone';
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			value: this.value,
		}
	}
}

	
///add,[{"type":"portal","name":"Hub","acronym":"Hub","difficulty":"Peaceful","difficultyNumber":0}]
class Portal {
	constructor(x, y, size, name, acronym, difficulty, difficultyNumber, musicPath) {
		this.x = x;
		this.y = y;
		this.w = size;
		this.h = size;
		this.name = name;
		this.acronym = acronym;
		this.difficulty = difficulty;
		this.difficultyNumber = difficultyNumber;
		this.type = 'portal';
		this.musicPath = musicPath;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			name: this.name,
			acronym: this.acronym,
			difficulty: this.difficulty,
			difficultyNumber: this.difficultyNumber,
			musicPath: this.musicPath,
		}
	}
}


///add,{"type":"move","currentPoint":0,"points":[[17050,0],[24400,0],[24400,-1000],[17050,-1000]],"speed":620,"collidable":true}
class MovingObstacle {
	constructor(w, h, points = [[50, 50]], speed = 30, currentPoint=0, alongWith = false) {
		this.type = 'move';
		this.currentPoint = currentPoint;
		this.points = points;
		this.speed = speed;
		this.w = w;
		this.h = h;
		this.x = this.points[currentPoint][0];
		this.y = this.points[currentPoint][1];
		this.alongWith = alongWith;

        let pointOn = this.points[this.currentPoint];
        this.pointOn = {x: pointOn[0], y: pointOn[1]};
        
        let nextPointIndex = this.currentPoint + 1;
        if (nextPointIndex >= this.points.length) {
            nextPointIndex = 0;
        }
        
        let nextPoint = this.points[nextPointIndex];
        this.pointTo = { x: nextPoint[0], y: nextPoint[1] };
        let angle = Math.atan2(this.pointTo.y - this.pointOn.y, this.pointTo.x - this.pointOn.x);
        this.xv = Math.cos(angle) * this.speed;
        this.yv = Math.sin(angle) * this.speed;
	}
	simulate(dt) {
		this.x += this.xv * dt;
	    this.y += this.yv * dt;
    	let over = false;
    	if (Math.abs(this.yv) > Math.abs(this.xv)) {
    		if (this.pointTo.y > this.pointOn.y) {
    			if (this.y > this.pointTo.y) {
    				over = true;
    			}
    		}
    		else {
    			if (this.y < this.pointTo.y) {
    				over = true;
    			}
    		}
    	}
    	else {
    		if (this.pointTo.x > this.pointOn.x) {
    			if (this.x > this.pointTo.x) {
    				over = true;
    			}
    		}
    		else {
    			if (this.x < this.pointTo.x) {
    				over = true;
    			}
    		}
    	}
    	if (over === true) {
    		this.currentPoint++;
    		if (this.currentPoint > this.points.length - 1) {
    			this.currentPoint = 0;
    		}
    
            let timeRemain = Math.sqrt(Math.pow(this.y - this.pointTo.y, 2) + Math.pow(this.x - this.pointTo.x, 2))/this.speed;
            
    		let pointOn = this.points[this.currentPoint];
            this.pointOn = {x: pointOn[0], y: pointOn[1]};
    
            this.x = this.pointOn.x;
    		this.y = this.pointOn.y;
    
            let nextPointIndex = this.currentPoint + 1;
    	    if (nextPointIndex >= this.points.length) {
        		nextPointIndex = 0;
        	}
        	let nextPoint = this.points[nextPointIndex];
        	this.pointTo = { x: nextPoint[0], y: nextPoint[1] };
    
            let angle = Math.atan2(this.pointTo.y - this.pointOn.y, this.pointTo.x - this.pointOn.x);
    	    this.xv = Math.cos(angle) * this.speed;
        	this.yv = Math.sin(angle) * this.speed;
    		this.simulate(timeRemain);
    	}
	}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			points: this.points,
			speed: this.speed,
			currentPoint: this.currentPoint,
			alongWith: this.alongWith,
		}
	}
}

class MorphMoving extends MovingObstacle {
	constructor(w, h, points=[[50, 50]], speed=30, currentPoint=0, morphId) {
		super(w, h, points, speed, currentPoint);
		this.type = 'morphmove'
		this.active = false;
		this.morphId = morphId;
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			points: this.points,
			speed: this.speed,
			currentPoint: this.currentPoint,
			alongWith: this.alongWith,
			active: this.active,
			morphId: this.morphId,
		}
	}
}

class MorphLavaMove extends MovingObstacle {
	constructor(w, h, points=[[50, 50]], speed=30, currentPoint=0, morphId, collidable=true) {
		super(w, h, points, speed, currentPoint);
		this.type = 'morphlavamove'
		this.active = false;
		this.morphId = morphId;
        this.collidable = collidable;
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			points: this.points,
			speed: this.speed,
			currentPoint: this.currentPoint,
			alongWith: this.alongWith,
			active: this.active,
			morphId: this.morphId,
            collidable: this.collidable,
		}
	}
}

class DeadPusher extends MovingObstacle {
	constructor(w, h, points = [[50, 50]], speed = 30, currentPoint=0) {
        super(w,h,points,speed,currentPoint);
		this.type = 'deadpusher';
	}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			points: this.points,
			speed: this.speed,
			currentPoint: this.currentPoint,
		}
	}
}

class MovingSafe {
	constructor(w, h, points = [[50, 50]], speed = 30, currentPoint = 0) {
		this.type = 'movingsafe';
		this.currentPoint = currentPoint;
		this.points = points;
		this.speed = speed;
		this.w = w;
		this.h = h;
		this.x = this.points[currentPoint][0];
		this.y = this.points[currentPoint][1];

        let pointOn = this.points[this.currentPoint];
        this.pointOn = {x: pointOn[0], y: pointOn[1]};
        
        let nextPointIndex = this.currentPoint + 1;
        if (nextPointIndex >= this.points.length) {
            nextPointIndex = 0;
        }
        
        let nextPoint = this.points[nextPointIndex];
        this.pointTo = { x: nextPoint[0], y: nextPoint[1] };
        let angle = Math.atan2(this.pointTo.y - this.pointOn.y, this.pointTo.x - this.pointOn.x);
        this.xv = Math.cos(angle) * this.speed;
        this.yv = Math.sin(angle) * this.speed;
	}
	simulate(dt) {
		this.x += this.xv * dt;
	    this.y += this.yv * dt;
    	let over = false;
    	if (Math.abs(this.yv) > Math.abs(this.xv)) {
    		if (this.pointTo.y > this.pointOn.y) {
    			if (this.y > this.pointTo.y) {
    				over = true;
    			}
    		}
    		else {
    			if (this.y < this.pointTo.y) {
    				over = true;
    			}
    		}
    	}
    	else {
    		if (this.pointTo.x > this.pointOn.x) {
    			if (this.x > this.pointTo.x) {
    				over = true;
    			}
    		}
    		else {
    			if (this.x < this.pointTo.x) {
    				over = true;
    			}
    		}
    	}
    	if (over === true) {
    		this.currentPoint++;
    		if (this.currentPoint > this.points.length - 1) {
    			this.currentPoint = 0;
    		}
    
            let timeRemain = Math.sqrt(Math.pow(this.y - this.pointTo.y, 2) + Math.pow(this.x - this.pointTo.x, 2))/this.speed;
            
    		let pointOn = this.points[this.currentPoint];
            this.pointOn = {x: pointOn[0], y: pointOn[1]};
    
            this.x = this.pointOn.x;
    		this.y = this.pointOn.y;
    
            let nextPointIndex = this.currentPoint + 1;
    	    if (nextPointIndex >= this.points.length) {
        		nextPointIndex = 0;
        	}
        	let nextPoint = this.points[nextPointIndex];
        	this.pointTo = { x: nextPoint[0], y: nextPoint[1] };
    
            let angle = Math.atan2(this.pointTo.y - this.pointOn.y, this.pointTo.x - this.pointOn.x);
    	    this.xv = Math.cos(angle) * this.speed;
        	this.yv = Math.sin(angle) * this.speed;
    		this.simulate(timeRemain);
    	}
	}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			points: this.points,
			speed: this.speed,
			currentPoint: this.currentPoint,
		}
	}
}



class RotatingSpeedTrap {
	constructor(x, y, w, h, spd, angle, pivotX, pivotY, minSpeed, maxSpeed, tpx, tpy) {
        this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
        this.minSpeed = minSpeed;
        this.maxSpeed = maxSpeed;
        this.tpx = tpx;
        this.tpy = tpy;
		this.type = 'rotatingspeedtrap';
		this.rotateSpeed = spd * Math.PI/180;
		this.angle = angle;
        this.pivotX = pivotX || x + w/2;
        this.pivotY = pivotY || y + h/2;
        this.distToPivot = Math.sqrt(Math.pow(this.pivotX - (x + w/2), 2) + Math.pow(this.pivotY - (y + h/2), 2));
        this.x = Math.cos(this.angle * Math.PI/180) * this.distToPivot + this.pivotX;
        this.y = Math.sin(this.angle * Math.PI/180) * this.distToPivot + this.pivotY;
	}
	simulate(dt) {
		this.angle += this.rotateSpeed * dt;
        this.x = Math.cos(this.angle * Math.PI/180) * this.distToPivot + this.pivotX;
        this.y = Math.sin(this.angle * Math.PI/180) * this.distToPivot + this.pivotY;
	}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			angle: this.angle,
			rotateSpeed: this.rotateSpeed,
            pivotX: this.pivotX,
            pivotY: this.pivotY,
            distToPivot: this.distToPivot,
            tpx: this.tpx,
            tpy: this.tpy,
            minSpeed: this.minSpeed,
            maxSpeed: this.maxSpeed,
		}
	}
}
///add,{"type":"move","currentPoint":0,"points":[[4100,350],[3900,300]],"speed":600}
///add,{"type":"lavamove","currentPoint":0,"points":[[4150,0],[4400,0]],"speed":120,"collidable":false}
///add,{"type":"tpmove","currentPoint":0,"points":[[3800,2875],[4150,2875]],"tpx":4000,"tpy":3325,"speed":120,"collidable":false}
class MovingLavaObstacle {
	constructor(w, h, points = [[50, 50]], speed = 30, currentPoint=0, collidable=true) {
		this.type = 'lavamove';
		this.currentPoint = currentPoint;
		this.points = points;
		this.speed = speed;
    	this.collidable = collidable;
		this.w = w;
		this.h = h;
		this.x = this.points[currentPoint][0];
		this.y = this.points[currentPoint][1];

        let pointOn = this.points[this.currentPoint];
        this.pointOn = {x: pointOn[0], y: pointOn[1]};
        
        let nextPointIndex = this.currentPoint + 1;
        if (nextPointIndex >= this.points.length) {
            nextPointIndex = 0;
        }
        
        let nextPoint = this.points[nextPointIndex];
        this.pointTo = { x: nextPoint[0], y: nextPoint[1] };
        let angle = Math.atan2(this.pointTo.y - this.pointOn.y, this.pointTo.x - this.pointOn.x);
        this.xv = Math.cos(angle) * this.speed;
        this.yv = Math.sin(angle) * this.speed;
	}
	simulate(dt) {
		this.x += this.xv * dt;
	    this.y += this.yv * dt;
    	let over = false;
    	if (Math.abs(this.yv) > Math.abs(this.xv)) {
    		if (this.pointTo.y > this.pointOn.y) {
    			if (this.y > this.pointTo.y) {
    				over = true;
    			}
    		}
    		else {
    			if (this.y < this.pointTo.y) {
    				over = true;
    			}
    		}
    	}
    	else {
    		if (this.pointTo.x > this.pointOn.x) {
    			if (this.x > this.pointTo.x) {
    				over = true;
    			}
    		}
    		else {
    			if (this.x < this.pointTo.x) {
    				over = true;
    			}
    		}
    	}
    	if (over === true) {
    		this.currentPoint++;
    		if (this.currentPoint > this.points.length - 1) {
    			this.currentPoint = 0;
    		}
    
            let timeRemain = Math.sqrt(Math.pow(this.y - this.pointTo.y, 2) + Math.pow(this.x - this.pointTo.x, 2))/this.speed;
            
    		let pointOn = this.points[this.currentPoint];
            this.pointOn = {x: pointOn[0], y: pointOn[1]};
    
            this.x = this.pointOn.x;
    		this.y = this.pointOn.y;
    
            let nextPointIndex = this.currentPoint + 1;
    	    if (nextPointIndex >= this.points.length) {
        		nextPointIndex = 0;
        	}
        	let nextPoint = this.points[nextPointIndex];
        	this.pointTo = { x: nextPoint[0], y: nextPoint[1] };
    
            let angle = Math.atan2(this.pointTo.y - this.pointOn.y, this.pointTo.x - this.pointOn.x);
    	    this.xv = Math.cos(angle) * this.speed;
        	this.yv = Math.sin(angle) * this.speed;
    		this.simulate(timeRemain);
    	}
	}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			points: this.points,
			speed: this.speed,
			currentPoint: this.currentPoint,
      collidable: this.collidable
		}
	}
}

class BouncyObstacle extends NormalObstacle {
	constructor(x, y, w, h, effect = 30) {
		super(x, y, w, h);
		this.type = 'bounce';
		this.effect = effect;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			effect: this.effect,
		}
	}
}
class WB extends NormalObstacle {
	constructor(x, y, w, h, baseEffect = 40, effect = 80) {
		super(x, y, w, h);
		this.type = 'wb';
		this.baseEffect = baseEffect;
		this.effect = effect;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			effect: this.effect,
			baseEffect: this.baseEffect,
		}
	}
}

class Oval {
	constructor(x, y, r0, r1) {
		this.x = x + r0/2;
		this.y = y + r1/2;
		this.radius = r0/2;
        this.radius2 = r1/2;
		this.type = 'oval';
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			radius: this.radius,
            radius2: this.radius2,
			type: this.type,
		}
	}
}

class LavaOval {
	constructor(x, y, r0, r1, canCollide=true) {
		this.x = x + r0/2;
		this.y = y + r1/2;
		this.radius = r0/2;
        this.radius2 = r1/2;
		this.type = 'lava-oval';
        this.canCollide = canCollide;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			radius: this.radius,
            radius2: this.radius2,
			type: this.type,
            canCollide: this.canCollide,
		}
	}
}

// vinette vision thing like eX
class Torch {
	constructor(x, y, innerRadius, outerRadius) {
		this.x = x;
		this.y = y;
		this.innerRadius = innerRadius;
        this.outerRadius = outerRadius;
		this.type = 'torch';
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			innerRadius: this.innerRadius,
            outerRadius: this.outerRadius,
			type: this.type,
		}
	}
}

class CircularNormalObstacle {
	constructor(x, y, r) {
		this.x = x;
		this.y = y;
		this.radius = r;
		this.type = 'circle-normal';
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			radius: this.radius,
			type: this.type,
		}
	}
}
///add,{"type":"circle-hollow","radius":1000,"innerRadius":500}
class CircularHollowObstacle {
	constructor(x, y, r, innerRadius) {
		this.x = x;
		this.y = y;
		this.radius = r;
		this.type = 'circle-hollow';
        this.innerRadius = innerRadius;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			radius: this.radius,
			type: this.type,
            innerRadius: this.innerRadius,
		}
	}
}

class CircularHollowLava {
	constructor(x, y, r, innerRadius) {
		this.x = x;
		this.y = y;
		this.radius = r;
		this.type = 'circle-hollow-lava';
        this.innerRadius = innerRadius;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			radius: this.radius,
			type: this.type,
            innerRadius: this.innerRadius,
		}
	}
}

class CircularHollowSlice {
	constructor(x, y, r, startAngle, endAngle, innerRadius, rotateSpeed=0) {
		this.x = x;
		this.y = y;
		this.radius = r;
        this.rotateSpeed = rotateSpeed*Math.PI/180;
        if(rotateSpeed != 0) {
            this.toRotate = true;
        } else {
            this.toRotate = false;
        }
		this.type = 'circle-hollow-slice';
        this.startAngle = startAngle*Math.PI/180;
        this.endAngle = endAngle*Math.PI/180;
        this.innerRadius = innerRadius;
        this.startPolygon = new Polygon([
            [this.x+Math.cos(this.startAngle)*this.innerRadius,this.y+Math.sin(this.startAngle)*this.innerRadius],
            [this.x+Math.cos(this.startAngle)*this.radius,this.y+Math.sin(this.startAngle)*this.radius],
        ], 'poly')
        this.endPolygon = new Polygon([
            [this.x+Math.cos(this.endAngle)*this.innerRadius,this.y+Math.sin(this.endAngle)*this.innerRadius],
            [this.x+Math.cos(this.endAngle)*this.radius,this.y+Math.sin(this.endAngle)*this.radius],
        ], 'poly')
	}
	simulate(dt) {
        if(!this.toRotate){
           return; 
        }

        this.startAngle += this.rotateSpeed*dt;
        this.endAngle += this.rotateSpeed*dt;
    }
	pack() {
		return {
			x: this.x,
			y: this.y,
			radius: this.radius,
			type: this.type,
            startAngle: this.startAngle,
            endAngle: this.endAngle,
            startPolygon: this.startPolygon,
            endPolygon: this.endPolygon,
            innerRadius: this.innerRadius,
            toRotate: this.toRotate,
            rotateSpeed: this.rotateSpeed,
		}
	}
}

class CircularHollowLavaSlice extends CircularHollowSlice {
	constructor(x, y, r, startAngle, endAngle, innerRadius, rotateSpeed=0) {
		super(x, y, r, startAngle, endAngle, innerRadius, rotateSpeed);
        this.type = 'circle-hollow-slice-lava'
	}
	simulate(dt) {
        super.simulate(dt);
    }
	pack() {
		return {
			...super.pack(),
		}
	}
}

class CircularSliceObstacle {
	constructor(x, y, r, startAngle, endAngle) {
		this.x = x;
		this.y = y;
		this.radius = r;
		this.type = 'circle-slice';
        this.startAngle = startAngle*Math.PI/180;
        this.endAngle = endAngle*Math.PI/180;
        this.startPolygon = new Polygon([
            [this.x,this.y],
            [this.x+Math.cos(this.startAngle)*this.radius,this.y+Math.sin(this.startAngle)*this.radius],
        ], 'poly')
        this.endPolygon = new Polygon([
            [this.x,this.y],
            [this.x+Math.cos(this.endAngle)*this.radius,this.y+Math.sin(this.endAngle)*this.radius],
        ], 'poly')
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			radius: this.radius,
			type: this.type,
            startAngle: this.startAngle,
            endAngle: this.endAngle,
            startPolygon: this.startPolygon,
            endPolygon: this.endPolygon
		}
	}
}

class CircularLavaSlice extends CircularSliceObstacle {
	constructor(x, y, r, startAngle, endAngle) {
		super(x, y, r, startAngle, endAngle)
        this.type = 'circle-slice-lava'
	}
	simulate(dt) {}
	pack() {
		return {
			...super.pack()
		}
	}
}
///add,{"type":"circle-bounce","radius":150,"effect":35}
///add,{"type":"bounce","effect":900}
class CircularBouncyObstacle extends CircularNormalObstacle {
	constructor(x, y, r, effect = 30) {
		super(x, y, r);
		this.type = 'circle-bounce';
		this.effect = effect;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			radius: this.radius,
			type: this.type,
			effect: this.effect,
		}
	}
}


class Lava extends NormalObstacle {
	constructor(x, y, w, h, canCollide = true, angle=0) {
		super(x, y, w, h);
		this.canCollide = canCollide;
		this.type = 'lava';
		if (angle % 360 !== 0) {
			// console.log(angle)
			return new RotatingLava(x, y, w, h, 0, angle, undefined, undefined, 0, canCollide);
		}
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			canCollide: this.canCollide,
		}
	}
}
///add,{"type":"switchlava","onTime":5,"offTime":5,"state":false,"timer":5}
class SwitchLava {
	constructor(x, y, w, h, offTime, onTime, state, offset, collidable=true) {
		this.type = 'switchlava';
        this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.offTime = offTime;
        this.onTime = onTime;
        this.state = state;
        this.timer = offset;// offset at the start
        this.collidable = collidable;
	}
	simulate(dt) {
        this.timer -= dt;
        if (this.timer < 0) {
            if (this.state == true) {
                this.timer += this.offTime; // speced ;-;
            } else {
                this.timer += this.onTime;
            }
            this.state = !this.state;
        }
    }
    pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			onTime: this.onTime,
			offTime: this.offTime,
            state: this.state,
            timer: this.timer,
            collidable: this.collidable
		}
	}
}

class SwitchObstacle extends SwitchLava {
	constructor(x, y, w, h, offTime, onTime, state, offset) {
        super(x, y, w, h, offTime, onTime, state, offset);
		this.type = 'switchnormal';
	}
    pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			onTime: this.onTime,
			offTime: this.offTime,
            state: this.state,
            timer: this.timer,
		}
	}
}
///add,{"type":"trans","collide":false,"opaq":0.95}
class TransObstacle extends NormalObstacle {
	constructor(x, y, w, h, collide = true, opaq = 0.25) {
		super(x, y, w, h);
		this.type = 'trans';
		this.collide = collide;
		this.opaq = opaq;
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			collide: this.collide,
			opaq: this.opaq,
		}
	}
}
///add,{"type":"push","dir":"right","max":1000,"pushBack":22,"startX":3000,"startY":1800}
///add,{"type":"push","dir":"up","max":100,"pushBack":10,"startX":3000,"startY":1800}
class Pusher extends NormalObstacle {
	constructor(x, y, w, h, dir = 'left', max=100, pushBack=20) {
		super(x, y, w, h);
		this.type = 'push';
		this.dir = dir;
		this.max = max;
		this.pushBack = pushBack;
		this.startX = x;
		this.startY = y;
        this.pusherId = Math.random();
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			dir: this.dir,
			max: this.max,
			pushBack: this.pushBack,
			startX: this.startX,
			startY: this.startY,
            pusherId: this.pusherId,
		}
	}
}
///add,{"type":"rotate-lava","angle":0,"rotateSpeed":80,"distToPivot":0,"collidable":true}
class RotatingLava extends Lava {
	constructor(x, y, w, h, spd, angle=0, pivotX, pivotY, distToPivot, canCollide) {
		super(x, y, w, h);
		this.type = 'rotate-lava';
		this.rotateSpeed = spd;
		this.angle = angle;
        this.canCollide = canCollide ?? true;
        this.pivotX = pivotX ?? x + w/2;
        this.pivotY = pivotY ?? y + h/2;
        this.distToPivot = distToPivot ?? Math.sqrt(Math.pow(this.pivotX - (x + w/2), 2) + Math.pow(this.pivotY - (y + h/2), 2));
        this.x = Math.cos(this.angle * Math.PI/180) * this.distToPivot + this.pivotX;
        this.y = Math.sin(this.angle * Math.PI/180) * this.distToPivot + this.pivotY;
	}
	simulate(dt) {
		this.angle += this.rotateSpeed * dt;
        if(this.distToPivot !== 0){
            this.x = Math.cos(this.angle * Math.PI/180) * this.distToPivot + this.pivotX;
            this.y = Math.sin(this.angle * Math.PI/180) * this.distToPivot + this.pivotY;
        }
	}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			angle: this.angle,
			rotateSpeed: this.rotateSpeed,
			pivotX: this.pivotX,
			pivotY: this.pivotY,
			distToPivot: this.distToPivot,
            canCollide: this.canCollide,
		}
	}
}
///add,{"type":"rotate-normal","angle":0,"rotateSpeed":80,"distToPivot":0,"collidable":true}
class RotatingNormal extends RotatingLava {
	constructor(x, y, w, h, spd, angle=0, pivotX, pivotY, distToPivot=0, canCollide=true) {
		super(x, y, w, h,  spd, angle, pivotX, pivotY, distToPivot, canCollide);
		this.type = 'rotate-normal'
	}
}
/*
points format: [
    50, // x
    50, // y
    30, // speed
    1, // pause time
]*/
class MovingPause {
	constructor(w, h, points = [[50, 50, 30, 1]], currentPoint=0) {
		this.type = 'move-pause';
		this.currentPoint = currentPoint;
		this.points = points;
		this.w = w;
		this.h = h;
		this.x = this.points[currentPoint][0];
		this.y = this.points[currentPoint][1];
        this.speed = this.points[currentPoint][2];
        this.waitTimer = this.points[currentPoint][3];
	}
	simulate(dt) {
        if(this.waitTimer > 0){
            this.waitTimer -= dt;
            if(this.waitTimer <= 0){
                const overflow = Math.abs(this.waitTimer);
                this.simulate(overflow);
            }
        } else {
            let nextPointIndex = this.currentPoint + 1;
            if (nextPointIndex >= this.points.length) {
                nextPointIndex = 0;
            }
            let nextPoint = this.points[nextPointIndex];
            let currentPoint = this.points[this.currentPoint];
            this.pointTo = { x: nextPoint[0], y: nextPoint[1], speed: nextPoint[2], pause: nextPoint[3] };
            this.pointOn = { x: currentPoint[0], y: currentPoint[1], speed: currentPoint[2], pause: currentPoint[3] };
            let angle = Math.atan2(this.pointTo.y - this.pointOn.y, this.pointTo.x - this.pointOn.x);
            let xv = Math.cos(angle) * this.speed;
            let yv = Math.sin(angle) * this.speed;
            this.x += xv * dt;
            this.y += yv * dt;
            let timeRemain = 0;
            let over = false;
            if (Math.abs(this.yv) > Math.abs(this.xv)) {
                if (this.pointTo.y > this.pointOn.y) {
                    if (this.y > this.pointTo.y) {
                        over = true;
                    }
                }
                else {
                    if (this.y < this.pointTo.y) {
                        over = true;
                    }
                }
            }
            else {
                if (this.pointTo.x > this.pointOn.x) {
                    if (this.x > this.pointTo.x) {
                        over = true;
                    }
                }
                else {
                    if (this.x < this.pointTo.x) {
                        over = true;
                    }
                }
            }
            if (over == true) {
                this.currentPoint++;
                if (this.currentPoint > this.points.length - 1) {
                    this.currentPoint = 0;
                }
                timeRemain = Math.sqrt(Math.pow(this.y - this.pointTo.y, 2) + Math.pow(this.x - this.pointTo.x, 2));
                this.x = this.pointTo.x;
                this.y = this.pointTo.y;
                timeRemain /= this.speed;
                this.pointOn = this.points[this.state];
                this.speed = this.pointTo.speed;
                this.waitTimer = this.pointTo.pause;
    
                this.simulate(timeRemain)
            }
        }
	}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			points: this.points,
			speed: this.speed,
            waitTimer: this.waitTimer,
			currentPoint: this.currentPoint,
		}
	}
}
// LMAO
class MovingLavaPause extends MovingPause {
	constructor(w, h, points = [[50, 50, 30, 1]], currentPoint=0) {
		super(w, h, points, currentPoint);
		this.type = 'move-pause-lava'
	}
}

// points format:
/*
[{
    angle: 120, // angle to rotate to
    time: 1, // time it takes to get there
    pause: 2, // how long to pause after it's made it there
}]
*/
class RotatingPause {
	constructor(x, y, w, h, currentPoint=0, points=[], pivotX, pivotY, distToPivot, canCollide) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
		this.type = 'rotate-pause';
        this.points = points;
        this.canCollide = canCollide ?? true;
        this.currentPoint = currentPoint ?? 0;
        this.angle = this.points[this.currentPoint].angle;
        if(this.currentPoint+1 >= this.points.length){
            this.nextPoint = 0;
        } else {
            this.nextPoint = this.currentPoint+1;
        }
        this.waitTimer = 0;
        this.rotateSpeed = this.points[this.currentPoint].speed;
        this.pivotX = pivotX ?? x + w/2;
        this.pivotY = pivotY ?? y + h/2;
        this.distToPivot = distToPivot ?? Math.sqrt(Math.pow(this.pivotX - (x + w/2), 2) + Math.pow(this.pivotY - (y + h/2), 2));
        this.x = Math.cos(this.angle * Math.PI/180) * this.distToPivot + this.pivotX;
        this.y = Math.sin(this.angle * Math.PI/180) * this.distToPivot + this.pivotY;
	}
	simulate(dt) {
        if(this.waitTimer > 0){
            this.waitTimer -= dt;
            if(this.waitTimer <= 0){
                const overflow = Math.abs(this.waitTimer);
                this.simulate(overflow);
            }
        } else {
            this.angle += this.rotateSpeed * dt;
            this.x = Math.cos(this.angle * Math.PI/180) * this.distToPivot + this.pivotX;
            this.y = Math.sin(this.angle * Math.PI/180) * this.distToPivot + this.pivotY;
            let ad = this.findAngleDifference(this.angle,this.points[this.nextPoint].angle);
            let over = false;
            if(this.lastad && Math.abs(ad) < Math.max(5,this.rotateSpeed*100*dt)){// no, this doesn't snap. it's just making sure we don't have a >90 deg +1 frame with high rot speed
                if(this.lastad > 0 && ad < 0){
                    over = true;
                } else if(this.lastad < 0 && ad > 0){
                    over = true;
                }
            }
            this.lastad = ad;
            if(over){
                this.angle = this.points[this.nextPoint].angle;
                this.waitTimer = this.points[this.nextPoint].pause;
                this.rotateSpeed = this.points[this.nextPoint].speed;
                this.currentPoint++;
                this.nextPoint++;
                if(this.currentPoint >= this.points.length){
                    this.currentPoint = 0;
                } else if(this.nextPoint >= this.points.length){
                    this.nextPoint = 0;
                }
                // t = d/s
                const overflow = Math.abs(this.findAngleDifference(this.angle,this.points[this.currentPoint].angle)/this.rotateSpeed);
                this.simulate(overflow);
            }
        }
	}
    findAngleDifference(a1,a2){
        return Math.atan2(Math.sin((a1-a2)*Math.PI/180), Math.cos((a1-a2)*Math.PI/180))*180/Math.PI;
    }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			angle: this.angle,
			rotateSpeed: this.rotateSpeed,
            nextPoint: this.nextPoint,
            currentPoint: this.currentPoint,
            waitTimer: this.waitTimer,
            points: this.points,
			pivotX: this.pivotX,
			pivotY: this.pivotY,
			distToPivot: this.distToPivot,
		}
	}
}

class RotatingLavaPause extends RotatingPause {
	constructor(x, y, w, h, currentPoint=0, points=[], pivotX, pivotY, distToPivot, canCollide) {
		super(x, y, w, h, currentPoint, points, pivotX, pivotY, distToPivot, canCollide);
		this.type = 'rotate-pause-lava';
	}
}

class Tp {
	constructor(x, y, w, h, tpx, tpy, bgColor, tileColor, changeColor=true) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.tpx = tpx;
		this.tpy = tpy;
		this.type = 'tp';
		this.bgColor = bgColor;
		this.tileColor = tileColor;
		this.changeColor = changeColor;
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			tpx: this.tpx,
			tpy: this.tpy,
			bgColor: this.bgColor,
			tileColor: this.tileColor,
			changeColor: this.changeColor,
		}
	}
}
///add,{"type":"color","bgColor":"#6C405F","tileColor":"#BB7F97"}
class ColorChange {
	constructor(x, y, w, h, bgColor, tileColor) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'color';
		this.bgColor = bgColor;
		this.tileColor = tileColor;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			bgColor: this.bgColor,
			tileColor: this.tileColor,
		}
	}
}
///add,{"type":"rotate-tp","angle":0,"rotateSpeed":100,"distToPivot":0}
class RotatingTp extends RotatingLava {
	constructor(x, y, w, h, spd, angle=0, tpx, tpy, pivotX, pivotY, distToPivot=0, canCollide=true) {
		super(x, y, w, h,  spd, angle, pivotX, pivotY, distToPivot, canCollide);		
		this.type = 'rotate-tp';
		this.tpx = tpx;
		this.tpy = tpy;
	}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			tpx: this.tpx,
			tpy: this.tpy,
			type: this.type,
			angle: this.angle,
			rotateSpeed: this.rotateSpeed,
			pivotX: this.pivotX,
			pivotY: this.pivotY,
			distToPivot: this.distToPivot,
            canCollide: this.canCollide,
		}
	}
}

class RotatingSafe extends RotatingLava {
	constructor(x, y, w, h, spd, angle=0, pivotX, pivotY, distToPivot=0, canCollide=true) {
		super(x, y, w, h,  spd, angle, pivotX, pivotY, distToPivot, canCollide);
		this.type = 'rotatingsafe'
	}
}

class MovingTpObstacle {
	constructor(w, h, points, speed, currentPoint=0, tpx, tpy) {

		this.tpx = tpx;
		this.tpy = tpy;
		this.type = 'tpmove';
		this.currentPoint = currentPoint;
		this.points = points;
		this.speed = speed;
		this.w = w;
		this.h = h;
		this.x = this.points[currentPoint][0];
		this.y = this.points[currentPoint][1];

        let pointOn = this.points[this.currentPoint];
        this.pointOn = {x: pointOn[0], y: pointOn[1]};
        
        let nextPointIndex = this.currentPoint + 1;
        if (nextPointIndex >= this.points.length) {
            nextPointIndex = 0;
        }
        
        let nextPoint = this.points[nextPointIndex];
        this.pointTo = { x: nextPoint[0], y: nextPoint[1] };
        let angle = Math.atan2(this.pointTo.y - this.pointOn.y, this.pointTo.x - this.pointOn.x);
        this.xv = Math.cos(angle) * this.speed;
        this.yv = Math.sin(angle) * this.speed;
	}
	simulate(dt) {
		this.x += this.xv * dt;
	    this.y += this.yv * dt;
    	let over = false;
    	if (Math.abs(this.yv) > Math.abs(this.xv)) {
    		if (this.pointTo.y > this.pointOn.y) {
    			if (this.y > this.pointTo.y) {
    				over = true;
    			}
    		}
    		else {
    			if (this.y < this.pointTo.y) {
    				over = true;
    			}
    		}
    	}
    	else {
    		if (this.pointTo.x > this.pointOn.x) {
    			if (this.x > this.pointTo.x) {
    				over = true;
    			}
    		}
    		else {
    			if (this.x < this.pointTo.x) {
    				over = true;
    			}
    		}
    	}
    	if (over === true) {
    		this.currentPoint++;
    		if (this.currentPoint > this.points.length - 1) {
    			this.currentPoint = 0;
    		}
    
            let timeRemain = Math.sqrt(Math.pow(this.y - this.pointTo.y, 2) + Math.pow(this.x - this.pointTo.x, 2))/this.speed;
            
    		let pointOn = this.points[this.currentPoint];
            this.pointOn = {x: pointOn[0], y: pointOn[1]};
    
            this.x = this.pointOn.x;
    		this.y = this.pointOn.y;
    
            let nextPointIndex = this.currentPoint + 1;
    	    if (nextPointIndex >= this.points.length) {
        		nextPointIndex = 0;
        	}
        	let nextPoint = this.points[nextPointIndex];
        	this.pointTo = { x: nextPoint[0], y: nextPoint[1] };
    
            let angle = Math.atan2(this.pointTo.y - this.pointOn.y, this.pointTo.x - this.pointOn.x);
    	    this.xv = Math.cos(angle) * this.speed;
        	this.yv = Math.sin(angle) * this.speed;
    		this.simulate(timeRemain);
    	}
	}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			points: this.points,
			speed: this.speed,
			currentPoint: this.currentPoint,
			tpx: this.tpx,
			tpy: this.tpy
		}
	}
}

class FrictionChanger {
	constructor(x, y, w, h, fric, speedInc=1) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'frictionchanger';
        this.fric = fric;
        this.speedInc = speedInc;
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            fric: this.fric,
            speedInc: this.speedInc,
		}
	}
}

class SpeedObstacle extends NormalObstacle {
	constructor(x, y, w, h, speedInc = 1.5) {
		super(x, y, w, h);
		this.speedInc = speedInc;
		this.type = 'speed';
	}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			speedInc: this.speedInc,
		}
	}
}

class GravObstacle extends NormalObstacle {
	constructor(x, y, w, h, dir, force = 500) {
		super(x, y, w, h);
		this.type = 'grav';
		this.force = force;
		this.dir = { x: 0, y: 0 };
		let direction = dir;
		if (dir == null) {
			direction = 'up';
		}
		this.direction = direction;
		if (direction === 'down') {
			this.dir.y = this.force;
		}
		if (direction === 'up') {
			this.dir.y = -this.force;
		}
		if (direction === 'left') {
			this.dir.x = -this.force;
		}
		if (direction === 'right') {
			this.dir.x = this.force;
		}
	}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			force: this.force,
			dir: this.dir,
			direction: this.direction,
		}
	}
} 
class PlatformerGrav extends NormalObstacle {
	constructor(x, y, w, h, dir, jumpHeight, force = 500, maxForce, variableJumpHeight = false, friction = 0.8) {
		super(x, y, w, h);
		this.type = 'platformer';
		this.force = force;
        this.jumpHeight = jumpHeight;
		this.dir = { x: 0, y: 0 };
		let direction = dir;
		if (dir == null) {
			direction = 'up';
		}
		this.direction = direction;
		if (direction === 'down') {
			this.dir.y = this.force;
		}
		if (direction === 'up') {
			this.dir.y = -this.force;
		}
		if (direction === 'left') {
			this.dir.x = -this.force;
		}
		if (direction === 'right') {
			this.dir.x = this.force;
		}
        this.maxForce = 1000//maxForce || this.dir.y/3;
        this.variableJumpHeight = variableJumpHeight;
        this.platformerFriction = friction;
	}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			force: this.force,
			dir: this.dir,
			direction: this.direction,
            jumpHeight: this.jumpHeight,
            maxForce: this.maxForce,
            variableJumpHeight: this.variableJumpHeight,
            platformerFriction: this.platformerFriction,
		}
	}
}
///add,{"type":"switchgrav","dirs":[{direction:'right',force:5000,time:2},{direction:'left',force:5000,time:2}]}
class SwitchGrav extends NormalObstacle {
	constructor(x, y, w, h, dirs) {
		super(x, y, w, h);
        this.dirs = dirs || [{direction:'up',force:500,time:1}];
		this.type = 'switchgrav';
        this.timer = this.dirs[0].time;
        this.index = 0;
        for(let i in this.dirs){
            this.dirs[i].x = 0;
            this.dirs[i].y = 0;
            if (this.dirs[i].direction === 'down') {
    			this.dirs[i].y = this.dirs[i].force;
    		}
    		else if (this.dirs[i].direction === 'up') {
    			this.dirs[i].y = -this.dirs[i].force;
    		}
    		else if (this.dirs[i].direction === 'left') {
    			this.dirs[i].x = -this.dirs[i].force;
    		}
    		else if (this.dirs[i].direction === 'right') {
    			this.dirs[i].x = this.dirs[i].force;
    		}
        }
	}
    simulate(dt) {
        this.timer -= dt;
        if(this.timer <= 0){
            this.index++;
            if(this.index >= this.dirs.length){
                this.index = 0;
            }
            this.timer += this.dirs[this.index].time;
        }
    }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			dirs: this.dirs,
            timer: this.timer,
            index: this.index,
		}
	}
} 

class Checkpoint {
	constructor(x, y, w, h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.spawn = {
			x: this.x + this.w / 2,
			y: this.y + this.h / 2,
		}
		this.type = 'check';
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			spawn: this.spawn,
			type: this.type,
			collected: false, // so on client, its never collected
		}
	}
}

class StoryDisplay {
	constructor(x, y, w, h, visible) {
		this.x = x;
		this.y = y;
		// we will only ever want an orb that is 1 tile in length
		this.w = w;
		this.h = h;
		this.type = 'story';
		this.visible = visible;
		if (this.visible === undefined) {
			this.visible = true;
		}
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			visible: this.visible,
		}
	}
}

// inverts player movement only
class Invert {
	constructor(x, y, w, h, invertx, inverty) {
		this.x = x;
		this.y = y;
		// we will only ever want an orb that is 1 tile in length
		this.w = w;
		this.h = h;
		this.type = 'invert';
		this.invertX = invertx||false;
        this.invertY = inverty||false;
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			invertX: this.invertX,
            invertY: this.invertY,
		}
	}
}

class ForceInput {
	constructor(x, y, w, h, inputs=[]) {
		this.x = x;
		this.y = y;
		// we will only ever want an orb that is 1 tile in length
		this.w = w;
		this.h = h;
		this.type = 'forceinput';
        this.inputs = inputs;
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			inputs: this.inputs
		}
	}
}

class InvincibilityPowerup {
	constructor(x, y, w, h, amount) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'invpu';
        this.amount = amount;
        this.maxAmount = amount;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            amount: this.amount,
            maxAmount: this.maxAmount,
		}
	}
}

///add,{"type":"drpu","state":false}
class DragonPowerup {
	constructor(x, y, w, h, state) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'drpu';
        this.state = state;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            state: this.state,
		}
	}
}

// basically what this does is creates an iframe until the iframe posts the quitmessage via window.top.postMessage. It's basically a temporary way to have another url play without having to set cookies
class IFramePlayer {
    constructor(x, y, w, h, url, closemessage) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.url = url;
        this.type = 'iframeplayer';
        this.closeMessage = closemessage;
    }
    simulate(dt) { }
    pack() {
        return {
            x: this.x,
            y: this.y,
            w: this.w,
            h: this.h,
            type: this.type,
            url: this.url,
            closeMessage: this.closeMessage,
            active: false,
        }
    }
}

// i saw this in gd once and it looked kinda cool so y not add it
class HidePlayer {
	constructor(x, y, w, h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'hideplayer';
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
		}
	}
}

///add,{"type":"revpu","amount":2}
class RevivePowerup {
	constructor(x, y, w, h, amount) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'revpu';
        this.amount = amount;
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            amount: this.amount,
		}
	}
}

class Air {
	constructor(x, y, w, h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'air';
	}
	simulate(dt) { }
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
		}
	}
}

///add,{"type":"poly","points":[[450,3000],[525,3125],[375,3125]]}
class Polygon {
	constructor(points = [], variant = 'poly', tpx = null, tpy = null) {
		this.points = points;
		this.type = variant;
		this.props = {};
		if (variant === 'poly-tp') {
			this.props.tpx = tpx;
			this.props.tpy = tpy;
		}
		// console.log(this)
	}
	simulate(dt) { }
	pack() {
		return {
			points: this.points,
			type: this.type,
			...this.props,
		}
	}
}

class PolygonBouncy {
	constructor(points = [], effect = 30) {
		this.points = points;
		this.type = 'poly-bounce';
        this.effect = effect;
	}
	simulate(dt) { }
	pack() {
		return {
			points: this.points,
			type: this.type,
			effect: this.effect,
		}
	}
}

class PolygonBreakable {
	constructor(points = [], strength, time, regenTime = 10) {
		this.points = points;
		this.type = 'poly-breakable';
        this.maxStrength = strength;
        this.currentStrength = strength;
        this.time = time;
        this.timer = time;
        this.regenTime = regenTime;
	}
	simulate(dt) { }
	pack() {
		return {
			points: this.points,
			type: this.type,
			maxStrength: this.maxStrength,
            currentStrength: this.currentStrength,
            time: this.time,
            timer: this.timer,
            regenTime: this.regenTime
		}
	}
}

class PolygonBouncyBreakable {
	constructor(points = [], strength, effect, regenTime = 10) {
		this.points = points;
		this.type = 'poly-bouncy-breakable';
        this.maxStrength = strength;
        this.currentStrength = strength;
        this.regenTime = regenTime;
        this.effect = effect;
	}
	simulate(dt) { }
	pack() {
		return {
			points: this.points,
			type: this.type,
            maxStrength: this.maxStrength,
            currentStrength: this.currentStrength,
            regenTime: this.regenTime,
			effect: this.effect,
		}
	}
}

// basically like circular rail except u can specify points. you can get off at the first or last point.
class Rail {
	constructor(points = []) {
		this.points = points;
		this.type = 'poly-rail';
        this.startPoint = {
            x: this.points[0][0],
            y: this.points[0][1],
        }
        this.endPoint = {
            x: this.points[this.points.length-1][0],
            y: this.points[this.points.length-1][1],
        }
	}
	simulate(dt) { }
	pack() {
		return {
			points: this.points,
			type: this.type,
            startPoint: this.startPoint,
            endPoint: this.endPoint,
		}
	}
}


// single curve
class Curve {
	constructor(handles = [], resolution) {
		this.handles = handles;
        for(let h = 0; h < this.handles.length; h++){
            const last = this.handles[h];
            this.handles[h] = {x: last[0], y: last[1]}
        }

		this.type = 'curve';
        this.resolution = resolution;
        this.points = [];
        // first val
        this.points.push({
            x: this.handles[0].x,
            y: this.handles[0].y
        });
        // calculate t values for x points
        let x = resolution;
        while(x > 0){
            x--;
            const t = x/this.resolution;// interp value
            // for every pair, we just calculate them at t and push value recursively
            let points = this.handles;
            while(points.length > 1){
                let nextPoints = [];
                for(let p = 0; p < points.length; p++){// ok
                    const point = points[p];
                    // don't wanna do it for the last one
                    if(p === points.length-1){
                        continue;
                    }
                    let nextPoint = points[p+1];
                    nextPoints.push({
                        x: this.interpolate(point.x,nextPoint.x,t),
                        y: this.interpolate(point.y,nextPoint.y,t)
                    });
                }
                points = nextPoints;
            }
            this.points.push(points[0]);
        }
	}
    interpolate(p1,p2,t){
        return p1*t+(1-t)*p2;
    }
	simulate(dt) { }
	pack() {
		return {
			points: this.points,
            handles: this.handles,
			type: this.type,
			resolution: this.resolution,
		}
	}
}

class MovingGrapplePoint extends MovingObstacle {
	constructor(points = [[50, 50]], speed = 30, currentPoint=0) {
        super(0, 0, points, speed, currentPoint)
		this.type = 'movinggrapplepoint';
	}
	pack() {
		return {
			...super.pack(),
            w: 0,
            h: 0
		}
	}
}

class Bezier {
	constructor(curves) {
		this.type = 'bezier';
        
        this.curves = [];
        for(let curve of curves){
            const p0 = {x:curve[0][0],y:curve[0][0]};
            const p1 = {x:curve[curve.length-1][0],y:curve[curve.length-1][1]};
            const d = this.findDistance(p0,p1);//Math.min(80,Math.max(10,dist)))
            let res = Math.min(100,Math.max(5,Math.ceil(d/20)));
            //let res = 3000;
            this.curves.push(new Curve(curve,res));// 10 just testing value; eventually calculate how long the curve is and push a curve with that resolution
        }

        let polygonPoints = [];
        for(let curve of this.curves){
            //console.log(curve);
            for(let point of curve.points){
                polygonPoints.push(point);
            }
        }
        
        this.polygon = new Polygon(polygonPoints.map(p => [p.x,p.y]), 'poly')
	}
    findDistance(p0,p1){
        return Math.sqrt((p0.x-p1.x)**2+(p0.y-p1.y)**2)
    }
	simulate(dt) { }
	pack() {
		return {
			polygon: this.polygon,
            curves: this.curves,
			type: this.type,
		}
	}
}

class Mirror {
	constructor(x, y, w, h, xoffset, yoffset) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'mirror';
        this.offset = {
            x: xoffset,
            y: yoffset,
        }
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
            offset: this.offset,
		}
	}
}

class RotateCanvas {
	constructor(x, y, w, h, deg) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.deg = deg;
		this.type = 'rotatecanvas';
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
			deg: this.deg,
		}
	}
}

class ResetTimeTraps {
	constructor(x, y, w, h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'resettimetraps';
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
		}
	}
}

// no using /respawn when inside these
class NoRespawn {
	constructor(x, y, w, h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.type = 'nores';
	}
	simulate(dt) {}
	pack() {
		return {
			x: this.x,
			y: this.y,
			w: this.w,
			h: this.h,
			type: this.type,
		}
	}
}

module.exports = {
	NormalObstacle,
	BouncyObstacle,
	Block,
	CircularNormalObstacle,
	CircularBouncyObstacle,
	CircularLavaObstacle,
	CircularSafeObstacle,
	Lava,
	RotatingLava,
	SpeedObstacle,
	GravObstacle,
	Checkpoint,
	Tp,
	Air,
	MovingObstacle,
	StoryDisplay,
	MovingLavaObstacle,
	Portal,
	Winpad,
	Zone,
	WB,
	RotatingTp,
	MovingTpObstacle,
	RotatingNormal,
	Booster,
	WallBooster,
	SpeedTrap,
	GrowingObstacle,
	GrowingLavaObstacle,
	GrowingCircleObstacle,
	GrowingCircleLavaObstacle,
	CircularTpObstacle,
	SizePlayer,
	Slip,
	BoostPad,
	Pushbox,
	Tornado,
	SnapGrid,
	VinetteIncrease,
	ColorChange,
	Pusher,
    Coin,
    CircularCoin,
    PlatformerGrav,
	TransObstacle,
    MovingSafe,
    RotatingSafe,
    BreakableObstacle,
    SwitchLava,
    SwitchObstacle,
    TimeTrap,
    InvincibilityPowerup,
    Filter,
    Particles,
    MovingSpeedTrap,
    RotatingSpeedTrap,
    DeadMove,
    Revive,
    DrawObstacle,
    Clone,
	Polygon,
    Ship,
    CoinDoor,
    MusicChange,
    Redirect,
    CookieCheck,
    Typing,
    Mashing,
    RevivePowerup,
    Raycasting,
    Spring,
    CircularSnap,
    IDIT,
    HidePlayer,
    CameraChange,
    Gun,
    Golf,
    Zoom,
	Deathmark,
    RestrictAxis,
    Custom,
    FallingArrow,
    CircularHollowObstacle, 
	Deathcure,
    SwitchGrav,
    Button,
    Door,
    CircularDoor,
    ReusableButton,
    ZombieMaker,
    TimeButton,
    TimeTrapButton,
    LavaDoor,
    Invert,
    DragonPowerup,
    PlayerCollide,
    CrowdButton,
    Hole,
    AmogusPowerup,
    DrawingCanvas,
    GunslingerPowerup,
    Demo,
    EnemyButton,
    CircularSliceObstacle,
    CircularHollowSlice,
	Camera,
    RoundedCorners,
    RoundedLava,
    GrapplePowerup,
    CircularHollowLava,
    CircularLavaSlice,
    CircularHollowLavaSlice,
    GrapplePoint,
    ResetCoins,
    Bezier,
    BoxButton,
    RotatingPause,
    RotatingLavaPause,
    MovingPause,
    MovingLavaPause,
    FrictionChanger,
    MovingGrapplePoint,
	Sentry,
    Oval,
    LavaOval,
    EnemyEffector,
    EnemyWall,
    EnemyTp,
    EnemyPolyWall,
    EnemyPolyTp,
    CircularHollowSliceEnemyWall,
    CircularHollowSliceEnemyTp,
    Mirror,
    Rail,
    TpTrap,
    DeadPusher,
    Bonus,
    CircularBonus,
    IFramePlayer,
	CircularPushbox,
	FullDeath,
	MorphButton,
	MorphObstacle,
	MorphButtonTimed,
	MorphMoving,
    MorphLavaMove,
	DirNormal,
	PushboxResetButton,
	ZMode,
    ResetTimeTraps,
    NoRespawn,
    RotateCanvas,
    ForceInput,
    MorphMoveReset,
    BouncyBreakable,
    Torch,
    TurretSentry,
    PolygonBouncy,
    PolygonBreakable,
    PolygonBouncyBreakable
};