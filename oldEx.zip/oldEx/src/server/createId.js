let c = 0;

module.exports = function createId() {
	c++;
	return c;
}