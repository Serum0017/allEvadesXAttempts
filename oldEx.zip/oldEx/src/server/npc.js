module.exports = class Npc {
	constructor(x, y, r, dialogue, hat) {
		this.x = x;
		this.y = y;
		this.r = r;
		this.type = 'npc';
        this.dialogue = dialogue || ['henlo world'];
        this.hat = hat;
	}
	pack() {
		return {
			x: this.x,
			y: this.y,
			r: this.r,
			type: this.type,
            dialogue: this.dialogue,
            hat: this.hat,
		}
	}
}