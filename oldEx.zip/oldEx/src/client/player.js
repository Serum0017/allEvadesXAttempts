window.trailDifficulty = 'Terrorizing';
class Player {
    constructor(init) {
        this.id = init.id;
        this.x = init.x;
        this.y = init.y;
        this.renderX = this.x;
        this.renderY = this.y;
        this.radius = init.radius;
        this.defaultRadius = init.radius;
        this.speed = init.speed;
        this.name = 'Serum'//init.name;
        this.fric = init.fric;
        this.dead = init.dead;
        this.spawn = init.spawn;
        this.god = init.god;
        this.dev = init.dev;
        this.ping = init.ping;
        this.guest = false;//init.guest;
        this.deathTimer = init.deathTimer;
        this.server = { x: this.x, y: this.y };
        this.renderRadius = this.radius / 4;
        this.ir = 0;
        this.or = 0;
        this.o = 0;
        this.golfCooldown = 0;
        this.strokes = 0;
        this.jumpcd = 0;
        this.arrows = [];
        this.arrowDt = 0;
        this.zombies = [];
        this.powerups = {
            inv: 0,
            gun: {
                state: false,
                angle: 0,
                currentCooldown: 0.3,
                maxCooldown: 0.3,
                speed: 300,
                radius: 30,
                life: 3,
                effectTime: 3,
                type: 'normal',
            },
            dragon: {
                state: false,
                hp: 10,
                angle: 0,
            },
            amogus: false,
            gunslinger: false,
            grapple: {
                direction: 0,
                state: false,
                grappling: false,
                length: 0,
                originalLength: 0,
                x: 0,
                y: 0,
                id: -1,
            },
        };
        this.gunslingerCursor = { x: canvas.width / 2, y: canvas.height / 2 };
        this.eyes = new Image();
        let dragImgs = [
            'gfx/golddrag.webp',
            'gfx/knightdrag.webp',
            'gfx/mopedragon.webp',
        ];

        this.eyes.src = dragImgs[Math.floor(Math.random() * dragImgs.length)];
        this.bullets = [];
        this.clones = [];
        this.ship = false; // false means that player isn't in ship, angle in radians means the player's angle
        this.history = [];
        this.historyLen = 0; //10 20

        this.historyInterval = 0;
        this.speedMults = [];
        this.hat = new Image();
        this.currentChar = 0;
        this.isTyping = false;

        // let possibleWreaths = ['/gfx/hats/spring-wreath.png','/gfx/hats/autumn-wreath.png','/gfx/hats/halo.png','/gfx/hats/gold-crown.png','/gfx/hats/winter-wreath.png'];
        // this.hat.src = possibleWreaths[Math.floor(Math.random()*possibleWreaths.length)];
        this.hat.src = 'gfx/hats/santa-hat.png';
        // this.hat.src =
        // 'https://cdn.discordapp.com/emojis/911012487799902309.webp?size=96&quality=lossless';
        // this.hat.src = '/gfx/hats.png';
        // this.hat.src = '/gfx/hats/winter-wreath.png';
        /*let videos = [
            `gfx/videos/pro evades.mp4`,
            `gfx/videos/black hole collision.webm`,
            `gfx/videos/wide putin walking.mp4`,
            `gfx/videos/yes.mp4`,
        ]*/
        //this.hat.src = videos[Math.floor(Math.random()*videos.length)];
        this.tagged = false;

        if (init.id !== selfId) {
            if (init.tagged !== undefined) this.tagged = init.tagged;
            if (init.bullets !== undefined) this.bullets = init.bullets;
            // fast forward bullets
            this.bullets.forEach((bullet) => {
                bullet.x +=
                    (debug.ping / 1000) * bullet.speed * Math.cos(bullet.angle);
                if (bullet.type === 'pvp') {
                    if (bullet.x + bullet.radius >= 1000) {
                        bullet.x = 1000 * 2 - bullet.x - bullet.radius * 2;
                        bullet.angle = Math.atan2(
                            Math.sin(bullet.angle),
                            -Math.cos(bullet.angle)
                        );
                    } else if (bullet.x - bullet.radius <= 0) {
                        bullet.x = 0 * 2 - bullet.x + bullet.radius * 2;
                        bullet.angle = Math.atan2(
                            Math.sin(bullet.angle),
                            -Math.cos(bullet.angle)
                        );
                    }
                }
                bullet.y +=
                    (debug.ping / 1000) * bullet.speed * Math.sin(bullet.angle);
                if (bullet.type === 'pvp') {
                    if (bullet.y + bullet.radius >= 1000) {
                        bullet.y = 1000 * 2 - bullet.y - bullet.radius * 2;
                        bullet.angle = Math.atan2(
                            -Math.sin(bullet.angle),
                            Math.cos(bullet.angle)
                        );
                    } else if (bullet.y - bullet.radius <= 0) {
                        bullet.y = 0 * 2 - bullet.y + bullet.radius * 2;
                        bullet.angle = Math.atan2(
                            -Math.sin(bullet.angle),
                            Math.cos(bullet.angle)
                        );
                    }
                }
                bullet.life -= debug.ping / 1000;
            });
            if (init.ship !== undefined) this.ship = init.ship;
            if (init.powerups !== undefined) this.powerups = init.powerups;
            if (init.clones !== undefined) this.clones = init.clones;
        }
        if (init.dimensions === 3) {
            return new ThreeDPlayer(this, init);
        }
    }
    packIntoState() {
        return {
            x: this.x,
            y: this.y,
            fric: this.fric,
            radius: this.radius,
            name: this.name,
            speed: this.speed,
            dead: this.dead,
            spawn: this.spawn,
            dev: this.dev,
            god: this.god,
            powerups: this.powerups,
            clones: this.clones,
            ship: this.ship,
            tagged: this.tagged,
            deahtTimer: this.deathTimer,
            bullets: this.bullets,
            guest: this.guest,
            xv: this.xv,
            yv: this.yv,
        };
    }
    respawn() {
        // this.x = this.spawn.x;
        // this.y = this.spawn.y;
        this.xv = 0;
        this.yv = 0;
        this.dead = false;
        this.grav.x = 0;
        this.grav.y = 0;
    }
    update(delt) {
        //console.log(this.clones);
        if (this.id !== selfId) {
            this.renderX = lerp(this.renderX, this.x, delt);
            this.renderY = lerp(this.renderY, this.y, delt);
        } else if (this.id === selfId) {
            // <-
            // NO INTERPOALTION
            // u dont interpolate ur own player
            this.renderX = this.x;
            this.renderY = this.y;
        }
        if (Math.abs(this.renderRadius - this.radius) > 0.1) {
            this.renderRadius = lerp(this.renderRadius, this.radius, delt / 2);
        } else {
            this.renderRadius = this.radius;
        } // wait rq before gtg
        for (let i in this.clones) {
            // ye they're camera relative and not position relative ;-;
            // this.clones[i].renderX = lerp(
            //     this.clones[i].renderX,
            //     this.clones[i].x,
            //     delt
            // );
            // this.clones[i].renderY = lerp(
            //     this.clones[i].renderY,
            //     this.clones[i].y,
            //     delt
            // );
            this.clones[i].renderX = this.clones[i].x;
            this.clones[i].renderY = this.clones[i].y;
            this.clones[i].renderRadius = this.clones[i].radius;
        }
        for (let i = 0; i < 2; i++) {
            this.historyInterval--;
            if (this.historyInterval < 0) {
                this.historyInterval += 2;
                this.history.push({ x: this.renderX, y: this.renderY });
                if (this.history.length > this.historyLen) {
                    this.history.shift(); // maybe w ecan optimize this
                    // since it will shift every farame
                }
            }
        }
    }
    setData(pack) {
        if (pack.ping != undefined) {
            this.ping = pack.ping;
        }
        if (this.id !== selfId) {
            if (pack.x != undefined) {
                this.x = pack.x;
            }
            if (pack.ship !== undefined) {
                pack.ship = this.ship;
            }
            if (pack.y != undefined) {
                this.y = pack.y;
            }
            if (pack.dead != undefined) {
                this.dead = pack.dead;
            }
            if (pack.powerups != undefined) {
                this.powerups = pack.powerups;
            }
            if (pack.bullets != undefined) {
                const old = [...this.bullets];
                this.bullets = pack.bullets;
                if (this.bullets.length <= 0) return;
                // const newlyAddedBullets = [];
                // let i = 0;
                // for (const newBullet of this.bullets) {
                // 	let unique = true;
                // 	for (const oldBullet of old) {
                // 		if (oldBullet.id === newBullet.id) {
                // 			unique = false;
                // 			break;
                // 		}
                // 		// how do u know its last bullet
                // 		// oh
                // 		// i dum
                // 	}// spec me
                // 	if (unique) {
                // 		newlyAddedBullets.push(i);
                // 	}
                // 	i++;
                // }
                // this should work?
                // ye?
                const bullet = this.bullets[this.bullets.length - 1];
                let unique = true;
                for (const oldBullet of old) {
                    if (oldBullet.id === bullet.id) {
                        // console.log(oldBullet.id, bullet.id)
                        unique = false;
                        return;
                    }
                }
                console.log(unique);

                bullet.x +=
                    (debug.ping / 1000) * bullet.speed * Math.cos(bullet.angle);
                if (bullet.type === 'pvp') {
                    if (bullet.x + bullet.radius >= 1000) {
                        bullet.x = 1000 * 2 - bullet.x - bullet.radius * 2;
                        bullet.angle = Math.atan2(
                            Math.sin(bullet.angle),
                            -Math.cos(bullet.angle)
                        );
                    } else if (bullet.x - bullet.radius <= 0) {
                        bullet.x = 0 * 2 - bullet.x + bullet.radius * 2;
                        bullet.angle = Math.atan2(
                            Math.sin(bullet.angle),
                            -Math.cos(bullet.angle)
                        );
                    }
                }
                bullet.y +=
                    (debug.ping / 1000) * bullet.speed * Math.sin(bullet.angle);
                if (bullet.type === 'pvp') {
                    if (bullet.y + bullet.radius >= 1000) {
                        bullet.y = 1000 * 2 - bullet.y - bullet.radius * 2;
                        bullet.angle = Math.atan2(
                            -Math.sin(bullet.angle),
                            Math.cos(bullet.angle)
                        );
                    } else if (bullet.y - bullet.radius <= 0) {
                        bullet.y = 0 * 2 - bullet.y + bullet.radius * 2;
                        bullet.angle = Math.atan2(
                            -Math.sin(bullet.angle),
                            Math.cos(bullet.angle)
                        );
                    }
                }
                bullet.life -= debug.ping / 1000;
                // we are missing one
            }
            // ;-;
        }
        if (pack.dev != undefined) {
            this.dev = pack.dev;
        }
        if (pack.x != undefined) {
            this.server.x = pack.x;
        }
        if (pack.y != undefined) {
            this.server.y = pack.y;
        }
        if (pack.god != undefined) {
            this.god = pack.god;
        }
        if (pack.guest != undefined) {
            this.guest = pack.guest;
        }
        if (pack.radius != undefined) {
            this.radius = pack.radius;
        }
        if (pack.tagged != undefined) {
            this.tagged = pack.tagged;
        }
        if (pack.deathchange != undefined && this.id !== me().id) {
            this.deathTimer = pack.deathTimer;
            console.log(pack);
        }
    }
    setCloneData(pack) {
        if (pack != undefined) {
            //this.clones = pack;
            for (let i in pack) {
                if (this.clones[i] !== undefined) {
                    this.clones[i] = Object.assign(this.clones[i], pack[i]);
                } else {
                    this.clones[i] = pack[i];
                }
            }
        }
    }
    renderTrail() {
        const pos = offset(this.renderX, this.renderY);
        if (this.history.length > 0) {
            // trail time
            // ctx.fillStyle = 'red';
            for (let i = this.history.length - 1; i >= 0; i--) {
                const { x, y } = this.history[i];
                const his = offset(x, y);
                ctx.globalAlpha = i / this.history.length;
                // ctx.beginPath();
                // ctx.arc(his.x - this.renderRadius / 2, his.y - this.renderRadius / 2, this.renderRadius, 0, Math.PI * 2);
                // ctx.stroke();
                // ctx.beginPath();
                // // ctx.arc(his.x - this.renderRadius / 2, his.y - this.renderRadius / 2, this.renderRadius, -Math.PI / 2.5, -Math.PI / 2.5);
                // ctx.fill();

                //window.difficultyImages["Grass"]
                // ctx.drawImage(
                //     window.difficultyImages[trailDifficulty],
                //     his.x - this.renderRadius * 0.4,
                //     his.y - this.renderRadius * 0.4,
                //     this.renderRadius * 0.8,
                //     this.renderRadius * 0.8
                // );
                ctx.fillStyle = 'black';
                ctx.strokeStyle = 'black';
                ctx.beginPath();
                ctx.arc(his.x, his.y, Math.abs(this.renderRadius - 1), 0, Math.PI * 2);
        
                if (this.renderRadius > 0) {
                    ctx.fill();
                } else {
                    ctx.lineDashOffset = -window.time * 50;
                    ctx.strokeStyle = ctx.fillStyle;
                    ctx.lineWidth = 4;
                    ctx.lineCap = 'round';
                    ctx.stroke();
                }
                ctx.closePath();
            }
            ctx.globalAlpha = 1;
        }
    }
    render() {
        if(/*this.id === selfId && */window.hidePlayer === true){
            return;
        }
        
        if (this.renderMirror) {
            const mirror = new Player(this.renderMirror);
            mirror.renderRadius = mirror.radius;
            mirror.renderX = mirror.x;
            mirror.renderY = mirror.y;
            delete this.renderMirror;
            mirror.render();
        }

        // if (this.id === selfId) {
        //     if (Object.keys(states).length > 0) {
        //         const { x, y } = states[Object.keys(states)[0]].player;
        //         const pos = offset(x, y);
        //         ctx.beginPath();
        //         ctx.fillStyle = 'black';
        //         ctx.globalAlpha = 0.2;
        //         ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
        //         ctx.fill();
        //         ctx.globalAlpha = 1;
        //     }
        // }

        const pos = offset(this.renderX, this.renderY);
        // const pos = offset(this.renderX, this.renderY);

        if (this.powerups.grapple.state) {
            // ctx.beginPath();
            // ctx.strokeStyle = '#c9c9c9';
            // if (this.powerups.grapple.grappling /*window.input.action*/) {
            ctx.strokeStyle = 'white';
            // }
            // if(!this.powerups.grapple.grappling  /*window.input.action */&& this.id === selfId){
            //     ctx.strokeStyle = 'red';
            // }
            ctx.globalAlpha = 0.5;
            ctx.lineWidth = 6;
            // ctx.lineCap = 'round'
            if (this.powerups.grapple.grappling) {
                ctx.beginPath();
                ctx.moveTo(
                    pos.x +
                        (Math.cos(this.powerups.grapple.angle) *
                            this.renderRadius) /
                            2,
                    pos.y +
                        (Math.sin(this.powerups.grapple.angle) *
                            this.renderRadius) /
                            2
                );
                const gpos = offset(
                    this.powerups.grapple.x,
                    this.powerups.grapple.y
                );
                ctx.lineTo(
                    gpos.x - Math.cos(this.powerups.grapple.angle) * 5,
                    gpos.y - Math.sin(this.powerups.grapple.angle) * 5
                );
                ctx.stroke();
                ctx.closePath();
                ctx.beginPath();
                ctx.strokeStyle = 'white';
                ctx.lineWidth = 5;
                ctx.arc(gpos.x, gpos.y, 5, 0, Math.PI * 2);
                ctx.stroke();
            } else if (window.input.action && this.id === selfId) {
                // already fixed
                // ye increase to like 200
                ctx.globalAlpha = 0.2;
                ctx.beginPath();
                ctx.arc(pos.x, pos.y, 244, 0, Math.PI * 2);
                ctx.stroke(); // lemme make a bit larger ye also gonna change other things
            }
            ctx.globalAlpha = 1;
            ctx.strokeStyle = 'black';
            ctx.lineWidth = window.lineWidth;
            // ctx.lineCap = 'butt'
        }
        
        ctx.globalAlpha = 1;
        ctx.fillStyle = 'black';
        // if (this.onSafe) {
        // ctx.fillStyle = 'rgb(50, 35, 35)'
        // }
        if (this.deathTimer != undefined) {
            ctx.fillStyle = 'rgb(50, 0, 0)';
        }
        if (this.dead) {
            ctx.fillStyle = 'rgb(255, 0, 0)';
        }
        if (this.guest) {
            ctx.globalAlpha = 0.25;
        } else if (this.id !== selfId) {
            ctx.globalAlpha = 1;
        }
        // ctx.globalAlpha = 0.9;

        // ctx.shadowColor = '#7e00de';
        // ctx.shadowColor = ctx.fillStyle;
        // ctx.shadowBlur = 25;
		if (this.id === selfId && this.zMode) {
			ctx.globalAlpha = 0.6;
		}

        ctx.beginPath();
        ctx.arc(pos.x, pos.y, Math.abs(this.renderRadius - 1), 0, Math.PI * 2);

        if (this.renderRadius > 0) {
            ctx.fill();
        } else {
            //ctx.setLineDash([8, 20]);
            ctx.lineDashOffset = -window.time * 50;
            ctx.strokeStyle = ctx.fillStyle;
            ctx.lineWidth = 4;
            ctx.lineCap = 'round';
            ctx.stroke();
            //ctx.setLineDash([]);
        }
        ctx.globalAlpha = 1;
        /*if (this.dead) {
			ctx.fillStyle = 'black';
			ctx.font = `${this.renderRadius*1.1}px Inter-Thick`;
			ctx.textAlign = 'center';
			ctx.textBaseline = 'middle';
			ctx.fillText('69', pos.x, pos.y);
		}*/
        if (this.powerups.gunslinger) {
            ctx.strokeStyle = '#1c1c1c'; // grey?
            ctx.lineWidth = 6;
            ctx.stroke();
            ctx.strokeStyle = 'black';
            ctx.lineWidth = 2;
            if (this.dead) {
                this.powerups.gunslinger = false;
            }
        }

        if (this.deathTimer > 0) {
            ctx.fillStyle = 'red';
            ctx.font = '30px Inter-Thick';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(Math.ceil(this.deathTimer), pos.x, pos.y);
        }
		if (this.id === selfId && this.zMode) {
			 ctx.fillStyle = 'black';
            ctx.font = '30px Inter-Thick';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('Z', pos.x, pos.y);
		}
        // ctx.shadowBlur = 0

        ctx.globalAlpha = 1;

        if (this.ship !== false) {
            ctx.strokeStyle = '#0033ed'; //'#ff00f7';
            ctx.lineCap = 'round';
            ctx.lineWidth = 5;
            ctx.translate(pos.x, pos.y);
            ctx.rotate(this.ship);
            ctx.moveTo(0, 0);
            ctx.lineTo(0, this.renderRadius);
            ctx.stroke();
            ctx.rotate(-this.ship);
            ctx.translate(-pos.x, -pos.y);
        }

        // tx.drawImage(imgJotunn,win.x/2-25,win.y/2-28,50,55);
        // if(this.hat.src == '/gfx/hats/D; hat.png'){
        //     ctx.drawImage(this.hat, pos.x - (30 * (this.renderRadius / 25)) /2, pos.y - (30 * (this.renderRadius / 25))/2, 30 * (this.renderRadius/25), 30 * (this.renderRadius / 25));
        // } else {
        // this.hat.src?
        if (false && showHat /*&& this.hat.src*/) {
            // <- somehow this makes the performance go down lol
            try {
                ctx.drawImage(
                    this.hat,
                    pos.x - (80 * (this.renderRadius / 25)) / 2,
                    pos.y - (80 * (this.renderRadius / 25)) / 2,
                    80 * (this.renderRadius / 25),
                    80 * (this.renderRadius / 25)
                );
            } catch (e) {
                /*if(!this.hat.src.includes('video')){
                        console.log(`hat not loaded!`);   
                    } */
            }
        }
        if (this.powerups.amogus) {
            ctx.drawImage(
                window.nothingToSeeHere,
                pos.x - (80 * (this.renderRadius / 25)) / 2,
                pos.y - (80 * (this.renderRadius / 25)) / 2,
                80 * (this.renderRadius / 25),
                80 * (this.renderRadius / 25)
            );
            if (this.dead) {
                this.powerups.amogus = false;
            }
        }
        ctx.globalAlpha = 1;
        // }
        // ctx.drawImage(this.hat, pos.x - this.renderRadius , pos.y - this.renderRadius , this.renderRadius * 3, this.hat.height);
        if (this.powerups.dragon.state) {
            // hp
            ctx.closePath();
            ctx.beginPath();
            if (this.powerups.dragon.hp > 5) {
                ctx.strokeStyle = '#14a914';
            } else if (this.powerups.dragon.hp > 2) {
                ctx.strokeStyle = 'yellow';
            } else {
                ctx.strokeStyle = 'red';
            }
            ctx.globalAlpha = 0.5;
            ctx.arc(
                pos.x,
                pos.y,
                this.renderRadius,
                0,
                (Math.PI * 2 * this.powerups.dragon.hp) / 10
            );
            ctx.lineWidth = this.renderRadius / 8;
            ctx.stroke();
            ctx.lineWidth = window.lineWidth;
            ctx.closePath();
            ctx.globalAlpha = 1;
            ctx.beginPath();
            // eyes img
            let ang =
                interpolateDirection(
                    this.lastdragangle,
                    this.powerups.dragon.angle,
                    0.5
                ) || this.powerups.dragon.angle;
            ctx.translate(pos.x, pos.y);
            ctx.rotate(ang + Math.PI);
            ctx.drawImage(
                this.eyes,
                (-this.renderRadius * 3) / 2,
                (-this.renderRadius * 3) / 2,
                this.renderRadius * 3,
                this.renderRadius * 3
            );
            ctx.rotate(-ang - Math.PI);
            ctx.translate(-pos.x, -pos.y);
            if (this.id == selfId) {
                this.lastdragangle = this.powerups.dragon.angle;
            }
            // testing
            /*if(this.dtailangle){
                ctx.globalAlpha = 0.5;
                ctx.translate(pos.x,pos.y);
                ctx.rotate(this.dtailangle);
                ctx.drawImage(this.eyes, -this.renderRadius, -this.renderRadius, this.renderRadius*2, this.renderRadius*2);
                ctx.rotate(-this.dtailangle);
                ctx.translate(-pos.x,-pos.y);
            }
            if(this.testPlayer){
                let toffset = offset(this.testPlayer.x,this.testPlayer.y);
                ctx.globalAlpha = 0.5;
                ctx.arc(toffset.x, toffset.y,this.renderRadius, 0, Math.PI * 2  * this.powerups.dragon.hp/10);
                ctx.fill();
            }*/
            ctx.globalAlpha = 1;
        }

        if (this.god) {
            ctx.strokeStyle = 'purple';
            ctx.lineWidth = 5;
            ctx.stroke();
        }

        if (this.tagged) {
            ctx.strokeStyle = '#4feb34';
            if(this.onTagCooldown !== undefined){
                ctx.strokeStyle = '#cccc00'//'red';
            }
            ctx.lineWidth = 5;
            ctx.stroke();
            ctx.globalAlpha = 1;
        }

        if (this.biteAnimTimer && this.biteAnimTimer > 0 && !this.dead) {
            ctx.globalAlpha = (this.biteAnimTimer * 3) / 5;
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
            ctx.fillStyle = 'red';
            ctx.fill();
            ctx.closePath();
            this.biteAnimTimer -= dt / 1.5;
            ctx.globalAlpha = 1;
        }

        if (window.showServer) {
            ctx.fillStyle = 'black';
            ctx.globalAlpha = 0.5;
            ctx.beginPath();
            const server = offset(this.server.x, this.server.y);
            ctx.arc(server.x, server.y, this.renderRadius, 0, Math.PI * 2);
            ctx.fill();
            ctx.globalAlpha = 1;
        }
        ctx.shadowBlur = 0;
        ctx.fillStyle = 'white';
        ctx.font = `${15 * ((Math.abs(this.renderRadius) + 0.5) / 25)}px Inter`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        if (!window.dontShowPlayerName) {
            if (this.guest) {
                ctx.globalAlpha = 0.25;
            } 
                if (this.id !== selfId) {
                    ctx.globalAlpha = 1;
                }
                // ctx.globalAlpha = 0.9;
                ctx.fillText(
                    this.name,
                    pos.x,
                    pos.y + this.renderRadius + this.renderRadius / 3 + 3
                );
                if (window.debugMode) {
                    ctx.fillText(
                        `${Math.round(this.ping * 1000)}ms`,
                        pos.x,
                        pos.y - this.renderRadius - this.renderRadius / 2
                    );
                }
                ctx.globalAlpha = 1;
            
            ctx.closePath();
            let scale = 1;
            if (this.powerups.rev && this.powerups.rev > 0) {
                const poffset =
                    (Math.max(0, this.powerups.inv ?? 0) *
                        20 *
                        this.renderRadius) /
                    this.defaultRadius;
                ctx.beginPath();
                if (
                    (this.powerups.rev * this.renderRadius) / 3 + poffset >
                    this.renderRadius
                ) {
                    scale =
                        this.renderRadius /
                        ((this.powerups.rev * this.renderRadius) / 3 + poffset);
                }
                ctx.arc(
                    pos.x,
                    pos.y,
                    ((this.powerups.rev * this.renderRadius) / 3 + poffset) *
                        scale,
                    0,
                    Math.PI * 2
                );
                ctx.fillStyle = '#05962b';
                //ctx.lineWidth = this.powerups.rev*2;
                ctx.fill();
                ctx.closePath();
                ctx.globalAlpha = 1;
            }

            if (this.powerups.inv && this.powerups.inv > 0) {
                ctx.beginPath();
                // if(this.powerups.inv*20*this.renderRadius/24.5 > this.renderRadius){
                //     scale = Math.min(scale, this.renderRadius/(this.powerups.inv*20*this.renderRadius/24.5))
                // }
                ctx.arc(
                    pos.x,
                    pos.y,
                    (this.powerups.inv / this.powerups.invMax) *
                        this.renderRadius *
                        0.6 /*(this.powerups.inv*20*this.renderRadius/24.5)*scale*/,
                    0,
                    Math.PI * 2
                );
                ctx.fillStyle = '#383838';
                // ctx.globalAlpha = this.powerups.inv/this.renderRadius*25;
                //ctx.lineWidth = this.powerups.inv*20;
                ctx.fill();
                ctx.closePath();
                ctx.globalAlpha = 1;
            }

            if (this.powerups.grapple.state) {
                ctx.beginPath();
                // ctx.strokeStyle = '#c9c9c9';
                ctx.strokeStyle = '#969696';
                if (this.powerups.grapple.grappling) {
                    ctx.strokeStyle = 'white';
                }
                // if(!this.powerups.grapple.grappling && this.id === selfId){
                //     ctx.strokeStyle = 'red';
                // }
                ctx.globalAlpha = 0.75;
                ctx.lineWidth = 6;
                ctx.arc(pos.x, pos.y, this.renderRadius / 2, 0, Math.PI * 2);
                ctx.stroke();
                ctx.closePath();
                ctx.strokeStyle = '#969696';
                ctx.globalAlpha = 1;
            }

            if (
                (this.powerups.gun && this.powerups.gun.state != false) ||
                this.bullets.length > 0
            ) {
                if (this.powerups.gun.type == 'normal') {
                    ctx.fillStyle = '#bd8b0d';
                } else if (this.powerups.gun.type == 'stun') {
                    ctx.fillStyle = 'purple';
                } else if (this.powerups.gun.type == 'push') {
                    ctx.fillStyle = '#458dc4';
                } else if (this.powerups.gun.type == 'pvp') {
                    ctx.fillStyle = 'red'; //"#C71111";
                    if (this.id === selfId) {
                        ctx.fillStyle = '#0d40fc'; //'#002aff'//'blue'//'#002aff';//'#132FD2'
                    }
                    // if (this.powerups.gun.currentCooldown > 0) {
                    // 	ctx.fillStyle = '#b30000';
                    // 	// ctx.globalAlpha = 0.5;
                    // }
                }
                if (this.powerups.gun.state) {
                    ctx.beginPath();
                    ctx.arc(
                        pos.x,
                        pos.y,
                        this.renderRadius / 1.7,
                        0,
                        Math.PI * 2
                    );
                    ctx.fill();
                    ctx.translate(pos.x, pos.y);
                    ctx.rotate(this.powerups.gun.angle);
                    ctx.fillRect(
                        -this.renderRadius / 2.4,
                        this.renderRadius / 2.4,
                        this.renderRadius / 1.2,
                        this.renderRadius / 1.25
                    );
                    ctx.rotate(-this.powerups.gun.angle);
                    ctx.translate(-pos.x, -pos.y);
                    // ctx.closePath();
                }
                ctx.globalAlpha = 1;
                for (let i in this.bullets) {
                    let bpos = offset(this.bullets[i].x, this.bullets[i].y);
                    if (this.bullets[i].life <= 0.5) {
                        ctx.globalAlpha = this.bullets[i].life / 0.5;
                    }
                    // console.log(ctx.fillStyle, ctx.globalAlpha, this.bullets[i].life)
                    ctx.beginPath();
                    ctx.arc(
                        bpos.x,
                        bpos.y,
                        this.bullets[i].radius,
                        0,
                        Math.PI * 2
                    );
                    ctx.fill();
                    ctx.strokeStyle = 'black';
                    ctx.lineWidth = 2;
                    ctx.stroke();
                    ctx.globalAlpha = 1;
                }
                // ctx.globalAlpha = 1;
            }

            if (this.arrows.length > 0) {
                //ctx.filter = 'invert(100%)';
                ctx.globalAlpha = 1;
                for (let i in this.arrows) {
                    if (this.arrows[i][3] == false) continue;
                    if (this.arrows[i][0] == 'up') {
                        ctx.drawImage(
                            window.invertUpArrowImage,
                            pos.x - this.renderRadius,
                            pos.y -
                                this.renderRadius -
                                this.arrows[i][1] * this.arrows[i][2],
                            this.renderRadius * 2,
                            this.renderRadius * 2
                        );
                    } else if (this.arrows[i][0] == 'right') {
                        ctx.drawImage(
                            window.invertRightArrowImage,
                            pos.x - this.renderRadius,
                            pos.y -
                                this.renderRadius -
                                this.arrows[i][1] * this.arrows[i][2],
                            this.renderRadius * 2,
                            this.renderRadius * 2
                        );
                    } else if (this.arrows[i][0] == 'down') {
                        ctx.drawImage(
                            window.invertDownArrowImage,
                            pos.x - this.renderRadius,
                            pos.y -
                                this.renderRadius -
                                this.arrows[i][1] * this.arrows[i][2],
                            this.renderRadius * 2,
                            this.renderRadius * 2
                        );
                    } else {
                        ctx.drawImage(
                            window.invertLeftArrowImage,
                            pos.x - this.renderRadius,
                            pos.y -
                                this.renderRadius -
                                this.arrows[i][1] * this.arrows[i][2],
                            this.renderRadius * 2,
                            this.renderRadius * 2
                        );
                    }
                }
                //ctx.filter = 'none';
            }

            if (this.zombies.length > 0) {
                for (let i in this.zombies) {
                    ctx.beginPath();
                    ctx.fillStyle = '#331212';
                    let zpos = offset(this.zombies[i].x, this.zombies[i].y);
                    ctx.arc(
                        zpos.x,
                        zpos.y,
                        this.zombies[i].radius,
                        0,
                        Math.PI * 2
                    );
                    ctx.fill();
                    ctx.closePath();
                }
            }
        }
    }
}
