class Enemy {
	constructor(init) {
        // console.trace();
		this.type = init.type;
        this.parentId = init.parentId;
        this.angle = init.angle;
        if(this.type !== 'rotatearoundparent') {
            this.childId = init.childId;
        }
        if(init.switchChildId){
            this.switchChildId = init.switchChildId;
            this.switchChildIndex = init.switchChildIndex;
            this.switchChildTimer = init.switchChildTimer;
        }
        if(init.switchParentId){
            this.switchParentId = init.switchParentId;
            this.switchParentIndex = init.switchParentIndex;
            this.switchParentTimer = init.switchParentTimer;
        }
        if(init.pushIndex){
            this.pushIndex = init.pushIndex;
        }
        if (init.stickParentIds){
            this.stickParentIds = init.stickParentIds;
        }
        if (init.stickFollowerIds){
            this.stickFollowerIds = init.stickFollowerIds;
        }
		if (this.type === 'square') {
			this.size = init.size;
		}
        if (this.type == 'rotatearoundparent'){
            this.rotateAngle = init.rotateAngle;
            this.rotateSpeed = init.rotateSpeed;
            this.rotateDist = init.rotateDist;
            this.chId = init.chId;
        }
        if(this.type == 'repel'){
            this.repelAmount = init.repelAmount;
            this.repelPower = init.repelPower;
            this.minDistance = init.minDistance;
        }
        if (this.type === 'oval' || this.type == 'growingoval'){
            this.r1 = init.r1;
            this.r2 = init.r2;
            if(this.type == 'growingoval'){
                this.growSpeedX = init.growSpeedX;
                this.growSpeedY = init.growSpeedY;
                this.maxX = init.maxX;
                this.minY = init.minY;
                this.minX = init.minX;
                this.maxY = init.maxY;
                this.growingX = init.growingX;
                this.growingY = init.growingY;
            }
        }
        if(this.type === 'pointaccel'){
            this.accelFactor = init.accelFactor;
            this.accelPower = init.accelPower;
            this.centerPoint = init.centerPoint;
            this.baseSpeed = init.baseSpeed;
        }
        if (this.type == 'e2dasher'){
            this.dashTimer = init.dashTimer;
            this.dashDistance = init.dashDistance;
            this.friction = init.friction;
            this.firstCooldown = init.firstCooldown;
            this.firstSpeed = init.firstSpeed;
            this.secondCooldown = init.secondCooldown;
            this.secondSpeed = init.secondSpeed;
            this.coolType = init.coolType;
        }
        if (this.type == 'tpplayer'){
            this.other = init.other;
        }
        if (this.type === 'polygon') {
			this.size = init.size;
            this.color = init.color;
            this.sides = init.sides;
            this.points = init.points;
            this.rotateSpeed = init.rotateSpeed;
            this.rotateAngle = init.rotateAngle;
		}
        if(this.type == 'boomerang'){
            this.throwCooldown = init.throwCooldown;
            this.throwAngle = init.throwAngle;
            this.throwTimer = init.throwTimer;
            this.boomerangSpeed = init.boomerangSpeed;
            this.boomerangRadius = init.boomerangRadius;
            this.boomerangs = init.boomerangs;
            this.shootIndex = init.shootIndex;
            this.shootAngles = init.shootAngles;
        }
        if(this.type === 'fire'){
            this.maxTime = init.maxTime;
            this.timer = init.timer;
            this.fire = init.fire;
            this.fireAmount = init.fireAmount;
            this.fireDistance = init.fireDistance;
            this.fireLife = init.fireLife;
            this.pauseTime = init.pauseTime || 0.5;
        }
        if(this.type === 'followaxis'){
            this.axis = init.axis;
        }
        if (this.type == 'enemymove'){
            this.points = init.points;
            this.speed = init.speed;
            this.currentPoint = init.currentPoint;
        }
		if (this.type === 'tp') {
			this.previewX = init.previewX;
			this.previewY = init.previewY;
			this.teleportTime = init.teleportTime;
			this.teleportTimer = init.teleportTimer;
		}
        if (this.type === 'sticky'){
            this.stickToPlayer = init.stickToPlayer;
            this.stickToEnemy = init.stickToEnemy;
            //this.stickParent = init.stickParent;
            this.stickOffset = init.stickOffset;
            this.toBoundStick = init.toBoundStick;
            // this.stickAll = init.stickAll;
            // this.stickTypes = init.stickTypes;
            //this.stickFollowers = init.stickFollowers;
            this.stickFollowers = {};
            this.uniqueStickId = init.uniqueStickId;
            this.stickParentId = init.stickParentId;
            this.toKill = init.toKill;
        }
        if (this.type === 'killenemy'){
            this.toKillParent = init.toKillParent;
            this.killAll = init.killAll;
            this.killTypes = init.killTypes;
        }
		if (this.type === 'switch') {
			this.switchTime = init.switchTime;
			this.switchTimer = init.switchTimer;
			this.currentSwitch = init.currentSwitch;
			this.bounceAmount = init.bounceAmount;
		}
        if(this.type === 'slower'){
            this.speedMult = init.speedMult;
        }
        if (this.type == "dasher"){
          this.time = init.time;
          this.baseRadius = init.baseRadius;
        }
        if (this.type === 'switchaccel'){
            this.firstSpeed = init.firstSpeed;
            this.secondSpeed = init.secondspeed;
            this.accelAmount = init.accelAmount;
            this.startingDirection = init.stratingDirection;
            this.normalized = {
                xv: Math.cos(this.angle),
                yv: Math.sin(this.angle),
            }
        }
        if(this.type == 'jump'){
            this.jumping = init.jumping;
            this.timer = init.timer;
            this.vz = init.vz;
            this.z = init.z;
            this.gravity = init.gravity;
            this.baseRadius = init.baseRadius;
            this.maxTimer = init.maxTimer;
            this.jumpHeight = init.jumpHeight;
        }
        if (this.type == "gaura" || this.type == "enemygrav"){
          this.auraStrength = init.auraStrength;
        }
        if (this.type == 'rchange'){
            this.addRadius = init.addRadius;
            this.multiplyRadius = init.multiplyRadius;
        }
        if (this.type == "flashlight"){
          this.flSize = init.flashlightSize;
          this.flAngle = init.flashlightAngle;
    		this.flashlightDir = init.flashlightDir;
        }
        if (this.type == "rain"){
          this.waitTimer = init.waitTimer;
          this.timer = init.timer;
          this.toWait = init.toWait;
          this.toWarp = init.toWarp;
            this.direction = init.direction;
        }
        if (this.type == "turning"){
          this.changeDir = init.changeDir;
        }
        if(this.type == 'shh'){
          this.impostor = init.impostor;
        }
        if (this.type == "memory"){
          this.time = init.time;
          this.timeOff = init.timeOff;
          this.timer = init.timer;
          this.on = init.on;
        }
        if (this.type == "wavy"){
          this.dir = init.dir;
          this.timer = init.timer;
          this.maxTimer = init.maxTimer;
        }
        if (this.type == 'spawn'){
            this.spawnTime = init.spawnTime;
            this.color = init.color;
            this.spawnTimer = init.spawnTimer;
            this.spawnParams = init.spawnParams;
            this.shootAngles = init.shootAngles;
            this.shootIndex = init.shootIndex;
            this.seed = init.seed;
            this.spawnIndex = init.spawnIndex;
            this.timeIndex = init.timeIndex;
            this.spawnPushIndex = init.spawnPushIndex;
        }
        if (this.type === 'reflectbullet'){
            this.health = init.health;
            this.maxHealth = init.health;
            console.log(this.maxHealth);
        }
        if (this.type == 'bomb'){
            this.bombNumber = init.bombNumber;
            this.bombs = init.bombs;
            this.bombSpeed = init.bombSpeed;
            this.bombRadius = init.bombRadius;
            this.bombLife = init.bombLife;
            this.bombDecay = init.bombDecay;
        }
        if (this.type == 'flower') {
            this.rotateSpeed = init.rotateSpeed;
            this.clonesRadius = init.clonesRadius;
            this.clonesDistance = init.clonesDistance;
            // this.clonesAngle = init.clonesAngle;
            // this.clonesX = init.clonesX;
            // this.clonesY = init.clonesY;
            this.layers = init.layers;
            // this.clonesLayer = init.clonesLayer;
            this.clonesEffect = init.clonesEffect;
            this.effectMagnitude = init.effectMagnitude;
            this.growingMultiple = init.growingMultiple;
            this.growingSpeed = init.growingSpeed;
            // this.clonesGrowing = init.clonesGrowing;
            this.clones = init.clones;
        }
        if(this.type == 'turret') {
          this.shootSpeed = init.shootSpeed;
          this.timer = init.timer;
          this.pRadius = init.pRadius;
          this.pSpeed = init.pSpeed;
          this.projectiles = init.projectiles;
          this.shootDirections = init.shootDirections;
          this.csd = init.csd;
            this.deadProjectiles = [];
        }
        if(this.type === 'growing') {
          this.minRadius = init.minRadius;
          this.maxRadius = init.maxRadius;
          this.growSpeed = init.growSpeed;
          this.growing = init.growing;
          this.bounceAmount = init.bounceAmount;
        }
        if(this.type === 'accelerating'){
          this.accelAmount = init.accelAmount;
        }
        if(this.type === 'wind'){
          this.strength = init.strength;
        }
        if(this.type === 'enemyobstacle'){
            this.boundRadius = init.boundRadius;
            this.parentOffset = init.parentOffset;
            this.obstacleParentId = init.obstacleParentId;
            this.toKill = init.toKill;
        }
        if (this.type === 'combo'){
            for(let key in init){
                this[key] = init[key];
            }
        }
        if (this.type === 'oscillating'){
            this.points = init.points;
            this.currentPoint = init.currentPoint;
        }
		this.radius = init.radius;
        if(this.radius < 0){
            this.radius = 0;
        }
		this.speed = init.speed;
		this.x = init.x;
		this.y = init.y;
		this.renderX = this.x;
		this.renderY = this.y;
		this.xv = init.xv;
		this.yv = init.yv;
		this.bound = init.bound;
		this.isLava = init.isLava;
        this.life = init.life ?? undefined;
        this.simulateBound = init.simulateBound || undefined;
	}
	update(delt) {
		this.renderX = this.x;
		this.renderY = this.y;
	}

	render() {
        if(this.type === 'enemyobstacle'){
            return;
        }
        ctx.globalAlpha = 1;
		ctx.lineWidth = 2;
		ctx.strokeStyle = 'black';
        if(this.life && this.life < 0.33){
            ctx.globalAlpha = this.life/0.33;
        }
        if (this.deadTimer != undefined){
            ctx.globalAlpha = Math.max(0,1-this.deadTimer/2);
        }
		const pos = offset(this.renderX, this.renderY);
		if (this.type === 'normal') {
			ctx.fillStyle = '#7d7d7d';
            if(window.renderGlitch || this.isLava){
                ctx.fillStyle = 'red';
            }
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill()
			ctx.stroke()
        } else if (this.type === 'followaxis') {
			ctx.fillStyle = 'black';
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill()
			ctx.stroke()
        } else if (this.type === 'toxic') {
			ctx.fillStyle = '#14e605';
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill()
			ctx.stroke()
        } else if (this.type === 'rotatearoundparent') {
			ctx.fillStyle = '#F7C91F';//'#706d15';
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill()
			ctx.stroke()
		} else if (this.type === 'enemymove') {
			ctx.fillStyle = '#0f0f0f';
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill()
			ctx.stroke()
		} else if (this.type === 'repel') {
			ctx.fillStyle = '#e8e8e8';
            ctx.globalAlpha = 0.9;
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill()
			ctx.stroke()
            ctx.globalAlpha = 1;
		} else if (this.type === 'pointaccel') {
			ctx.fillStyle = '#3295a8';// bad color; change later
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill()
			ctx.stroke()
		} else if (this.type === 'nokill') {
			ctx.fillStyle = window.bgColor||'#141414';
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill()
            ctx.globalAlpha = 0.1;
			ctx.stroke()
            ctx.globalAlpha = 1;
		}  else if (this.type === 'outline') {
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.stroke()
		} else if (this.type === 'wavy') {
			ctx.fillStyle = '#c22311';
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill()
			ctx.stroke()
		} else if (this.type === 'jump') {
			ctx.fillStyle = '#2c0073';
            ctx.globalAlpha = Math.max(0.2,1-this.z/this.jumpHeight*2.2);
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill()
			ctx.stroke()
            ctx.globalAlpha = 1;
		} else if (this.type === 'bomb') {
            ctx.fillStyle = '#300000';
            for(let i in this.bombs){
                let b = this.bombs[i];
                ctx.globalAlpha = b.life;
                const bpos = offset(b.x, b.y);
                ctx.beginPath();
    			ctx.arc(bpos.x, bpos.y, b.radius, 0, Math.PI * 2);
    			ctx.fill();
    			ctx.stroke();
                ctx.closePath();
                ctx.globalAlpha = 1;
            }
            ctx.globalAlpha = 1;
			ctx.fillStyle = '#210112';
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill()
			ctx.stroke()
            ctx.closePath();
		} else if (this.type === 'fire') {
            ctx.fillStyle = '#590813';
            for(let i in this.fire){
                let f = this.fire[i];
                ctx.globalAlpha = f.life;
                const bpos = offset(f.x, f.y);
                var gradient = ctx.createRadialGradient(bpos.x,bpos.y,0,bpos.x,bpos.y,this.radius*1.5);
                gradient.addColorStop(0, '#590813');
                gradient.addColorStop(1, '#1a0104');
                ctx.beginPath();
                ctx.fillStyle = gradient;
    			ctx.arc(bpos.x, bpos.y, this.radius, 0, Math.PI * 2);
    			ctx.fill();
    			ctx.stroke();
                ctx.closePath();
                ctx.globalAlpha = 1;
            }
            ctx.globalAlpha = 1;
			ctx.fillStyle = '#300000';
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill()
			ctx.stroke()
            ctx.closePath();
		} else if (this.type === 'wind') {
            ctx.fillStyle = 'white';
            ctx.globalAlpha = 0.3;
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
            ctx.fill();
            ctx.globalAlpha = 1;
            ctx.stroke();
		} else if (this.type === 'forcemove') {
            ctx.fillStyle = 'orange';
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
            ctx.fill();
            ctx.globalAlpha = 1;
            ctx.stroke();
		} else if (this.type === 'forcestop') {
            ctx.fillStyle = 'blue';
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
            ctx.fill();
            ctx.globalAlpha = 1;
            ctx.stroke();
		} else if (this.type === 'tpplayer') {
            ctx.fillStyle = '#d49020';
            ctx.globalAlpha = 0.3;
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
            ctx.fill();
            //ctx.globalAlpha = 0.1;
            ctx.stroke();
            ctx.globalAlpha = 1;
            ctx.closePath();
            ctx.beginPath();
            ctx.fillStyle = '#2065d4';
            ctx.globalAlpha = 0.3;
            ctx.beginPath();
            let opos = offset(this.other.x,this.other.y);
            ctx.arc(opos.x, opos.y, this.radius, 0, Math.PI * 2);
            ctx.fill();
            //ctx.globalAlpha = 0.1;
            ctx.stroke();
            ctx.globalAlpha = 1;
		} else if (this.type === 'selfcollide') {
            ctx.fillStyle = '#262626';
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();
		} else if (this.type === 'spawn') {
            try{
                ctx.fillStyle = this.color;
                ctx.beginPath();
                ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
                ctx.fill();
                ctx.stroke();
                ctx.closePath();
            } catch(e){
                ctx.fillStyle = '#490794';
                ctx.beginPath();
                ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
                ctx.fill();
                ctx.stroke();
                ctx.closePath();
            }
            if(this.shootAngles){
                ctx.translate(pos.x,pos.y);
                let dir = this.shootAngles[this.shootIndex+1] || this.shootAngles[0];
                ctx.rotate(dir-Math.PI/2)
                ctx.drawImage(window.downArrowImage, -this.radius, -this.radius, this.radius*2, this.radius*2);
                ctx.rotate(-dir+Math.PI/2)
                ctx.translate(-pos.x,-pos.y);
            }
		} else if (this.type === 'slower') {
            if(this.speedMult > 1){
                ctx.fillStyle = '#ba2916';
                ctx.globalAlpha = Math.min(0.18,0.06*this.speedMult);
                ctx.beginPath();
                ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
                ctx.fill();
            } else {
                ctx.fillStyle = '#1644ba';
                ctx.globalAlpha = Math.min(0.18,0.06*1/this.speedMult);
                ctx.beginPath();
                ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
                ctx.fill();
            }
            ctx.globalAlpha = 1;
		}  else if (this.type === 'accelerating') {
			ctx.fillStyle = '#595959';
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill()
			ctx.stroke()
		} else if (this.type === 'growing') {
            ctx.fillStyle = '#fcba03';
            ctx.beginPath();
            if(this.bounceAmount !== undefined && this.bounceAmount !== null && this.bounceAmount !== ''){
                // temporary image; ill only put in final release wiht haha's permission ;c
                ctx.drawImage(window.bouncyImage, pos.x-this.radius,pos.y-this.radius,this.radius*2,this.radius*2);
                // bouncy sprite is only temporary ;-; i don't wanna steal haha's stuff for release
            } else {
                ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
                ctx.fill()
            }
            ctx.stroke()
		} else if (this.type === 'flower') {
			ctx.fillStyle = '#240c2e';
            if(window.renderGlitch){
                ctx.fillStyle = 'red';
            }
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill()
			ctx.stroke()
            ctx.closePath();
            // drawing clones
            if(this.clonesEffect == 'slow'){
                if(this.effectMagnitude > 1){
                    ctx.fillStyle = '#103047';
                } else {
                    ctx.fillStyle = '#c48e0e';
                }
            } else if(this.clonesEffect == 'size'){
                if(this.effectMagnitude > 24.5){
                    ctx.fillStyle = "#0b1466";
                } else {
                    ctx.fillStyle = "#7a7600";
                } 
            } else if(this.clonesEffect == 'grav'){
                if(this.effectMagnitude > 0){
                    ctx.fillStyle = "#72007a";
                } else {
                    ctx.fillStyle = "#a595a6";
                } 
            } else if(this.clonesEffect == 'vinette'){
                ctx.fillStyle = '#0c0c0c';
            } else {
                ctx.fillStyle = '#371047';
            }
            
            for(let clone of this.clones){
                let clonerad = this.clonesRadius;
                // clone.x = this.x + Math.random() + Math.cos(clone.angle) * this.clonesDistance * (clone.layer+1);
                // clone.y = this.y + Math.random() + Math.sin(clone.angle) * this.clonesDistance * (clone.layer+1);
                ctx.beginPath();
                const clonepos = offset(clone.x, clone.y);
                
                if(this.growingMultiple != undefined){
                    clonerad = clone.growing.radius; 
                }
                ctx.arc(clonepos.x, clonepos.y, clonerad, 0, Math.PI * 2);
                ctx.fill()
                ctx.stroke()
                ctx.closePath();
            }
		} else if (this.type == 'turret') {
            ctx.fillStyle = '#053564';
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill()
			ctx.stroke()
            ctx.closePath();
            ctx.fillStyle = '#107691';
			ctx.strokeStyle = 'black';
			ctx.lineWidth = lineWidth;
            for(let p in this.deadProjectiles){
                ctx.globalAlpha = this.deadProjectiles[p].life;
                ctx.beginPath();
                const projpos = offset(this.deadProjectiles[p].x, this.deadProjectiles[p].y);
                ctx.arc(projpos.x, projpos.y, this.pRadius, 0, Math.PI * 2);
                ctx.fill();
                ctx.stroke()
                ctx.closePath();
                ctx.globalAlpha = 1;
            }
            for(let p in this.projectiles){
                ctx.beginPath();
                const projpos = offset(this.projectiles[p].x, this.projectiles[p].y);
                ctx.arc(projpos.x, projpos.y, this.pRadius, 0, Math.PI * 2);
                ctx.fill();
                ctx.stroke()
                ctx.closePath();
            }
    } else if (this.type === 'memory') {
        ctx.fillStyle = '#dbdbc3';
        if(window.renderGlitch){
            ctx.fillStyle = 'red';
        }
      if(this.on){
        ctx.globalAlpha = this.timer;
      } else if(this.timer < 0.25 && this.timeOff > 0.25){
        ctx.globalAlpha = 4*(0.25-this.timer);
      } else {
        ctx.globalAlpha = 0;
      }
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill()
			ctx.stroke()
		} else if (this.type === 'enemygrav') {
			ctx.fillStyle = '#8019a6';
			// ctx.beginPath();
			// ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			// ctx.fill();
			// ctx.stroke();
            ctx.globalAlpha = 0.3;
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
            ctx.fill();
            ctx.globalAlpha = 1;
            ctx.stroke();
		} else if (this.type === 'boomerang') {
            ctx.fillStyle = '#d1ce1b';
            for(let i in this.boomerangs){
                let b = this.boomerangs[i];
                let bopos = offset(b.x, b.y);
                ctx.beginPath();
    			ctx.arc(bopos.x, bopos.y, b.radius, 0, Math.PI * 2);
    			ctx.fill();
    			ctx.stroke();
                ctx.closePath();
            }
			ctx.fillStyle = '#634418';
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill();
			ctx.stroke();
            ctx.closePath();
		} else if (this.type === 'rain') {
            if(this.toWarp){
                ctx.fillStyle = '#104a4a';
            } else {
                ctx.fillStyle = '#7dd1d1';   
            }
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill();
			ctx.stroke();
            ctx.closePath();
		} else if (this.type === 'turning') {
			ctx.fillStyle = '#162110';
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill()
			ctx.stroke()
		} else if (this.type === 'dasher') {
			ctx.fillStyle = "#4b9fd6";
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill()
			ctx.stroke()
		} else if (this.type === 'switchaccel') {
			ctx.fillStyle = "#4b9fd6";
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill()
			ctx.stroke()
		} else if (this.type === 'square') {
			ctx.fillStyle = '#ff4000';
			ctx.beginPath();
			ctx.rect(pos.x - this.size / 2, pos.y - this.size / 2, this.size, this.size);
			ctx.fill()
			ctx.stroke()
		} else if (this.type === 'polygon') {
			ctx.fillStyle = this.color||'#00e06c';// diep.io green tank color lol
            ctx.beginPath();
            ctx.moveTo(pos.x + this.points[0][0], pos.y + this.points[0][1]);
            for(let s = 1; s < this.points.length; s++){
                ctx.lineTo(pos.x + this.points[s][0], pos.y + this.points[s][1]);
            }
            ctx.fill();
            ctx.stroke();
		} else if (this.type === 'switch') {
			ctx.fillStyle = '#8304cc'; // switch color
			if (!this.currentSwitch) {
				ctx.globalAlpha = 0.4; // if disabled
			}
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill()
			ctx.stroke()
			ctx.globalAlpha = 1;
		} else if (this.type === 'sticky') {
            ctx.fillStyle = '#34eb71';
            if(this.toKill === false){
                ctx.globalAlpha = 0.4;
            }
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill()
            ctx.stroke();
            ctx.closePath();
            // ctx.beginPath();
            // ctx.globalAlpha = 1;
            // if(this.stickParent !== undefined){
            //     ctx.strokeStyle = '#34eb71';
            //     ctx.globalAlpha = 0.3;
            //     ctx.arc(pos.x - this.stickOffset.x, pos.y - this.stickOffset.y, (this.stickParent.radius+ctx.lineWidth) || 0, 0, Math.PI*2);
            //     ctx.stroke();
            //     ctx.strokeStyle = 'black';
            //     ctx.globalAlpha = 1;
            // }
            // ctx.closePath();
        } else if (this.type === 'killenemy') {
            //ctx.fillStyle = '#F0F7D2';
            //const t = Math.abs(1-(performance.now()%2400)/1200);// 0 to 1
            //ctx.fillStyle = `rgb(255,${t*255},${t*255})`;.
            ctx.fillStyle = 'red';
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius-ctx.lineWidth, 0, Math.PI * 2);
			ctx.fill();
			ctx.stroke();
            ctx.closePath();
            ctx.strokeStyle = 'red';
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
            ctx.stroke();
            ctx.strokeStyle = 'black';
            ctx.closePath();
        } else if (this.type === 'oval' || this.type == 'growingoval') {
            ctx.fillStyle = '#7d7d7d';
			ctx.beginPath();
			ctx.ellipse(pos.x, pos.y, Math.abs(this.r1), Math.abs(this.r2), 0, 0, Math.PI * 2);
			ctx.fill()
			ctx.stroke()
			ctx.globalAlpha = 1;
		} else if (this.type === 'e2dasher') {
            ctx.fillStyle = '#023252';
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill()
			ctx.stroke()
			ctx.globalAlpha = 1;
		} else if (this.type === 'reflectbullet') {
            ctx.fillStyle = '#16181D';
			ctx.beginPath();
            ctx.lineWidth = lineWidth*(this.health+1);
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill()
			ctx.stroke()
			ctx.globalAlpha = 1;
            ctx.lineWidth = lineWidth;
		} else if (this.type === 'tp') {
			ctx.fillStyle = '#cf4eb5';
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill();
			ctx.stroke();

			const pre = offset(this.previewX, this.previewY);
			ctx.globalAlpha = 0.1 + 0.8 * (this.teleportTimer / this.teleportTime);
			ctx.fillStyle = '#a12287';
			ctx.beginPath();
			ctx.arc(pre.x, pre.y, this.radius, 0, Math.PI * 2);
			ctx.fill();
			ctx.stroke();
			ctx.globalAlpha = 1;
		} else if (this.type === 'gaura') {
            ctx.globalAlpha = 0.3;
            if(this.auraStrength > 0){
                ctx.fillStyle = '#320745';
            } else {
                ctx.fillStyle = '#a69bab';
            }
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill();
            ctx.globalAlpha = 0.1;
			ctx.stroke();
            ctx.globalAlpha = 1;
		} else if (this.type === 'rchange') {
            ctx.globalAlpha = 0.3;
            ctx.fillStyle = '#500a50';
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill();
            ctx.globalAlpha = 0.1;
			ctx.stroke();
            ctx.globalAlpha = 1;
		} else if (this.type === 'flashlight') {
			ctx.fillStyle = '#2b2b2b';
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill();
			ctx.stroke();
            ctx.closePath();
            ctx.beginPath();
            var grd = ctx.createRadialGradient(pos.x,pos.y, this.radius, pos.x, pos.y,this.flSize-1);
              
            if(window.renderGlitch){
                grd.addColorStop(0, "rgba(255, 0, 0, 0.5)");
            } else {
                grd.addColorStop(0, "rgba(230, 230, 21, 0.3)");
            }
            grd.addColorStop(1, "rgba(230, 230, 21,0)");
            ctx.fillStyle = grd;
			let angle = Math.atan2(this.yv, this.xv);
			if (this.xv === 0 && this.yv === 0) {
				angle = this.flashlightDir;
			}
			ctx.arc(pos.x, pos.y, this.flSize*1.5, angle-this.flAngle/2, angle+this.flAngle/2);
            ctx.lineTo(pos.x, pos.y);
			ctx.fill();
            ctx.closePath();
		} else if(this.type === 'combo'){
            for(let i = 0; i < this.enemyTypes.length; i++){
                this.type = this.enemyTypes[i];
                ctx.globalAlpha = 1/this.enemyTypes.length;
                this.render()
            }
            this.type = 'combo';
        } else if(this.type === 'oscillating'){
            ctx.lineCap = 'round';
            let nextPointIndex = this.currentPoint + 1;
            if (nextPointIndex >= this.points.length) {
                nextPointIndex = 0;
            }
            // drawing targets
            // for(let i = 0; i < this.points.length; i++){
            //     let currentPointAlpha = 1;
            //     if(i === nextPointIndex){
            //         currentPointAlpha = 1.5;
            //     }
            //     const pt = this.points[i];
            //     const ptPos = offset(pt.x,pt.y);

            //     ctx.globalAlpha = 0.2*currentPointAlpha;
            //     ctx.setLineDash([5, 8]);
                
            //     ctx.lineDashOffset = -Math.sin(performance.now()/600) * 60;
            //     ctx.lineWidth = lineWidth;
            //     ctx.strokeStyle = 'red';
            //     ctx.beginPath();
            //     ctx.arc(ptPos.x, ptPos.y, 4, 0, Math.PI*2);
            //     ctx.stroke();
            //     ctx.closePath();
            //     ctx.strokeStyle = 'blue';
            //     ctx.setLineDash([7,12]);
            //     ctx.lineDashOffset *= -1;
            //     ctx.globalAlpha = 0.35*currentPointAlpha;
            //     ctx.beginPath();
            //     ctx.arc(ptPos.x, ptPos.y, 10, 0, Math.PI*2);
            //     ctx.stroke();
            //     ctx.closePath();
            // }

            // drawing them on top in a sep loop
            for (let i = 0; i < this.points.length; i++){
                const pt = this.points[i];
                const ptPos = offset(pt.x,pt.y);
                ctx.globalAlpha = 0.45;
                if(this.currentPoint === i){
                    ctx.globalAlpha = 0.6;
                }
                let nextPointIndex = i + 1;
                if (nextPointIndex >= this.points.length) {
                    nextPointIndex = 0;
                }
                ctx.setLineDash([12,12]);
                ctx.strokeStyle = 'white';
                const nextPtPos = offset(this.points[nextPointIndex].x,this.points[nextPointIndex].y);
                ctx.beginPath();
                ctx.moveTo(ptPos.x, ptPos.y);
                ctx.lineTo(nextPtPos.x, nextPtPos.y);
                ctx.stroke();
                ctx.closePath();
                ctx.setLineDash([]);
                ctx.strokeStyle = 'black';
            }

            ctx.globalAlpha = 1;
            
            ctx.fillStyle = '#869e0f';
			ctx.beginPath();
			ctx.arc(pos.x, pos.y, this.radius, 0, Math.PI * 2);
			ctx.fill();
			ctx.stroke();
        }
        ctx.closePath();
		ctx.globalAlpha = 1;
 	}
}