// crazy idea but i wanna play eX on my pro controller.
let haveEvents = 'ongamepadconnected' in window;
let controllers = {};

window.usingController = false;

function connecthandler(e) {
  addgamepad(e.gamepad);
}

function addgamepad(gamepad) {
  controllers[gamepad.index] = gamepad;
  requestAnimationFrame(updateStatus);
    window.usingController = true;
}

function disconnecthandler(e) {
  removegamepad(e.gamepad);
}

function removegamepad(gamepad) {
  delete controllers[gamepad.index];
    if(controllers.length === 0){
        window.usingController = fasle;
    }
}

function updateStatus() {
  if (!haveEvents) {
    scangamepads();
  }

  let i = 0;
  let j;

  for (j in controllers) {
    let controller = controllers[j];
    window.useMouse = true;
    window.mouse = {x: canvas.width/2, y: canvas.height/2};

    for (i = 0; i < controller.buttons.length; i++) {
        let val = controller.buttons[i];
        let pressed = val == 1.0;
        if (typeof(val) == "object") {
            pressed = val.pressed;
            val = val.value;
        }
        if(pressed && me().dead){
            send({respawn: true});
        }
    }
      
    for (let i = 0; i < controller.axes.length-1; i+=2) {
        // just set mouse position to a radius of like 500* this (its -1 to 1)
        if(controller.axes[i] === 0 && controller.axes[i] === 0){
            continue;
        }
        let radius = Math.min(canvas.width,canvas.height)/2;
        window.mouse = {
            x: canvas.width/2+controller.axes[i]*radius,
            y: canvas.height/2+controller.axes[i+1]*radius,
        }
    }
  }

  requestAnimationFrame(updateStatus);
}

function scangamepads() {
  let gamepads = navigator.getGamepads ? navigator.getGamepads() : (navigator.webkitGetGamepads ? navigator.webkitGetGamepads() : []);
  for (let i = 0; i < gamepads.length; i++) {
    if (gamepads[i]) {
      if (gamepads[i].index in controllers) {
        controllers[gamepads[i].index] = gamepads[i];
      } else {
        addgamepad(gamepads[i]);
      }
    }
  }
}

window.addEventListener("gamepadconnected", connecthandler);
window.addEventListener("gamepaddisconnected", disconnecthandler);