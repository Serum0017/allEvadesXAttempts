window.ws = new WebSocket(location.origin.replace(/^http/, 'ws'));


const encode = (msg) => msgpack.encode(msg);
const decode = (msg) => msgpack.decode(new Uint8Array(msg));

const send = (msg) => {
    // console.log(msg);
    const data = encode(msg);
    upstreambytes += data.byteLength;
    // console.log(msg, data.byteLength);
    ws.send(data);
};
window.upstreambytes = 0;
window.downstreambytes = 0;
window.upstreambytesR = 0;
window.downstreambytesR = 0;
ws.binaryType = 'arraybuffer';

let connected = false;
let extraLag = 0;

window.mg1countdownStart = false;

const _captchaKey = '6LcXTdogAAAAAJ-uDjOX6RJH3bEDJn4npV-ZenAG';

let newPlayer = localStorage.getItem('newPlayer');

// let savedName = localStorage.getItem('name');
let gridState = localStorage.getItem('gridState');
let lastShowGrid = true;
// if (savedName == undefined) {
//     savedName = '';
// }
if (gridState === undefined) {
    gridState = 'false';
}
if (gridState === 'false') {
    gridState = false;
} else {
    gridState = true;
}
let onBetaKey = true;
let __lastLoginAttempt = {
    name: '',
    password: '',
};
// ref.nameInput.value = savedName;

ref.loginForm.onsubmit = (event) => {
    event.preventDefault();
};

ref.playButton.addEventListener('mousedown', (event) => {
    ws.send(encode({ enterGame: true }));
});

ref.logoutButton.addEventListener('mousedown', (event) => {
    ref.loginForm.classList.remove('hidden');
    ref.loginSuccess.classList.add('hidden');
    ref.usernameInput.value = __lastLoginAttempt.name;
    ref.passwordInput.value = __lastLoginAttempt.password;
});

ref.guestButton.addEventListener('mousedown', (event) => {
    grecaptcha.ready(function () {
        grecaptcha
            .execute(_captchaKey, { action: 'submit' })
            .then(function (token) {
                ws.send(
                    encode({
                        guest: true,
                        token,
                    })
                );
            });
    });
});

ref.loginButton.addEventListener('mousedown', (event) => {
    const name = ref.usernameInput.value.trim();
    const password = ref.passwordInput.value.trim();
    const hashedPassword = SHA(password + 'ZeroTix');
    __lastLoginAttempt.name = name;
    __lastLoginAttempt.password = password;
    localStorage.setItem('username', name);
    localStorage.setItem('password', hashedPassword);
    console.log(name, password, hashedPassword, 'login');
    if (name.length > 0 && password.length > 0) {
        grecaptcha.ready(function () {
            grecaptcha
                .execute(_captchaKey, { action: 'submit' })
                .then(function (token) {
                    ws.send(
                        encode({
                            login: true,
                            username: name,
                            password: hashedPassword,
                            token,
                        })
                    );
                });
        });
    }
});

ref.registerButton.addEventListener('mousedown', (event) => {
    const name = ref.usernameInput.value.trim();
    const password = ref.passwordInput.value.trim();
    const hashedPassword = SHA(password + 'ZeroTix');
    console.log(name, password, hashedPassword, 'register');
    if (name.length > 0 && password.length > 0) {
        grecaptcha.ready(function () {
            grecaptcha
                .execute(_captchaKey, { action: 'submit' })
                .then(function (token) {
                    ws.send(
                        encode({
                            register: true,
                            username: name,
                            password: hashedPassword,
                            token,
                        })
                    );
                });
        });
    }
});

// gonna be annoying to uncomment
let inputtedBetaKey = '';
ref.nameForm.addEventListener('submit', (event) => {
    const name = ref.nameInput.value;
    ref.nameInput.value = '';
    //   localStorage.setItem("name", name);
    if (connected) {
        if (onBetaKey) {
            localStorage.setItem('betaKey', name);
            ws.send(encode({ betaKey: name }));
        } else {
            ws.send(encode({ joinGame: true, name }));
        }
    }
    //   if (newPlayer == undefined) {
    //     send({ world: 'PoPB' });
    //   }
    localStorage.setItem('newPlayer', false);
    event.preventDefault();
});

// window.addEventListener('load', () => {
//     console.log('assets loaded in', Math.round(window.performance.now()), 'ms');
// });

ws.onopen = () => {
    //console.log('CONNECTED TO THE GAME SERVER SUCCESSFULLY')
    // ref.mainMenu.classList.remove('hidden');
    // ref.mainMenu.classList.add('unblur');
    // ref.evadeText.classList.add('eanim')
    console.log(
        'connected to server in',
        Math.round(window.performance.now()),
        'ms'
    );
    let savedBetaKey = localStorage.getItem('betaKey');
    if (savedBetaKey != undefined) {
        //   window.ws.addEventListener("open", () => {
        window.ws.send(encode({ betaKey: savedBetaKey }));
        //   })
    }

    connected = true;
    window.showGrid = gridState;
};

ws.onmessage = (msg) => {
    const data = decode(msg.data);
    downstreambytes += msg.data.byteLength;
    // console.log(data, msg.data.byteLength)
	 if (data.loginFailure != undefined) {
        alert(data.loginFailure);
        // return;
    }
    if(data.rickroll){
        alert('you have been hacked');
        // window.location.replace("https://www.youtube.com/watch?v=5BZLz21ZS_Y");
    }
    if (data.joinGame) {
        // document.body.classList.remove('onMenu')
        setTimeout(() => {
            runGame(data.data);
        }, extraLag);
        return;
    }
    if (data.loginSuccess) {
        // name = account name
        ref.loginForm.classList.add('hidden');
        ref.loginSuccess.classList.remove('hidden');
        ref.loginData.innerText = `Logged in as ${data.name}`;
        return;
    }
    if (data.registerSuccess != undefined) {
        alert('Successfully created account!');
        return;
    }
   
    if (data.type === 'verify') {
        // gave the right betaKey
        ref.beta.innerHTML = '';
        ref.evadeTitle.classList.remove('hidden');

        onBetaKey = false;
        // const params = new URLSearchParams(document.location.search);
        // if (params.get('name')) {
        //     ws.send(
        //         encode({
        //             joinGame: true,
        //             name:
        //                 params.get('name') +
        //                 (params.get('disc') != undefined
        //                     ? '#' + params.get('disc')
        //                     : ''),
        //         })
        //     );
        // }
        const name = localStorage.getItem('username');
        const password = localStorage.getItem('password');
        if (name != undefined && password != undefined) {
            grecaptcha.ready(function () {
                grecaptcha
                    .execute(_captchaKey, { action: 'submit' })
                    .then(function (token) {
                        ws.send(
                            encode({
                                login: true,
                                username: name,
                                password,
                                token,
                            })
                        );
                    });
            });
        }
        return;
    }
    setTimeout(() => {
        processGameMessage(data);
    }, extraLag); //You realize setTimeout with 0 still adds extra lag right
    if (showGrid != lastShowGrid) {
        lastShowGrid = showGrid;
        localStorage.setItem('gridState', showGrid);
    }
};

ws.onclose = (e) => {
    connected = false;
	console.log('closeData from websocket', e);
    // setInterval(() => {
    //     location.reload();
    //     // window.ws = new WebSocket(location.origin.replace(/^http/, 'ws'));
    // }, 1000)
    //console.error('WEBSOSCKET CLOSED!!!')
};

ws.onerror = (e) => {
	console.log('errorData from websocket', e);
}

ws.addEventListener('error', event => {
    console.log('errorData from websocket', event);
})