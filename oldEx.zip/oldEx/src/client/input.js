const Controls = {
    KeyW: { key: 'up' },
    KeyS: { key: 'down' },
    KeyA: { key: 'left' },
    KeyD: { key: 'right' },
    ArrowUp: { key: 'up' },
    ArrowDown: { key: 'down' },
    ArrowLeft: { key: 'left' },
    ArrowRight: { key: 'right' },
    Space: { key: 'action' },
    KeyC: { key: 'action' },
    KeyY: { key: 'action' },
};

window.zenMode = false;

function onTouchStart(event) {
    event.preventDefault();
    // chat
    const touch = event.changedTouches[0];
    const bound = canvas.getBoundingClientRect();
    if (touch.pageX < 100 && touch.pageY < 300) {
        ref.chatDiv.classList.remove('hidden');
        ref.chat.focus();
        window.chatOpen = true;
    } else {
        useMouse = true;
        mouse.x = touch.pageX;
        mouse.y = touch.pageY;
        ref.chatDiv.blur();
        ref.chat.blur();
        if (me().dead) {
            send({ respawn: true });
        }
    }
}

function onTouchEnd(event) {
    useMouse = false;
    event.preventDefault();
}
function trackKeys(event, input, mobile) {
    if (event.repeat && !chatOpen) return event.preventDefault();
    if (event.code === 'Enter' || mobile) {
        if ((chatOpen && event.type === 'keydown') || mobile) {
            ref.chatDiv.classList.add('hidden');
            const text = ref.chat.value.trim();
            if (text.toLowerCase() == '/help') {
                const div = document.createElement('div');
                div.classList.add('chat-message');
                div.innerHTML = `${'<span class="rainbow">[SERVER]</span> '}: <span style="color: #c4c4c4;">WASD or Arrow Keys to Move. You can also toggle mouse by clicking the screen. R to respawn.</span>`;
                ref.chatMessageDiv.appendChild(div);
                ref.chatMessageDiv.scrollTop = ref.chatMessageDiv.scrollHeight;
            } else if (text.slice(0, 5) === '/diff') {
                const difficulty = text.slice(6).trim();
                trailDifficulty = difficulty;
            } else if (text.slice(0, 6) === '/scale') {
                const num = Number(text.slice(7)) ?? renderScale;
                window.renderScale = num;
                window.scaleChanged = true;
            } else if (text.slice(0, 4) === '/ray') {
                raycastvision = !raycastvision;
                if (raycastvision) {
                    computeLines();
                }
            } else if (text.slice(0, 5) === '/mute') {
                let p = text.slice(6);
                window.muted.push(p);
                window.processGameMessage({
                    leaderboardChanged: true,
                    playerData: window.lastpdata,
                }); // refreshing leaderboard
            } /*else if (text.trim() === '/rc') {
                window.raycastvision = !window.raycastvision;
                console.log(window.raycastvision);
			}*/ else if (text.slice(0, 7) === '/unmute') {
                let p = text.slice(8);
                if (window.muted.includes(p)) {
                    window.muted = window.muted.filter((player) => player != p);
                    window.processGameMessage({
                        leaderboardChanged: true,
                        playerData: window.lastpdata,
                    }); // refreshing leaderboard
                }
            } else if (text.slice(0, 4) === '/add') {
                let fullText = text.slice(5);
                fullText.trim();
                window.obsType = JSON.parse(fullText);
                console.log(window.obsType);
                // example:
                /*
                /add,[{"type":"tp","tpx":2500,"tpy":2500}]
                or nested objects
                 |
                 v
                /add,[{"type":"grav","force":1500,"dir":{"x":-1500,"y":0},"direction":"left"}]
                */
            } else if (text.slice(0, 4) === '/rec') {
                window.recordInputs = !window.recordInputs;
                if (!window.recordInputs) {
                    console.log(window.recordedInputs);
                    var cpy = document.createElement('textarea');
                    cpy.value = JSON.stringify(window.recordedInputs);
                    cpy.setAttribute('readonly', '');
                    cpy.style = { position: 'absolute', left: '-9999px' };
                    document.body.appendChild(cpy);
                    cpy.select();
                    document.execCommand('copy');
                    document.body.removeChild(cpy);
                }
            } else if (text.slice(0, 4).toLowerCase() === '/lag') {
                const txt = text.slice(5).trim();
                extraLag = Number(txt) * 2;
            } else if (text.slice(0, 11).toLowerCase() == '/changesnap') {
                let snapd = text.slice(11);
                window.snapDistance = Math.min(
                    200,
                    Math.max(1, parseInt(snapd))
                );
                //console.log(window.snapDistance);
            } else if (
                text.toLowerCase() === '/comic' ||
                text.toLowerCase() === '/anime'
            ) {
                if (lineWidth != 2) {
                    lineWidth = 2;
                } else {
                    lineWidth = 7;
                }
            } else if (text.toLowerCase() === '/dragon') {
                if (me().powerups.dragon.state == false) {
                    me().powerups.dragon.hp = 10;
                }
                me().powerups.dragon.state = !me().powerups.dragon.state;
                send({ powerups: me().powerups });
            } else if (text.slice(0, 7).toLowerCase() == '/delete') {
                console.log(text.slice(7));
                send({
                    del: text.slice(7),
                });
            } else if (text.toLowerCase() === '/hat') {
                showHat = !showHat;
            } else if (text.toLowerCase() == '/clear') {
                ref.chatMessageDiv.innerHTML = '';
            } else if (text.toLowerCase() === '/copy') {
                var cpy = document.createElement('textarea');
                let obsString = window.obstacles;
                /*for(let s in window.safes){
                    console.log(window.safes[s]);
                    obsString += `,{"type":"revive","x":${window.safes[s].x},"y":${window.safes[s].y},"w":${window.safes[s].w},"h":${window.safes[s].h}}`
                }*/
                for (let i in obsString) {
                    delete obsString[i].sat;
                    if (obsString[i].collected == true) {
                        obsString[i].collected = false;
                    }
                }
                cpy.value = JSON.stringify(obsString);
                cpy.setAttribute('readonly', '');
                cpy.style = { position: 'absolute', left: '-9999px' };
                document.body.appendChild(cpy);
                cpy.select();
                document.execCommand('copy');
                document.body.removeChild(cpy);
            } else if (text.toLowerCase() === '/markers') {
                var cpy = document.createElement('textarea');
                const val = window.markers;//window.markers.map(m => [Math.round(m[0]),Math.round(m[1])]);
                console.log(val);
                cpy.value = JSON.stringify(val);
                cpy.setAttribute('readonly', '');
                cpy.style = { position: 'absolute', left: '-9999px' };
                document.body.appendChild(cpy);
                cpy.select();
                document.execCommand('copy');
                document.body.removeChild(cpy);
            } else if (text.toLowerCase() === '/respawn') {
                if(me().insideNoRes){
                    const div = document.createElement('div');
                    div.classList.add('chat-message');
                    div.innerHTML = `${'<span class="rainbow">[SERVER]</span> '}: <span style="color: #c4c4c4;">Respawning is disabled inside this area.</span>`;
                    ref.chatMessageDiv.appendChild(div);
                    ref.chatMessageDiv.scrollTop = ref.chatMessageDiv.scrollHeight;
                } else {
                    send({ respawn: true });
                }
            } else if (text.toLowerCase() === '/dc' && me().dev) {
                ws.close(); // this could also just reload page :v
            } else if (
                text.toLowerCase().slice(0, 6) === '/tpmap' &&
                me().dev
            ) {
                send({ world: text.slice(7) });
                setTimeout(() => {
                    send({powerups: me().powerups})
                    send({ship: me().ship});
                }, 400)
            } else if (
                text.toLowerCase().slice(0, 7) === '/tpzone' &&
                me().dev
            ) {
                for(let o of window.obstacles){
                    if(o.type === 'zone' && o.value == text.slice(8)){
                        me().x = o.x + o.w/2;
                        me().y = o.y + o.h/2;
                    }
                }
            } else if (
                text.toLowerCase() === '/reset' ||
                text.toLowerCase() === '/hub'
            ) {
                window.won = false;
                window.resetMusic = true;
                if (
                    world === 'PoTH' ||
                    world === 'Sandbox' ||
                    world === 'PoT' ||
                    world === 'MoBD' ||
                    world === 'Stellar' ||
                    world === 'PoV'
                ) {
                    // maps in stellar
                    send({ world: 'Stellar' });
                } else {
                    send({ world: 'Hub' });
                }
                setTimeout(() => {
                    send({powerups: me().powerups})
                    send({ship: me().ship});
                }, 400)
                // window.backgroundColor = '#1f2229';
                // window.tileColor = '#323645';
            } else if (
                text.toLowerCase() === '/restart' ||
                text.toLowerCase() === '/rest'
            ) {
                window.won = false;
                window.resetMusic = true;
                window.goingToNewWorld = true;
                send({ world: window.world });
                setTimeout(() => {
                    send({powerups: me().powerups})
                    send({ship: me().ship});
                }, 400)
            } else if (text.length > 0) {
                if (text.slice(0, 5) === '/spec' && !window.spectating) {
                    const name = text.slice(6);
                    for (const playerId of Object.keys(players)) {
                        const player = players[playerId];
                        if (player.name === name) {
                            window.spectating = true;
                            window.spectateId = playerId;
                            break;
                        }
                    }
                }
                if (text.slice(0, 7) === '/unspec' && window.spectating) {
                    window.spectating = false;
                }
                send({ chat: text });
                if (me().insideIframe) {
                    ref.iframeplaceholder.firstChild.contentWindow.focus();
                }
                if (text.trim().toLowerCase() === '/restartgame') {
                    const oldref = window.location.href;
                    const newref = `https://evade.zerotix.repl.co/?name=${
                        me().name
                    }`;
                    window.location.href = newref;
                }
            } else if(me().insideIframe){
                ref.iframeplaceholder.firstChild.contentWindow.focus();
            }
            ref.chat.blur();
            ref.chat.value = '';
            return;
        } else if (event.type === 'keydown') {
            chatOpen = true;
            ref.chatDiv.classList.remove('hidden');
            ref.chat.focus();
            return;
        }
    }
    if (chatOpen) return;
    if (me().isTyping && !me().dead && event.type == 'keydown') {
        if (me().input.typing == undefined) me().input.typing = [];
        me().input.typing.push(event.key);
        return;
    }
    if (Controls[event.code] != undefined) {
        if(window.lockedInput[Controls[event.code].key]) return event.preventDefault();
        if (window.dimensions === 3 && event.code.startsWith('Arrow')) {
            let cameraInput = 'c' + Controls[event.code].key;
            input[cameraInput] = event.type === 'keydown';
        } else {
            input[Controls[event.code].key] = event.type === 'keydown';
        }
        event.preventDefault();
    }
    if (event.code === 'Escape' && event.type === 'keydown') {
        ref.editorFrame.classList.toggle('hidden');
        if (!ref.editorFrame.classList.contains('hidden')) {
            ref.editorFrame.focus();
        }
    }
    if (event.code === 'KeyB' && event.type === 'keydown') {
        //console.log('toggling chat..')
        ref.chat.blur();
        if (ref.chatMessageDiv.classList.contains('hidden')) {
            ref.chatMessageDiv.classList.remove('hidden');
        } else {
            ref.chatMessageDiv.classList.add('hidden');
        }
        ref.chatMessageDiv.scrollTop = ref.chatMessageDiv.scrollHeight;
    }
	if (event.code === 'KeyF' && event.type === 'keydown') {
		window.canvasText = !window.canvasText;
		ref.textLayer.innerHTML = ''
	}
    if (event.code === 'KeyZ' && event.type === 'keydown') {
        if (!zenMode) {
            ref.chat.blur();
            if (!ref.chatMessageDiv.classList.contains('hidden')) {
                ref.chatMessageDiv.classList.add('hidden');
            }
            if (!ref.lb.classList.contains('hide')) {
                ref.lb.classList.add('hide');
            }
        } else {
            if (ref.chatMessageDiv.classList.contains('hidden')) {
                ref.chatMessageDiv.classList.remove('hidden');
                ref.chatMessageDiv.scrollTop = ref.chatMessageDiv.scrollHeight;
            }
            if (ref.lb.classList.contains('hide')) {
                ref.lb.classList.remove('hide');
            }
        }
        zenMode = !zenMode;
    }
    if (event.code === 'KeyL' && event.type === 'keydown') {
        console.log('toggling leaderboard...');
        ref.lb.classList.toggle('hide');
        // if (ref.lb.classList.contains('hidden')) {
        // 	ref.lb.classList.remove('hidden');
        // } else {
        // 	ref.lb.classList.add('hidden')
        // }
    }
    if (event.code === 'Digit1' && event.type === 'keydown') {
        window.firstPointX =
            Math.round((window.mouse.x + me().x) / snapDistance) *
                snapDistance -
            1600 / 2; //Math.round(me().x/25)*25;
        window.firstPointY =
            Math.round((window.mouse.y + me().y) / snapDistance) *
                snapDistance -
            900 / 2; //Math.round(me().y/25)*25;
    }
    if (event.code === 'KeyM' && event.type === 'keydown') {
        showMinimap = !showMinimap;
    }
    if (event.code === 'Digit2' && event.type === 'keydown') {
        //{"x":1100,"y":5000,"w":200,"h":10,"type":"rotate-lava"}
        // well this is what i do in darrows-eidotr
        // hmm that looks like something in game.js
        window.secondPointX =
            Math.round((window.mouse.x + me().x) / snapDistance) *
                snapDistance -
            1600 / 2 -
            window.firstPointX; //Math.round((me().x-window.firstPointX)/25)*25;
        window.secondPointY =
            Math.round((window.mouse.y + me().y) / snapDistance) *
                snapDistance -
            900 / 2 -
            window.firstPointY; //Math.round((me().y-window.firstPointY)/25)*25;
        if (window.secondPointX < 0) {
            window.firstPointX += window.secondPointX;
            window.secondPointX *= -1;
        }
        if (window.secondPointY < 0) {
            window.firstPointY += window.secondPointY;
            window.secondPointY *= -1;
        }

        if (
            window.secondPointX != 0 &&
            window.secondPointY != 0 &&
            window.firstPointX != undefined &&
            window.firstPointY != undefined &&
            window.secondPointX != undefined &&
            window.secondPointY !=
                undefined /* && window.obsType.type !== undefined*/
        ) {
            if (Array.isArray(window.obsType)) {
                for (let o in window.obsType) {
                    let base = {
                        x: window.firstPointX,
                        y: window.firstPointY,
                        w: window.secondPointX,
                        h: window.secondPointY,
                    };

                    const toAdd = Object.assign({}, base, window.obsType[o]);
                    if (
                        toAdd.type == 'rotate-lava' &&
                        toAdd.pivotX === undefined
                    ) {
                        toAdd.pivotX = base.x;
                        toAdd.pivotY = base.y;
                    }
                    console.log(toAdd);

                    send({
                        add: toAdd,
                    });
                }
            } else {
                let base = {
                    x: window.firstPointX,
                    y: window.firstPointY,
                    w: window.secondPointX,
                    h: window.secondPointY,
                };

                //console.log(window.obsType);

                const toAdd = Object.assign({}, base, window.obsType);
                console.log(toAdd);

                send({
                    add: toAdd,
                });
            }
        }
        // copying to clipboard
        var cpy = document.createElement('textarea');
        let obsString = window.obstacles;
        for (let i in obsString) {
            delete obsString[i].sat;
            if (obsString[i].collected == true) {
                obsString[i].collected = false;
            }
            /*if(obsString[i].angle !== undefined && obsString[i].angle !== null){
                obsString[i].angle = 0;
            }*/
        }
        cpy.value = JSON.stringify(obsString);
        cpy.setAttribute('readonly', '');
        cpy.style = { position: 'absolute', left: '-9999px' };
        document.body.appendChild(cpy);
        cpy.select();
        document.execCommand('copy');
        document.body.removeChild(cpy);
        window.firstPointX = undefined;
        window.firstPointY = undefined;
    }
    // if(event.code === 'KeyZ' && event.type === 'keydown'){
    //     send({
    //         delete: true,
    //     });
    // }
    if (event.code === 'KeyT' && event.type === 'keydown') {
        showTimer = !showTimer;
    }
    // if (event.code === 'KeyE' && event.type === 'keydown') {
    //     if (Object.keys(states).length > 0) {
    //         const state = states[Object.keys(states)[0]];
    //         setObjToNext(me(), state.player);
    //         obstacles = state.obstacles;
    //         const initStateTick = Number(Object.keys(states)[0]);
    //         const simTickTime = simTick - initStateTick;
    //         const currentInput = { ...input };
    //         let nowTick = simTick;
    //         simTick = initStateTick;
    //         // let tick = nowTick - simTickTime;
    //         while (simTick < nowTick) {
    //             // input = { ...states[simTick].input };
    //             // console.log(input.up, simTick);
    //             // let tick = simTick;
    //             runPhysics(1000 / 120);
    //             // console.log('updated by', simTick - tick);
    //         }
    //         // simTick -= simTickTime;
    //         input = { ...currentInput };
    //     }
    // }
    if (event.code === 'KeyO' && event.type === 'keydown') {
        send({ chat: '/god' });
    }
    if (event.key == 'Shift') {
        input.shift = event.type === 'keydown';
        event.preventDefault();
    }
    if (event.code === 'KeyX' && event.type === 'keydown') {
        showServer = !showServer;
    }

    if (event.code === 'KeyU' && event.type === 'keydown') {
        showPos = !showPos;
    }

    if (event.code === 'KeyQ' && event.type === 'keydown') {
        if(window.markers.length === 0){
            window.markersFirst = performance.now(); 
        }
        const directionChoices = ['down','left','right','up'];
        const randomDirection = directionChoices[Math.floor(Math.random()*directionChoices.length)];
        //direction, time, speed
        const dt = performance.now()-window.markersFirst;
        window.markers.push(/*[me().x,me().y]*/[randomDirection, Math.round(dt)/1000, 320]);
        console.log(window.markers);
    }

    if (
        event.code === 'KeyR' &&
        connected &&
        me().dead &&
        event.type === 'keydown'
    ) {
        if (me().powerups.rev && me().powerups.rev > 0) {
            me().dead = false;
            me().powerups.rev--;
            send({ powerups: me().powerups });
        } else {
            send({ respawn: true });
        }
    }

    if (event.code === 'KeyN' && event.type === 'keydown') {
        debugMode = !debugMode;
    }
    if (event.code === 'KeyJ' && event.type === 'keydown') {
        const oldref = window.location.href;
        const newref = `https://evade.zerotix.repl.co/?name=${me().name}`;
        window.location.href = newref;
    }

    if (event.code === 'KeyG' && event.type === 'keydown') {
        window.showGrid = !window.showGrid;
    }
}
