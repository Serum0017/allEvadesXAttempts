const sw = new Audio();
sw.src = '/sounds/swoosh.mp3';
sw.loop = false;
sw.volume = 1;
window.audios = {};
window.globalVolume = 0.7;
window.bg = undefined;
window.hubMusicPath = '/sounds/ultimate-battle.mp3'; //'/sounds/coffee-shop.mp3'
window.buttonPath = '/sounds/mouse click.mp3';
window.bonusPath = '/sounds/skill_point.mp3';
window.naniPath = '/sounds/!.mp3';

window.loadAudio = function (
    path,
    delay = 0,
    volume = globalVolume,
    name = '', loop = true,
) {
    if (audios[path] != undefined) return;
    const audio = new Audio();
    audio.src = path;
    // audio.crossOrigin = 'anonymous';
    audio._initDelay = delay;
    audio.playbackRate = 1;
    audio.volume = volume;
    audio._path = path;
    audio.currentTime = delay;
    audio.loop = loop;
    audio._name = name;
    console.log('loading..', path);
    audio.load();
    audios[path] = audio;
};
window.changeMusic = function (
    path,
    delay = 0,
    volume = globalVolume,
    name = ''
) {
    if (bg && bg._path != path) {
        bg.pause();
        bg.currentTime = bg._initDelay;
    }
    if (audios[path] != undefined) {
        console.log('audio already loaded..', path);
        bg = audios[path];
        bg.currentTime = delay;
        bg.play();
        return;
    }
    console.log('creating new audio...', path);
    const audio = new Audio();
    // audio.crossOrigin = 'anonymous';
    audio.src = path;
    audio.currentTime = delay;
    audio.loop = true;
    audio._name = name;
    audio._initDelay = delay;
    audio.playbackRate = 1;
    audio._path = path;
    audio.volume = volume;
    audios[path] = audio;
    bg = audios[path];
    bg.play();
};
window.playAudio = function(path, delay = 0, volume = globalVolume, name='') {
	if (audios[path] != undefined) {
		if (!audios[path].AudioPlaying) {
			audios[path].currentTime = delay;
			audios[path].play();
			audios[path].AudioPlaying = true;
			audios[path].addEventListener('ended', () => {
				audios[path].AudioPlaying = false;
			})
		} else {
			const newAudio = audios[path].cloneNode();
            newAudio.volume = volume;
			newAudio.currentTime = delay;
			newAudio.play();
			newAudio.addEventListener('ended', () => {
				delete newAudio;
			})
		}
		return;
	}
	console.log('cant play audio: ', path, ': audio must be loaded beforehand')
}
// hmm if ur adding anything else to this list maybe we should
// make like an audio system per map that checks if the obs are
// there and then loads
// 
// there's some commented code in game.js
// setTimeout((event) => {
//     loadAudio('/pings/ping.mp3', 0, 1, 'Ping', false);
//     loadAudio(hubMusicPath, 0, 0.7, 'Ultimate Battle');
//     loadAudio(bonusPath, 0, 0.035, 'Skill Point', false);
//     loadAudio(naniPath, 0, 0.3, 'nani', false);
//     loadAudio(buttonPath, 0, 1, 'Button click', false);
// },300)
window.addEventListener('load', () => {
    console.log('assets loaded in', Math.round(window.performance.now()), 'ms');
    loadAudio('/pings/ping.mp3', 0, 1, 'Ping', false);
    loadAudio(hubMusicPath,     0, 0.7, 'Ultimate Battle');
    loadAudio(bonusPath, 0, 0.035, 'Skill Point', false);
    loadAudio(naniPath, 0, 0.3, 'nani', false);
    loadAudio(buttonPath, 0, 1, 'Button click', false);
})


let inPoUC = false;
let insidePlatformer = false;
let insideCircleSnap = false;
let insideGolf = false;
let insideFrictionChanger = false;
let onHole = false;
let touchingNormal = false;

// window.runPlayerTagged = function (player, players, dt) {
//     if (player.tagCooldown === undefined) {
//         player.tagCooldown = 1;
//     }
//     player.tagCooldown -= dt;
//     if (player.tagCooldown < 0) {
//         for (let i in players) {
//             if (i != player.id) {
//                 let dist = Math.sqrt(
//                     (player.x - players[i].x) ** 2 +
//                         (player.y - players[i].y) ** 2
//                 );
//                 if (dist < player.radius + players[i].radius) {
//                     player.tagged = false;
//                     players[i].tagged = true;
//                     player.tagCooldown = undefined;
//                     send({ tag: false, id: player.id });
//                     send({ tag: true, id: i });
//                     break;
//                 }
//             }
//         }
//     }
// };

window.bouncePlayers = function (p1, p2, effect = 30) {
    const distX = p1.x - p2.x;
    const distY = p1.y - p2.y;
    const magnitude = Math.sqrt(distX * distX + distY * distY) || 1;
    const normal = { x: distX / magnitude, y: distY / magnitude };
    const angle = Math.atan2(normal.y, normal.x);
    p1.xv = Math.cos(angle) * effect;
    p1.yv = Math.sin(angle) * effect;
    p1.x = p2.x + (p1.radius + p2.radius) * normal.x;
    p1.y = p2.y + (p1.radius + p2.radius) * normal.y;
};

function deepCopy(object){
    let deepObj = JSON.parse(JSON.stringify(object));
    let otherFunctions = getAllMethodNames(object);
    // dynamically getting all functions (including helper functions)
    for(let otherfunc of otherFunctions){
        if(!["constructor","__defineGetter__","__defineSetter__","hasOwnProperty","__lookupGetter__","__lookupSetter__","isPrototypeOf","propertyIsEnumerable","toString","valueOf","__proto__","toLocaleString"].includes(otherfunc)){
            deepObj[otherfunc] = object[otherfunc];
        }
    }
    return deepObj;
}

function getAllMethodNames(obj) {
    let methods = [];
    while (obj = Reflect.getPrototypeOf(obj)) {
        let keys = Reflect.ownKeys(obj)
        keys.forEach((k) => methods.push(k));
    }
    return methods;
}

window.interpolateDirection = function (d1, d2, angleIncrement) {
    let dir;
    let dif = d1 - d2;
    let angleDif = Math.atan2(Math.sin(dif), Math.cos(dif));
    if (Math.abs(angleDif) >= angleIncrement) {
        if (angleDif < 0) {
            dir = 1;
        } else {
            dir = -1;
        }
    } else {
        dir = 0;
    }
    return d1 + dir * angleIncrement * Math.min(3, Math.abs(angleDif));
};

// thank u animale :D
// window.interpolateLinearDirection = function (d1, d2, angleIncrement) {
//     let dir;
//     let dif = d1 - d2;
//     let angleDif = Math.atan2(Math.sin(dif), Math.cos(dif));
//     if (Math.abs(angleDif) >= angleIncrement) {
//         if (angleDif < 0) {
//             dir = 1;
//         } else {
//             dir = -1;
//         }
//     } else {
//         dir = 0;
//     }
//     return d1 + dir * angleIncrement;
// };

// caching so that we don't have to run the switch statement every frame
// bascially we're gonna have an object w/ type object + array of pointers
// so that we don't have to run expensive switch statements every frame
// I tested this and it was around 1000ms for old ver and 400 for this
function sortObstacles(obstacles) {
    // rendering
    const renderTypes = {
        'renderrotating': 'rotating',
        'rotate-pause-lava': 'rotating',
        'rotate-lava': 'rotating',
        'rotate-normal': 'rotating',
        'rotate-pause': 'rotating',
        'rotate-tp': 'rotating',
        'rotate-safe': 'rotating',
        'rotatingspeedtrap': 'rotating',

        'circle-bonus':'circle',
        'circle-bounce':'circle',
        'camera':'circle',
        'circle-normal':'circle',
        'circle-hollow':'circle',
        'circle-coin':'circle',
        'circle-slice':'circle',
        'circle-hollow-slice':'circle',
        'circlesnap':'circle',
        'circle-door':'circle',
        'circle-hollow-slice-lava':'circle',
        'circle-slice-lava':'circle',
        'circle-hollow-lava':'circle',
        'circle-hollow-slice-enemywall':'circle',
        'circle-hollow-slice-enemytp':'circle',
        
        // circles that have .r and not .radius
        'growingcircle':'circleR',
        'growinglavacircle':'circleR',
        'circle-lava':'circleR',
        'circle-safe':'circleR',
        'circle-tp':'circleR',
        'circularpushbox':'circleR',

        'circle-sentry':'circleSentry',
        'circle-turret-sentry':'circleTurretSentry',

        'oval':'oval',
        'lava-oval':'oval',
        'demo':'demo',
        'grapplepoint':'grapple',
        'movinggrapplepoint':'grapple',
        'spring':'spring'
    };
    
    window.sortedObstacles = {};
    for (let i = 0; i < obstacles.length; i++) {
        let objtype = obstacles[i].type;
        if (window.sortedObstacles[objtype] === undefined) {
            window.sortedObstacles[objtype] = [];
        }
        window.sortedObstacles[objtype].push(obstacles[i]);

        if(renderTypes[obstacles[i].type] !== undefined){
            obstacles[i].renderType = renderTypes[obstacles[i].type];
        }
        
        
        if(obstacles[i].type.startsWith('poly') || obstacles[i].type === 'bezier'){
            if(obstacles[i].type === 'bezier'){
                obstacles[i].points = obstacles[i].polygon.points;
            }
            obstacles[i].most = {};
            obstacles[i].most.left = Infinity;
            obstacles[i].most.right = -Infinity;
            obstacles[i].most.top = Infinity;
            obstacles[i].most.bottom = -Infinity;
            for (const pos of obstacles[i].points) {
                if (pos[0] < obstacles[i].most.left) {
                    obstacles[i].most.left = pos[0];
                }
                if (pos[0] > obstacles[i].most.right) {
                    obstacles[i].most.right = pos[0];
                }
                if (pos[1] < obstacles[i].most.top) {
                    obstacles[i].most.top = pos[1];
                }
                if (pos[1] > obstacles[i].most.bottom) {
                    obstacles[i].most.bottom = pos[1];
                }
            }
            obstacles[i].renderType = 'poly';
        } else if(obstacles[i].type.startsWith('rotat')){
            obstacles[i].cullingRadius = Math.sqrt(obstacles[i].w**2+obstacles[i].h**2)/2 + obstacles[i].distToPivot;
        }
    }

    for(let i = 0; i < portals.length; i++){
        portals[i].renderType = 'portal';
    }
    
    window.sortedObstacles['rotating'] = [].concat(
        (sortedObstacles['rotate-normal']??[]),
        (sortedObstacles['rotate-tp']??[]),
        (sortedObstacles['rotate-lava']??[]),
        (sortedObstacles['rotatingsafe']??[]),
        (sortedObstacles['rotatingspeedtrap']??[]),
    )
    window.sortedObstacles['rotatepause'] = [].concat(
        (sortedObstacles['rotate-pause']??[]),
        (sortedObstacles['rotate-pause-lava']??[]),
    )
    window.sortedObstacles['moving'] = [].concat(
        (sortedObstacles['move']??[]),
        (sortedObstacles['lavamove']??[]),
        (sortedObstacles['tpmove']??[]),
        (sortedObstacles['movingsafe']??[]),
        (sortedObstacles['deadpusher']??[]),
        (sortedObstacles['movinggrapplepoint']??[]),
    )
    window.sortedObstacles['movepause'] = [].concat(
        (sortedObstacles['move-pause']??[]),
        (sortedObstacles['move-pause-lava']??[]),
    )
    window.sortedObstacles['switch'] = [].concat(
        (sortedObstacles['switchnormal']??[]),
        (sortedObstacles['switchlava']??[]),
    )
    window.sortedObstacles['grow'] = [].concat(
        (sortedObstacles['growing']??[]),
        (sortedObstacles['growinglava']??[]),
    )
    window.sortedObstacles['growcircle'] = [].concat(
        (sortedObstacles['growingcircle']??[]),
        (sortedObstacles['growinglavacircle']??[]),
    )
    window.sortedObstacles['morphmoving'] = [].concat(
        (sortedObstacles['morphmove']??[]),
        (sortedObstacles['morphlavamove']??[]),
    )
    window.sortedObstacles['circlehollowslice'] = [].concat(
        (sortedObstacles['circle-hollow-slice']??[]),
        (sortedObstacles['circle-hollow-slice-lava']??[]),
    )

    const movings = [].concat(
        (sortedObstacles.moving??[]),
        (sortedObstacles.movingspeedtrap??[]),
        (sortedObstacles.morphmoving??[])
    );
    for (let i = 0; i < movings.length; i++){
        const obs = movings[i];
        let pointOn = obs.points[obs.currentPoint];
        obs.pointOn = {x: pointOn[0], y: pointOn[1]};
        
        let nextPointIndex = obs.currentPoint + 1;
        if (nextPointIndex >= obs.points.length) {
            nextPointIndex = 0;
        }
        
        let nextPoint = obs.points[nextPointIndex];
        obs.pointTo = { x: nextPoint[0], y: nextPoint[1] };
        let angle = Math.atan2(obs.pointTo.y - obs.pointOn.y, obs.pointTo.x - obs.pointOn.x);
        obs.xv = Math.cos(angle) * obs.speed;
        obs.yv = Math.sin(angle) * obs.speed;
    }

    for (let o = 0; o < (window.sortedObstacles['circle-turret-sentry']??[]).length; o++){
        obstacles[o].bullets = [];
        obstacles[o].deadBullets = [];
        obstacles[o].range = obstacles[o].bulletSpeed*obstacles[o].bulletLife+obstacles[o].bulletRadius;
        obstacles[o].timer = obstacles[o].shootSpeed;
    }

    // collision groups
    window.sortedObstacles['square'] = [].concat(
        (sortedObstacles['normal']??[]),
        (sortedObstacles['trans']??[]),
        (sortedObstacles['push']??[]),
        (sortedObstacles['wb']??[]),
        (sortedObstacles['spring']??[]),
        (sortedObstacles['bounce']??[]),
        (sortedObstacles['lava']??[]),
        (sortedObstacles['lavamove']??[]),
        (sortedObstacles['morphlavamove']??[]),
        (sortedObstacles['move']??[]),
        (sortedObstacles['move-pause']??[]),
        (sortedObstacles['move-pause-lava']??[]),
        (sortedObstacles['wallboost']??[]),
        (sortedObstacles['growing']??[]),
        (sortedObstacles['growinglava']??[]),
        (sortedObstacles['morphmove']??[]),
    )
    
    window.sortedObstacles['doors'] = [].concat(
        (sortedObstacles['lavadoor']??[]),
        (sortedObstacles['door']??[]),
    )

    window.sortedObstacles['circles'] = [].concat(
        (sortedObstacles['circle-normal']??[]),
        (sortedObstacles['circle-bounce']??[]),
        (sortedObstacles['circle-lava']??[]),
        (sortedObstacles['circle-safe']??[]),
        (sortedObstacles['growingcircle']??[]),
        (sortedObstacles['growinglavacircle']??[]),
        (sortedObstacles['circle-tp']??[]),
        (sortedObstacles['circle-hollow']??[]),
        (sortedObstacles['circle-door']??[]),
        (sortedObstacles['circle-slice']??[]),
        (sortedObstacles['circle-hollow-slice']??[]),
        (sortedObstacles['camera']??[]),
        (sortedObstacles['circle-hollow-lava']??[]),
        (sortedObstacles['circle-slice-lava']??[]),
        (sortedObstacles['circle-hollow-slice-lava']??[]),
    )
    
    window.sortedObstacles['polys'] = [].concat(
        (sortedObstacles['poly']??[]),
        (sortedObstacles['poly-lava']??[]),
        (sortedObstacles['poly-safe']??[]),
        (sortedObstacles['poly-rail']??[]),
        (sortedObstacles['poly-tp']??[]),
        (sortedObstacles['poly-bounce']??[]),
        (sortedObstacles['poly-breakable']??[]),
        (sortedObstacles['poly-bouncy-breakable']??[]),
        (sortedObstacles['poly-wb']??[]),
    )

    window.sortedObstacles['ovals'] = [].concat(
        (sortedObstacles['oval']??[]),
        (sortedObstacles['lava-oval']??[]),
    )

    window.sortedObstacles['tps'] = [].concat(
        (sortedObstacles['tp']??[]),
        (sortedObstacles['tpmove']??[]),
    )

    window.sortedObstacles['safecollisions'] = [].concat(
        (sortedObstacles['movingsafe']??[]),
        (sortedObstacles['revive']??[]),
    )

    // portals
    window.sortedObstacles['portal'] = portals;
}

function normalizeDist(x) {
    if (x > 0) {
        return 1;
    } else if (x == 0) {
        return 0;
    } else {
        return -1;
    }
}

function getMag({ x, y }) {
    return Math.sqrt(x * x + y * y);
}

function getNormal({ x, y }) {
    const mag = getMag({ x, y });
    if (mag > 0) {
        return { x: x / mag, y: y / mag };
    }
    return 0;
}

function interpolateMopeDirection(d1, d2, angleIncrement) {
    let dir;
    let dif = d1 - d2;
    let angleDif = Math.atan2(Math.sin(dif), Math.cos(dif));
    if (Math.abs(angleDif) >= angleIncrement) {
        if (angleDif < 0) {
            dir = 1;
        } else {
            dir = -1;
        }
    } else {
        dir = 0;
    }
    return (
        d1 +
        dir * angleIncrement * clamp(0, 10000, Math.abs(angleDif) ** 0.6 * 0.55)
    );
}

window.runDragonCollision = function (players, dt, player) {
    if (!player.bitecooldown) {
        player.bitecooldown = 0;
    }
    player.bitecooldown -= dt;
    // simulating movement
    for (let i in players) {
        if (players[i].id == player.id) continue;
        if (player.bitecooldown < 0 && checkTailbite(player, players[i])) {
            player.bitecooldown = 2;
            // broadcast tailbite
            send({ tailbite: true, id: i });
        }
    }
};

function clamp(min, max, x) {
    return Math.min(max, Math.max(min, x));
}

function checkTailbite(p1, p2) {
    // 4 tests
    // p1 is trying to bite p2
    // test 1 - are they colliding?

    /*let ptail = {
        x: p2.x - p2.renderRadius * Math.sin(p2.powerups.dragon.angle),
        y: p2.y + p2.renderRadius * Math.cos(p2.powerups.dragon.angle)
    }
    let tep = {
        x: p1.x + p1.renderRadius*2 * Math.sin(p1.powerups.dragon.angle),
        y: p1.y - p1.renderRadius*2 * Math.cos(p1.powerups.dragon.angle)
    };
    let a = Math.atan2(ptail.y-p1.y,ptail.x-p1.x)-Math.PI/2;
    p1.testPlayer = tep;
    p1.dtailangle = a;*/

    if (
        Math.sqrt((p1.x - p2.x) ** 2 + (p1.y - p2.y) ** 2) >
        p1.radius + p2.radius
    ) {
        return false;
    }
    // test 2 - is p2 in front of p1?
    let tp = {
        x: p1.x + p1.renderRadius * 2.1 * Math.sin(p1.powerups.dragon.angle),
        y: p1.y - p1.renderRadius * 2.1 * Math.cos(p1.powerups.dragon.angle),
    };
    // checking if the testPlayer is colliding with p2
    if (
        Math.sqrt((tp.x - p2.x) ** 2 + (tp.y - p2.y) ** 2) >
        p1.radius + p2.radius
    ) {
        return false;
    }
    // test 3 - is the biter pointing towards others tail?
    let p2tail = {
        x: p2.x - p2.renderRadius * Math.sin(p2.powerups.dragon.angle),
        y: p2.y + p2.renderRadius * Math.cos(p2.powerups.dragon.angle),
    };
    let angle = Math.atan2(p2tail.y - p1.y, p2tail.x - p1.x) - Math.PI / 2;
    if (
        Math.min(
            angle - p1.powerups.dragon.angle,
            Math.PI * 2 - (angle - p1.powerups.dragon.angle)
        ) >
        (22 * Math.PI) / 180
    ) {
        return false;
    }
    // test 3.5: also check for middle
    p2tail = {
        x: p2.x,
        y: p2.y,
    };
    angle = Math.atan2(p2tail.y - p1.y, p2tail.x - p1.x) - Math.PI / 2;
    if (
        Math.min(
            angle - p1.powerups.dragon.angle,
            Math.PI * 2 - (angle - p1.powerups.dragon.angle)
        ) >
        (20 * Math.PI) / 180
    ) {
        return false;
    }
    // test 4 - are the 2 players facing roughly the same angle?
    let angleDif = findAngleDifference(
        p1.powerups.dragon.angle,
        p2.powerups.dragon.angle
    );
    if (Math.abs(angleDif) < (16 * Math.PI) / 180) {
        return true;
    }
    return false;
}

window.simulateOtherBullets = function (players, dt, enemy, player) {
    for (let i in players) {
        if (players[i].id !== selfId) {
            players[i].bullets.forEach((bullet, index) => {
                bullet.life -= dt;
                if (bullet.life < 0) {
                    players[i].bullets.splice(index, 1); // btw u should also apply it to all players bullets befcfause this is just other bullets :>
                }
                bullet.x += dt * bullet.speed * Math.cos(bullet.angle);
                if (bullet.type === 'pvp') {
                    if (bullet.x + bullet.radius >= 1000) {
                        bullet.x = 1000 * 2 - bullet.x - bullet.radius * 2;
                        bullet.angle = Math.atan2(
                            Math.sin(bullet.angle),
                            -Math.cos(bullet.angle)
                        );
                    } else if (bullet.x - bullet.radius <= 0) {
                        bullet.x = 0 * 2 - bullet.x + bullet.radius * 2;
                        bullet.angle = Math.atan2(
                            Math.sin(bullet.angle),
                            -Math.cos(bullet.angle)
                        );
                    }
                }
                bullet.y += dt * bullet.speed * Math.sin(bullet.angle);
                if (bullet.type === 'pvp') {
                    if (bullet.y + bullet.radius >= 1000) {
                        bullet.y = 1000 * 2 - bullet.y - bullet.radius * 2;
                        bullet.angle = Math.atan2(
                            -Math.sin(bullet.angle),
                            Math.cos(bullet.angle)
                        );
                    } else if (bullet.y - bullet.radius <= 0) {
                        bullet.y = 0 * 2 - bullet.y + bullet.radius * 2;
                        bullet.angle = Math.atan2(
                            -Math.sin(bullet.angle),
                            Math.cos(bullet.angle)
                        );
                    }
                }
                // imma just cop ypaste this code over to server xD
                //?
                // ye i added && bullet.type
                // me fix >:)
                // this is where u kill player, right?
                // didnt see lol ;c
                if (
                    intersectingCircle(bullet, player) &&
                    bullet.type === 'pvp'
                ) {
                    player.dead = true;
                    player.powerups.gun.state = false;
                    player.bullets = [];
                    send({ dead: true });
                    send({ powerups: player.powerups });
                    send({ bullets: player.bullets });
                }
                for (let i in enemy) {
                    const ene = enemy[i];
                    if (intersectingCircle(bullet, ene)) {
                        if (bullet.type === 'normal') {
                            enemy[i].deadTimer = 3;
                        } else if (bullet.type === 'push') {
                            boundPlayerCircularObstacle(ene, bullet);
                        } else if (bullet.type === 'stun') {
                            enemy[i].stopTimer = 3;
                        }
                    }
                }
            });
        }
    }
};

const buttonSounds = {};
window.triggerButtonEffects = function (id, obstacles) {
    // button audio
	playAudio(buttonPath, 0.05);
    
    for (let i in obstacles) {
        // lol optimizing obstacles[i] is 1%
        // finished first zone of my map

        const obs = obstacles[i]; // nicee try it out in game >:D
        const obstype = obs.type;
        if (obs.id == id) {
            // it just flips the state. there's nothing else that needs to be done
            /*if(obstype == 'button'){
                obstacles[i].active = false;// lol this is 
            }*/ if (
                obstype == 'door' ||
                obstype == 'circle-door' ||
                obstype == 'lavadoor'
            ) {
                obstacles[i].active = !obs.active;
            }
        }
    }
};

window.triggerMorphEffects = function (id, obstacles) {
	for (const i in obstacles) {
		const obs = obstacles[i];
		if ((obs.type === 'morphnormal' || obs.type === 'morphmove' || obs.type === 'morphlavamove' || obs.type === 'morphbutton' /*buttons should always be in sync. Crucial for a part in poqt pls dont change*/) &&
			obs.morphId === id) {
            if(obs.type === 'morphbutton'){
                obs.timedObstacles = obs.maxTimedObstacles;
                obs.active = !obs.active;
                if(obs.active === false){
                    playAudio(buttonPath, 0.05);
                }
            } else {
                obs.active = !obs.active;
            }
		}
	}
}

// optimization
let obsNotToSimulate = {};//[/*'deadpusher', 'lava', 'switchlava', 'switch', 'pushbox', 'push', 'normal', 'trans', 'circle-normal', 'tp', 'rotate-lava', 'bounce', 'block', 'circle-bounce', 'circle-lava', 'circle-safe', 'check', 'move', 'story', 'lavamove', 'winpad', 'wb', 'rotate-tp', 'tpmove', 'rotate-normal', 'wallboost', 'growing', 'growinglava', 'growingcircle', 'growinglavacircle', 'circle-tp', 'color', 'movingsafe', 'rotatingsafe', 'rotatingspeedtrap', 'poly', 'musicchange', 'cookie', 'circle-hollow', 'door', 'circle-door', 'lavadoor', 'enemybutton', 'circle-slice', 'roundedcorners', 'roundedlava', 'circle-hollow-lava', 'circle-slice-lava', 'grapplepoint', 'bezier', 'rotate-pause', 'rotate-pause-lava', 'move-pause', 'move-pause-lava', 'movinggrapplepoint', 'oval', 'lava-oval', 'enemyeffect'*/];

window.runPlayerPhysics = function (
    player,
    arena,
    obstacles,
    input,
    dt,
    players,
    enemy,
    safes,
    npcs,
) { 
    if (window.resetMusic === true) {
        // exclusively so that /reset actually returns u to hub music
        window.resetMusic = false;
        changeMusic(hubMusicPath);
    }
    window.timers = [];
    window.hidePlayer = false;
    window.dt = dt;
    if (player.xv == undefined || player.yv == undefined) {
        player.xv = 0;
        player.yv = 0;
    }
    if (player.gxv == undefined || player.gyv == undefined) {
        player.gxv = 0;
        player.gyv = 0;
    }
    if (player.grav == undefined) {
        player.grav = { x: 0, y: 0 };
    }
    if (player.platgrav == undefined) {
        player.platgrav = { x: 0, y: 0 };
    }
    if (player.shiftTimer == undefined) {
        player.shiftTimer = 0;
    }
    if (player.coins === undefined) {
        player.coins = 0;
    }

    if (player.sat == undefined) {
        player.sat = new SAT.Circle(
            new SAT.Vector(player.x, player.y),
            player.radius
        );
    }

    if (input.shift) {
        player.shiftTimer += dt;
    } else {
        player.shiftTimer = 0;
    }

    if (player.deathTimer != undefined) {
        player.deathTimer -= dt;
        if (player.deathTimer <= 0) {
            // KILL PLAYER LMAO
            player.dead = true;
            send({ dead: true });
            player.deathTimer = undefined;
        }
    }

    // for tpplayer enemies
    if (player.tpTimer) {
        player.tpTimer -= dt;
    }

    player.input = input;
    let xspeed = (input.right - input.left) * player.speed;
    let yspeed = (input.down - input.up) * player.speed;
    window.mouseMode = useMouse && xspeed === 0 && yspeed === 0;
    if (!mouseMode && useMouse === true) {
        useMouse = false;
    }
    if (inPoUC && world === 'Hub') {
        inPoUC = false;
    }
    if (xspeed === 0 && yspeed === 0 && !inPoUC) {
        if (player.stillTimer == undefined) {
            player.stillTimer = 0;
        }
        player.stillTimer += dt;
        if (player.stillTimer > 1 && player.x == 2125.5 && player.y == 2674.5) {
            send({ world: 'PoUC' });

            // to prevent ship/ powerups in another world bug
            setTimeout(() => {
                send({powerups: player.powerups})
                send({ship: player.ship});
            }, 400)
            // if (bg.currentTime > 0) {
            //     bg.currentTime = 0;
            // }
            player.stillTimer = -Infinity;
            // bg.src = '/sounds/Tension.mp3';
            // bg.loop = false;
            // bg.loop = true;
            // bg.play();
            inPoUC = true;
        }
    } else if (xspeed !== 0 || yspeed !== 0) {
        // player.stillTimer = 0;
    }

    if (mouseMode) {
        const angle = Math.atan2(
            mouse.y - canvas.height / 2,
            mouse.x - canvas.width / 2
        );
        let dist = Math.sqrt(
            (mouse.x - canvas.width / 2) * (mouse.x - canvas.width / 2) +
                (mouse.y - canvas.height / 2) * (mouse.y - canvas.height / 2)
        );
        if (dist > 200) {
            dist = 200;
        }
        xspeed = ((Math.cos(angle) * player.speed * 1) / 200) * dist;
        yspeed = ((Math.sin(angle) * player.speed * 1) / 200) * dist;
    }

    if (player.speedMults.length > 0) {
        for (let i in player.speedMults) {
            xspeed *= player.speedMults[i];
            yspeed *= player.speedMults[i];
        }
        player.speedMults = [];
    }

    if (
        input.shift &&
        player.ship === false &&
        player.powerups.dragon.state === false
    ) {
        if (player.god) {
            xspeed *= 3;
            yspeed *= 3;
        } else {
            xspeed *= 0.6; // lol we should have a setting that makes shift have a user-controlled number between .4-.6
            yspeed *= 0.6;
        }
    }

    if (player.isTyping || player.insideIframe) {
        xspeed = 0;
        yspeed = 0;
        player.xv = 0;
        player.yv = 0;
        player.input.right = false;
        player.input.left = false;
        player.input.up = false;
        player.input.down = false;
    }

    // if (player.dead) {
    //     xspeed = 0;
    //     yspeed = 0;
    // }

    if (insideFrictionChanger === true) {
        player.fric = insideFrictionChanger;
        insideFrictionChanger = false;
    }

    if (insideGolf === true) {
        player.golfCooldown -= dt;
        if (
            (player.input.up ||
                player.input.right ||
                player.input.left ||
                player.input.down ||
                mouseMode) &&
            player.golfCooldown < 0
        ) {
            player.golfCooldown = 1;
            player.strokes++;
            if (mouseMode) {
                const angle = Math.atan2(
                    mouse.y - canvas.height / 2,
                    mouse.x - canvas.width / 2
                );
                player.golfangle = angle; //Math.round(angle/90)*90;
            } else {
                player.golfangle = Math.atan2(yspeed, xspeed);
            }
        }
        insideGolf = false;
    }
    

    if (player.arrows && player.arrows.length > 0) {
        player.arrows.forEach((arrow, i) => {
            arrow[1] -= dt; //time till u have to press
            if (arrow[1] < -0.15 && arrow[3] != false) {
                player.dead = true;
                player.arrows = [];
            } else if (arrow[1] <= 0.15) {
                let e = false;
                if (player.input.right && arrow[0] == 'right') {
                    e = true;
                } else if (player.input.left && arrow[0] == 'left') {
                    e = true;
                } else if (player.input.down && arrow[0] == 'down') {
                    e = true;
                } else if (player.input.up && arrow[0] == 'up') {
                    e = true;
                }
                if (e) {
                    arrow[3] = false; // active
                }
            }
        });
        player.arrowDt += dt;
    }

    if (player.ship !== false) {
        const lastshipangle = player.ship;
        if (player.ship > Math.PI * 2) {
            player.ship -= Math.PI * 2;
        } else if (player.ship < -Math.PI * 2) {
            player.ship += Math.PI * 2;
        }
        const turnSpeed = Math.PI;
        if (player.shipSpeedMult === undefined) {
            player.shipSpeedMult = 1;
        }
        if (mouseMode) {
            const angle =
                Math.atan2(
                    mouse.y - canvas.height / 2,
                    mouse.x - canvas.width / 2
                ) -
                Math.PI / 2;
            let interpDir = interpolateDirection(player.ship, angle, 0.02);
            if (interpDir != NaN) {
                player.ship = interpDir;
            }
            player.xv -=
                Math.cos(player.ship - Math.PI / 2) *
                dt *
                player.speed *
                player.shipSpeedMult;
            player.yv -=
                Math.sin(player.ship - Math.PI / 2) *
                dt *
                player.speed *
                player.shipSpeedMult;
        } else {
            // KB MODE
            if (xspeed < 0) {
                player.ship -= turnSpeed * dt;
            } else if (xspeed > 0) {
                player.ship += turnSpeed * dt;
            }
            player.xv +=
                Math.cos(player.ship - Math.PI / 2) *
                yspeed *
                player.shipSpeedMult *
                dt;
            player.yv +=
                Math.sin(player.ship - Math.PI / 2) *
                yspeed *
                player.shipSpeedMult *
                dt;
        }
        xspeed = 0;
        yspeed = 0;
        player.shipSpeedMult = 1;
        if (lastshipangle !== player.ship) send({ ship: Math.round(player.ship * 1000) / 1000 });
    }

    if (player.powerups.grapple.state === true && player.input.action === true) {
        if (player.powerups.grapple.grappling) {
            // we're already grappling; we just need to sim physics
            let grappleObs = obstacles[player.powerups.grapple.id];
            if (
                player.powerups.grapple.lastpos &&
                player.powerups.grapple.id != -1
            ) {
                if (player.powerups.grapple.lastpos.x != grappleObs.x) {
                    let dif = player.powerups.grapple.lastpos.x - grappleObs.x;
                    player.powerups.grapple.x -= dif;
                }
                if (player.powerups.grapple.lastpos.y != grappleObs.y) {
                    let dif = player.powerups.grapple.lastpos.y - grappleObs.y;
                    player.powerups.grapple.y -= dif;
                }
            }
            player.powerups.grapple.length = Math.sqrt(
                (player.powerups.grapple.x - player.x) ** 2 +
                    (player.powerups.grapple.y - player.y) ** 2
            );
            player.powerups.grapple.angle = Math.atan2(
                player.powerups.grapple.y - player.y,
                player.powerups.grapple.x - player.x
            );

            player.powerups.grapple.lastpos = {
                x: grappleObs.x,
                y: grappleObs.y,
            };
            // rotation forces
            // const playerDir = getNormal({ x: player.xv, y: player.yv });
            // const dirToGrapple = getNormal({ x: player.powerups.grapple.x - player.x, y: player.powerups.grapple.y - player.y });
            // const perp = { y: dirToGrapple.y + playerDir.y, x: dirToGrapple.x+playerDir.x};
            // const totalSpeed = getMag({ x: player.xv, y: player.yv });
            // const perpAngle = Math.atan2(-perp.y, perp.x);
            // player.gxv += Math.cos(perpAngle) * 5;
            // player.gyv += Math.sin(perpAngle) * 5;

            //grapple force
            player.gxv +=
                Math.cos(player.powerups.grapple.angle) *
                ((50 * player.powerups.grapple.length) / 375);
            player.gyv +=
                Math.sin(player.powerups.grapple.angle) *
                ((50 * player.powerups.grapple.length) / 375); // actually lemme tri 300
        } else {
            // initialize grapple
            // attempting to find nearest grap point
            let minDistance = 244; // starting min dist
            let minPriorityDistance = 244;
            let angle = 0;
            let priorityangle = 0;
            let id = 0;
            let priorityId = 0;
            for (let i = 0; i < obstacles.length; i++) {
                const obs = obstacles[i];
                const obj = obs; // lol
                const objtype = obs.type;
                if (
                    !(
                        objtype === 'normal' ||
                        objtype === 'oval' ||
                        objtype === 'lava-oval' ||
                        objtype === 'trans' ||
                        objtype === 'push' ||
                        objtype === 'wb' ||
                        objtype === 'spring' ||
                        objtype === 'bounce' ||
                        objtype === 'lava' ||
                        objtype === 'lavamove' ||
                        objtype === 'deadpusher' ||
                        objtype === 'move' ||
                        objtype === 'move-pause' ||
                        objtype === 'move-pause-lava' ||
                        objtype === 'wallboost' ||
                        (objtype === 'door' && obj.active) ||
                        (objtype === 'lavadoor' && obj.active) ||
                        objtype === 'growing' ||
						(objtype === 'morphnormal' && !obj.active) ||
                        objtype === 'growinglava' ||
                        ((objtype === 'breakable' || objtype === 'bouncybreakable') && obj.currentStrength > 0) ||
                        (objtype === 'switchobstacle' && obj.state) ||
                        (objtype === 'switchlava' &&
                            obj.state &&
                            obj.collidable) ||
                        (objtype === 'switchnormal' && obj.state) ||
                        (objtype === 'coindoor' && obj.currentCoins > 0) ||
                        (objtype === 'custom' && obj.collidable != false) ||
                        (objtype === 'cookie' &&
                            (getCookie(obj.cookie) !== obj.value ||
                                (obj.value == 'any' &&
                                    getCookie(obj.cookie == '')))) ||
                        ((obj.type.startsWith('circle') ||
                            (!player.usingCamera && objtype === 'camera') ||
                            objtype === 'growingcircle' ||
                            objtype === 'grapplepoint' ||
                            objtype === 'bezier' ||
                            objtype === 'movinggrapplepoint' ||
                            objtype === 'growinglavacircle') &&
                            objtype != 'circle-coin' && objtype != 'circle-bonus') ||
                        objtype.startsWith('poly')
                    )
                ) {
                    continue;
                }
                if(obs.inView === false){
                    continue;
                }
                let dist = 244;
                let prioritydist = 244;
                let thispriority = 0;
                let thisid = i;
                let pangle;
                if (obs.w && obs.h) {
                    // checking if there is a collision
                    const intersection = returnIntersectingCircleRect(
                        { x: player.x, y: player.y, radius: minDistance },
                        obs,
                        true
                    );
                    if (intersection === false) {
                        continue;
                    } else {
                        // find the point by getting the overlap v and taking
                        // the inverse of that with respect to the minDistance
                        dist =
                            minDistance -
                            Math.sqrt(
                                intersection.overlapV.x ** 2 +
                                    intersection.overlapV.y ** 2
                            );
                        pangle =
                            (Math.atan2(
                                intersection.overlapN.y,
                                intersection.overlapN.x
                            ) -
                                Math.PI) %
                            (Math.PI * 2);
                    }
                } /*else if(objtype === 'oval' || objtype === 'lava-oval'){
                    let cp = findClosestPointOvalCircle({x: player.x, y: player.y, radius: minDistance},obs);
                    if(cp){
                        dist = Math.sqrt((player.x-cp.x)**2+(player.y-cp.y)**2);
                        pangle = Math.atan2(player.y-cp.y,player.x-cp.x)%(Math.PI*2);
                    }
                }*/ else if (
                    (obs.radius || obs.r) &&
                    !obs.startAngle &&
                    !obs.innerRadius
                ) {
                    // "culling" far away objects bc math.sin and cos are relatively slow
                    const r = obs.radius || obs.r;
                    if (
                        (Math.abs(obs.x - player.x) > 300 ||
                            Math.abs(obs.y - player.y) > 300) &&
                        r < 150
                    )
                        continue;

                    const dir = Math.atan2(player.y - obs.y, player.x - obs.x);
                    const closestPoint = {
                        x: obs.x + Math.cos(dir) * r - player.x,
                        y: obs.y + Math.sin(dir) * r - player.y,
                    };
                    const a = Math.atan2(closestPoint.y, closestPoint.x);
                    if (
                        obs.startAngle &&
                        obs.endAngle &&
                        checkAngleBetween(a, obs.startAngle, obs.endAngle) ===
                            false
                    ) {
                        continue;
                    }
                    dist = Math.sqrt(closestPoint.x ** 2 + closestPoint.y ** 2);
                    pangle = a;
                } else if (
                    obs.type.startsWith('poly') ||
                    obs.type === 'bezier'
                ) {
                    if (obs.type === 'bezier') {
                        obs.points = obs.polygon.points;
                    }
                    const intersection = returnBoundPlayerPolygon(
                        { x: player.x, y: player.y, radius: minDistance },
                        obs
                    );
                    if (intersection === false) {
                        continue;
                    } else {
                        // find the point by getting the overlap v and taking
                        // the inverse of that with respect to the minDistance
                        dist =
                            minDistance -
                            Math.sqrt(
                                intersection.overlapV.x ** 2 +
                                    intersection.overlapV.y ** 2
                            );
                        pangle =
                            (Math.atan2(
                                intersection.overlapN.y,
                                intersection.overlapN.x
                            ) -
                                Math.PI) %
                            (Math.PI * 2);
                    }
                } else if (
                    objtype === 'grapplepoint' ||
                    objtype === 'movinggrapplepoint'
                ) {
                    dist = Math.sqrt(
                        (player.x - obj.x) ** 2 + (player.y - obj.y) ** 2
                    );
                    pangle =
                        (Math.atan2(player.y - obj.y, player.x - obj.x) -
                            Math.PI) %
                        (Math.PI * 2);
                    thispriority = 1;
                }

                if (thispriority === 1) {
                    if (dist < minPriorityDistance && dist != NaN) {
                        minPriorityDistance = dist;
                        priorityangle = pangle;
                        priorityId = thisid;
                    }
                } else {
                    if (dist < minDistance && dist != NaN) {
                        minDistance = dist;
                        angle = pangle;
                        id = thisid;
                    }
                }
            }
            if (minDistance < 244) {
                // start grappling to that point
                player.powerups.grapple.grappling = true;
                player.powerups.grapple.length = minDistance;
                player.powerups.grapple.originalLength = minDistance;
                player.powerups.grapple.angle = angle;
                player.powerups.grapple.x =
                    player.x +
                    Math.cos(player.powerups.grapple.angle) *
                        player.powerups.grapple.length;
                player.powerups.grapple.y =
                    player.y +
                    Math.sin(player.powerups.grapple.angle) *
                        player.powerups.grapple.length;
                player.powerups.grapple.id = id;
                send({ powerups: player.powerups });
            }
            if (minPriorityDistance < 244 && minPriorityDistance != NaN) {
                // start grappling to that point
                player.powerups.grapple.grappling = true;
                player.powerups.grapple.length = minPriorityDistance;
                player.powerups.grapple.originalLength = minPriorityDistance;
                player.powerups.grapple.angle = priorityangle;
                player.powerups.grapple.x =
                    player.x +
                    Math.cos(player.powerups.grapple.angle) *
                        player.powerups.grapple.length;
                player.powerups.grapple.y =
                    player.y +
                    Math.sin(player.powerups.grapple.angle) *
                        player.powerups.grapple.length;
                player.powerups.grapple.id = priorityId;
                send({ powerups: player.powerups });
            }
        }
    } else if (player.powerups.grapple.grappling) {
        player.powerups.grapple.grappling = false;
        player.powerups.grapple.id = -1;
        player.powerups.grapple.lastpos = undefined;
        send({ powerups: player.powerups });
    }

    let dragTurnspeed = 2;
    if (player.powerups.dragon.state) {
        const mouseAngle = Math.atan2(
            mouse.y - canvas.height / 2,
            mouse.x - canvas.width / 2
        );
        useMouse = true;
        mouseMode = true;
        let lastAngle = player.powerups.dragon.angle;
        //player.powerups.dragon.angle -= Math.PI;
        if (!player.powerups.dragon.angle) {
            player.powerups.dragon.angle = 0;
        }
        const accel =
            interpolateDirection(
                player.powerups.dragon.angle - Math.PI / 2,
                mouseAngle,
                0.01
            ) %
            (Math.PI * 2);
        if (accel != NaN) {
            player.powerups.dragon.angle =
                (interpolateDirection(accel, mouseAngle, 0.005) + Math.PI / 2) %
                (Math.PI * 2);
        }
        //player.powerups.dragon.angle += Math.PI;
        if (lastAngle != player.powerups.dragon.angle) {
            send({ powerups: player.powerups });
        }
        player.speedMults.push(0.0181);
        if (player.boostCooldown == undefined) {
            player.boostCooldown = 0.2;
        }
        player.boostCooldown -= dt;
        player.input.right = false;
        player.input.left = false;
        player.input.up = false;
        player.input.down = false;
    }

    if (player.raycasting && player.rays) {
        if (!player.rayCastingAngle) {
            player.rayCastingAngle = 0;
        }
        player.lastRayCastingAngle = player.rayCastingAngle;
        // ship cons
        const turnSpeed = Math.PI;
        /*if (mouseMode) {
			const angle = Math.atan2(mouse.y - canvas.height / 2, mouse.x - canvas.width / 2) - Math.PI / 2;
            let absdiff = Math.abs(player.rayCastingAngle-angle);
            if(absdiff > Math.PI){
                if(player.rayCastingAngle > angle){
                    player.rayCastingAngle += (angle + 2 * Math.PI - player.rayCastingAngle) * dt * turnSpeed;
                } else {
                    player.rayCastingAngle -= (angle - 2 * Math.PI - player.rayCastingAngle) * dt * turnSpeed;
                }
            } else {
                player.rayCastingAngle += (angle - player.rayCastingAngle) * dt * turnSpeed;
            }
            player.xv -= Math.cos(player.rayCastingAngle-Math.PI/2)*dt*player.speed;
			player.yv -= Math.sin(player.rayCastingAngle-Math.PI/2)*dt*player.speed;
		} else*/ {
            // KB MODE
            if (xspeed < 0) {
                player.rayCastingAngle -= turnSpeed * dt;
            } else if (xspeed > 0) {
                player.rayCastingAngle += turnSpeed * dt;
            }
            player.xv +=
                Math.cos(player.rayCastingAngle - Math.PI) * yspeed * dt;
            player.yv +=
                Math.sin(player.rayCastingAngle - Math.PI) * yspeed * dt;
        }
        xspeed = 0;
        yspeed = 0;
        // moving rays
        for (let i in player.rays) {
            player.rays[i].angle += player.rayCastingAngle - player.lastRayCastingAngle;
        }
    }

    //if(player.raycasting){
    //    player.ship = false;
    //}
    player.raycasting = false;

    if (player.cameraChange != undefined) {
        player.xv = 0;
        player.yv = 0;
        xspeed = 0;
        yspeed = 0;
    }

    if (player.powerups.gun.state) {
        // dont change it; this is better >:(
        // if u do then dm / argue with me
        if (yspeed != 0 || xspeed != 0) {
            let lastangle = player.powerups.gun.angle;
            if (mouseMode) {
                const playerOffset = offset(player.x, player.y);
                player.powerups.gun.angle =
                    Math.atan2(
                        mouse.y - playerOffset.y,
                        mouse.x - playerOffset.x
                    ) -
                    Math.PI / 2;
            } else {
                player.powerups.gun.angle =
                    Math.atan2(yspeed, xspeed) - Math.PI / 2;
            }
            if (lastangle != player.powerups.gun.angle)
                send({ powerups: player.powerups });
        }
        player.powerups.gun.currentCooldown -= dt;
        player.powerups.gun.currentCooldown = Math.max(
            player.powerups.gun.currentCooldown,
            0
        );
        if (input.shift && player.powerups.gun.currentCooldown <= 0) {
            // fire a bullet
            player.bullets.push({
                x:
                    player.x -
                    Math.cos(player.powerups.gun.angle + Math.PI / 2) *
                        (player.radius / 2),
                y:
                    player.y -
                    Math.sin(player.powerups.gun.angle + Math.PI / 2) *
                        (player.radius / 2),
                angle: player.powerups.gun.angle + Math.PI / 2,
                radius: player.powerups.gun.radius,
                speed: player.powerups.gun.speed,
                type: player.powerups.gun.type,
                life: player.powerups.gun.life,
                effectTime: player.powerups.gun.effectTime,
                id: `${Math.random()}-bullet`,
            });
            send({ bullets: player.bullets });

            player.powerups.gun.currentCooldown =
                player.powerups.gun.maxCooldown;
            // player.powerups.gun.currentCooldown = 0.1;
        }
        // sim bullets
        player.bullets.forEach((bullet, index) => {
            bullet.life -= dt;
            if (bullet.life <= 0) {
                player.bullets.splice(index, 1);
                send({ bullets: player.bullets });
            }
            bullet.x += dt * bullet.speed * Math.cos(bullet.angle);
            bullet.y += dt * bullet.speed * Math.sin(bullet.angle);
            if (bullet.type === 'pvp') {
                if (bullet.x + bullet.radius >= 1000) {
                    bullet.x = 1000 * 2 - bullet.x - bullet.radius * 2;
                    bullet.angle = Math.atan2(
                        Math.sin(bullet.angle),
                        -Math.cos(bullet.angle)
                    );
                } else if (bullet.x - bullet.radius <= 0) {
                    bullet.x = 0 * 2 - bullet.x + bullet.radius * 2;
                    bullet.angle = Math.atan2(
                        Math.sin(bullet.angle),
                        -Math.cos(bullet.angle)
                    );
                }
            }
            if (bullet.type === 'pvp') {
                if (bullet.y + bullet.radius >= 1000) {
                    bullet.y = 1000 * 2 - bullet.y - bullet.radius * 2;
                    bullet.angle = Math.atan2(
                        -Math.sin(bullet.angle),
                        Math.cos(bullet.angle)
                    );
                } else if (bullet.y - bullet.radius <= 0) {
                    bullet.y = 0 * 2 - bullet.y + bullet.radius * 2;
                    bullet.angle = Math.atan2(
                        -Math.sin(bullet.angle),
                        Math.cos(bullet.angle)
                    );
                }
            }
            if (bullet.type == 'pvp') {
                // arena for uni 2
                for (const otherId of Object.keys(players)) {
                    const other = players[otherId];
                    if (otherId == player.id) continue;
                    // double equal because id is number
                    // and might be string
                    // if(intersectingCircle(bullet, other)){
                    //     other.dead = true;
                    //     send({ dead: true, id: otherId, type: 'pvp' })
                    // }
                }
            }
        });
    } else if (player.bullets.length > 0) {
        player.bullets = [];
        send({ bullets: player.bullets });
    }

    if (player.invertX) {
        player.invertX = false;
        xspeed *= -1;
    }

    if (player.invertY) {
        player.invertY = false;
        yspeed *= -1;
    }

    if(window.canvasRotation !== 0){
        window.canvasRotation = 0;
    }

    let insideGravZone = false;
    let insideSlip = false;
    let toBeRadius = player.defaultRadius;
    let insideSnap = false;
    let insideVinette = false;
    insidePlatformer = false;
    let insideNoRes = false;
    let platformerForce = { x: 0, y: 0 };
    let platformerFriction = 0.8;
    let variableJumpHeight = false;
    let platformerDir = 'down';
    let touchingGround = false;
    let outside = false;
    let inZombie = false;
    
    for(let i = 0; i < (sortedObstacles.rotating??[]).length; i++){
        const obj = sortedObstacles.rotating[i];
        if (obj.pivotX === undefined) {
            obj.pivotX = obj.x;
        }
		// since it can be rly far adn we nee dto account for that
		// 
        if (obj.pivotY === undefined) {
            obj.pivotY = obj.y;
        }
		if (obj.inView === false) {
			if (obj.unSim == undefined) {
				obj.unSim = 0;
			}
			obj.unSim += dt;
			continue;
		}
		let time = dt + (obj.unSim === undefined ? 0: obj.unSim);
        obj.angle += obj.rotateSpeed * time;
        obj.unSim = 0;
		
        obj.x =
            Math.cos((obj.angle * Math.PI) / 180) *
                obj.distToPivot +
            obj.pivotX;
        obj.y =
            Math.sin((obj.angle * Math.PI) / 180) *
                obj.distToPivot +
            obj.pivotY;
    }

    for(let i = 0; i < (sortedObstacles.rotatepause??[]).length; i++){
        const obj = sortedObstacles.rotatepause[i];
        simulateRotatingPauseObstacle(obj, dt);
    }

    for(let i = 0; i < (sortedObstacles.moving??[]).length; i++){
        const obj = sortedObstacles.moving[i];
        simulateMovingObstacle(obj, dt);
    }

    for(let i = 0; i < (sortedObstacles.movepause??[]).length; i++){
        const obj = sortedObstacles.movepause[i];
        simulateMovingPauseObstacle(obj, dt);
    }

    for(let i = 0; i < (sortedObstacles.switch??[]).length; i++){
        const obj = sortedObstacles.switch[i];
        simulateSwitchingObstacle(obj, dt);
    }

    for(let i = 0; i < (sortedObstacles.grow??[]).length; i++){
        const obj = sortedObstacles.grow[i];
        simulateGrowingObstacle(obj, dt);
    }

    for(let i = 0; i < (sortedObstacles.growcircle??[]).length; i++){
        const obj = sortedObstacles.growcircle[i];
        simulateGrowingCircularObstacle(obj, dt);
    }

    for(let i = 0; i < (sortedObstacles.movingspeedtrap??[]).length; i++){
        const obj = sortedObstacles.movingspeedtrap[i];
        simulateMovingObstacle(obj, dt);
        if (intersectingCircleRect(player, obj)) {
            if (
                Math.sqrt(player.xv ** 2 + player.yv ** 2) <
                obj.minSpeed
            ) {
                if (
                    obj.tpx != undefined &&
                    obj.tpy != undefined
                ) {
                    player.x = obj.tpx;
                    player.y = obj.tpy;
                    player.isTyping = false;
                    player.grav.x = 0;
                    player.grav.y = 0;
                    player.xv = 0;
                    player.yv = 0;
                    insideCircleSnap = false;
                } else {
                    player.dead = true;
                    send({ dead: true });
                }
            }
            if (obj.maxSpeed != undefined) {
                if (
                    Math.sqrt(player.xv ** 2 + player.yv ** 2) >
                    obj.maxSpeed
                ) {
                    if (
                        obj.tpx != undefined &&
                        obj.tpy != undefined
                    ) {
                        player.x = obj.tpx;
                        player.y = obj.tpy;
                        player.isTyping = false;
                        player.grav.x = 0;
                        player.grav.y = 0;
                        player.xv = 0;
                        player.yv = 0;
                        insideCircleSnap = false;
                    } else {
                        player.dead = true;
                        send({ dead: true });
                    }
                }
            }
        }
    }

    for(let i = 0; i < (sortedObstacles.morphmoving??[]).length; i++){
        const obj = sortedObstacles.morphmoving[i];
        if (obj.active) {
            simulateMovingObstacle(obj, dt)
        }
    }

    for(let i = 0; i < (sortedObstacles.enemybutton??[]).length; i++){
        const obj = sortedObstacles.enemybutton[i];
        if(obj.active === true){
            simulateEnemyButton(obj, dt, enemy);
        }
    }

    for(let i = 0; i < (sortedObstacles.enemyeffect??[]).length; i++){
        const obj = sortedObstacles.enemyeffect[i];
        simulateEnemyEffector(obj, dt, enemy||[], i);
    }

    for(let i = 0; i < (sortedObstacles.enemytp??[]).length; i++){
        const obj = sortedObstacles.enemytp[i];
        simulateEnemyTp(obj, dt, enemy);
    }

    for(let i = 0; i < (sortedObstacles.enemywall??[]).length; i++){
        const obj = sortedObstacles.enemywall[i];
        simulateEnemyWall(obj, dt, enemy);
    }

    for(let i = 0; i < (sortedObstacles['poly-enemywall']??[]).length; i++){
            const obj = sortedObstacles['poly-enemywall'][i];
        simulateEnemyPolyWall(obj, dt, enemy);
    }

    for(let i = 0; i < (sortedObstacles['circle-hollow-slice-enemywall']??[]).length; i++){
            const obj = sortedObstacles['circle-hollow-slice-enemywall'][i];
        simulateCircleHollowSliceEnemyWall(obj, dt, enemy);
    }

    for(let i = 0; i < (sortedObstacles['circle-hollow-slice-enemytp']??[]).length; i++){
            const obj = sortedObstacles['circle-hollow-slice-enemytp'][i];
        simulateCircleHollowSliceEnemyTp(obj, dt, enemy);
    }

    for(let i = 0; i < (sortedObstacles['poly-enemytp']??[]).length; i++){
            const obj = sortedObstacles['poly-enemytp'][i];
        simulateEnemyPolyTp(obj, dt, enemy);
    }

    for(let i = 0; i < (sortedObstacles['circlehollowslice']??[]).length; i++){
        const obj = sortedObstacles['circlehollowslice'][i];
        if(obj.toRotate) {
            obj.startAngle += obj.rotateSpeed * dt;
            obj.endAngle += obj.rotateSpeed * dt;
            obj.startPolygon.points = [
                [
                    obj.x + Math.cos(obj.startAngle) * obj.innerRadius,
                    obj.y + Math.sin(obj.startAngle) * obj.innerRadius,
                ],
                [
                    obj.x + Math.cos(obj.startAngle) * obj.radius,
                    obj.y + Math.sin(obj.startAngle) * obj.radius,
                ],
            ];
            obj.endPolygon.points = [
                [
                    obj.x + Math.cos(obj.endAngle) * obj.innerRadius,
                    obj.y + Math.sin(obj.endAngle) * obj.innerRadius,
                ],
                [
                    obj.x + Math.cos(obj.endAngle) * obj.radius,
                    obj.y + Math.sin(obj.endAngle) * obj.radius,
                ],
            ];
        }
    }

    // for all obstacles that are simulated on interaction, stuff starts here
    if(player.god === false){
        for(let i = 0; i < (sortedObstacles['morphbuttontimed']??[]).length; i++){
            const obj = sortedObstacles['morphbuttontimed'][i];
            if (!obj.active) {
                obj.timer -= dt;
                if (obj.timer <= 0) {
                    obj.active = true;
                    // for (const ob of obstacles) {
                    // 	if (ob.type === 'morphnormal' || ob.type === 'morphlavamove' && obj.morphId === ob.morphId) {
                    // 		ob.active = !ob.active;
                    // 	}
                    // }
                    triggerMorphEffects(obj.morphId, obstacles)
                }
            }
            if (intersectingCircleRect(player, obj) && obj.active) {
                obj.active = false;
                obj.timer = obj.time;
                triggerMorphEffects(obj.morphId, obstacles)
            }
        }
        
        for(let i = 0; i < (sortedObstacles['morphmovereset']??[]).length; i++){
            const obj = sortedObstacles['morphmovereset'][i];
            const touchingPlayer = intersectingCircleRect(player, obj);
            if (touchingPlayer && obj.active) {
                triggerMorphEffects(obj.morphId, obstacles);
                obj.active = false;
                for(let tobstacle of obstacles){
                    if((tobstacle.type === 'morphmove' || tobstacle.type === 'morphlavamove') && tobstacle.morphId === obj.morphId){
                        tobstacle.currentPoint = obj.resetPoint;
                        tobstacle.active = false;
                        if (tobstacle.currentPoint >= tobstacle.points.length) {
                            tobstacle.currentPoint = 0;
                        }
                        let nextPoint = tobstacle.points[tobstacle.currentPoint];
                        tobstacle.x = nextPoint[0];
                        tobstacle.y = nextPoint[1];
    
                        updateMorphersMoving(tobstacle);
                    }
                }
            } else if(!touchingPlayer) {
                obj.active = true;
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['dirnormal']??[]).length; i++){
            const obj = sortedObstacles['dirnormal'][i];
            if (obj.active && obj.activeTimer < 0.25) {
                obj.activeTimer += dt;
                if (obj.activeTimer > 0.25) {
                    obj.activeTimer = 0.25;
                }
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['circle-sentry']??[]).length; i++){
            const obj = sortedObstacles['circle-sentry'][i];
            simulateSentry(obj, dt, players);
        }

        for(let i = 0; i < (sortedObstacles['circle-turret-sentry']??[]).length; i++){
            const obj = sortedObstacles['circle-turret-sentry'][i];
            simulateTurretSentry(obj, dt, players);
        }
        
        for(let i = 0; i < (sortedObstacles['mirror']??[]).length; i++){
            const obj = sortedObstacles['mirror'][i];
            if (intersectingCircleRect(player, obj) && !player.isMirror) {
                player.mirror = JSON.parse(
                    JSON.stringify({
                        ...JSON.parse(JSON.stringify(player)),
                        x: player.x + obj.offset.x,
                        y: player.y + obj.offset.y,
                        isMirror: true,
                    })
                );
                delete player.mirror.mirror;
                runPlayerPhysics(
                    player.mirror,
                    arena,
                    obstacles,
                    input,
                    dt,
                    players
                );
                runCollision(
                    player.mirror,
                    enemy,
                    obstacles,
                    safes,
                    npcs,
                    players
                );
                player.renderMirror = player.mirror;
                // re-applying physics
                for (let key of Object.keys(player.mirror)) {
                    if (
                        key === 'hat' ||
                        key === 'isMirror' ||
                        key === 'renderMirror'
                    ) {
                        
                    } else if (key === 'x') {
                        player.x = player.mirror.x - obj.offset.x;
                    } else if (key === 'y') {
                        player.y = player.mirror.y - obj.offset.y;
                    } else if (player[key] != player.mirror[key]) {
                        player[key] = player.mirror[key];
                    }
                }
                delete player.isMirror;
                delete player.mirror;
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['air']??[]).length; i++){
            const obj = sortedObstacles['air'][i];
            if (intersectingCircleRect(player, obj)) {
                outside = true;
            }
        } 
        
        for(let i = 0; i < (sortedObstacles['rotatecanvas']??[]).length; i++){
            const obj = sortedObstacles['rotatecanvas'][i];
            if (intersectingCircleRect(player, obj)) {
                window.canvasRotation += obj.deg*Math.PI/180;
            }
        }
        
        for(let i = 0; i < (sortedObstacles['resettimetraps']??[]).length; i++){
            const obj = sortedObstacles['resettimetraps'][i];
            const isIntersecting = intersectingCircleRect(player, obj);
            if (isIntersecting && !obj.lastIntersecting) {
                obj.lastIntersecting = true;
                for(let o of obstacles){
                    if(o.type === 'timetrap' || o.type === 'tptrap'){
                        o.time = 0;
                    }
                }
            } else if(isIntersecting === false) {
                obj.lastIntersecting = false;
            }
        } 
        
        for(let i = 0; i < (sortedObstacles['nores']??[]).length; i++){
            const obj = sortedObstacles['nores'][i];
            if (intersectingCircleRect(player, obj)) {
                insideNoRes = true;
            }
        }
        
        for(let i = 0; i < (sortedObstacles['zoom']??[]).length; i++){
            const obj = sortedObstacles['zoom'][i];
            if (intersectingCircleRect(player, obj)) {
                window.renderScale = obj.zoom;
            }
        } 
        
        for(let i = 0; i < (sortedObstacles['morphbutton']??[]).length; i++){
            const obj = sortedObstacles['morphbutton'][i];
            if(obj.timedObstacles === undefined){
                obj.maxTimedObstacles = 0;
                for(let tobstacle of obstacles){
                    if((tobstacle.type === 'morphmove' || tobstacle.type === 'morphlavamove') && tobstacle.morphId === obj.morphId){
                        obj.maxTimedObstacles++;
                    }
                }
                obj.timedObstacles = 0;
                //obj.timedObstacles = obj.maxTimedObstacles;
            }
            if (intersectingCircleRect(player, obj) && obj.active && obj.timedObstacles === 0) {
                //obj.active = false;
                //obj.timedObstacles = obj.maxTimedObstacles;
                triggerMorphEffects(obj.morphId, obstacles);
            }
            if(obj.timedObstacles === 0 && obj.maxTimedObstacles !== 0){
                obj.active = true;
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['button']??[]).length; i++){
            const obj = sortedObstacles['button'][i];
            if(obj.active === true){
                if (intersectingCircleRect(player, obj)) {
                    obj.active = false;
                    triggerButtonEffects(obj.id, obstacles);
                }
            }
            for (let obj2 of obstacles) {
                if (obj2.type !== 'pushbox') {
                    continue;
                }
                const collisionSAT2 = returnIntersectingRectRect(
                    obj,
                    obj2
                );
                if (collisionSAT2 != false) {
                    triggerButtonEffects(obj.id, obstacles);
                    obj.active = false;
                }
            }
        }
        
        for(let i = 0; i < (sortedObstacles['bbutton']??[]).length; i++){
            const obj = sortedObstacles['bbutton'][i];
            if (obj.active) {
                for (let obj2 of obstacles) {
                    if (obj2.type !== 'pushbox') {
                        continue;
                    }
                    const collisionSAT2 = returnIntersectingRectRect(
                        obj,
                        obj2
                    );
                    if (collisionSAT2 != false) {
                        triggerButtonEffects(obj.id, obstacles);
                        obj.active = false;
                    }
                }
            }
            obj.tempActive = false;
            if (intersectingCircleRect(player, obj) && obj.active) {
                obj.tempActive = true;
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['crowdbutton']??[]).length; i++){
            const obj = sortedObstacles['crowdbutton'][i];
            let psintersecting = 0;
            for (let k in Object.keys(players)) {
                const p = players[Object.keys(players)[k]];
                if (intersectingCircleRect(p, obj, true)) {
                    psintersecting++;
                }
            }
            if (!obj.active) {
                obj.playersOn = psintersecting;
                if (psintersecting >= obj.minPlayers) {
                    triggerButtonEffects(obj.id, obstacles);
                    obj.active = true;
                    obj.timer = obj.delay;
                    send({
                        crowdbutton: true,
                        timer: obj.timer,
                        id: obj.id,
                    });
                }
            } else {
                if (psintersecting < obj.minPlayers) {
                    // after the delay is done, then we reset button
                    obj.timer -= dt;
                    if (obj.timer < 0) {
                        triggerButtonEffects(obj.id, obstacles);
                        obj.active = false;
                    }
                }
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['tbutton']??[]).length; i++){
            const obj = sortedObstacles['tbutton'][i];
            obj.timer -= dt;
            if (obj.timer < 0) {
                triggerButtonEffects(obj.id, obstacles);
                obj.timer += obj.time;
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['ttbutton']??[]).length; i++){
            const obj = sortedObstacles['ttbutton'][i];
            if (
                intersectingCircleRect(player, obj) &&
                !obj.active
            ) {
                obj.active = true;
                triggerButtonEffects(obj.id, obstacles);
            } else if (obj.active) {
                obj.timer -= dt;
                if (obj.timer < 0) {
                    obj.active = false;
                    obj.timer += obj.time;
                    triggerButtonEffects(obj.id, obstacles);
                }
            }
        }
        
        for(let i = 0; i < (sortedObstacles['rbutton']??[]).length; i++){
            const obj = sortedObstacles['rbutton'][i];
            obj.active = false;
            if (intersectingCircleRect(player, obj)) {
                obj.active = true;
            }
            if (
                obj.lastPressed == false &&
                obj.active == true
            ) {
                triggerButtonEffects(obj.id, obstacles);
            }
            obj.lastPressed = obj.active;
            
        }
        
        for(let i = 0; i < (sortedObstacles['cure']??[]).length; i++){
            const obj = sortedObstacles['cure'][i];
            if (
                player.deathTimer != undefined &&
                intersectingCircleRect(player, obj)
            ) {
                player.deathTimer = undefined;
            }
        }

        for(let i = 0; i < (sortedObstacles['mark']??[]).length; i++){
            const obj = sortedObstacles['mark'][i];
            if (
                player.deathTimer == undefined &&
                intersectingCircleRect(player, obj)
            ) {
                player.deathTimer = obj.time;
            }
        }
        
        for(let i = 0; i < (sortedObstacles['zone']??[]).length; i++){
            const obj = sortedObstacles['zone'][i];
            if (
                player.zone !== obj.value &&
                intersectingCircleRect(player, obj)
            ) {
                player.zone = obj.value;
                send({ zone: obj.value });
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['invert']??[]).length; i++){
            const obj = sortedObstacles['invert'][i];
            if (intersectingCircleRect(player, obj)) {
                if (obj.invertX) player.invertX = true;
                if (obj.invertY) player.invertY = true;
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['custom']??[]).length; i++){
            const obj = sortedObstacles['custom'][i];
            // simulating with the sim function provided and then doing the onCollision when collision
            const simexec = obj.sim.replaceAll(
                'this',
                'obj'
            );
            try {
                eval(simexec);
            } catch (e) {
                console.log('client side simulation error ' + e);
            }
            if (intersectingCircleRect(player, obj)) {
                const colexec = obj.onCollision.replaceAll(
                    'this',
                    'obj'
                );
                try {
                    eval(colexec);
                } catch (e) {
                    console.log('client side collision error ' + e);
                }
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['farrow']??[]).length; i++){
            const obj = sortedObstacles['farrow'][i];
            if (
                obj.active &&
                intersectingCircleRect(player, obj)
            ) {
                obj.active = false;
                player.arrows = obj.arrows;
            }
            if (player.dead && !obj.active) {
                obj.active = true;
                player.arrows = [];
                for (let a in obj.arrows) {
                    obj.arrows[a][1] += player.arrowDt;
                    obj.arrows[a][3] = undefined;
                }
                player.arrowDt = 0;
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['camerachange']??[]).length; i++){
            const obj = sortedObstacles['camerachange'][i];
            player.cameraChange = undefined;
            if (
                intersectingCircleRect(player, obj) &&
                obj.intersecting != true
            ) {
                obj.intersecting = true;
                player.cameraChange = {
                    x: obj.cameraX,
                    y: obj.cameraY,
                    canReturn: obj.canReturn,
                };
            }
            if (obj.canReturn && input.shift) {
                player.cameraChange = undefined;
            } else {
                obj.intersecting = false;
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['forceinput']??[]).length; i++){
            const obj = sortedObstacles['forceinput'][i];
            if (intersectingCircleRect(player, obj)){
                obj.intersecting = true;
                for(let forceinput of obj.inputs){
                    window.input[forceinput] = true;
                    window.lockedInput[forceinput] = true;
                }
            } else if(obj.intersecting === true){
                obj.intersecting = false;
                for(let forceinput of obj.inputs){
                    window.input[forceinput] = false;
                    window.lockedInput[forceinput] = false;
                }
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['typing']??[]).length; i++){
            const obj = sortedObstacles['typing'][i];
            if (player.dead) {
                player.isTyping = false;
                player.currentChar = 0;
                obj.currentChar = 0;
                obj.active = true;
            }
            if (
                intersectingCircleRect(player, obj) &&
                obj.active
            ) {
                if (!player.isTyping) {
                    player.isTyping = true;
                    player.currentChar = 0;
                    obj.currentChar = 0;
                }
                for (let j in player.input.typing) {
                    if (
                        player.input.typing[j] ==
                        obj.text.charAt(player.currentChar)
                    ) {
                        player.currentChar++;
                        obj.currentChar = player.currentChar;
                        if (
                            player.currentChar >
                            obj.text.length - 1
                        ) {
                            obj.active = false;
                            player.isTyping = false;
                            player.currentChar = 0;
                            obj.currentChar = 0;
                        }
                    }
                }
                player.input.typing = [];
    
                insideVinette = true;
                window.io += (0.9 - window.io) * 0.03;
                window.ior += (0.5 - window.ior) * 0.03;
                window.iir += (0.5 - window.iir) * 0.03;
                window.vinette = [window.iir, window.ior, window.io];
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['mashing']??[]).length; i++){
            const obj = sortedObstacles['mashing'][i];
            if (player.dead) {
                player.isTyping = false;
                player.mashing = undefined;
                player.currentChar = 0;
                obj.currentNum = 0;
                obj.active = true;
            }
            if (
                intersectingCircleRect(player, obj) &&
                obj.active
            ) {
                if (!player.isTyping) {
                    player.isTyping = true;
                    player.mashing = true;
                    player.currentChar = 0;
                    obj.currentNum = 0;
                }
                for (let j in player.input.typing) {
                    player.currentChar++;
                    obj.currentNum = player.currentChar;
                    if (player.currentChar > obj.amount - 1) {
                        obj.active = false;
                        player.isTyping = false;
                        player.mashing = undefined;
                        player.currentChar = 0;
                        obj.currentNum = 0;
                    }
                }
                player.input.typing = [];
    
                insideVinette = true;
                window.io += (0.9 - window.io) * 0.03;
                window.ior += (0.5 - window.ior) * 0.03;
                window.iir += (0.5 - window.iir) * 0.03;
                window.vinette = [window.iir, window.ior, window.io];
            }
            
        }
        /*player.isTyping = true;
        if(player.typingInputs){
            if(player.typingInput == obj.text[obj.currentCharacter]){
                enemy.text = text;
                enemy.maxCharacters = text.length;
                enemy.currentCharacter = 0;
            }
        }*/
        for(let i = 0; i < (sortedObstacles['playerdraw']??[]).length; i++){
            const obj = sortedObstacles['playerdraw'][i];
            if (intersectingCircleRect(player, obj)) {
                if(input.action){
                    if(!obj.lineStart){
                        obj.lineStart = [player.x, player.y];
                    } else {
                        obj.timer -= dt;
                        if(obj.timer < 0){
                            obj.timer = 0.05;
                            obj.lines.push([obj.lineStart,[player.x,player.y],101]);// preview line will dissapear at 100
                            send({drawLine: [
                                [
                                    Math.round(obj.lineStart[0]),
                                    Math.round(obj.lineStart[1])
                                ],[
                                    Math.round(player.x),
                                    Math.round(player.y)
                                ]
                            ]});
                            delete obj.lineStart;
                        }
                    }
                } else if(obj.lineStart) {
                    delete obj.lineStart;
                }
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['playercollide']??[]).length; i++){
            const obj = sortedObstacles['playercollide'][i];
            let lastradius = player.radius;
            player.radius = 0;
            if (intersectingCircleRect(player, obj)) {
                player.radius = lastradius;
                for (let p in players) {
                    if (players[p].id == player.id) continue;
                    if (
                        Math.sqrt(
                            (players[p].x - player.x) ** 2 +
                                (players[p].y - player.y) ** 2
                        ) <
                        players[p].radius + player.radius
                    ) {
                        bouncePlayers(
                            player,
                            players[p],
                            obj.bounciness
                        );
                        send({
                            bounce: true,
                            id: players[p].id,
                            effect: obj.bounciness,
                        });
                    }
                }
            }
            player.radius = lastradius;
            
        }
        
        for(let i = 0; i < (sortedObstacles['deadmove']??[]).length; i++){
            const obj = sortedObstacles['deadmove'][i];
            if (
                intersectingCircleRect(player, obj) &&
                player.dead &&
                (obj.decayTime > 0 ||
                    obj.decayTime === null)
            ) {
                player.deadMove = true;
                if (obj.decayTime !== null) {
                    obj.decayTime -= dt;
                }
            } else if (
                obj.decayTime <= obj.maxDecayTime &&
                obj.decayTime !== null &&
                !player.dead
            ) {
                obj.decayTime += Math.max(
                    0,
                    obj.maxDecayTime
                );
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['speed']??[]).length; i++){
            const obj = sortedObstacles['speed'][i];
            if (intersectingCircleRect(player, obj)) {
                xspeed *= obj.speedInc;
                yspeed *= obj.speedInc;
                if (player.ship !== false) {
                    player.shipSpeedMult *= obj.speedInc;
                }
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['raycasting']??[]).length; i++){
            const obj = sortedObstacles['raycasting'][i];
            if (intersectingCircleRect(player, obj)) {
                if(player.raycasting === false){
                    computeRaycastingLines();
                }
                player.raycasting = true;
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['idit']??[]).length; i++){
            const obj = sortedObstacles['idit'][i];
            if (intersectingCircleRect(player, obj)) {
                if (player.iditangle == undefined) {
                    player.iditangle = 0;
                }
                // subtracting last angle
                player.x -=
                    Math.cos(player.iditangle) *
                    obj.spinRadius *
                    dt;
                player.y -=
                    Math.sin(player.iditangle) *
                    obj.spinRadius *
                    dt;
                // inc idit angle
                player.iditangle += dt * obj.speed;
                (player.iditangle % Math.PI) * 2;
    
                // moving to this angle
                player.x +=
                    Math.cos(player.iditangle) *
                    obj.spinRadius *
                    dt;
                player.y +=
                    Math.sin(player.iditangle) *
                    obj.spinRadius *
                    dt;
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['revive']??[]).length; i++){
            const obj = sortedObstacles['revive'][i];
            if (intersectingCircleRect(player, obj)) {
                if (player.dead) {
                    onSafe = true;
                    player.dead = false;
                    send({ dead: false });
                }
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['hole']??[]).length; i++){
            const obj = sortedObstacles['hole'][i];
            // regening circle sat to check if we're COMPLETELY within
            if (
                intersectingCircleRect(
                    { ...player, radius: -player.radius },
                    obj,
                    true
                )
            ) {
                // resetting sat
                player.sat = new SAT.Circle(
                    new SAT.Vector(player.x, player.y),
                    player.radius
                );
                onHole = true;
                
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['draw']??[]).length; i++){
            const obj = sortedObstacles['draw'][i];
            if (intersectingCircleRect(player, obj)) {
                if (!player.dead) {
                    obj.touchingPlayer = true;
                    let playerCrude = [
                        Math.round(
                            player.x / obj.distanceBetween
                        ) * obj.distanceBetween,
                        Math.round(
                            player.y / obj.distanceBetween
                        ) * obj.distanceBetween,
                    ];
                    if (
                        !obj.addedPoints.includes(
                            playerCrude[0] + ' ' + playerCrude[1]
                        )
                    ) {
                        const objToAdd = Object.assign(
                            {},
                            {
                                x:
                                    playerCrude[0] -
                                    obj.obsToAdd.w / 2 +
                                    obj.offsetX,
                                y:
                                    playerCrude[1] -
                                    obj.obsToAdd.h / 2 +
                                    obj.offsetY,
                            },
                            obj.obsToAdd
                        );
                        obj.addedPoints.push(
                            playerCrude[0] + ' ' + playerCrude[1]
                        );
                        window.obstacles.push(objToAdd); // x and y should be -w/2 and -h/2
                        obj.lastObsPos = [
                            playerCrude[0] + obj.offsetX,
                            playerCrude[1] + obj.offsetY,
                        ];
                    }
                    //window.obstacles.push({x:player.x,y:player.y,w:50,h:50,type:"normal"});
                    //for(let x = 0; x < obj.w; x+= 50){
    
                    //}
                }
            } else {
                obj.touchingPlayer = false;
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['speedtrap']??[]).length; i++){
            const obj = sortedObstacles['speedtrap'][i];
            if (
                !player.god &&
                !player.dead &&
                intersectingCircleRect(player, obj)
            ) {
                if (
                    Math.sqrt(player.xv ** 2 + player.yv ** 2) <
                    obj.minSpeed
                ) {
                    if (
                        obj.tpx != undefined &&
                        obj.tpy != undefined
                    ) {
                        player.x = obj.tpx;
                        player.y = obj.tpy;
                        player.isTyping = false;
                        player.grav.x = 0;
                        player.grav.y = 0;
                        player.xv = 0;
                        player.yv = 0;
                        insideCircleSnap = false;
                    } else {
                        player.dead = true;
                        send({ dead: true });
                    }
                }
                if (obj.maxSpeed != undefined) {
                    if (
                        Math.sqrt(player.xv ** 2 + player.yv ** 2) >
                        obj.maxSpeed
                    ) {
                        if (
                            obj.tpx != undefined &&
                            obj.tpy != undefined
                        ) {
                            player.x = obj.tpx;
                            player.y = obj.tpy;
                            player.isTyping = false;
                            player.grav.x = 0;
                            player.grav.y = 0;
                            player.xv = 0;
                            player.yv = 0;
                            insideCircleSnap = false;
                        } else {
                            player.dead = true;
                            send({ dead: true });
                        }
                    }
                }
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['filter']??[]).length; i++){
            const obj = sortedObstacles['filter'][i];
            if (intersectingCircleRect(player, obj)) {
                obj.touchingFilter = true;
            } else {
                obj.touchingFilter = false;
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['zombie']??[]).length; i++){
            const obj = sortedObstacles['zombie'][i];
            if (intersectingCircleRect(player, obj)) {
                inZombie = true;
                obj.timer -= dt;
                if (obj.timer < 0) {
                    obj.timer += obj.timeBetween;
                    // push player zombie
                    let a = Math.random() * Math.PI * 2;
                    let zx = player.x + Math.cos(a) * obj.dist;
                    let zy = player.y + Math.sin(a) * obj.dist;
                    let radius =
                        player.radius * 0.8 +
                        Math.random() * player.radius * 1.2;
                    if (zx - radius < obj.x) {
                        zx = obj.x + radius;
                    } else if (
                        zx + radius >
                        obj.x + obj.w
                    ) {
                        zx = obj.x + obj.w - radius;
                    }
                    if (zy - radius < obj.y) {
                        zy = obj.y + radius;
                    } else if (
                        zy + radius >
                        obj.y + obj.h
                    ) {
                        zy = obj.y + obj.h - radius;
                    }
                    player.zombies.push({
                        x: zx,
                        y: zy,
                        radius: radius,
                        speed: 1 / Math.sqrt(radius),
                        bound: {
                            x: obj.x,
                            y: obj.y,
                            w: obj.w,
                            h: obj.h,
                        },
                    });
                }
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['frictionchanger']??[]).length; i++){
            const obj = sortedObstacles['frictionchanger'][i];
            if (intersectingCircleRect(player, obj)) {
                insideFrictionChanger = obj.fric;
                if (obj.speedInc) {
                    xspeed *= obj.speedInc;
                    yspeed *= obj.speedInc;
                    if (player.ship !== false) {
                        player.shipSpeedMult *= obj.speedInc;
                    }
                }
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['golf']??[]).length; i++){
            const obj = sortedObstacles['golf'][i];
            if (intersectingCircleRect(player, obj)) {
                insideGolf = true;
                if (player.golfangle != undefined) {
                    player.xv +=
                        Math.cos(player.golfangle) *
                        obj.speed *
                        player.golfCooldown;
                    player.yv +=
                        Math.sin(player.golfangle) *
                        obj.speed *
                        player.golfCooldown;
                }
                if (player.golfCooldown < 0.75) {
                    player.xv *= obj.friction;
                    player.yv *= obj.friction;
                    if (player.golfCooldown < 0) {
                        player.golfangle = undefined;
                    }
                }
    
                xspeed = 0;
                yspeed = 0;
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['gun']??[]).length; i++){
            const obj = sortedObstacles['gun'][i];
            if (
                intersectingCircleRect(player, obj) &&
                !player.dead &&
                (player.powerups.gun.state != obj.state ||
                    player.powerups.gun.type != obj.gunType)
            ) {
                player.bullets = [];
                player.powerups.gun.state = obj.state;
                if (obj.state != false) {
                    player.powerups.gun.type = obj.gunType;
                    player.powerups.gun.maxCooldown =
                        obj.fireCooldown;
                    player.powerups.gun.currentCooldown = 0; //obj.fireCooldown;
                    player.powerups.gun.speed = obj.speed;
                    player.powerups.gun.radius = obj.radius;
                    player.powerups.gun.life = obj.life;
                    player.powerups.gun.effectTime = obj.effectTime||3;
                }
                send({ powerups: player.powerups });
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['particles']??[]).length; i++){
            const obj = sortedObstacles['particles'][i];
            if (intersectingCircleRect(player, obj)) {
                obj.time -= dt;
                if (obj.time < 0) {
                    obj.time += obj.spawnRate;
                    let offsetX = obj.offsetX;
                    let offsetY = obj.offsetY;
                    if (offsetX === null || offsetX === undefined) {
                        offsetX = 0;
                    }
                    if (offsetY === null || offsetY === undefined) {
                        offsetY = 0;
                    }
                    obj.particles.push([
                        obj.x + obj.w / 2 + offsetX,
                        obj.y + obj.h / 2 + offsetY,
                        Math.PI * Math.random() * 2,
                        obj.particleLifespan,
                    ]);
                }
            } else {
                obj.time = obj.spawnRate;
            }
            for (let p in obj.particles) {
                // update particles
                let speed = obj.particleSpeed;
                if (obj.toDecay) {
                    speed *=
                        obj.particles[p][3] /
                        obj.particleLifespan;
                }
                obj.particles[p][0] +=
                    Math.cos(obj.particles[p][2]) * speed;
                obj.particles[p][1] +=
                    Math.sin(obj.particles[p][2]) * speed;
                obj.particles[p][3] -= dt;
                if (obj.particles[p][3] < 0) {
                    obj.particles.splice(p, 1);
                }
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['invpu']??[]).length; i++){
            const obj = sortedObstacles['invpu'][i];
            if (
                !player.god &&
                !player.dead &&
                intersectingCircleRect(player, obj)
            ) {
                player.powerups.inv = obj.amount; // todo: remove maxamount because uneeded
                player.powerups.invMax = obj.maxAmount;
                send({ powerups: player.powerups });
            }
            // inefficient if there's multiple obs; maybe we can have a var that activates this check at the end of the loop so that we never dup check
            if (player.dead && player.powerups.inv != 0) {
                player.powerups.inv = 0;
                send({ powerups: player.powerups });
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['gupu']??[]).length; i++){
            const obj = sortedObstacles['gupu'][i];
            if (
                !player.god &&
                !player.dead &&
                intersectingCircleRect(player, obj)
            ) {
                player.powerups.gunslinger = obj.state; // todo: remove maxamount because uneeded
                send({ powerups: player.powerups });
                if (!player.powerups.gunslinger) {
                    gunslingerCursors[player.id] = { x: NaN, y: NaN };
                    send({ gsc: undefined });
                }
            }
            // inefficient if there's multiple obs; maybe we can have a var that activates this check at the end of the loop so that we never dup check
            if (player.dead && player.powerups.gunslinger != 0) {
                player.powerups.gunslinger = 0;
                send({ powerups: player.powerups });
            }
            
        } 
        
        for(let i = 0; i < (sortedObstacles['ampu']??[]).length; i++){
            const obj = sortedObstacles['ampu'][i];
            if (
                !player.god &&
                !player.dead &&
                intersectingCircleRect(player, obj)
            ) {
                const lastPowerup = player.powerups.amogus;
                player.powerups.amogus = obj.state; // todo: remove maxamount because uneeded
                if(player.powerups.amogus === true && lastPowerup === false){
                    changeMusic('/sounds/drip.mp3');
                }
                send({ powerups: player.powerups });
            }
            // inefficient if there's multiple obs; maybe we can have a var that activates this check at the end of the loop so that we never dup check
            if (player.dead && player.powerups.amogus) {
                player.powerups.amogus = false;
                send({ powerups: player.powerups });
            }
            
        } 
        
        for(let i = 0; i < (sortedObstacles['grpu']??[]).length; i++){
            const obj = sortedObstacles['grpu'][i];
            if (
                !player.dead &&
                intersectingCircleRect(player, obj)
            ) {
                player.powerups.grapple.state = obj.state;
                send({ powerups: player.powerups });
            }
            if (player.dead && player.powerups.grapple) {
                player.powerups.grapple.state = 0;
                send({ powerups: player.powerups });
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['drpu']??[]).length; i++){
            const obj = sortedObstacles['drpu'][i];
            if (
                !player.god &&
                !player.dead &&
                intersectingCircleRect(player, obj)
            ) {
                let lastState = player.powerups.dragon.state;
                if (player.powerups.dragon.state == false) {
                    player.powerups.dragon.hp = 10;
                }
                player.powerups.dragon.state = obj.state;
                if (lastState != player.powerups.dragon.state) {
                    send({ powerups: player.powerups });
                }
            }
            if (player.dead) {
                player.powerups.dragon.state = false;
                send({ powerups: player.powerups });
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['revpu']??[]).length; i++){
            const obj = sortedObstacles['revpu'][i];
            if (
                !player.god &&
                !player.dead &&
                intersectingCircleRect(player, obj) &&
                obj.active != false
            ) {
                player.powerups.rev = obj.amount;
                obj.maxAmount = obj.amount;
                obj.active = false;
                obj.amount = 0;
                send({ powerups: player.powerups });
            }
            if (player.dead && obj.maxAmount) {
                obj.active = true;
                obj.amount = obj.maxAmount;
                obj.maxAmount = false;
            }
        }

        for(let i = 0; i < (sortedObstacles['hideplayer']??[]).length; i++){
            const obj = sortedObstacles['hideplayer'][i];
            if (!player.dead && intersectingCircleRect(player, obj)){
                window.hidePlayer = true;
            }
        }
        
        for(let i = 0; i < (sortedObstacles['breakable']??[]).length; i++){
            const obj = sortedObstacles['breakable'][i];
            if (obj.currentStrength < obj.maxStrength) {
                if (obj.lastBrokeTime === undefined) {
                    obj.lastBrokeTime = performance.now();
                }
                // obj.healTimer += dt;
                // if (obj.healTimer > obj.regenTime) {
                //     obj.currentStrength = obj.maxStrength;
                //     obj.healTimer = 0;
                // }
                if(performance.now()-obj.lastBrokeTime > obj.regenTime*1000){
                    obj.lastBrokeTime = performance.now();
                    obj.currentStrength = obj.maxStrength;
                }
            } 
        }

        for(let i = 0; i < (sortedObstacles['bouncybreakable']??[]).length; i++){
            const obj = sortedObstacles['bouncybreakable'][i];
            if (obj.currentStrength < obj.maxStrength) {
                if (obj.lastBrokeTime === undefined) {
                    obj.lastBrokeTime = performance.now();
                }
                // obj.healTimer += dt;
                // if (obj.healTimer > obj.regenTime) {
                //     obj.currentStrength = obj.maxStrength;
                //     obj.healTimer = 0;
                // }
                if(performance.now()-obj.lastBrokeTime > obj.regenTime*1000){
                    obj.lastBrokeTime = performance.now();
                    obj.currentStrength = obj.maxStrength;
                }
            } 
        }

        for(let i = 0; i < (sortedObstacles['poly-breakable']??[]).length; i++){
            const obj = sortedObstacles['poly-breakable'][i];
            if (obj.currentStrength < obj.maxStrength) {
                if (obj.lastBrokeTime === undefined) {
                    obj.lastBrokeTime = performance.now();
                }
                // obj.healTimer += dt;
                // if (obj.healTimer > obj.regenTime) {
                //     obj.currentStrength = obj.maxStrength;
                //     obj.healTimer = 0;
                // }
                if(performance.now()-obj.lastBrokeTime > obj.regenTime*1000){
                    obj.lastBrokeTime = performance.now();
                    obj.currentStrength = obj.maxStrength;
                }
            } 
        }

        for(let i = 0; i < (sortedObstacles['poly-bouncy-breakable']??[]).length; i++){
            const obj = sortedObstacles['poly-bouncy-breakable'][i];
            if (obj.currentStrength < obj.maxStrength) {
                if (obj.lastBrokeTime === undefined) {
                    obj.lastBrokeTime = performance.now();
                }
                // obj.healTimer += dt;
                // if (obj.healTimer > obj.regenTime) {
                //     obj.currentStrength = obj.maxStrength;
                //     obj.healTimer = 0;
                // }
                if(performance.now()-obj.lastBrokeTime > obj.regenTime*1000){
                    obj.lastBrokeTime = performance.now();
                    obj.currentStrength = obj.maxStrength;
                }
            } 
        }
        
        for(let i = 0; i < (sortedObstacles['demo']??[]).length; i++){
            const obj = sortedObstacles['demo'][i];
            obj.ind++;
            if (obj.ind >= obj.posArray.length - 1) {
                obj.ind = 0;
            }
            obj.x = obj.posArray[obj.ind].x;
            obj.y = obj.posArray[obj.ind].y;
            
        }
        
        for(let i = 0; i < (sortedObstacles['camera']??[]).length; i++){
            const obj = sortedObstacles['camera'][i];
            if (
                !player.usingCamera &&
                intersectingCircleRect(player, {
                    x: obj.triggerX,
                    y: obj.triggerY,
                    w: obj.triggerW,
                    h: obj.triggerH,
                })
            ) {
                player.usingCamera = true;
                player.x = obj.x;
                player.y = obj.y;
                // player.radius = obj.radius / 2;
    
                // toBeRadius = obj.radius / 2;
            } else {
                // player.usingCamera = false;
            }
            if (player.usingCamera) {
                player.x = obj.x;
                player.y = obj.y;
                player.xv = 0;
                player.yv = 0;
                toBeRadius = obj.radius;
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['timetrap']??[]).length; i++){
            const obj = sortedObstacles['timetrap'][i];
            // trap types:
            // death (default)
            // speed
            // size
            // normal
            // tp
            // safe
            // morph
            // conveyor?
            if (intersectingCircleRect(player, obj)) {
                if (player.dead) {
                    obj.time = 0;  
                } else {
                    obj.time += dt;
                    window.timers.push(
                        Math.max(0,Math.round(obj.maxTime - obj.time))
                    );
                    if (obj.time > obj.maxTime) {
                        if(obj.trapType === 'death') {
                            player.dead = true;
                            send({ dead: true });
                        } else if(obj.trapType === 'tp'){
                            player.x = obj.tpx;
                            player.y = obj.tpy;
                            player.grav.x = 0;
                            player.grav.y = 0;
                            player.xv = 0;
                            player.yv = 0;
                            // Tp whoosh sound
                            if (sw.currentTime > 0) {
                                sw.currentTime = 0;
                            }
                            sw.play();
                        } else if(obj.trapType === 'normal'){
                            boundPlayerObstacle(player, obj);
                        } else if(obj.trapType === 'safe'){
                            player.safe = true;
                        } else if(obj.trapType === 'morph'){
                            if(obj.fresh !== false){
                                triggerMorphEffects(obj.morphId, obstacles);
                                obj.fresh = false;
                            }
                        }
                    }
                    if(obj.trapType === 'speed'){
                        let t = Math.max(0,Math.min(1,obj.time/obj.maxTime));
                        player.speedMults.push(t*obj.speedMult+(1-t)*1);
                    } else if(obj.trapType === 'size'){
                        let t = Math.max(0,Math.min(1,obj.time/obj.maxTime));
                        toBeRadius = t*obj.radiusMult+(1-t)*24.5;
                    }
                }
            } else {
                if (obj.time > 0) {
                    obj.time -= obj.cdmult * dt;
                    if (obj.time < 0) {
                        obj.time = 0;
                    }
                    if(obj.trapType === 'morph'){
                        obj.fresh = true;
                    }
                }
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['tptrap']??[]).length; i++){
            const obj = sortedObstacles['tptrap'][i];
            if (
                !player.god &&
                intersectingCircleRect(player, obj) &&
                obj.resetTime != true
            ) {
                if (player.dead) {
                    obj.time = 0;
                } else {
                    obj.time += dt;
                    window.timers.push(
                        Math.round(obj.maxTime - obj.time)
                    );
                    if (obj.time > obj.maxTime) {
                        player.x = obj.tpx;
                        player.y = obj.tpy;
                        player.grav.x = 0;
                        player.grav.y = 0;
                        player.xv = 0;
                        player.yv = 0;
                        // Tp whoosh sound
                        if (sw.currentTime > 0) {
                            sw.currentTime = 0;
                        }
                        sw.play();
                        obj.resetTime = true;
                    }
                }
            } else if (obj.resetTime) {
                obj.time -= obj.cdmult * dt;
                if (obj.time < 0) {
                    obj.resetTime = false;
                }
            } else if (!player.god) {
                if (obj.time > 0) {
                    obj.time -= obj.cdmult * dt;
                    if (obj.time < 0) {
                        obj.time = 0;
                    }
                }
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['coindoor']??[]).length; i++){
            const obj = sortedObstacles['coindoor'][i];
            if (
                !player.god /* && intersectingCircleRect(player, obj)*/
            ) {
                if (
                    player.coins > 0 &&
                    player.coins !== undefined &&
                    obj.currentCoins > 0
                ) {
                    // obj.currentCoins -= player.coins;
                    obj.currentCoins = Math.max(
                        obj.coins - player.coins,
                        0
                    );
                    // player.coins = 0;
                    /*if(obj.currentCoins > 0){
                        for(let j in obstacles){
                            if(obstacles[j].type == 'coin' && obstacles[j].collected == true){
                                obstacles[j].collected = false;
                            }
                        }
                    }*/
                }
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['resetcoins']??[]).length; i++){
            const obj = sortedObstacles['resetcoins'][i];
            if (
                player.coins > 0 &&
                intersectingCircleRect(player, obj)
            ) {
                player.coins = 0;
                for (let o of obstacles) {
                    if (o.type === 'coin' || o.type === 'circle-coin') {
                        o.collected = false;
                    } else if (o.type === 'coindoor') {
                        o.currentCoins = Math.max(
                            o.coins - player.coins,
                            0
                        );
                    }
                }
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['ship']??[]).length; i++){
            const obj = sortedObstacles['ship'][i];
            if (
                !player.god &&
                intersectingCircleRect(player, obj)
            ) {
                if (obj.state == true) {
                    if (player.ship === false) {
                        player.ship = obj.shipAngle;
                        send({ ship: Math.round(player.ship * 1000) / 1000 });
                    }
                } else {
                    send({ ship: false });
                    player.ship = false;
                }
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['boost']??[]).length; i++){
            const obj = sortedObstacles['boost'][i];
            if (intersectingCircleRect(player, obj)) {
                player.xv *= 1.3;
                player.yv *= 1.3;
                if (player.ship !== false) {
                    player.shipSpeedMult *= 1.3;
                }
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['vinette']??[]).length; i++){
            const obj = sortedObstacles['vinette'][i];
            if (intersectingCircleRect(player, obj)) {
                insideVinette = true;
                window.io += (obj.o - window.io) * 0.03;
                window.ior += (obj.or - window.ior) * 0.03;
                window.iir += (obj.ir - window.iir) * 0.03;
                window.vinette = [window.iir, window.ior, window.io];
                window.vc = obj.vc;
            }
            
        }
        
        /*for(let i = 0; i < (sortedObstacles['timetrap']??[]).length; i++){
        /*    const obj = sortedObstacles['timetrap'][i];
        // wierd timetrap vinette
            if (intersectingCircleRect(player, obj) && obj.maxTime - obj.time < 2) {
                insideVinette = true;
                window.io += (1 - window.io) * 0.03;
                window.ior += (1/Math.max(4,obj.time*2) - window.ior) * 0.03;
                window.iir += (1/Math.max(4,obj.time*2) - window.iir) * 0.03;
                window.vinette = [window.iir, window.ior, window.io];
            }
        }*/
        for(let i = 0; i < (sortedObstacles['circlesnap']??[]).length; i++){
            const obj = sortedObstacles['circlesnap'][i];
            if (intersectingCircle(player, obj)) {
                if (insideCircleSnap) {
                    const obstacle = obj;
                    // calculating angle
                    const angle = Math.atan2(
                        player.y - obstacle.y,
                        player.x - obstacle.x
                    );
                    const point = {
                        x: obstacle.x + Math.cos(angle) * obstacle.radius,
                        y: obstacle.y + Math.sin(angle) * obstacle.radius,
                    };
                    // snapping to that pt
                    player.x = point.x;
                    player.y = point.y;
                }
                insideCircleSnap = true;
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['snap']??[]).length; i++){
            const obj = sortedObstacles['snap'][i];
            if (intersectingCircleRect(player, obj)) {
                insideSnap = true;
                if (
                    player.lastSnapX != undefined &&
                    player.lastSnapY != undefined &&
                    player.snapWait != undefined &&
                    player.snapWait < 0
                ) {
                    if (obj.snapX) {
                        const offset = (obj.x % obj.snapDistance)
                        if (
                            Math.round(player.x) >
                            Math.round(player.lastSnapX)
                        ) {
                            player.snapWait = obj.snapWait;
                            let crudeX = Math.ceil(
                                (player.x - offset) / obj.snapDistance
                            );
                            player.x = crudeX * obj.snapDistance + offset;
                        } else if (
                            Math.round(player.x) <
                            Math.round(player.lastSnapX)
                        ) {
                            player.snapWait = obj.snapWait;
                            let crudeX = Math.floor(
                                (player.x - offset) / obj.snapDistance
                            );
                            player.x = crudeX * obj.snapDistance + offset;
                        }
                        if (
                            Math.round(player.y) >
                                Math.round(player.lastSnapY) ||
                            Math.round(player.y) <
                                Math.round(player.lastSnapY)
                        ) {
                            let crudeX = Math.round(
                                (player.x - offset) / obj.snapDistance
                            );
                            player.x = crudeX * obj.snapDistance + offset;
                        }
                    }
    
                    if (obj.snapY) {
                        const offset = (obj.y % obj.snapDistance)
                        if (
                            Math.round(player.y) >
                            Math.round(player.lastSnapY)
                        ) {
                            player.snapWait = obj.snapWait;
                            let crudeY = Math.ceil(
                                (player.y - offset) / obj.snapDistance
                            );
                            player.y = crudeY * obj.snapDistance + offset;
                        } else if (
                            Math.round(player.y) <
                            Math.round(player.lastSnapY)
                        ) {
                            player.snapWait = obj.snapWait;
                            let crudeY = Math.floor(
                                (player.y - offset) / obj.snapDistance
                            );
                            player.y = crudeY * obj.snapDistance + offset;
                        }
                        if (
                            Math.round(player.x) >
                                Math.round(player.lastSnapX) ||
                            Math.round(player.x) <
                                Math.round(player.lastSnapX)
                        ) {
                            let crudeY = Math.round(
                                (player.y - offset) / obj.snapDistance
                            );
                            player.y = crudeY * obj.snapDistance + offset;
                        }
                    }
                } else if (
                    player.lastSnapX != undefined &&
                    player.lastSnapY != undefined &&
                    player.snapWait != undefined &&
                    player.snapWait > 0
                ) {
                    if (obj.snapX) {
                        player.x = player.lastSnapX;
                    }
                    if (obj.snapY) {
                        player.y = player.lastSnapY;
                    }
                }
                player.lastSnapX = player.x;
                player.lastSnapY = player.y;
                if (player.snapWait === undefined) {
                    player.snapWait = 0;
                } else {
                    player.snapWait -= dt;
                }
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['raxis']??[]).length; i++){
            const obj = sortedObstacles['raxis'][i];
            if (intersectingCircleRect(player, obj)) {
                if (obj.rx) {
                    xspeed = 0;
                }
                if (obj.ry) {
                    yspeed = 0;
                }
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['tornado']??[]).length; i++){
            const obj = sortedObstacles['tornado'][i];
            if (intersectingCircleRect(player, obj)) {
                player.x +=
                    Math.cos(Math.random() * 360) * obj.spinRadius;
                player.y +=
                    Math.sin(Math.random() * 360) * obj.spinRadius;
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['redirect']??[]).length; i++){
            const obj = sortedObstacles['redirect'][i];
            if (intersectingCircleRect(player, obj)) {
                if (obj.active != false) {
                    if (obj.cookie != undefined) {
                        document.cookie = obj.cookie;
                    }
                    window.onbeforeunload = function () {};
                    window.location.replace(obj.url);
                    obj.active = false;
                }
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['iframeplayer']??[]).length; i++){
            const obj = sortedObstacles['iframeplayer'][i];
            if (intersectingCircleRect(player, obj)) {
                if(!obj.active){
                    // create the iframe
                    const pl = document.getElementById('iframeplaceholder')
                    const iframe = document.createElement('iframe')
                    iframe.src = obj.url;
                    iframe.style.border = "5px solid black";
                    iframe.style.outline = "none";
                    iframe.style.imageRendering = "crisp-edges";
                    iframe.style.width = "100%";
                    iframe.style.height = "100%";
                    iframe.style.position = "absolute";
                    iframe.id = i;
                    pl.appendChild(iframe)
                    iframe.onload = () => {
                        iframe.contentWindow.focus()
                    };
                    window.closeMessages.push(obj.closeMessage);
                    window.closeIds.push(i);
                    obj.active = true;
                    // todo: fix a bug where resetting in an iframe causes u to b locked into any other one forever
                    if(!goingToNewWorld){
                        player.insideIframe = true;
                    }
                }
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['boostpad']??[]).length; i++){
            const obj = sortedObstacles['boostpad'][i];
            if (intersectingCircleRect(player, obj)) {
                if (Math.round(player.xv) > 0) {
                    player.xv = obj.speed;
                } else if (Math.round(player.xv) < 0) {
                    player.xv = -obj.speed;
                }
                if (Math.round(player.yv) > 0) {
                    player.yv = obj.speed;
                } else if (Math.round(player.yv) < 0) {
                    player.yv = -obj.speed;
                }
                if (player.ship !== false) {
                    player.shipSpeedMult *= obj.speedInc;
                }
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['size']??[]).length; i++){
            const obj = sortedObstacles['size'][i];
            let rad = player.radius;
            if (obj.size < player.defaultRadius) {
                rad = obj.size;
            }
            let playerCol = { x: player.x, y: player.y, radius: rad };
            if (intersectingCircleRect(playerCol, obj, true)) {
                if (toBeRadius != player.defaultRadius) {
                    // if we are intersecting with two speed modifiers, keep the bigger one
                    toBeRadius = Math.max(player.radius, obj.size);
                } else {
                    toBeRadius = obj.size;
                }
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['clone']??[]).length; i++){
            const obj = sortedObstacles['clone'][i];
            if (player.dead && obj.active == false) {
                obj.active = true;
            }
            if (
                intersectingCircleRect(player, obj) &&
                obj.active != false
            ) {
                obj.active = false;
                // can u add the abilites to crewate multiple clones
                let clone = JSON.parse(JSON.stringify(player));
                clone.x = player.x + obj.offsetX;
                clone.y = player.y + obj.offsetY;
                delete clone.clones;
                player.clones.push(clone);
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['grav']??[]).length; i++){
            const obj = sortedObstacles['grav'][i];
            insideGravZone = true;
            if (intersectingCircleRect(player, obj)) {
                player.grav.x += obj.dir.x * 2.5 * dt;
                player.grav.y += obj.dir.y * 2.5 * dt;
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['platformer']??[]).length; i++){
            const obj = sortedObstacles['platformer'][i];
            if (intersectingCircleRect(player, obj)) {
                insidePlatformer = true;
                // if (player.jumpcd <= 0.48) {
                //     if (obj.direction === 'down') {
                //         if (
                //             player.y + player.radius >=
                //             obj.y + obj.h
                //         ) {
                //             touchingGround = true;
                //             player.hasJump = true;
                //         }
                //     } else if (obj.direction === 'up') {
                //         if (player.y - player.radius <= obj.y) {
                //             touchingGround = true;
                //             player.hasJump = true;
                //         }
                //     } else if (obj.direction === 'left') {
                //         if (player.x - player.radius <= obj.x) {
                //             touchingGround = true;
                //             player.hasJump = true;
                //         }
                //     } else if (obj.direction === 'right') {
                //         if (
                //             player.x + player.radius >=
                //             obj.x + obj.w
                //         ) {
                //             touchingGround = true;
                //             player.hasJump = true;
                //         }
                //     }
                // }
                player.platgrav.x += obj.dir.x * dt * 2;
                player.platgrav.y += obj.dir.y * dt * 2;
                platformerFriction = obj.platformerFriction;
                if (obj.direction === 'down') {
                    platformerForce.y =
                        (obj.jumpHeight || 100) * 2;
                } else if (obj.direction === 'up') {
                    platformerForce.y =
                        -(obj.jumpHeight || 100) * 2;
                } else if (obj.direction === 'right') {
                    platformerForce.x =
                        (obj.jumpHeight || 100) * 2;
                } else if (obj.direction === 'left') {
                    platformerForce.x =
                        -(obj.jumpHeight || 100) * 2;
                }
                if (obj.variableJumpHeight){
                    variableJumpHeight = true;
                }
                platformerDir = obj.direction;
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['bonus']??[]).length; i++){
            const obj = sortedObstacles['bonus'][i];
            if(intersectingCircleRect(player, obj)){
                if(!obj.collected){
                    playAudio(bonusPath,0, 0.035,false)
                }
                obj.collected = true;
                
            }
            
        } 
        
        for(let i = 0; i < (sortedObstacles['circle-bonus']??[]).length; i++){
            const obj = sortedObstacles['circle-bonus'][i];
            if(intersectingCircle(player, obj)){
                if(!obj.collected){
                    playAudio(bonusPath,0,0.035,false)
                }
                obj.collected = true;
            }
            
        }
        
        for(let i = 0; i < (sortedObstacles['coin']??[]).length; i++){
            const obj = sortedObstacles['coin'][i];
            if (
                intersectingCircleRect(player, obj) &&
                !player.god
            ) {
                if (!obj.collected) {
                    if (player.coins === undefined) {
                        player.coins = 1;
                    } else {
                        player.coins++;
                    }
                    window.totalCoins++;
                }
                obj.collected = true;
            }
            // if(player.dead){
            // 	obj.collected = false;
            // }
            
        } 
        
        for(let i = 0; i < (sortedObstacles['circle-coin']??[]).length; i++){
            const obj = sortedObstacles['circle-coin'][i];
            if (intersectingCircle(player, obj) && !player.god) {
                if (!obj.collected) {
                    if (player.coins === undefined) {
                        player.coins = 1;
                    } else {
                        player.coins++;
                    }
                    window.totalCoins++;
                }
                obj.collected = true;
            }
            // if(player.dead){
            // 	obj.collected = false;
            // }
        }
        
        for(let i = 0; i < (sortedObstacles['spring']??[]).length; i++){
            const obj = sortedObstacles['spring'][i];
            // springs pulling the object
            if (obj.xv == undefined) {
                obj.xv = 0;
            }
            if (obj.yv == undefined) {
                obj.yv = 0;
            }
            let fric = 1 - obj.friction * dt * 60;
            obj.xv *= fric;
            obj.yv *= fric;
            for (let s in obj.springs) {
                const spring = obj.springs[s];
                const angle = Math.atan2(
                    spring.y - obj.y,
                    spring.x - obj.x
                );
                obj.xv += (Math.cos(angle) * spring.strength) / 10;
                obj.yv += (Math.sin(angle) * spring.strength) / 10;
            }
            const collisionSAT = returnIntersectingCircleRect(
                player,
                obj
            );
            if (collisionSAT != false) {
                // push the spring to make it not collide w/ player
                obj.x -= collisionSAT.overlapV.x;
                obj.y -= collisionSAT.overlapV.y;
            }
            obj.x += obj.xv * dt;
            obj.y += obj.yv * dt;
        }

        for(let i = 0; i < (sortedObstacles['switchgrav']??[]).length; i++){
            const obj = sortedObstacles['switchgrav'][i];
            insideGravZone = true;
            if (intersectingCircleRect(player, obj)) {
                player.grav.x +=
                    obj.dirs[obj.index].x * 2.5 * dt;
                player.grav.y +=
                    obj.dirs[obj.index].y * 2.5 * dt;
            }
            // simulating
            obj.timer -= dt;
            if (obj.timer <= 0) {
                obj.index++;
                if (obj.index >= obj.dirs.length) {
                    obj.index = 0;
                }
                obj.timer +=
                    obj.dirs[obj.index].time;
            }
            for(let ind = 0; ind < obj.dirs.length; ind++){
                if(Array.isArray(obj.dirs[ind].key)){
                    for(let i = 0; i < obj.dirs[ind].key.length; i++){
                        if(obj.dirs[ind].shouldTouchGround === true && touchingNormal === false){
                            continue;
                        }
                        if(window.input[obj.dirs[ind].key[i]] === true){
                            obj.index = ind;
                            obj.timer =
                    obj.dirs[obj.index].time;
                            break;
                        } else if(mouseMode === true){
                            let maxName = Math.abs(player.ySpeed) > Math.abs(player.xSpeed) ? 'y' : 'x';
                            if(obj.dirs[ind].key[i] === 'right' && player.xSpeed > 0 && maxName === 'x'){
                                obj.index = ind;
                                obj.timer =
                        obj.dirs[obj.index].time;
                                break;
                            } else if(obj.dirs[ind].key[i] === 'left' && player.xSpeed < 0 && maxName === 'x'){
                                obj.index = ind;
                                obj.timer =
                        obj.dirs[obj.index].time;
                                break;
                            } else if(obj.dirs[ind].key[i] === 'up' && player.ySpeed < 0 && maxName === 'y'){
                                obj.index = ind;
                                obj.timer =
                        obj.dirs[obj.index].time;
                                break;
                            } else if(obj.dirs[ind].key[i] === 'down' && player.ySpeed > 0 && maxName === 'y'){
                                obj.index = ind;
                                obj.timer =
                        obj.dirs[obj.index].time;
                                break;
                            }
                        }
                    }
                }
            }
        }
        
        for(let i = 0; i < (sortedObstacles['slip']??[]).length; i++){
            const obj = sortedObstacles['slip'][i];
            if (intersectingCircleRect(player, obj)) {
                insideSlip = true;
            }
        }
    }

    if (player.lastSnapX != undefined && !insideSnap) {
        player.lastSnapX = undefined;
        player.lastSnapY = undefined;
    }
    if (!insideSnap) {
        player.snapWait = 0;
    }
    // else if(player.lastSlipXV !== undefined){
    //     delete player.lastSlipXV;
    //     delete player.lastSlipYV;
    // }
    if (window.vinette != undefined && !insideVinette) {
        window.io += (0.5 - window.io) * 0.03;
        window.ior += (1 - window.ior) * 0.03;
        window.iir += (1 - window.iir) * 0.03;
        window.vinette = [window.iir, window.ior, window.io];
        window.vc = { r: 0, g: 0, b: 0 };
    }
    player.radius = toBeRadius;
    //window.renderScale = 24.5/me().renderRadius;
    //window.scaleChanged = true;
    //}
    
    if(player.insideNoRes !== insideNoRes){
        player.insideNoRes = insideNoRes;
    }
    if (player.zombies.length > 0) {
        if (inZombie) {
            // simulate zombies
            try {
                for (let i in player.zombies) {
                    let dx = player.zombies[i].x - player.x;
                    let dy = player.zombies[i].y - player.y;
                    let zangle = Math.atan2(dy, dx);
                    player.zombies[i].x -=
                        Math.cos(zangle) * player.zombies[i].speed * 5;
                    player.zombies[i].y -=
                        Math.sin(zangle) * player.zombies[i].speed * 5;
                    // collision with walls
                    if (
                        player.zombies[i].x - player.zombies[i].radius <
                        player.zombies[i].bound.x
                    ) {
                        player.zombies[i].x =
                            player.zombies[i].bound.x +
                            player.zombies[i].radius;
                    } else if (
                        player.zombies[i].x + player.zombies[i].radius >
                        player.zombies[i].bound.x + player.zombies[i].bound.w
                    ) {
                        player.zombies[i].x =
                            player.zombies[i].bound.x +
                            player.zombies[i].bound.w -
                            player.zombies[i].radius;
                    }
                    if (
                        player.zombies[i].y - player.zombies[i].radius <
                        player.zombies[i].bound.y
                    ) {
                        player.zombies[i].y =
                            player.zombies[i].bound.y +
                            player.zombies[i].radius;
                    } else if (
                        player.zombies[i].y + player.zombies[i].radius >
                        player.zombies[i].bound.y + player.zombies[i].bound.h
                    ) {
                        player.zombies[i].y =
                            player.zombies[i].bound.y +
                            player.zombies[i].bound.h -
                            player.zombies[i].radius;
                    }
                    // bounding with other zombies
                    for (let j in player.zombies) {
                        if (i > j) {
                            if (
                                Math.sqrt(
                                    (player.zombies[j].x -
                                        player.zombies[i].x) **
                                        2 +
                                        (player.zombies[j].y -
                                            player.zombies[i].y) **
                                            2
                                ) <
                                player.zombies[j].radius +
                                    player.zombies[i].radius
                            ) {
                                // push the weaker zombie (j) out
                                let zzangle = Math.atan2(
                                    player.zombies[j].y - player.zombies[i].y,
                                    player.zombies[j].x - player.zombies[i].x
                                );
                                let si = new SAT.Circle(
                                    new SAT.Vector(
                                        player.zombies[i].x,
                                        player.zombies[i].y
                                    ),
                                    player.zombies[i].radius
                                );
                                let sj = new SAT.Circle(
                                    new SAT.Vector(
                                        player.zombies[j].x,
                                        player.zombies[j].y
                                    ),
                                    player.zombies[j].radius
                                );
                                let zresp = new SAT.Response();
                                let collided = SAT.testCircleCircle(
                                    si,
                                    sj,
                                    zresp
                                );
                                if (collided) {
                                    player.zombies[i].x -= zresp.overlapV.x / 2;
                                    player.zombies[i].y -= zresp.overlapV.y / 2;
                                    player.zombies[j].x += zresp.overlapV.x / 2;
                                    player.zombies[j].y += zresp.overlapV.y / 2;
                                }
                            }
                        }
                    }
                    if (intersectingCircle(player.zombies[i], player)) {
                        player.dead = true;
                        player.zombies = [];
                    }
                }
            } catch (e) {}
        } else {
            // we're not in a zombie zone anymore -> we should delete zombies
            player.zombies = [];
        }
        if (player.dead) {
            player.zombies = [];
        }
    }

	if (player.dead) {
		let alive = false;
        for (const playerId of Object.keys(players)) {
            if (Number(playerId) === Number(selfId) || alive) continue;
            if (
                !players[playerId].dead &&
                intersectingCircle(player, players[playerId])
            ) {
                player.dead = false;
                send({ dead: false });
				alive = true;
            }
        }
    }

    if (player.dead && player.god) {
        player.dead = false;
        send({ dead: false });
    }

    if (insidePlatformer) {
        player.jumpcd -= dt;
        // platformer jumping
        if (player.jumping) {
            if (platformerForce.y !== 0) {
                player.platgrav.y +=
                    -player.jumpcd * dt * platformerForce.y * 100;
            } else {
                player.platgrav.x =
                    -player.jumpcd * dt * platformerForce.x * 100;
            }
            if (player.jumpcd <= 0) {
                player.jumping = false;
            }
        }
        if (player.jumpcd >= 0.48) touchingGround = false;
        
        let inputtingJump = false;
        if (platformerDir === 'down' && yspeed < 0) {
            inputtingJump = true;
        } else if (platformerDir === 'up' && yspeed > 0) {
            inputtingJump = true;
        } else if (platformerDir === 'right' && xspeed < 0) {
            inputtingJump = true;
        } else if (platformerDir === 'left' && xspeed > 0) {
            inputtingJump = true;
        }
        if (inputtingJump && player.hasJump && player.jumpcd <= 0) {
            player.hasJump = false;
            player.jumpcd = 0.5;
            player.jumping = true;
            player.platgrav.y = 0;
        } else if(variableJumpHeight && !inputtingJump){
            player.jumping = false;
        } else {
            if (platformerDir === 'up' || platformerDir === 'down') {
                yspeed = 0;
            } else {
                xspeed = 0;
            }
        }
        touchingGround = false;

        // grapple
        if (player.powerups.grapple.grappling) {
            if (input.up) {
                player.yv -= player.speed * dt;
            }
            if (input.down) {
                player.yv += player.speed * dt;
            }
        }
    } else if(player.hasJump !== false){
        player.hasJump = false;
    }

    if (player.forceMove && player.lastXV) {
        xspeed = player.lastXV;
        yspeed = player.lastYV;
        player.forceMove = false;
    }

    if(insideSlip){
        // if(touchingNormal){
        //     console.log('xd');
        //     player.canSlip = true;
        //     delete player.lastSlipXV;
        //     delete player.lastSlipYV;
        // }
        // if (
        //     player.lastSlipXV != undefined &&
        //     player.lastSlipYV != undefined
        // ) {
        //     player.xv = player.lastSlipXV;
        //     player.yv = player.lastSlipYV;
        //     xspeed = 0;
        //     yspeed = 0;
        // }
        // if((player.yv !== 0 || player.xv !== 0) && player.canSlip){
        //     player.canSlip = false;
        //     player.lastSlipXV = player.xv;
        //     player.lastSlipYV = player.yv;
        // }
        if(touchingNormal || player.slipX === undefined){
            player.canChangeDirections = true;
        }
        if(player.canChangeDirections){
            if(xspeed !== 0 || yspeed !== 0){
                player.canChangeDirections = false;
                player.slipX = xspeed;
                player.slipY = yspeed;
            }
        } else {
            // slip
            xspeed = player.slipX;
            yspeed = player.slipY;
        }
    } else if(player.slipX !== undefined){
        delete player.slipX;
        delete player.slipY;
    }

    if (player.forceStop) {
        xspeed = 0;
        yspeed = 0;
        player.xv = 0;
        player.yv = 0;
        player.forceStop = false;
    }

    player.xv += xspeed * dt;
    player.yv += yspeed * dt;
    player.xv += (player.grav.x + player.gxv + player.platgrav.x) * dt;
    player.yv += (player.grav.y + player.gyv + player.platgrav.y) * dt;

    player.xSpeed = xspeed;
    player.ySpeed = yspeed; // for pushables
    if (player.powerups.dragon.state) {
        player.xv *= Math.pow(0.95, dt * 60);
        player.yv *= Math.pow(0.95, dt * 60);
    } else {
        // fine
        player.xv *= Math.pow(player.fric, dt * 60);
        player.yv *= Math.pow(player.fric, dt * 60);
        // player.xv = xspeed * dt;
        // player.yv = yspeed * dt;
    }
    player.grav.x *= Math.pow(0.7, dt * 60);
    player.grav.y *= Math.pow(0.7, dt * 60);
    player.platgrav.x *= Math.pow(platformerFriction, dt * 60);
    player.platgrav.y *= Math.pow(platformerFriction, dt * 60);
    player.gxv *= Math.pow(0.97, dt * 60);
    player.gyv *= Math.pow(0.97, dt * 60);

    if (player.dead && !player.deadMove) {
        player.xv = 0;
        player.yv = 0;
    } else if (player.deadMove) {
        player.deadMove = false;
    }
    if (player.usingCamera) {
        player.xv = 0;
        player.yv = 0;
    }
    player.x += player.xv * (60 * dt);
    player.y += player.yv * (60 * dt);
    // player.xv = 0;
    // player.yv = 0;
    if (!player.god && !outside) {
        if (player.x - player.radius <= 0) {
            player.x = player.radius;
            player.xv = 0;
            if (player.jumpcd <= 0) {
                touchingGround = true;
                player.hasJump = true;
            }
            touchingNormal = true;
        }
        if (player.x + player.radius >= arena.width) {
            player.x = arena.width - player.radius;
            player.xv = 0;
            if (player.jumpcd <= 0) {
                touchingGround = true;
                player.hasJump = true;
            }
            touchingNormal = true;
        }
        if (player.y - player.radius <= 0) {
            player.y = player.radius;
            player.yv = 0;
            if (player.jumpcd <= 0) {
                touchingGround = true;
                player.hasJump = true;
            }
            touchingNormal = true;
        }
        if (player.y + player.radius >= arena.height) {
            player.y = arena.height - player.radius;
            player.yv = 0;
            if (player.jumpcd <= 0) {
                touchingGround = true;
                player.hasJump = true;
            }
            touchingNormal = true;
        }
    }

    if (player.clones !== undefined && player.clones.length > 0) {
        for (let c in player.clones) {
            if (player.clones[c].dead == true) {
                player.dead = true;
                player.clones = [];
                break;
            }
            boundPlayerCircularObstacle(player, {
                x: player.clones[c].x,
                y: player.clones[c].y,
                radius: player.clones[c].radius,
                type: 'lmao no one cares',
            });
        }
    }

    if (insideGolf === false) {
        player.golfangle = undefined;
        player.golfCooldown = 0;
    }

    if (insideFrictionChanger === false) {
        player.fric = 0.4;
    }

    player.sat = new SAT.Circle(
        new SAT.Vector(player.x, player.y),
        player.radius
    );

    if (player.dead && player.deathTimer != undefined) {
        player.deathTimer = undefined;
    }
    touchingNormal = false;
    // trail physics
    // if (player.xv > 6) {
    // player.historyInterval --;
    // if(player.historyInterval < 0){
    //     player.historyInterval += 2;
    //     player.history.push({ x: player.renderX, y: player.renderY });
    //     if (player.history.length > player.historyLen) {
    //         player.history.shift() // maybe w ecan optimize
    //         // since it will shift every farame
    //     }

    // }
    // }
    if (window.recordInputs) {
        window.recordedInputs.push({
            x: Math.round(player.x),
            y: Math.round(player.y),
        });
    }
}

window.rotatePoint = function (
    pointX,
    pointY,
    ogx,
    ogy,
    angle,
    distToPivot = 0
) {
    angle = (angle * Math.PI) / 180.0;
    // xangledir * (dist) - yangledir * (dist) + ogx
    //yangledir * (dist) + yangledir * (dist) + ogy
    // ogx = pointX - oroginX
    let originX = ogx + Math.cos(angle) * distToPivot;
    let originY = ogy + Math.sin(angle) * distToPivot;
    return {
        x:
            Math.cos(angle) * (pointX - originX) -
            Math.sin(angle) * (pointY - originY) +
            originX,
        y:
            Math.sin(angle) * (pointX - originX) +
            Math.cos(angle) * (pointY - originY) +
            originY,
    };
};

function boundPlayerRotatingObstacle(player, obstacle) {
	// if (player.zMode) return;
    const centerX = obstacle.x;
    const centerY = obstacle.y;
    const refX = obstacle.x - obstacle.w / 2;
    const refY = obstacle.y - obstacle.h / 2;
    const oldAngle = obstacle.angle;
    obstacle.angle = degToRad(obstacle.angle);
    const unrotatedCircleX =
        Math.cos(-obstacle.angle) * (player.x - centerX) -
        Math.sin(-obstacle.angle) * (player.y - centerY) +
        centerX;
    const unrotatedCircleY =
        Math.sin(-obstacle.angle) * (player.x - centerX) +
        Math.cos(-obstacle.angle) * (player.y - centerY) +
        centerY;
    obstacle.angle = oldAngle;

    let closestX, closestY;

    if (unrotatedCircleX < refX) {
        closestX = refX;
    } else if (unrotatedCircleX > refX + obstacle.w) {
        closestX = refX + obstacle.w;
    } else {
        closestX = unrotatedCircleX;
    }

    if (unrotatedCircleY < refY) {
        closestY = refY;
    } else if (unrotatedCircleY > refY + obstacle.h) {
        closestY = refY + obstacle.h;
    } else {
        closestY = unrotatedCircleY;
    }

    const rClosestX =
        Math.cos(obstacle.angle) * (closestX - centerX) -
        Math.sin(obstacle.angle) * (closestY - centerY) +
        centerX;
    const rClosestY =
        Math.sin(obstacle.angle) * (closestX - centerX) +
        Math.cos(obstacle.angle) * (closestY - centerY) +
        centerY;

    if (
        findDistance(unrotatedCircleX, unrotatedCircleY, closestX, closestY) <
        player.radius
    ) {
        if (player.jumpcd <= 0 && obstacle.canJump != false) {
            touchingGround = true;
            player.hasJump = true;
        }
        touchingNormal = true;
        if (
            obstacle.type === 'rotate-normal' ||
            obstacle.type === 'rotate-pause'
        ) {
            const oldX = obstacle.x;
            const oldY = obstacle.y;
            obstacle.x -= obstacle.w / 2;
            obstacle.y -= obstacle.h / 2;
            const points = [
                rotatePoint(
                    obstacle.x,
                    obstacle.y,
                    obstacle.pivotX,
                    obstacle.pivotY,
                    obstacle.angle,
                    obstacle.distToPivot
                ),
                rotatePoint(
                    obstacle.x + obstacle.w,
                    obstacle.y,
                    obstacle.pivotX,
                    obstacle.pivotY,
                    obstacle.angle,
                    obstacle.distToPivot
                ),
                rotatePoint(
                    obstacle.x + obstacle.w,
                    obstacle.y + obstacle.h,
                    obstacle.pivotX,
                    obstacle.pivotY,
                    obstacle.angle,
                    obstacle.distToPivot
                ),
                rotatePoint(
                    obstacle.x,
                    obstacle.y + obstacle.h,
                    obstacle.pivotX,
                    obstacle.pivotY,
                    obstacle.angle,
                    obstacle.distToPivot
                ),
            ];
            if (window.rpoints == undefined) window.rpoints = [];
            // points.forEach((p) => window.rpoints.push(p))
            obstacle.x = oldX;
            obstacle.y = oldY;
            const polySat = new SAT.Polygon(new SAT.Vector(0, 0), [
                ...points.map(({ x, y }) => new SAT.Vector(x, y)),
            ]);
            const res = new SAT.Response();
            const collision = SAT.testPolygonCircle(polySat, player.sat, res);
            if (collision) {
                player.x += res.overlapV.x;
                player.y += res.overlapV.y;
            }
        }
        if (
            obstacle.type === 'rotate-lava' ||
            obstacle.type === 'rotate-pause-lava'
        ) {
            if (obstacle.canCollide) {
                const oldX = obstacle.x;
                const oldY = obstacle.y;
                const oldPivot = { x: obstacle.pivotX, y: obstacle.pivotY };
                // obstacle.pivotX += Math.cos(obstacle.angle) * obstacle.distToPivot;
                // obstacle.pivotY += Math.sin(obstacle.angle) * obstacle.distToPivot;
                obstacle.x -= obstacle.w / 2;
                obstacle.y -= obstacle.h / 2;
                // obstacle.x += Math.cos(obstacle.angle) * (obstacle.distToPivot / 2);
                // obstacle.y += Math.sin(obstacle.angle) * (obstacle.distToPivot / 2);
                const points = [
                    rotatePoint(
                        obstacle.x,
                        obstacle.y,
                        obstacle.pivotX,
                        obstacle.pivotY,
                        obstacle.angle,
                        obstacle.distToPivot
                    ),
                    rotatePoint(
                        obstacle.x + obstacle.w,
                        obstacle.y,
                        obstacle.pivotX,
                        obstacle.pivotY,
                        obstacle.angle,
                        obstacle.distToPivot
                    ),
                    rotatePoint(
                        obstacle.x + obstacle.w,
                        obstacle.y + obstacle.h,
                        obstacle.pivotX,
                        obstacle.pivotY,
                        obstacle.angle,
                        obstacle.distToPivot
                    ),
                    rotatePoint(
                        obstacle.x,
                        obstacle.y + obstacle.h,
                        obstacle.pivotX,
                        obstacle.pivotY,
                        obstacle.angle,
                        obstacle.distToPivot
                    ),
                ];
                obstacle.x = oldX;
                obstacle.y = oldY;
                obstacle.pivotX = oldPivot.x;
                obstacle.pivotY = oldPivot.y;
                const polySat = new SAT.Polygon(new SAT.Vector(0, 0), [
                    ...points.map(({ x, y }) => new SAT.Vector(x, y)),
                ]);
                const res = new SAT.Response();
                const collision = SAT.testPolygonCircle(
                    polySat,
                    player.sat,
                    res
                );
                if (collision) {
                    player.x += res.overlapV.x;
                    player.y += res.overlapV.y;
                }
            }
            if (player.dead) return;
            player.dead = true;
        }
        if (obstacle.type == 'rotatingsafe') {
            return true;
        }
        if (obstacle.type == 'rotate-tp') {
            if (player.dead) return;
            player.x = obstacle.tpx;
            player.y = obstacle.tpy;
            player.grav.x = 0;
            player.grav.y = 0;
            player.xv = 0;
            player.yv = 0;
            // Tp whoosh sound
            if (sw.currentTime > 0) {
                sw.currentTime = 0;
            }
            sw.play();
        }
        if (obstacle.type == 'rotatingspeedtrap') {
            if (player.dead) return;
            if (
                Math.sqrt(player.xv ** 2 + player.yv ** 2) < obstacle.minSpeed
            ) {
                if (obstacle.tpx != undefined && obstacle.tpy != undefined) {
                    player.x = obstacle.tpx;
                    player.y = obstacle.tpy;
                    player.grav.x = 0;
                    player.grav.y = 0;
                    player.xv = 0;
                    player.yv = 0;
                } else {
                    player.dead = true;
                    send({ dead: true });
                }
            }
            if (obstacle.maxSpeed != undefined) {
                if (
                    Math.sqrt(player.xv ** 2 + player.yv ** 2) >
                    obstacle.maxSpeed
                ) {
                    if (
                        obstacle.tpx != undefined &&
                        obstacle.tpy != undefined
                    ) {
                        player.x = obstacle.tpx;
                        player.y = obstacle.tpy;
                        player.grav.x = 0;
                        player.grav.y = 0;
                        player.xv = 0;
                        player.yv = 0;
                    } else {
                        player.dead = true;
                        send({ dead: true });
                    }
                }
            }
        }
    }
    return false;
}

function findDistance(x1, y1, x2, y2) {
    const a = Math.abs(x1 - x2);
    const b = Math.abs(y1 - y2);
    return Math.sqrt(a * a + b * b);
}

// function findClosestPointOvalCircle(circle, oval) {
//     console.log(oval);
//     const distX = circle.x - oval.x;
//     const distY = circle.y - oval.y;
//     const angle = Math.atan2(distY, distX);
//     const closestPoint = {
//         x: circle.x - Math.cos(angle) * circle.radius,
//         y: circle.y - Math.sin(angle) * circle.radius,
//     };
//     const closestDist = {
//         x: closestPoint.x - oval.x,
//         y: closestPoint.y - oval.y,
//     };
//     // scaling down oval.radius2 to oval.radius
//     closestDist.y *= oval.radius / oval.radius2;
//     // circle-point collision
//     if (Math.sqrt(closestDist.x ** 2 + closestDist.y ** 2) < oval.radius) {
//         // collision
//         // finding the correct angle for ovals is a lot more tricky than just cos and sin for x and y. There's a standard formula of ab/sqrt((a*cos(angle))^2+(b*sin(angle))^2) where the x is k*cos(angle) and y is k*sin(angle).
//         // btw k simplifies to just radius for circles
//         const k =
//             (oval.radius * oval.radius2) /
//             Math.sqrt(
//                 (oval.radius2 * Math.cos(angle)) ** 2 +
//                     (oval.radius * Math.sin(angle)) ** 2
//             );
//         const ellipsePoint = {
//             x: oval.x + k * Math.cos(angle),
//             y: oval.y + k * Math.sin(angle),
//         };
//         return {
//             x: ellipsePoint.x,
//             y: ellipsePoint.y,
//         };
//     }
//     return false;
// }

function boundPlayerOval(player, obstacle) {
	// if (player.zMode) return;
    /*if(!(Math.abs(player.x-obstacle.x) < player.radius*2+obstacle.radius*2 && Math.abs(player.y-obstacle.y) < player.radius*2+obstacle.radius2*2)){
        return;
    }*/
    // const distX = player.x - obstacle.x;
    // const distY = player.y - obstacle.y;
    // const i = Math.atan2(distY, distX);
    // const k =
    //     (obstacle.radius * obstacle.radius2) /
    //     Math.sqrt(
    //         (obstacle.radius2 * Math.cos(i)) ** 2 +
    //             (obstacle.radius * Math.sin(i)) ** 2
    //     );
    // const closestPoint = {
    //     x: k * Math.cos(i) + obstacle.x,
    //     y: k * Math.sin(i) + obstacle.y,
    // };
    // //obstacle.testPoint = closestPoint;
    // const i2 = Math.atan2(distY, distX) + 0.001;
    // const k2 =
    //     (obstacle.radius * obstacle.radius2) /
    //     Math.sqrt(
    //         (obstacle.radius2 * Math.cos(i2)) ** 2 +
    //             (obstacle.radius * Math.sin(i2)) ** 2
    //     );
    // const closestPoint2 = {
    //     x: k2 * Math.cos(i2) + obstacle.x,
    //     y: k2 * Math.sin(i2) + obstacle.y,
    // };
    // // now just find the slope of those two points
    // // y2-y1/x2-x1
    // const t = Math.atan2(
    //     closestPoint2.y - closestPoint.y,
    //     closestPoint2.x - closestPoint.x
    // );

    // //const angleToCenter = Math.atan2(k*Math.sin(i),k*Math.cos(i));
    // //const t = angleToCenter+Math.PI/2;
    // const closestLine = [
    //     [
    //         closestPoint.x + Math.cos(t) * obstacle.radius,
    //         closestPoint.y + Math.sin(t) * obstacle.radius2,
    //     ],
    //     [
    //         closestPoint.x - Math.cos(t) * obstacle.radius,
    //         closestPoint.y - Math.sin(t) * obstacle.radius2,
    //     ],
    // ];
    // // todo: calculate slope instead of just snapping. This will break for very big ovals.
    // for (let point of closestLine) {
    //     point[0] = Math.max(
    //         obstacle.x - obstacle.radius,
    //         Math.min(obstacle.x + obstacle.radius, point[0])
    //     );
    //     point[1] = Math.max(
    //         obstacle.y - obstacle.radius2,
    //         Math.min(obstacle.y + obstacle.radius2, point[1])
    //     );
    // }
    // const closestPointOnPlayer = {
    //     x: player.x - Math.cos(i) * player.radius,
    //     y: player.y - Math.sin(i) * player.radius,
    // };
    // if (
    //     !lineCircleCollide(
    //         closestLine[0],
    //         closestLine[1],
    //         player,
    //         player.radius
    //     )
    // ) {
    //     return;
    // }

    // i'm just gonna approx it as a polygon for now ...
    // maybe later post-release ill make it better
    if (
        Math.abs(player.x-obstacle.x) > obstacle.radius + player.radius ||
        Math.abs(player.y-obstacle.y) > obstacle.radius2 + player.radius
    ) {
        return;
    }
    if (!obstacle.sat) {
        const ovalPoly = [];
        const points = Math.sqrt(obstacle.radius * obstacle.radius2) * 10;
        for (let i = 0; i < Math.PI * 2; i += (Math.PI * 2) / points) {
            const k =
                (obstacle.radius * obstacle.radius2) /
                Math.sqrt(
                    (obstacle.radius2 * Math.cos(i)) ** 2 +
                        (obstacle.radius * Math.sin(i)) ** 2
                );
            ovalPoly.push([
                obstacle.x + k * Math.cos(i),
                obstacle.y + k * Math.sin(i),
            ]);
        }
        obstacle.sat = new SAT.Polygon(new SAT.Vector(0, 0), [
            ...ovalPoly.map(([x, y]) => new SAT.Vector(x, y)),
        ]);
    }
    const res = new SAT.Response();
    const collision = SAT.testPolygonCircle(obstacle.sat, player.sat, res);
    debug.cTests[0]++;
    if (collision) {
        if (obstacle.type === 'oval') {
            player.x += res.overlapV.x;
            player.y += res.overlapV.y;
        } else if (obstacle.type === 'lava-oval') {
            if (obstacle.canCollide) {
                player.x += res.overlapV.x;
                player.y += res.overlapV.y;
            }
            player.dead = true;
        }
        
        if (player.jumpcd <= 0) {
            touchingGround = true;
            player.hasJump = true;
        }
        touchingNormal = true;
    }
    /*const obstacletype = obstacle.type;
    const distX = player.x - obstacle.x;
	const distY = player.y - obstacle.y;
    const angle = Math.atan2(distY,distX);
    const closestPoint = {
        x: player.x-Math.cos(angle)*player.radius,
        y: player.y-Math.sin(angle)*player.radius
    }
    
    const closestDist = {
        x: closestPoint.x-obstacle.x,
        y: closestPoint.y-obstacle.y,
    }
    // scaling down obstacle.radius2 to obstacle.radius
    closestDist.y *= obstacle.radius/obstacle.radius2;
    // circle-point collision

    // projected point of player onto the oval. This determines the closest point and thus we can check for collision
    const k = (obstacle.radius)*(obstacle.radius2)/Math.sqrt((obstacle.radius2*Math.cos(angle))**2+(obstacle.radius*Math.sin(angle))**2);
    if(Math.sqrt((ellipsePoint.x-player.x)**2+(ellipsePoint.y-player.y)**2)){
        // collision
        // finding the correct angle for ovals is a lot more tricky than just cos and sin for x and y. There's a standard formula of ab/sqrt((a*cos(angle))^2+(b*sin(angle))^2) where the x is k*cos(angle) and y is k*sin(angle).
        // btw k simplifies to just radius for circles
        
    }*/
}

function boundPlayerCircularObstacle(player, obstacle) {
	// if (player.zMode) return;
    const obstacletype = obstacle.type;
    if (
        obstacletype === 'growingcircle' ||
        obstacletype === 'circle-sentry' ||
        obstacletype === 'circle-turret-sentry' ||
        obstacletype === 'circle-lava' ||
        obstacletype === 'circle-tp' ||
        obstacletype === 'growinglavacircle' ||
        obstacletype == 'circle-safe' || obstacletype === 'circularpushbox'
    ) {
        obstacle.radius = obstacle.r;
    } // wtf dont comment this out we need it >:c or else circularnormals dont work idk how
    if (obstacletype == 'circle-door' && obstacle.active == false) {
        return false;
    }
    let OnSafe = false;
    const distX = player.x - obstacle.x;
    const distY = player.y - obstacle.y;
    if (
        distX * distX + distY * distY <
        (player.radius + obstacle.radius) * (player.radius + obstacle.radius)
    ) {
        const magnitude = Math.sqrt(distX * distX + distY * distY) || 1;
        const normal = { x: distX / magnitude, y: distY / magnitude };
        if (obstacletype !== 'circle-safe') {
            if (
                obstacletype === 'circle-hollow' ||
                obstacletype === 'circle-hollow-lava'
            ) {
                if (
                    distX * distX + distY * distY >
                    (obstacle.innerRadius - player.radius) ** 2
                ) {
                    if (player.jumpcd <= 0) {
                        touchingGround = true;
                        player.hasJump = true;
                    }
                    touchingNormal = true;
                    // checking if ur inside or outside
                    const outsideDist = Math.abs(
                        distX * distX +
                            distY * distY -
                            (player.radius + obstacle.radius) *
                                (player.radius + obstacle.radius)
                    );
                    const insideDist = Math.abs(
                        distX * distX +
                            distY * distY -
                            (obstacle.radius - player.radius) ** 2
                    );
                    if (insideDist < outsideDist) {
                        // we're inside; just invert the push
                        player.x =
                            obstacle.x +
                            (obstacle.innerRadius - player.radius) * normal.x;
                        player.y =
                            obstacle.y +
                            (obstacle.innerRadius - player.radius) * normal.y;
                    } else {
                        player.x =
                            obstacle.x +
                            (obstacle.radius + player.radius) * normal.x;
                        player.y =
                            obstacle.y +
                            (obstacle.radius + player.radius) * normal.y;
                    }

                    if (obstacletype === 'circle-hollow-lava') {
                        player.dead = true;
                    }
                }
            } else if (
                obstacletype === 'circle-slice' ||
                obstacletype === 'circle-slice-lava'
            ) {
                // bounding players in 2 diff ways
                // 1: checking if players should be bounded by circle
                // 2nd check will cover cases when player is on the edges of the circle
                const angle = Math.atan2(
                    player.y - obstacle.y,
                    player.x - obstacle.x
                );
                if (
                    checkAngleBetween(
                        angle,
                        obstacle.startAngle,
                        obstacle.endAngle
                    )
                ) {
                    if (obstacletype === 'circle-slice-lava') {
                        boundPlayerCircularObstacle(player, {
                            ...obstacle,
                            type: 'circle-lava',
                            r: obstacle.radius,
                        });
                    } else {
                        boundPlayerCircularObstacle(player, {
                            ...obstacle,
                            type: 'circle-normal',
                        });
                    }
                }

                // 2: bounding players in the edges by polygon
                if (obstacletype === 'circle-slice-lava') {
                    boundPlayerPolygon(player, {
                        ...obstacle.startPolygon,
                        type: 'poly-lava',
                    });
                    boundPlayerPolygon(player, {
                        ...obstacle.endPolygon,
                        type: 'poly-lava',
                    });
                } else {
                    boundPlayerPolygon(player, obstacle.startPolygon);
                    boundPlayerPolygon(player, obstacle.endPolygon);
                }
            } else if (
                obstacletype === 'circle-hollow-slice' ||
                obstacletype === 'circle-hollow-slice-lava'
            ) {
                // same thing for circle-hollow-slice except we copy both things of code >:)
                // bounding players in 2 diff ways
                // 1: checking if players should be bounded by circle
                // 2nd check will cover cases when player is on the edges of the circle
                const angle = Math.atan2(
                    player.y - obstacle.y,
                    player.x - obstacle.x
                );
                if (
                    checkAngleBetween(
                        angle,
                        obstacle.startAngle,
                        obstacle.endAngle
                    )
                ) {
                    if (
                        distX * distX + distY * distY >
                        (obstacle.innerRadius - player.radius) ** 2
                    ) {
                        if (player.jumpcd <= 0) {
                            touchingGround = true;
                            player.hasJump = true;
                        }
                        touchingNormal = true;
                        // checking if ur inside or outside
                        const outsideDist = Math.abs(
                            distX * distX +
                                distY * distY -
                                (player.radius + obstacle.radius) *
                                    (player.radius + obstacle.radius)
                        );
                        const insideDist = Math.abs(
                            distX * distX +
                                distY * distY -
                                (obstacle.radius - player.radius) ** 2
                        );
                        if (insideDist < outsideDist) {
                            // we're inside; just invert the push
                            player.x =
                                obstacle.x +
                                (obstacle.innerRadius - player.radius) *
                                    normal.x;
                            player.y =
                                obstacle.y +
                                (obstacle.innerRadius - player.radius) *
                                    normal.y;
                        } else {
                            player.x =
                                obstacle.x +
                                (obstacle.radius + player.radius) * normal.x;
                            player.y =
                                obstacle.y +
                                (obstacle.radius + player.radius) * normal.y;
                        }

                        if (obstacletype === 'circle-hollow-slice-lava') {
                            player.dead = true;
                        }
                    }
                }

                // 2: bounding players in the edges by polygon
                if (obstacletype === 'circle-hollow-slice-lava') {
                    boundPlayerPolygon(player, {
                        ...obstacle.startPolygon,
                        type: 'poly-lava',
                    });
                    boundPlayerPolygon(player, {
                        ...obstacle.endPolygon,
                        type: 'poly-lava',
                    });
                } else {
                    boundPlayerPolygon(player, obstacle.startPolygon);
                    boundPlayerPolygon(player, obstacle.endPolygon);
                }
            } else if (obstacletype === 'circle-tp') {
                if (player.jumpcd <= 0) {
                    touchingGround = true;
                    player.hasJump = true;
                }
                touchingNormal = true;
                player.x = obstacle.tpx;
                player.y = obstacle.tpy;
                player.grav.x = 0;
                player.grav.y = 0;
                player.xv = 0;
                player.yv = 0;
                // Tp whoosh sound
                if (sw.currentTime > 0) {
                    sw.currentTime = 0;
                }
                sw.play();
            } else {
                if (player.jumpcd <= 0) {
                    touchingGround = true;
                    player.hasJump = true;
                }
                touchingNormal = true;
                player.x =
                    obstacle.x + (obstacle.radius + player.radius) * normal.x;
                player.y =
                    obstacle.y + (obstacle.radius + player.radius) * normal.y;
            }
        } else {
            OnSafe = true;
        }
        if (obstacletype === 'circle-bounce' || obstacletype === 'growing') {
            if (player.jumpcd <= 0) {
                touchingGround = true;
                player.hasJump = true;
            }
            touchingNormal = true;
            // enemy growing
            const angle = Math.atan2(normal.y, normal.x);
            player.xv = Math.cos(angle) * obstacle.effect;
            player.yv = Math.sin(angle) * obstacle.effect;
        }
        if (!player.dead) {
            if (obstacletype === 'circle-lava') {
                if (player.jumpcd <= 0) {
                    touchingGround = true;
                    player.hasJump = true;
                }
                touchingNormal = true;
                player.dead = true;
            }
            else if (obstacletype === 'growinglavacircle') {
                if (player.jumpcd <= 0) {
                    touchingGround = true;
                    player.hasJump = true;
                }
                touchingNormal = true;
                player.dead = true;
            }
        }
    }
    return OnSafe;
}

function rectOverlaps(ax1,ax2,ay1,ay2,bx1,bx2,by1,by2) {
	// no horizontal overlap
    if(ax1 > bx2 || ax2 < bx1) return false;

	// no vertical overlap
    if(ay1 > by2 || by1 > ay2) return false;

	return true;
}

const tmp = [0, 0];

function lineCircleCollide(a, b, circle, radius, nearest) {
    // dont add nearest param when using dis fyunction

    // basic optimization by making square bounding boxes
    if(!rectOverlaps(
        circle.x-radius,
        circle.x+radius,
        circle.y-radius,
        circle.y+radius,
        Math.min(a[0],b[0]),
        Math.max(a[0],b[0]),
        Math.min(a[1],b[1]),
        Math.max(a[1],b[1]),
    )){
        return false;
    }

    if (pointCircleCollide(a, circle, radius)) {
        if (nearest) {
            nearest[0] = a[0];
            nearest[1] = a[1];
        }
        return true;
    }
    if (pointCircleCollide(b, circle, radius)) {
        if (nearest) {
            nearest[0] = b[0];
            nearest[1] = b[1];
        }
        return true;
    }

    let x1 = a[0],
        y1 = a[1],
        x2 = b[0],
        y2 = b[1],
        cx = circle.x,
        cy = circle.y;

    let dx = x2 - x1;
    let dy = y2 - y1;

    let lcx = cx - x1;
    let lcy = cy - y1;
    // projection
    let dLen2 = dx * dx + dy * dy;
    let px = dx;
    let py = dy;
    if (dLen2 > 0) {
        let dp = (lcx * dx + lcy * dy) / dLen2;
        px *= dp;
        py *= dp;
    }

    if (!nearest) nearest = tmp;
    nearest[0] = x1 + px;
    nearest[1] = y1 + py;

    let pLen2 = px * px + py * py;

    return (
        pointCircleCollide(nearest, circle, radius) &&
        pLen2 <= dLen2 &&
        px * dx + py * dy >= 0
    );
}

function boundPlayerPolygon(player, polygon) {
	// if (player.zMode) return;
    let touching = false;
    let OnSafe = false;
    for (let i = 0; i < polygon.points.length; i++) {
        if (i === 0) {
            if (
                lineCircleCollide(
                    polygon.points[polygon.points.length - 1],
                    polygon.points[0],
                    player,
                    player.radius
                ) &&
                polygon.type !== 'poly-rail'
            ) {
                touching = true;
                break;
            }
        } else if (i === polygon.points.length) {
            if (
                lineCircleCollide(
                    polygon.points[i],
                    polygon.points[0],
                    player,
                    player.radius
                )
            ) {
                touching = true;
                break;
            }
        } else {
            if (
                lineCircleCollide(
                    polygon.points[i - 1],
                    polygon.points[i],
                    player,
                    player.radius
                )
            ) {
                touching = true;
                break;
            }
        }
    }
    if (!touching && polygon.type != 'poly-safe') {
        return;
    } else if (polygon.type === 'polygon' && player.dead === false) {
        // enemy polygon
        return true;
    }
    const polySat = new SAT.Polygon(new SAT.Vector(0, 0), [
        ...polygon.points.map(([x, y]) => new SAT.Vector(x, y)),
    ]);
    const res = new SAT.Response();
    const collision = SAT.testPolygonCircle(polySat, player.sat, res);
    if (collision) {
        if (polygon.type !== 'poly-safe') {
            if (player.jumpcd <= 0) {
                touchingGround = true;
                player.hasJump = true;
            }
            touchingNormal = true;
        }
        if (polygon.type === 'poly-lava') {
            player.dead = true;
            player.xv = 0;
            player.yv = 0;
        }
        if (polygon.type === 'poly-safe') {
            OnSafe = true;
        } else if (polygon.type === 'poly-rail') {
            if (
                intersectingCirclePoint(player, polygon.startPoint) ||
                intersectingCirclePoint(player, polygon.endPoint)
            ) {
                return;
            }
            let angle =
                (Math.atan2(res.overlapV.y, res.overlapV.x) - Math.PI) %
                (Math.PI * 2);
            let point = (player.x +=
                Math.cos(angle) * player.radius + res.overlapV.x);
            player.y += Math.sin(angle) * player.radius + res.overlapV.y;
        } else if (polygon.type === 'poly-bounce') {
            player.x += res.overlapV.x;
            player.y += res.overlapV.y;
            const angle = Math.atan2(res.overlapV.y, res.overlapV.x); // angle of contact
            player.xv = Math.cos(angle) * polygon.effect;
            player.yv = Math.sin(angle) * polygon.effect;
        }
        else if (polygon.type === 'poly-breakable') {
            if(polygon.currentStrength <= 0){
                return;
            }
            player.x += res.overlapV.x;
            player.y += res.overlapV.y;
            polygon.lastBrokeTime = performance.now();
            polygon.time -= dt;
            if (polygon.time < 0) {
                polygon.time += polygon.timer;
                polygon.currentStrength--;
            }
        }
        else if (polygon.type === 'poly-bouncy-breakable') {
            if(polygon.currentStrength <= 0){
                return;
            }
            const angle = Math.atan2(res.overlapV.y, res.overlapV.x); // angle of contact
            player.xv = Math.cos(angle) * polygon.effect;
            player.yv = Math.sin(angle) * polygon.effect;
            polygon.lastBrokeTime = performance.now();
            polygon.currentStrength--;
        } else {
            player.x += res.overlapV.x;
            player.y += res.overlapV.y;
        }
        if (polygon.type === 'poly-tp') {
            player.x = polygon.tpx;
            player.y = polygon.tpy;
            player.grav.x = 0;
            player.grav.y = 0;
            player.xv = 0;
            player.yv = 0;
            // Tp whoosh sound
            if (sw.currentTime > 0) {
                sw.currentTime = 0;
            }
            sw.play();
        }
        else if (polygon.type === 'poly-wb') {
            const angle = Math.atan2(res.overlapV.y, res.overlapV.x); // angle of contact
            const xVel = player.xv;
            const yVel = player.yv;
            if (player.shiftTimer > 0 && player.shiftTimer < 0.2) {
                const force =
                    polygon.baseEffect +
                    /*((player.shiftTimer) / 0.5))*/ polygon.effect;
                player.xv =
                    Math.cos(angle) * (xVel * 20) + Math.cos(angle) * force;
                player.yv =
                    Math.sin(angle) * (yVel * 20) + Math.sin(angle) * force;
                console.log(player.shiftTimer, force);
                console.log('xv', player.xv, 'yv', player.yv);
                console.log('init', xVel, yVel);
                console.log(angle);
                player.shiftTimer = Infinity;
            }
        }
    }
    return OnSafe;
}

function intersectingCirclePoint(circle, point) {
    return (
        Math.sqrt((circle.x - point.x) ** 2 + (circle.y - point.y) ** 2) <
        circle.radius
    );
}

function rectContainsCircle(rect, circle) {
	let dx = Math.max(Math.abs(circle.x - rect.x), Math.abs(rect.x + rect.w - circle.x));
	let dy = Math.max(Math.abs(circle.y - rect.y + rect.h), Math.abs(rect.y - circle.y));
	return (circle.radius * circle.radius) >= (dx * dx) + (dy * dy)
}

function boundPlayerObstacle(player, obstacle) {
	// if (player.zMode) return;
    const distX = Math.abs(player.x - obstacle.x - obstacle.w / 2);
    const distY = Math.abs(player.y - obstacle.y - obstacle.h / 2);
    if (
        distX < obstacle.w / 2 + player.radius &&
        distY < obstacle.h / 2 + player.radius
    ) {
        // const playerSat = new SAT.Circle(new SAT.Vector(player.x, player.y), player.radius);
        // console.log('testing for collision', obstacle.type)
        const res = new SAT.Response();
        obstacle.sat = new SAT.Box(
            new SAT.Vector(obstacle.x, obstacle.y),
            obstacle.w,
            obstacle.h
        ).toPolygon();
		// let oldSat = player.sat;
        const collision = SAT.testPolygonCircle(obstacle.sat, player.sat, res);
		// player.sat = oldSat;
        if (collision) {
			// console.log(obstacle.type)
            if (
                (obstacle.type === 'lava' ||
                    obstacle.type == 'lavadoor' ||
                    obstacle.type === 'lavamove' ||
                    obstacle.type === 'growinglava' ||
                    obstacle.type === 'switchlava' ||
                    obstacle.type === 'move-pause-lava' ||
                    obstacle.type === 'morphlavamove') &&
                !player.dead
            ) {
                player.dead = true;
            }
			
			
            if (obstacle.collidable != false) {

                if (obstacle.type === 'push') {
                    if (
                        obstacle.xv === undefined ||
                        obstacle.yv === undefined
                    ) {
                        obstacle.xv = 0;
                        obstacle.yv = 0;
                    }
                    if (obstacle.dir === 'left') {
                        if (
                            res.overlapV.x < 0 &&
                            res.overlapV.y === 0 &&
                            player.xSpeed > 0 /*player.input.right*/
                        ) {
                            obstacle.xv = 300;
                            player.x += 300 * dt;
                            obstacle.x += 300 * dt;
                            obstacle.pushing = true;
                        }
                        // if (obstacle.xv < 0) {
                        // player.x -= obstacle.xv * dt;
                        // }
                    }
                    if (obstacle.dir === 'right') {
                        if (
                            res.overlapV.x > 0 &&
                            res.overlapV.y === 0 &&
                            player.xSpeed < 0 /*player.input.left*/
                        ) {
                            obstacle.xv = -300;
                            player.x -= 300 * dt;
                            obstacle.x -= 300 * dt;
                            obstacle.pushing = true;
                        }
                    }
                    if (obstacle.dir === 'up') {
                        if (
                            res.overlapV.x === 0 &&
                            res.overlapV.y < 0 &&
                            player.ySpeed > 0 /*player.input.down*/
                        ) {
                            // console.log('pushing down')
                            obstacle.yv = 300;
                            player.y += 300 * dt;
                            obstacle.y += 300 * dt;
                            obstacle.pushing = true;
                        }
                    }
                    if (obstacle.dir === 'down') {
                        if (
                            res.overlapV.x === 0 &&
                            res.overlapV.y > 0 &&
                            player.ySpeed < 0 /*player.input.up*/
                        ) {
                            obstacle.yv = -300;
                            player.y -= 300 * dt;
                            obstacle.y -= 300 * dt;
                            obstacle.pushing = true;
                        }
                    }
                }
                const xVel = player.xv;
                const yVel = player.yv;
                if (
                    obstacle.type !== 'trans' ||
                    (obstacle.type === 'trans' && obstacle.collide)
                ) {
                    if (
                        obstacle.type !== 'lava' ||
                        (obstacle.type === 'lava' && obstacle.canCollide)
                    ) {
                        // collision
                        if (obstacle.collidable != false) {
                            if (obstacle.type == 'spring') {
                                player.x += res.overlapV.x / 4;
                                player.y += res.overlapV.y / 4;
                            } else {
								let mult = 1;
								// if (obstacle.type === 'move' && obstacle.alongWith) {
								// 	mult = 0.75;
								// }
                                player.x += res.overlapV.x// * mult;
                                player.y += res.overlapV.y //* mult;
                            }
                        }

                        if (
                            Math.abs(res.overlapV.y) > Math.abs(res.overlapV.x)
                        ) {
                            if (obstacle.type === 'push' && !obstacle.pushing) {
                                player.yv = obstacle.yv * dt; //* 1/dt;
                                // console.log(player.yv, 'yv');
                            } else {
                                player.yv = 0;
                            }
                        } else {
                            if (obstacle.type === 'push' && !obstacle.pushing) {
                                player.xv = obstacle.xv * dt; //* 1/dt;
                                // console.log(player.xv, 'xv');
                            } else {
                                player.xv = 0;
                            }
                        }

                        touchingNormal = true;
                        if (player.jumpcd <= 0 && obstacle.canJump != false) {
                            touchingGround = true;
                            player.hasJump = true;
                        }
                    }
                }
                const angle = Math.atan2(res.overlapV.y, res.overlapV.x); // angle of contact
                if (
                    player.shiftTimer > 0 &&
                    player.shiftTimer < 0.2 &&
                    obstacle.type === 'wb'
                ) {
                    const force =
                        obstacle.baseEffect +
                        /*((player.shiftTimer) / 0.5))*/ obstacle.effect;
                    player.xv =
                        Math.cos(angle) * (xVel * 20) + Math.cos(angle) * force;
                    player.yv =
                        Math.sin(angle) * (yVel * 20) + Math.sin(angle) * force;
                    console.log(player.shiftTimer, force);
                    console.log('xv', player.xv, 'yv', player.yv);
                    console.log('init', xVel, yVel);
                    player.shiftTimer = Infinity;
                }
                // } else if (player.shiftTimer <= 1 / 60 && player.shiftTimer < 0.5 && obstacle.type === 'wb') {
                // 	player.shiftTimer = Infinity;
                // }
                if (obstacle.type === 'bounce') {
                    player.xv = Math.cos(angle) * obstacle.effect;
                    player.yv = Math.sin(angle) * obstacle.effect;
                }

                else if (obstacle.type === 'wallboost') {
                    player.xv *= 1.8;
                    player.yv *= 1.8;
                    if (player.ship !== false) {
                        player.shipSpeedMult *= 1.8;
                    }
                }

                else if (obstacle.type === 'breakable') {
                    obstacle.lastBrokeTime = performance.now();
                    obstacle.time -= dt;
                    if (obstacle.time < 0) {
                        obstacle.time += obstacle.timer;
                        obstacle.currentStrength--;
                    }
                }

                else if (obstacle.type === 'bouncybreakable') {
                    player.xv = Math.cos(angle) * obstacle.effect;
                    player.yv = Math.sin(angle) * obstacle.effect;
                    obstacle.lastBrokeTime = performance.now();
                    obstacle.currentStrength--;
                }

                if (
                    obstacle.type === 'move' ||
                    obstacle.type === 'move-pause' ||
					(obstacle.type === 'morphmove' && obstacle.active) ||
                    obstacle.type === 'deadpusher'
                ) {
                    // amogus code
					if (obstacle.alongWith == false) {
	                    if (Math.abs(obstacle.xv) > Math.abs(player.yv)) {
	                        player.grav.x = obstacle.xv;
	                    }
	                    if (Math.abs(obstacle.yv) > Math.abs(player.xv)) {
	                        player.grav.y = obstacle.yv;
	                    }
					} else {
						player.grav.x = obstacle.xv;
						player.grav.y = obstacle.yv;
					}
                    // player.xv = obstacle.xv;
                    // player.yv = obstacle.yv;
                    
                    // if(Math.abs(obstacle.xv) > Math.abs(player.xv)){
                    //     player.xv = obstacle.xv;
                    // }
                    // if(Math.abs(obstacle.yv) > Math.abs(player.yv)){
                    //     player.yv = obstacle.yv;
                    // }
                } // +=?
            }
        }
        // return;
    }
    if (obstacle.type === 'push') {
        simulatePushingObstacle(obstacle, dt);
    }
}

window.runEnemyPhysics = function (
    enemy,
    arena,
    dt,
    obstacles,
    player,
    players,
    simIndex = null// only used for combo enemies
) {
    let calcsizings = false;
    mainLoop: for (let i = 0; i < enemy.length; i++) {
        if(simIndex !== null && i !== simIndex){
            continue;
        }
        const ene = enemy[i];
        if (ene.simulateBound) {
            let touching = false;
            for (const playerId of Object.keys(players)) {
                const p = players[playerId];
                if (intersectingCircleRect(p, ene.simulateBound, true)) {
                    touching = true;
                    break;
                }
            }
            if (!touching) {
                continue;
            }
        }
        const enetype = ene.type;
        if (ene.deadTimer != undefined) {
            ene.deadTimer -= dt;
            if (ene.deadTimer < 0) {
                ene.deadTimer = undefined;
            }
        }
        if (enetype === 'enemygrav') {
            // for (let j = 0; j < enemy.length; j++) {
            //     const enemy2 = enemy[j];
            //     let dx = enemy2.x - ene.type.x;
            //     let dy = enemy2.y - ene.type.y;
            //     let force = 0;
            //     if (dx > 0 || dy > 0) {
            //         force = 1 / Math.sqrt(dx ** 2 + dy ** 2) ** 2;
            //         console.log(enemy[j].type);
            //     }
            //     //enemy2.x = enemy[i].x;
            //     //enemy2.y = enemy[i].y;
            //     let angle = Math.atan2(dy, dx);
            //     enemy[j].xv -=
            //         Math.cos(angle) *
            //         Math.min(
            //             force * 1000000 * ene.auraStrength,
            //             0.3 * ene.auraStrength
            //         ) *
            //         dt *
            //         60;
            //     enemy[j].yv -=
            //         Math.sin(angle) *
            //         Math.min(
            //             force * 1000000 * ene.auraStrength,
            //             0.3 * ene.auraStrength
            //         ) *
            //         dt *
            //         60;
            // }
            for(let e of enemy){
                if(intersectingCircle(e, ene)){
                    const dx = e.x-ene.x;
                    const dy = e.y-ene.y;
                    if(dx === 0 && dy === 0){
                        continue;
                    }
                    const angle = Math.atan2(dy,dx);
                    const vel = Math.sqrt(e.xv**2+e.yv**2);
                    e.xv = Math.cos(angle)*vel//*ene.auraStrength+e.xv*(1-ene.auraStrength);
                    e.yv = Math.sin(angle)*vel//*ene.auraStrength+e.yv*(1-ene.auraStrength);
                }
            }
        } else if (enetype === 'rchange') {
            calcsizings = true;
            for (let j = 0; j < enemy.length; j++) {
                const enemy2 = enemy[j];
                if (enemy2.type == 'rchange') continue;
                if (
                    Math.sqrt(
                        (enemy2.x - ene.x) ** 2 + (enemy2.y - ene.y) ** 2
                    ) <
                    ene.radius + enemy2.radius
                ) {
                    enemy[j].collidedWSizer = i;
                }
            }
        } else if (enetype === 'selfcollide') {
            for (let e in enemy) {
                const enemy2 = enemy[e];
                let dist = Math.sqrt(
                    (enemy2.x - ene.x) ** 2 + (enemy2.y - ene.y) ** 2
                );
                if (
                    dist < ene.radius + enemy2.radius &&
                    dist != 0 &&
                    enemy2.type != 'spawn'
                ) {
                    //colliding
                    let angle = Math.atan2(enemy2.y - ene.y, enemy2.x - ene.x);
                    let magnitude = (50000 / dist) * dt;
                    enemy[i].xv -= Math.cos(angle) * magnitude;
                    enemy[i].yv -= Math.sin(angle) * magnitude;
                    if (ene.xv > ene.speed) {
                        enemy[i].xv = ene.speed;
                    } else if (ene.xv < -ene.speed) {
                        enemy[i].xv = -ene.speed;
                    }
                    if (ene.yv > ene.speed) {
                        enemy[i].yv = ene.speed;
                    } else if (ene.yv < -ene.speed) {
                        enemy[i].yv = -ene.speed;
                    }
                    enemy[e].xv += Math.cos(angle) * magnitude;
                    enemy[e].yv += Math.sin(angle) * magnitude;
                }
            }
        } else if (ene.type == 'spawn') {
            enemy[i].spawnTimer -= dt;
            if (ene.spawnTimer <= 0) {
                if (Array.isArray(ene.spawnTime)) {
                    enemy[i].timeIndex++;
                    if (ene.timeIndex >= ene.spawnTime.length) {
                        enemy[i].timeIndex = 0;
                    }
                    enemy[i].spawnTimer += ene.spawnTime[ene.timeIndex];
                } else {
                    enemy[i].spawnTimer += ene.spawnTime;
                }
                enemy[i].seed =
                    Math.sin(ene.seed++) * 10000 -
                    Math.floor(Math.sin(ene.seed++) * 10000);
                let angle = (ene.seed * 10) % (Math.PI * 2);
                if (ene.shootAngles) {
                    angle = ene.shootAngles[ene.shootIndex];
                    enemy[i].shootIndex++;
                    if (ene.shootIndex >= ene.shootAngles.length) {
                        enemy[i].shootIndex = 0;
                    }
                }
                enemy[i].spawnIndex++;
                if (ene.spawnIndex >= ene.spawnParams.length) {
                    enemy[i].spawnIndex = 0;
                }
                let data;
                let spawnData;
                if(Array.isArray(ene.spawnParams)){
                    spawnData = ene.spawnParams[ene.spawnIndex];
                } else {
                    spawnData = ene.spawnParams;
                }
                if (
                    angle != 'none' &&
                    spawnData.type !== 'enemyobstacle'
                ) {
                    if (Array.isArray(ene.spawnParams)) {
                        data = JSON.parse(JSON.stringify(ene.spawnParams[ene.spawnIndex]));
                        enemy.push(
                            new Enemy(JSON.parse(JSON.stringify({
                                angle: angle,
                                x: ene.spawnParams[ene.spawnIndex].x || ene.x,
                                y: ene.spawnParams[ene.spawnIndex].y || ene.y,
                                xv:
                                    ene.spawnParams[ene.spawnIndex].xv ||
                                    Math.cos(angle) *
                                        ene.spawnParams[ene.spawnIndex].speed,
                                yv:
                                    ene.spawnParams[ene.spawnIndex].yv ||
                                    Math.sin(angle) *
                                        ene.spawnParams[ene.spawnIndex].speed,
                                bound:
                                    ene.spawnParams[ene.spawnIndex].bound ||
                                    ene.bound,
                                ...ene.spawnParams[ene.spawnIndex]
                            })))
                        );
                    } else {
                        data = JSON.parse(JSON.stringify(ene.spawnParams));
                        enemy.push(
                            new Enemy(JSON.parse(JSON.stringify({
                                angle: angle,
                                x: ene.spawnParams.x || ene.x,
                                y: ene.spawnParams.y || ene.y,
                                xv:
                                    ene.spawnParams.xv ||
                                    Math.cos(angle) * ene.spawnParams.speed,
                                yv:
                                    ene.spawnParams.yv ||
                                    Math.sin(angle) * ene.spawnParams.speed,
                                bound: ene.spawnParams.bound || ene.bound,
                                ...ene.spawnParams
                            })))
                        );
                    }
                    if(data.parentId && data.parentId > 0){
                        enemy[enemy.length-1].parentId = data.parentId;
                        const po = data.pushIndexOffset||0;
                        enemy[enemy.length-1].pushIndex = ene.spawnPushIndex+po;
                    }
                    if(data.childId && data.childId > 0){
                        if(data.type !== 'rotatearoundparent'){
                            enemy[enemy.length-1].childId = data.childId;    
                        }
                        const po = data.pushIndexOffset||0;
                        enemy[enemy.length-1].pushIndex = ene.spawnPushIndex+po;
                    }
                    if(data.switchChildId){
                        enemy[enemy.length-1].switchChildId = data.switchChildId;
                        enemy[enemy.length-1].switchChildIndex = 0;
                        enemy[enemy.length-1].switchChildTimer = enemy[enemy.length-1].switchChildId[0][1];
                    }
                    if(data.switchParentId){
                        enemy[enemy.length-1].switchParentId = data.switchParentId;
                        enemy[enemy.length-1].switchParentIndex = 0;
                        enemy[enemy.length-1].switchParentTimer = enemy[enemy.length-1].switchParentId[0][1];
                    }
                    if(data.simulateBound){
                        enemy[enemy.length-1].simulateBound = data.simulateBound;
                    }
                
                    ene.spawnPushIndex++;
                }
            }
        } else if(ene.type === 'combo'){
            for(let t = 0; t < ene.enemyTypes.length; t++){
                ene.type = ene.enemyTypes[t];
                runEnemyPhysics(enemy,arena,dt,obstacles,player,players,i);
            }
            ene.type = 'combo';
        } else if (ene.type === 'repel') {
            for (let e of enemy) {
                if (e === ene) continue;
                const edist = Math.sqrt(
                    (e.x - ene.x) ** 2 + (e.y - ene.y) ** 2
                );
                if (edist < ene.minDistance) {
                    //const eangle = (Math.atan2(e.y-ene.y,e.x-ene.x) + Math.PI / 2) % (Math.PI*2);
                    let dx = e.x - ene.x;
                    let dy = e.y - ene.y;
                    const eangle = Math.atan2(dy, dx);
                    ene.angle = eangle;
                    //ene.xv -= Math.cos(eangle) * ene.speed;
                    //ene.yv -= Math.sin(eangle) * ene.speed;
                    ene.xv +=
                        (Math.cos(eangle) * ene.repelAmount * 100) /
                        Math.pow(edist, ene.repelPower);
                    ene.yv +=
                        (Math.sin(eangle) * ene.repelAmount * 100) /
                        Math.pow(edist, ene.repelPower);
                    // capping at ene.speed
                    const curSpeed = Math.sqrt(ene.xv ** 2 + ene.yv ** 2);
                    const spRatio = ene.speed / curSpeed;
                    ene.xv *= spRatio;
                    ene.yv *= spRatio;
                }
            }
        } else if (ene.type === 'rotatearoundparent') {
            if (ene.chId) {
                ene.rotateAngle += dt * ene.rotateSpeed;
                //console.log(ene.rotateSpeed);
                for (let e of enemy) {
                    if (
                        e.parentId &&
                        e.parentId === ene.chId &&
                        ene.pushIndex === e.pushIndex
                    ) {
                        ene.x =
                            e.x + Math.cos(ene.rotateAngle) * ene.rotateDist;
                        ene.y =
                            e.y + Math.sin(ene.rotateAngle) * ene.rotateDist;
                    }
                }
            }
        }  else if(ene.type === 'sticky') {
            // SCRAPPED ENEMY
            // DO NOT TRY AND USE OR ADD TO EDITOR UNTIL FIXED
            // making sure that pointers match up
            if(!ene.sortedPointers){
                for(let e = 0; e < enemy.length; e++){
                    // if(ene.stickAll === false && ene.stickTypes[enemy[e].type] === undefined){
                    //     console.log('continuing');
                    //     continue;
                    // }
                    if(enemy[e].stickParentIds && enemy[e].stickParentIds[ene.uniqueStickId] === true){
                        ene.stickParent = enemy[e];
                    } else if(enemy[e].stickFollowerIds && enemy[e].stickFollowerIds[ene.uniqueStickId] === true) {
                        ene.stickFollowers[e] = {enemy: enemy[e], offsetX: enemy[e].x - ene.x, offsetY: enemy[e].y - ene.y};
                        ene.stickFollowers[e].enemy.bound = {x: -1E99, y: -1E99, w: 2E99, h: 2E99};
                        ene.stickFollowers[e].enemy.speed = 0;
                    }
                }
                ene.sortedPointers = true;
            }
            
            // check collisions for new enemies/ player
            if(ene.stickToPlayer && !ene.stickParent && intersectingCircle(ene, player)){
                ene.stickParent = player;
                if(ene.toBoundStick === true){
                    const angle = Math.atan2(ene.y - player.y, ene.x - player.x);
                    ene.x = player.x + Math.cos(angle) * ene.radius;
                    ene.y = player.y + Math.sin(angle) * ene.radius;
                }
                ene.stickOffset = {x: ene.x - player.x, y: ene.y - player.y};
                ene.bound = {x: -1E99, y: -1E99, w: 2E99, h: 2E99};
                ene.speed = 0;
            }
            
            if(ene.stickToEnemy){
                for(let e = 0; e < enemy.length; e++){
                    if(intersectingCircle(enemy[e], ene) && ene.uniqueStickId !== enemy[e].uniqueStickId && ene.stickFollowers[e] === undefined){
                        if(!ene.stickParent){
                            ene.stickParent = enemy[e];
                            if(ene.toBoundStick === true){
                                const angle = Math.atan2(ene.y - enemy[e].y, ene.x - enemy[e].x);
                                ene.x = enemy[e].x + Math.cos(angle) * ene.radius;
                                ene.y = enemy[e].y + Math.sin(angle) * ene.radius;
                            }
                            ene.stickOffset = {x: ene.x - enemy[e].x, y: ene.y - enemy[e].y};
                            
                            
                            ene.speed = 0;
                            if(enemy[e].type === 'sticky'){
                                ene.type = 'normal';
                                continue mainLoop;
                            }
                            //ene.bound = {x: -1E99, y: -1E99, w: 2E99, h: 2E99};
                        } else if(enemy[e].x !== ene.stickParent.x || enemy[e].y !== ene.stickParent.y) {
                            ene.stickFollowers[e] = {enemy: enemy[e], offsetX: enemy[e].x - ene.x, offsetY: enemy[e].y - ene.y};
                            if(ene.toBoundStick === true){
                                const angle = Math.atan2(enemy[e].y - ene.y, enemy[e].x - ene.x);
                                enemy[e].x = ene.x + Math.cos(angle) * ene.radius;
                                enemy[e].y = ene.y + Math.sin(angle) * ene.radius;
                            }
                            
                            ene.stickFollowers[e].enemy.speed = 0;
                            if(enemy[e].type === 'sticky'){
                                enemy[e].type = 'normal';
                                continue mainLoop;
                            }
                            //ene.stickFollowers[e].enemy.bound = {x: -1E99, y: -1E99, w: 2E99, h: 2E99};
                        }
                    }
                }
            }
            
            // make enemies stick
            if(ene.stickParent){
                ene.x = ene.stickParent.x + ene.stickOffset.x;
                ene.y = ene.stickParent.y + ene.stickOffset.y;
            }
            
            if(Object.keys(ene.stickFollowers).length !== 0){
                for(let key in ene.stickFollowers){
                    const followerData = ene.stickFollowers[key];
                    followerData.enemy.x = ene.x + followerData.offsetX;
                    followerData.enemy.y = ene.y + followerData.offsetY;
                }
            }
            
            // for(let e = 0; e < enemy.length; e++){
            //     if(ene.stickFollowers[e] !== undefined){
            //         continue;
            //     }
            //     if(ene.stickParentId === e || e === i){
            //         continue;
            //     }
            //     if(intersectingCircle(ene, enemy[e]) === true){
            //         if(!ene.stickParent){
            //             if(ene.stickAll === false && !ene.stickTypes.includes(enemy[e].type)){
            //                 continue;
            //             }
            //             ene.stickParent = enemy[e];
            //             if(ene.toBoundStick === true){
            //                 const angle = Math.atan2(ene.y - ene.stickParent.y, ene.x - ene.stickParent.x);
            //                 ene.x = enemy[e].x + Math.cos(angle) * ene.radius;
            //                 ene.y = enemy[e].y + Math.sin(angle) * ene.radius;
            //             }
            //             ene.stickOffset = {x: ene.x - ene.stickParent.x, y: ene.y - ene.stickParent.y};
            //             ene.stickParentId = e;
            //             continue mainLoop;
            //         }
            //         if(ene.toBoundStick === true){
            //             const angle = Math.atan2(enemy[e].y - ene.y, enemy[e].x - ene.x);
            //             ene.stickFollowers[e] = {enemy: enemy[e], offsetX: ene.x + Math.cos(angle) * ene.radius, offsetY: ene.y + Math.sin(angle) * ene.radius};
            //         } else {
            //             ene.stickFollowers[e] = {enemy: enemy[e], offsetX: enemy[e].x - ene.x, offsetY: enemy[e].y - ene.y};
            //         }
            //     }
            // }

            // if(Object.keys(ene.stickFollowers).length !== 0){
            //     for(let key in ene.stickFollowers){
            //         ene.stickFollowers[key].enemy.x = ene.x + ene.stickFollowers[key].offsetX;
            //         ene.stickFollowers[key].enemy.y = ene.y + ene.stickFollowers[key].offsetY;
            //     }
            // }
            
            // if(ene.stickParent){
            //     ene.x = ene.stickParent.x + ene.stickOffset.x;
            //     ene.y = ene.stickParent.y + ene.stickOffset.y;
            //     continue mainLoop;
            // } else {
            //     if(ene.stickToPlayer === true){
            //         if(intersectingCircle(ene, player)){
            //             ene.stickParent = player;
            //             if(ene.toBoundStick === true){
            //                 const angle = Math.atan2(ene.y - ene.stickParent.y, ene.x - ene.stickParent.x);
            //                 ene.x = ene.x + Math.cos(angle) * ene.stickParent.radius;
            //                 ene.y = ene.y + Math.sin(angle) * ene.stickParent.radius;
            //             }
            //             ene.stickOffset = {x: ene.x - ene.stickParent.x, y: ene.y - ene.stickParent.y};
            //             continue mainLoop;
            //         }
            //     }
                
            //     if(ene.stickToEnemy === true){
            //     }
            // }
        } else if(ene.type === 'killenemy') {
            //simulateNormalEnemy(ene, dt);
            enemy.forEach((e, ind) => {
                // no battle royale
                if(e.type === 'killenemy'){
                    return;
                }
                if(ene.killAll === false && !ene.killTypes.includes(e.type)){
                    return;
                }
                if(intersectingCircle(e,ene)){
                    if(ene.toKillParent === true || e.parentId !== ene.childId || ene.childId === undefined){
                        enemy.splice(ind, 1);
                    }
                }
            })
        } else if (ene.type == 'enemyobstacle') {
            const actualRadius = ene.radius;
            ene.radius = ene.boundRadius;
            simulateNormalEnemy(ene, dt);
            ene.radius = actualRadius;
            for (let o of obstacles) {
                if (o.enemyChildId === ene.obstacleParentId) {
                    if (o.type.startsWith('poly')) {
                        if (enemy[i].originalPoints === undefined) {
                            // deep array copy
                            enemy[i].originalPoints = JSON.parse(
                                JSON.stringify(
                                    o.points.map((a) => [
                                        a[0] - ene.parentOffset.x,
                                        a[1] - ene.parentOffset.y,
                                    ])
                                )
                            );
                        }
                        for (let p = 0; p < o.points.length; p++) {
                            const originalpt = enemy[i].originalPoints[p];
                            o.points[p][0] =
                                originalpt[0] + ene.x - ene.parentOffset.x;
                            o.points[p][1] =
                                originalpt[1] + ene.y - ene.parentOffset.y;
                        }
                    } else {
                        o.x = ene.x - ene.parentOffset.x;
                        o.y = ene.y - ene.parentOffset.y;
                    }
                    break;
                }
            }
        }
        // if (enemy[i].childId) {
        //     for (let j in enemy) {
        //         const enemy2 = enemy[j];
        //         if (
        //             enemy2.parentId &&
        //             enemy2.parentId === ene.childId &&
        //             enemy2.pushIndex === ene.pushIndex
        //         ) {
        //             enemy[i].x = enemy2.x;
        //             enemy[i].y = enemy2.y;
        //             if (ene.type === 'flashlight') {
        //                 enemy[i].xv = enemy2.xv;
        //                 enemy[i].yv = enemy2.yv;
        //             }
        //         }
        //     }
        // }
        if (enemy[i].childId) {
            if(enemy[i].switchChildId){
                //switchChildIndex, switchChildTimer
                enemy[i].switchChildTimer -= 0.5*dt;
                if(enemy[i].switchChildTimer < 0){
                    enemy[i].switchChildIndex++;
                    if(enemy[i].switchChildIndex > enemy[i].switchChildId.length-1){
                        enemy[i].switchChildIndex = 0;
                    }
                    enemy[i].childId = enemy[i].switchChildId[enemy[i].switchChildIndex][0];
                    enemy[i].switchChildTimer = enemy[i].switchChildId[enemy[i].switchChildIndex][1];
                    enemy[i].parentIdEnemy = undefined;
                    if(enemy[i].childId < 0){
                        enemy[i].childId = 'none' + Math.random();
                    }
                    // console.log(enemy[i].type + ' c ' + enemy[i].childId);
                }
            }
            if(enemy[i].parentIdEnemy !== undefined){
                enemy[i].x = enemy[i].parentIdEnemy.x;
                enemy[i].y = enemy[i].parentIdEnemy.y;
            } else {
                for (let j in enemy) {
                    const enemy2 = enemy[j];
                    if (
                        enemy2.parentId &&
                        enemy2.parentId === enemy[i].childId &&
                        enemy2.pushIndex === enemy[i].pushIndex
                    ) {
                        enemy[i].x = enemy2.x;
                        enemy[i].y = enemy2.y;
                        enemy[i].parentIdEnemy = enemy2;
                    }
                }
            }
        }
        if(enemy[i].parentId && enemy[i].switchParentId){
            //switchParentIndex, switchParentTimer
            enemy[i].switchParentTimer -= dt;
            if(enemy[i].switchParentTimer < 0){
                enemy[i].switchParentIndex++;
                if(enemy[i].switchParentIndex > enemy[i].switchParentId.length-1){
                    enemy[i].switchParentIndex = 0;
                }
                enemy[i].parentId = enemy[i].switchParentId[enemy[i].switchParentIndex][0];
                enemy[i].switchParentTimer = enemy[i].switchParentId[enemy[i].switchParentIndex][1];
                if(enemy[i].parentId < 0){
                    enemy[i].parentId = 'none' + Math.random();
                }
                // console.log(enemy[i].type + enemy[i].parentId);
                for (let j in enemy) {
                    const enemy2 = enemy[j];
                    if (
                        enemy2.childId &&
                        enemy2.childId === enemy[i].parentId &&
                        enemy2.pushIndex === enemy[i].pushIndex
                    ) {
                        delete enemy[j].parentIdEnemy;
                    }
                }
            }
        }
        simulateEnemy(enemy[i], dt, player, players);
        if (enemy[i].childId) {
            if(enemy[i].switchChildId){
                //switchChildIndex, switchChildTimer
                enemy[i].switchChildTimer -= 0.5*dt;
                if(enemy[i].switchChildTimer < 0){
                    enemy[i].switchChildIndex++;
                    if(enemy[i].switchChildIndex > enemy[i].switchChildId.length-1){
                        enemy[i].switchChildIndex = 0;
                    }
                    enemy[i].childId = enemy[i].switchChildId[enemy[i].switchChildIndex][0];
                    enemy[i].switchChildTimer = enemy[i].switchChildId[enemy[i].switchChildIndex][1];
                    if(enemy[i].childId < 0){
                        enemy[i].childId = 'none' + Math.random();
                    }
                    // console.log(enemy[i].type + ' c ' + enemy[i].childId);
                }
            }
            if(enemy[i].parentIdEnemy !== undefined){
                enemy[i].x = enemy[i].parentIdEnemy.x;
                enemy[i].y = enemy[i].parentIdEnemy.y;
            } else {
                for (let j in enemy) {
                    const enemy2 = enemy[j];
                    if (
                        enemy2.parentId &&
                        enemy2.parentId === enemy[i].childId &&
                        enemy2.pushIndex === enemy[i].pushIndex
                    ) {
                        enemy[i].x = enemy2.x;
                        enemy[i].y = enemy2.y;
                        enemy[i].parentIdEnemy = enemy2;
                    }
                }
            }
        }
    }

    enemy.forEach((e, ind) => {
        if (!isNaN(e.life)) {
            e.life -= dt;
            if (e.life <= 0) {
                if (e.type === 'enemyobstacle' && e.obstacleParentId) {
                    // remove obstacle
                    obstacles.forEach((o, ind) => {
                        if (o.enemyChildId == e.obstacleParentId) {
                            obstacles.splice(ind, 1);
                        }
                    });
                }
                enemy.splice(ind, 1);
            }
        }

        if (e.effectorIds) {
            // resetting enemy param mults
            for (let eid of e.effectorIds) {
                const ob = obstacles[eid];
                e[ob.effectParam] /= ob.multiply;
            }
            delete e.effectorIds;
        }
    });

    if (calcsizings) {
        for (let j = 0; j < enemy.length; j++) {
            const enemy2 = enemy[j];
            if (enemy2.collidedWSizer != undefined) {
                if (!enemy2.baseRadius) {
                    enemy[j].baseRadius = enemy2.radius;
                    enemy[j].radius =
                        enemy2.radius *
                            enemy[enemy2.collidedWSizer].multiplyRadius +
                        enemy[enemy2.collidedWSizer].addRadius;
                }
                enemy[j].collidedWSizer = undefined;
            } else if (enemy2.baseRadius != undefined) {
                enemy[j].radius = enemy2.baseRadius;
                enemy[j].baseRadius = undefined;
            }
        }
    }
};

function pointCircleCollide(po, pos, r) {
    if (!Array.isArray(po)) {
        return false;
    }
    const [x, y] = po;
    return (x - pos.x) * (x - pos.x) + (y - pos.y) * (y - pos.y) <= r * r;
}

function simulateRotatingPauseObstacle(obstacle, dt) {
    if (obstacle.waitTimer > 0) {
        obstacle.waitTimer -= dt;
        if (obstacle.waitTimer <= 0) {
            const overflow = Math.abs(obstacle.waitTimer);
            simulateRotatingPauseObstacle(obstacle, overflow);
        }
    } else {
        obstacle.angle += obstacle.rotateSpeed * dt;
        obstacle.x =
            Math.cos((obstacle.angle * Math.PI) / 180) * obstacle.distToPivot +
            obstacle.pivotX;
        obstacle.y =
            Math.sin((obstacle.angle * Math.PI) / 180) * obstacle.distToPivot +
            obstacle.pivotY;
        let ad = findAngleDifference(
            obstacle.angle,
            obstacle.points[obstacle.nextPoint].angle
        );
        let over = false;
        if (
            obstacle.lastad &&
            Math.abs(ad) < Math.max(5, obstacle.rotateSpeed * 100 * dt)
        ) {
            // no, this doesn't snap. it's just making sure we don't have a >90 deg +1 frame with high rot speed
            if (obstacle.lastad > 0 && ad < 0) {
                over = true;
            } else if (obstacle.lastad < 0 && ad > 0) {
                over = true;
            }
        }
        obstacle.lastad = ad;
        if (over) {
            obstacle.angle = obstacle.points[obstacle.nextPoint].angle;
            obstacle.waitTimer = obstacle.points[obstacle.nextPoint].pause;
            obstacle.rotateSpeed = obstacle.points[obstacle.nextPoint].speed;
            obstacle.currentPoint++;
            obstacle.nextPoint++;
            if (obstacle.currentPoint >= obstacle.points.length) {
                obstacle.currentPoint = 0;
            } else if (obstacle.nextPoint >= obstacle.points.length) {
                obstacle.nextPoint = 0;
            }
            // t = d/s
            const overflow = Math.abs(
                findAngleDifference(
                    obstacle.angle,
                    obstacle.points[obstacle.currentPoint].angle
                ) / obstacle.rotateSpeed
            );
            simulateRotatingPauseObstacle(obstacle, overflow);
        }
    }
}

function simulateMovingPauseObstacle(obstacle, dt) {
    if (obstacle.waitTimer > 0) {
        obstacle.waitTimer -= dt;
        if (obstacle.waitTimer <= 0) {
            const overflow = Math.abs(obstacle.waitTimer);
            simulateMovingPauseObstacle(obstacle, overflow);
        }
    } else {
        let nextPointIndex = obstacle.currentPoint + 1;
        if (nextPointIndex >= obstacle.points.length) {
            // points undefined??
            nextPointIndex = 0;
        }
        let nextPoint = obstacle.points[nextPointIndex];
        let currentPoint = obstacle.points[obstacle.currentPoint];
        obstacle.pointTo = {
            x: nextPoint[0],
            y: nextPoint[1],
            speed: nextPoint[2],
            pause: nextPoint[3],
        };
        obstacle.pointOn = {
            x: currentPoint[0],
            y: currentPoint[1],
            speed: currentPoint[2],
            pause: currentPoint[3],
        };
        let angle = Math.atan2(
            obstacle.pointTo.y - obstacle.pointOn.y,
            obstacle.pointTo.x - obstacle.pointOn.x
        );
        let xv = Math.cos(angle) * obstacle.speed;
        let yv = Math.sin(angle) * obstacle.speed;
        obstacle.x += xv * dt;
        obstacle.y += yv * dt;
        let timeRemain = 0;
        let over = false;
        if (Math.abs(yv) > Math.abs(xv)) {
            if (obstacle.pointTo.y > obstacle.pointOn.y) {
                if (obstacle.y > obstacle.pointTo.y) {
                    over = true;
                }
            } else {
                if (obstacle.y < obstacle.pointTo.y) {
                    over = true;
                }
            }
        } else {
            if (obstacle.pointTo.x > obstacle.pointOn.x) {
                if (obstacle.x > obstacle.pointTo.x) {
                    over = true;
                }
            } else {
                if (obstacle.x < obstacle.pointTo.x) {
                    over = true;
                }
            }
        }
        if (over == true) {
            obstacle.currentPoint++;
            if (obstacle.currentPoint > obstacle.points.length - 1) {
                obstacle.currentPoint = 0;
            }
            timeRemain = Math.sqrt(
                Math.pow(obstacle.y - obstacle.pointTo.y, 2) +
                    Math.pow(obstacle.x - obstacle.pointTo.x, 2)
            );
            obstacle.x = obstacle.pointTo.x;
            obstacle.y = obstacle.pointTo.y;
            timeRemain /= obstacle.speed;
            obstacle.pointOn = obstacle.points[obstacle.state];
            obstacle.speed = obstacle.pointTo.speed;
            obstacle.waitTimer = obstacle.pointTo.pause;

            simulateMovingPauseObstacle(obstacle, timeRemain);
        }
    }
}

function findAngleDifference(a1, a2) {
    return (
        (Math.atan2(
            Math.sin(((a1 - a2) * Math.PI) / 180),
            Math.cos(((a1 - a2) * Math.PI) / 180)
        ) *
            180) /
        Math.PI
    );
}

function simulateMovingObstacle(obstacle, dt) {
	obstacle.x += obstacle.xv * dt;
	obstacle.y += obstacle.yv * dt;
	let over = false;
	if (Math.abs(obstacle.yv) > Math.abs(obstacle.xv)) {
		if (obstacle.pointTo.y > obstacle.pointOn.y) {
			if (obstacle.y > obstacle.pointTo.y) {
				over = true;
			}
		}
		else {
			if (obstacle.y < obstacle.pointTo.y) {
				over = true;
			}
		}
	}
	else {
		if (obstacle.pointTo.x > obstacle.pointOn.x) {
			if (obstacle.x > obstacle.pointTo.x) {
				over = true;
			}
		}
		else {
			if (obstacle.x < obstacle.pointTo.x) {
				over = true;
			}
		}
	}
	if (over === true) {
		obstacle.currentPoint++;
		if (obstacle.currentPoint > obstacle.points.length - 1) {
			obstacle.currentPoint = 0;
		}

        let timeRemain = Math.sqrt(Math.pow(obstacle.y - obstacle.pointTo.y, 2) + Math.pow(obstacle.x - obstacle.pointTo.x, 2))/obstacle.speed;
        
		let pointOn = obstacle.points[obstacle.currentPoint];
        obstacle.pointOn = {x: pointOn[0], y: pointOn[1]};

        obstacle.x = obstacle.pointOn.x;
		obstacle.y = obstacle.pointOn.y;

        let nextPointIndex = obstacle.currentPoint + 1;
	    if (nextPointIndex >= obstacle.points.length) {
    		nextPointIndex = 0;
    	}
    	let nextPoint = obstacle.points[nextPointIndex];
    	obstacle.pointTo = { x: nextPoint[0], y: nextPoint[1] };

        let angle = Math.atan2(obstacle.pointTo.y - obstacle.pointOn.y, obstacle.pointTo.x - obstacle.pointOn.x);
	    obstacle.xv = Math.cos(angle) * obstacle.speed;
    	obstacle.yv = Math.sin(angle) * obstacle.speed;
		simulateMovingObstacle(obstacle, timeRemain);

        if (obstacle.type === 'morphmove' || obstacle.type === 'morphlavamove') {
            updateMorphersMoving(obstacle);
        }
	}
}

function updateMorphersMoving(obstacle){
    // console.log('morphing move')
    obstacle.active = false;
    // obstacle.x = obstacle.points[0][0];
    // obstacle.y = obstacle.points[0][1];
    for (const ob of obstacles) {
        if (ob.type === 'morphbutton' && obstacle.morphId === ob.morphId) {
            //ob.active = !ob.active;
            ob.timedObstacles--;
        }
    }
}

function simulateSwitchingObstacle(obstacle, dt) {
    obstacle.timer -= dt;
    if (obstacle.timer < 0) {
        if (obstacle.state == true) {
            obstacle.timer += obstacle.offTime; // speced ;-;
        } else {
            obstacle.timer += obstacle.onTime;
        }
        obstacle.state = !obstacle.state;
    }
}

function simulateGrowingObstacle(obstacle, dt) {
    if (obstacle.growing) {
        obstacle.w += obstacle.growSpeed * dt;
        obstacle.h += obstacle.growSpeed * dt;
        obstacle.x -= (obstacle.growSpeed * dt) / 2;
        obstacle.y -= (obstacle.growSpeed * dt) / 2;
        if (obstacle.w > obstacle.maxWidth) {
            obstacle.growing = false;
            let overGrowth = obstacle.w - obstacle.maxWidth;
            obstacle.w -= overGrowth * 2;
            obstacle.h -= overGrowth * 2;
            obstacle.x += overGrowth;
            obstacle.y += overGrowth;
        }
    } else {
        obstacle.w -= obstacle.growSpeed * dt;
        obstacle.h -= obstacle.growSpeed * dt;
        obstacle.x += (obstacle.growSpeed * dt) / 2;
        obstacle.y += (obstacle.growSpeed * dt) / 2;
        if (obstacle.w < obstacle.minWidth) {
            obstacle.growing = true;
            let underGrowth = obstacle.minWidth - obstacle.w;
            obstacle.w += underGrowth * 2;
            obstacle.h += underGrowth * 2;
            obstacle.x -= underGrowth;
            obstacle.y -= underGrowth;
        }
    }
}

function simulateGrowingCircularObstacle(obstacle, dt) {
    if (obstacle.growing) {
        obstacle.r += obstacle.growSpeed * dt;
        if (obstacle.r > obstacle.maxWidth) {
            obstacle.growing = false;
            let overGrowth = obstacle.r - obstacle.maxWidth;
            obstacle.r -= overGrowth * 2;
        }
    } else {
        obstacle.r -= obstacle.growSpeed * dt;
        if (obstacle.r < obstacle.minWidth) {
            obstacle.growing = true;
            let underGrowth = obstacle.minWidth - obstacle.r;
            obstacle.r += underGrowth * 2;
        }
    }
}

// window.runObstaclePhysics = function (obstacles, dt, players, enemy) {
//     for (let i = 0; i < obstacles.length; i++) {
//         const obstacle = obstacles[i];
//         switch (obstacle.type) {
//             case 'rotate-lava':
//             case 'rotate-normal':
//             case 'rotate-tp':
//             case 'rotatingsafe':
//             case 'rotatingspeedtrap':
//                 if (obstacle.pivotX === undefined) {
//                     obstacle.pivotX = obstacle.x;
//                 }
//                 if (obstacle.pivotY === undefined) {
//                     obstacle.pivotY = obstacle.y;
//                 }
//                 obstacle.angle += obstacle.rotateSpeed * dt;
//                 obstacle.x =
//                     Math.cos((obstacle.angle * Math.PI) / 180) *
//                         obstacle.distToPivot +
//                     obstacle.pivotX;
//                 obstacle.y =
//                     Math.sin((obstacle.angle * Math.PI) / 180) *
//                         obstacle.distToPivot +
//                     obstacle.pivotY;
//                 break;
//             case 'rotate-pause':
//             case 'rotate-pause-lava':
//                 simulateRotatingPauseObstacle(obstacles[i], dt);
//                 break;
//             case 'move':
//             case 'lavamove':// make sure u dont place it in the middle of nowhere in between this
//             case 'tpmove':
//             case 'movingsafe':
//             case 'movingspeedtrap': // oh ok leeme readd morphmove bck
//             case 'movinggrapplepoint': { // i never saw this before ;-;
//                 simulateMovingObstacle(obstacle, dt)// lol u didnt becasue i added it
//                 // basicalyl u interrupted this by doing this
//             }
// 			case 'morphmove': {
// 				if (obstacle.active) {
// 					simulateMovingObstacle(obstacle, dt)
// 				}
// 				break;
//             }
//             case 'morphbuttontimed': {
// 				if (!obstacle.active) {
// 					obstacle.timer -= dt;
// 					if (obstacle.timer <= 0) {
// 						obstacle.active = true;
// 						for (const ob of obstacles) {
// 							if (ob.type === 'morphnormal' && obstacle.morphId === ob.morphId) {
// 								ob.active = !ob.active;
// 							}
// 						}
// 					}
// 				}
// 				break;
// 			}
// 			case 'dirnormal': {
// 				if (obstacle.active && obstacle.activeTimer < 0.25) {
// 					obstacle.activeTimer += dt;
// 					if (obstacle.activeTimer > 0.25) {
// 						obstacle.activeTimer = 0.25;
// 					}
// 				}
// 				break;
// 			}
//             case 'deadpusher':
//                 simulateMovingObstacle(obstacle, dt);
//                 break;
//             case 'move-pause':
//             case 'move-pause-lava':
//                 simulateMovingPauseObstacle(obstacles[i], dt);
//                 break;
//             case 'switchlava':
//             case 'switchnormal':
//                 simulateSwitchingObstacle(obstacle, dt);
//                 break;
//             case 'growing':
//             case 'growinglava':
//                 simulateGrowingObstacle(obstacle, dt);
//                 break;
//             case 'growingcircle':
//             case 'growinglavacircle':
//                 simulateGrowingCircularObstacle(obstacle, dt);
//                 break;
//             case 'circle-sentry':
//                 simulateSentry(obstacle, dt, players);
//                 break;
//             case 'enemyeffect':
//                 simulateEnemyEffector(obstacle, dt, enemy, i);
//                 break;
//         }
//     }
// };

function simulateEnemyEffector(obstacle, dt, enemy, obsid) {
    for (let ene of enemy) {
        if (
            ene[obstacle.effectParam] != undefined &&
            !isNaN(ene[obstacle.effectParam]) &&
            intersectingCircleRect(ene, obstacle, true)
        ) {
            if (!ene.effectorIds) {
                ene.effectorIds = [];
            }
            ene.effectorIds.push(obsid);
            ene[obstacle.effectParam] *= obstacle.multiply;
        }
    }
}

function simulateEnemyTp(obstacle, dt, enemy) {
    for (let ene of enemy) {
        if (intersectingCircleRect(ene, obstacle, true)) {
            ene.x = obstacle.tpx;
            ene.y = obstacle.tpy;
            ene.angle = Math.PI*obstacle.seed/10000;
            ene.xv = Math.cos(ene.angle) * ene.speed;
            ene.yv = Math.sin(ene.angle) * ene.speed;
            obstacle.seed = Math.sin(obstacle.seed++) * 10000 - Math.floor(Math.sin(obstacle.seed++) * 10000);
        }
    }
}

function simulateEnemyWall(obstacle, dt, enemy) {
    for (let ene of enemy) {
        const intersecting = returnIntersectingCircleRect(ene, obstacle, true)
        if (intersecting !== false) {
            // ene.xv = ene.speed * intersecting.overlapN.x;
            // ene.yv = ene.speed * intersecting.overlapN.y;
            // ok this is literally a leetcode question
            // how do you calculate the reflection of a vector, given
            // BRO IM LITERALLY A GENIUS HOW DID THIS WORK FIRST TRY WTFF
            // const n = {
            //     x: intersecting.overlapN.x,
            //     y: intersecting.overlapN.y
            // }
            // const d = {
            //     x: ene.xv,
            //     y: ene.yv,
            // }
            // let r = {
            //     x: d.x - 2 * (d.x*n.x+d.y*n.y) * n.x,
            //     y: d.y - 2 * (d.x*n.x+d.y*n.y) * n.y,
            // }
            let r = {
                x: ene.xv - 2 * (ene.xv*intersecting.overlapN.x+ene.yv*intersecting.overlapN.y) * intersecting.overlapN.x,
                y: ene.yv - 2 * (ene.xv*intersecting.overlapN.x+ene.yv*intersecting.overlapN.y) * intersecting.overlapN.y,
            }
            const magnitude = Math.sqrt(r.x**2+r.y**2);
            r.x /= magnitude;
            r.y /= magnitude;
            ene.xv = ene.speed * r.x;
            ene.yv = ene.speed * r.y;
            ene.x += intersecting.overlapV.x;
            ene.y += intersecting.overlapV.y;
        }
    }
}

function simulateEnemyButton(obstacle, dt, enemy){
    for(let ene of enemy){
        if (ene.deadTimer !== undefined) continue;
        if (intersectingCircleRect({radius: ene.radius||ene.r, ...ene}, obstacle)) {
            obstacle.active = false;
            triggerButtonEffects(obstacle.id, obstacles);
        }
    }
}

function simulateEnemyPolyTp(obstacle, dt, enemy) {
    for (let ene of enemy) {
        if (returnBoundPlayerPolygon(ene, obstacle) !== false) {
            ene.x = obstacle.tpx;
            ene.y = obstacle.tpy;
            ene.angle = Math.PI*obstacle.seed/10000;
            ene.xv = Math.cos(ene.angle) * ene.speed;
            ene.yv = Math.sin(ene.angle) * ene.speed;
            obstacle.seed = Math.sin(obstacle.seed++) * 10000 - Math.floor(Math.sin(obstacle.seed++) * 10000);
        }
    }
}

function simulateEnemyPolyWall(obstacle, dt, enemy) {
    for (let ene of enemy) {
        const intersecting = returnBoundPlayerPolygon(ene, obstacle)
        if (intersecting !== false) {
            // ene.xv = ene.speed * intersecting.overlapN.x;
            // ene.yv = ene.speed * intersecting.overlapN.y;
            // ok this is literally a leetcode question
            // how do you calculate the reflection of a vector, given
            // BRO IM LITERALLY A GENIUS HOW DID THIS WORK FIRST TRY WTFF
            // const n = {
            //     x: intersecting.overlapN.x,
            //     y: intersecting.overlapN.y
            // }
            // const d = {
            //     x: ene.xv,
            //     y: ene.yv,
            // }
            // let r = {
            //     x: d.x - 2 * (d.x*n.x+d.y*n.y) * n.x,
            //     y: d.y - 2 * (d.x*n.x+d.y*n.y) * n.y,
            // }
            let r = {
                x: ene.xv - 2 * (ene.xv*intersecting.overlapN.x+ene.yv*intersecting.overlapN.y) * intersecting.overlapN.x,
                y: ene.yv - 2 * (ene.xv*intersecting.overlapN.x+ene.yv*intersecting.overlapN.y) * intersecting.overlapN.y,
            }
            const magnitude = Math.sqrt(r.x**2+r.y**2);
            r.x /= magnitude;
            r.y /= magnitude;
            ene.xv = ene.speed * r.x;
            ene.yv = ene.speed * r.y;
            ene.x += intersecting.overlapV.x;
            ene.y += intersecting.overlapV.y;
        }
    }
}

function simulateCircleHollowSliceEnemyWall(obstacle, dt, enemy){
    if(obstacle.toRotate){
        obstacle.startAngle += obstacle.rotateSpeed*dt;
        obstacle.endAngle += obstacle.rotateSpeed*dt;
        obstacle.startPolygon.points = [
            [
                obstacle.x + Math.cos(obstacle.startAngle) * obstacle.innerRadius,
                obstacle.y + Math.sin(obstacle.startAngle) * obstacle.innerRadius,
            ],
            [
                obstacle.x + Math.cos(obstacle.startAngle) * obstacle.radius,
                obstacle.y + Math.sin(obstacle.startAngle) * obstacle.radius,
            ],
        ];
        obstacle.endPolygon.points = [
            [
                obstacle.x + Math.cos(obstacle.endAngle) * obstacle.innerRadius,
                obstacle.y + Math.sin(obstacle.endAngle) * obstacle.innerRadius,
            ],
            [
                obstacle.x + Math.cos(obstacle.endAngle) * obstacle.radius,
                obstacle.y + Math.sin(obstacle.endAngle) * obstacle.radius,
            ],
        ];
    }
    
    for (let ene of enemy) {
        const distX = ene.x - obstacle.x;
        const distY = ene.y - obstacle.y;
        const mag = Math.sqrt(distX * distX + distY * distY) || 1;
        const normal = { x: distX / mag, y: distY / mag };
        const lastX = ene.x;
        const lastY = ene.y;
        const angle = Math.atan2(
            ene.y - obstacle.y,
            ene.x - obstacle.x
        );

        const sat1 = returnBoundPlayerPolygon(ene, obstacle.startPolygon);
        const sat2 = returnBoundPlayerPolygon(ene, obstacle.endPolygon);
        if(sat1 !== false){
            ene.x += sat1.overlapV.x;
            ene.y += sat1.overlapV.y;
        } 
        if(sat2 !== false){
            ene.x += sat2.overlapV.x;
            ene.y += sat2.overlapV.y;
        }
        
        if (
            checkAngleBetween(
                angle,
                obstacle.startAngle,
                obstacle.endAngle
            )
        ) {
            if (
                mag > obstacle.innerRadius - ene.radius &&
                mag < obstacle.radius + ene.radius
            ) {
                // checking if ur inside or outside
                const outsideDist = Math.abs(
                    distX * distX +
                        distY * distY -
                        (ene.radius + obstacle.radius) *
                            (ene.radius + obstacle.radius)
                );
                const insideDist = Math.abs(
                    distX * distX +
                        distY * distY -
                        (obstacle.radius - ene.radius) ** 2
                );
                if (insideDist < outsideDist && obstacle.innerRadius > ene.radius) {
                    // we're inside; just invert the push
                    ene.x =
                        obstacle.x +
                        (obstacle.innerRadius - ene.radius) *
                            normal.x;
                    ene.y =
                        obstacle.y +
                        (obstacle.innerRadius - ene.radius) *
                            normal.y;
                } else {
                    ene.x =
                        obstacle.x +
                        (obstacle.radius + ene.radius) * normal.x;
                    ene.y =
                        obstacle.y +
                        (obstacle.radius + ene.radius) * normal.y;
                }
            }
        }

        if(ene.x !== lastX || ene.y !== lastY){
            // getting a normalized vector
            const dX = ene.x-lastX;
            const dY = ene.y-lastY;
            const pushMagnitude = Math.sqrt(dX**2+dY**2);
            const vec = {
                x: dX/pushMagnitude,
                y: dY/pushMagnitude,
            };
            // reflecting over that vector
            let r = {
                x: ene.xv - 2 * (ene.xv*vec.x+ene.yv*vec.y) * vec.x,
                y: ene.yv - 2 * (ene.xv*vec.x+ene.yv*vec.y) * vec.y,
            }
            const magnitude = Math.sqrt(r.x**2+r.y**2);
            r.x /= magnitude;
            r.y /= magnitude;
            ene.xv = ene.speed * r.x;
            ene.yv = ene.speed * r.y;
        }
    }
}

function simulateCircleHollowSliceEnemyTp(obstacle, dt, enemy){
    if(obstacle.toRotate){
        obstacle.startAngle += obstacle.rotateSpeed*dt;
        obstacle.endAngle += obstacle.rotateSpeed*dt;
        obstacle.startPolygon.points = [
            [
                obstacle.x + Math.cos(obstacle.startAngle) * obstacle.innerRadius,
                obstacle.y + Math.sin(obstacle.startAngle) * obstacle.innerRadius,
            ],
            [
                obstacle.x + Math.cos(obstacle.startAngle) * obstacle.radius,
                obstacle.y + Math.sin(obstacle.startAngle) * obstacle.radius,
            ],
        ];
        obstacle.endPolygon.points = [
            [
                obstacle.x + Math.cos(obstacle.endAngle) * obstacle.innerRadius,
                obstacle.y + Math.sin(obstacle.endAngle) * obstacle.innerRadius,
            ],
            [
                obstacle.x + Math.cos(obstacle.endAngle) * obstacle.radius,
                obstacle.y + Math.sin(obstacle.endAngle) * obstacle.radius,
            ],
        ];
    }
    
    for (let ene of enemy) {
        const distX = ene.x - obstacle.x;
        const distY = ene.y - obstacle.y;
        const mag = Math.sqrt(distX * distX + distY * distY) || 1;
        const normal = { x: distX / mag, y: distY / mag };
        const lastX = ene.x;
        const lastY = ene.y;
        const angle = Math.atan2(
            ene.y - obstacle.y,
            ene.x - obstacle.x
        );
        let colliding = false;
        if (
            checkAngleBetween(
                angle,
                obstacle.startAngle,
                obstacle.endAngle
            )
        ) {
            if (
                mag > obstacle.innerRadius - ene.radius &&
                mag < obstacle.radius + ene.radius
            ) {
                colliding = true;
            }
        }

        // 2: bounding players in the edges by polygon
        const sat1 = returnBoundPlayerPolygon(ene, obstacle.startPolygon);
        const sat2 = returnBoundPlayerPolygon(ene, obstacle.endPolygon);
        if(sat1 !== false || sat2 !== false){
            colliding = true;
        }

        if(colliding){
            ene.x = obstacle.tpx;
            ene.y = obstacle.tpy;
            ene.angle = Math.PI*obstacle.seed/10000;
            ene.xv = Math.cos(ene.angle)*ene.speed;
            ene.yv = Math.sin(ene.angle)*ene.speed;
            obstacle.seed = Math.sin(obstacle.seed++) * 10000 - Math.floor(Math.sin(obstacle.seed++) * 10000);
        }
    }
}

function simulateSentry(obstacle, dt, players) {
    let minDist = 100000;
    let minPlayer = null;

    // for (const playerId of Object.keys(players)) {
        const p = me();
        
        const distX = p.x - obstacle.x;
        const distY = p.y - obstacle.y;
        const dist = Math.sqrt(distX ** 2 + distY ** 2);
        if (dist < minDist && dist < obstacle.laser.w / 2) {
            minDist = dist;
            minPlayer = { x: p.x, y: p.y };
        }
    // }
    if (minPlayer != null && !p.dead) {
        // ! sound
        if(obstacle.lastNoticed !== true){
            playAudio(naniPath, 0, 0.3, false);
        }
        let dest =
            ((Math.atan2(minPlayer.y - obstacle.y, minPlayer.x - obstacle.x) *
                180) /
                Math.PI) %
            360;
        obstacle.angle = (obstacle.angle - 360) % 360;
        let angleDif = ((dest - obstacle.angle + 180) % 360) - 180;
        let otherAngleDif = ((dest - obstacle.angle + 360) % 360) - 180;
        let min = angleDif;
        if (Math.abs(otherAngleDif) < Math.abs(angleDif)) {
            min = otherAngleDif;
        }
        let interp = obstacle.speed * Math.min(Math.PI / 5, Math.abs(angleDif));
        obstacle.angle +=
            normalizeDist(min) * Math.min(Math.abs(min), Math.abs(interp * dt));
    } else {
        let dest = obstacle.rest;
        obstacle.angle = (obstacle.angle - 360) % 360;
        let angleDif = ((dest - obstacle.angle + 180) % 360) - 180;
        let otherAngleDif = ((dest - obstacle.angle + 360) % 360) - 180;
        let min = angleDif;
        if (Math.abs(otherAngleDif) < Math.abs(angleDif)) {
            min = otherAngleDif;
        }
        let interp = obstacle.speed * Math.min(Math.PI / 5, Math.abs(angleDif));
        obstacle.angle +=
            normalizeDist(min) * Math.min(Math.abs(min), Math.abs(interp * dt));
    }
    obstacle.lastNoticed = minPlayer !== null;
}

function interpTurret(d1, d2, amount){
    var dif = d2 - d1;
    var angleDif = Math.atan2(Math.sin(dif), Math.cos(dif));
    if (Math.abs(angleDif) >= amount) {
        if (angleDif < 0) {
            return d1-amount;
        } else {
            return d1+amount;
        }
    } else {
        return d2;
    }
}

function simulateTurretSentry(obstacle, dt, players) {
    let minDist = 100000;
    let minPlayer = null;
    
    const p = me();
    
    const distX = p.x - obstacle.x;
    const distY = p.y - obstacle.y;
    const dist = Math.sqrt(distX ** 2 + distY ** 2);
    // bulletRadius: this.bulletRadius,
    // shootSpeed: this.shootSpeed,
    // interpolateSpeed: this.interpolateSpeed,
    // angle: this.angle,
    // restAngle: this.restAngle,
    // type: this.type,
    // bulletLife: this.life,
    // bulletSpeed: this.bulletSpeed,
    // bullets: []
    // shooting a bullet if necesary
    obstacle.timer -= dt;
    if (obstacle.timer <= 0) {
        obstacle.bullets.push({
            x: obstacle.x,
            y: obstacle.y,
            life: obstacle.bulletLife,
            angle: obstacle.angle,
        });
        obstacle.timer = obstacle.shootSpeed;
    }
    
    // simulating bullets
    for (let p in obstacle.bullets) {
        obstacle.bullets[p].x +=
            Math.cos(obstacle.bullets[p].angle) * obstacle.bulletSpeed * dt;
        obstacle.bullets[p].y +=
            Math.sin(obstacle.bullets[p].angle) * obstacle.bulletSpeed * dt;
        obstacle.bullets[p].life -= dt;

        // checking collisions to kill bullets outside of bounds
        if (obstacle.bullets[p].life < 0) {
            // take out the projectile on the array
            obstacle.deadBullets.push({
                ...obstacle.bullets[p],
                life: 1,
            });
            obstacle.bullets.splice(p, 1);
        }
    }
    for (let p in obstacle.deadBullets) {
        obstacle.deadBullets[p].x +=
            Math.cos(obstacle.deadBullets[p].angle) * obstacle.bulletSpeed * dt;
        obstacle.deadBullets[p].y +=
            Math.sin(obstacle.deadBullets[p].angle) * obstacle.bulletSpeed * dt;

        // checking collisions to kill bullets outside of bounds
        obstacle.deadBullets[p].life -= dt*3.5;
        if (obstacle.deadBullets[p].life < 0) {
            obstacle.deadBullets.splice(p, 1);
        }
    }
    
    if (dist > obstacle.range + me().radius || me().dead === true) {
        obstacle.lastNoticed = false;
        obstacle.timer = obstacle.shootSpeed;
        obstacle.angle = interpTurret(obstacle.angle, obstacle.restAngle, obstacle.interpolateSpeed*dt);
        return;
    }
    
    obstacle.angle = interpTurret(obstacle.angle, Math.atan2(distY, distX), obstacle.interpolateSpeed*dt);
    obstacle.lastNoticed = true;

    if(obstacle.timer === undefined){
        obstacle.timer = obstacle.shootSpeed;
    }
}

function simulatePushingObstacle(obstacle, dt, isGhost = false) {
    // hmm idk rn
    if (obstacle.xv === undefined || obstacle.yv === undefined) {
        obstacle.xv = 0;
        obstacle.yv = 0;
    }
    if (obstacle.dir === 'left') {
        // obstacle.xv -= obstacle.pushBack * dt;
        // if (obstacle.x === obstacle.startX) {
        // 	obstacle.xv = 0;
        // }
        if (obstacle.xv > 0 && !obstacle.pushing) {
            // ITS KINDA WORKING NOW
            obstacle.xv -= obstacle.pushBack * 1500 * dt;
        }
    }
    if (obstacle.dir === 'right') {
        if (obstacle.xv < 0 && !obstacle.pushing) {
            obstacle.xv += obstacle.pushBack * 1500 * dt;
        }
    }
    if (obstacle.dir === 'down') {
        if (obstacle.yv < 0 && !obstacle.pushing) {
            obstacle.yv += obstacle.pushBack * 1500 * dt;
            // console.lg('pushing back on y')
        }
    }
    if (obstacle.dir === 'up') {
        if (obstacle.yv > 0 && !obstacle.pushing) {
            obstacle.yv -= obstacle.pushBack * 1500 * dt;
        }
    }
    obstacle.x += obstacle.xv * dt;
    obstacle.y += obstacle.yv * dt;
    // left
    if (obstacle.dir === 'left') {
        if (obstacle.x > obstacle.startX + obstacle.max) {
            obstacle.x = obstacle.startX + obstacle.max;
        }
        if (obstacle.x < obstacle.startX) {
            obstacle.x = obstacle.startX;
        }
    }
    if (obstacle.dir === 'right') {
        if (obstacle.x > obstacle.startX) {
            obstacle.x = obstacle.startX;
        }
        if (obstacle.x < obstacle.startX - obstacle.max) {
            obstacle.x = obstacle.startX - obstacle.max;
        }
    }
    if (obstacle.dir === 'down') {
        if (obstacle.y < obstacle.startY - obstacle.max) {
            obstacle.y = obstacle.startY - obstacle.max;
        }
        if (obstacle.y > obstacle.startY) {
            obstacle.y = obstacle.startY;
        }
    }
    if (obstacle.dir === 'up') {
        if (obstacle.y < obstacle.startY) {
            obstacle.y = obstacle.startY;
        }
        if (obstacle.y > obstacle.startY + obstacle.max) {
            obstacle.y = obstacle.startY + obstacle.max;
        }
    }
    obstacle.pushing = false;
}

function simulateEnemy(enemy, dt, player, players) {
    const enemytype = enemy.type;
    if (enemy.stopTimer != undefined) {
        enemy.stopTimer -= dt;
        if (enemy.stopTimer < 0) {
            enemy.stopTimer = undefined;
        }
        return;
    }
    if (enemytype === 'rotatearoundparent' || enemytype === 'enemyobstacle' || enemytype === 'combo')
        return;
    if (enemytype === 'switch') {
        enemy.switchTimer += dt;
        if (enemy.switchTimer >= enemy.switchTime) {
            enemy.switchTimer -= enemy.switchTime;
            enemy.currentSwitch = !enemy.currentSwitch;
        }
    }
    if (enemytype === 'tpplayer') {
        // simulating other
        enemy.other.x += enemy.other.xv * dt;

        if (
            enemy.other.x + enemy.other.radius >=
            enemy.bound.x + enemy.bound.w
        ) {
            enemy.other.xv = -enemy.other.xv;
            enemy.other.x =
                (enemy.bound.x + enemy.bound.w) * 2 -
                enemy.other.x -
                enemy.other.radius * 2;
        } else if (enemy.other.x - enemy.other.radius <= enemy.bound.x) {
            enemy.other.xv = -enemy.other.xv;
            enemy.other.x =
                enemy.bound.x * 2 - enemy.other.x + enemy.other.radius * 2;
        }
        enemy.other.y += enemy.other.yv * dt;
        if (
            enemy.other.y + enemy.other.radius >=
            enemy.bound.y + enemy.bound.h
        ) {
            enemy.other.yv = -enemy.other.yv;
            enemy.other.y =
                (enemy.bound.y + enemy.bound.h) * 2 -
                enemy.other.y -
                enemy.other.radius * 2;
        } else if (enemy.other.y - enemy.other.radius <= enemy.bound.y) {
            enemy.other.yv = -enemy.other.yv;
            enemy.other.y =
                enemy.bound.y * 2 - enemy.other.y + enemy.other.radius * 2;
        }
    }
    if (enemytype === 'pointaccel') {
        let dist2center = Math.sqrt(
            (enemy.centerPoint.x - enemy.x) ** 2 +
                (enemy.centerPoint.y - enemy.y) ** 2
        );
        enemy.speed =
            enemy.baseSpeed * Math.pow(dist2center / 200, enemy.accelPower);
        enemy.xv = Math.cos(Math.atan2(enemy.yv, enemy.xv)) * enemy.speed;
        enemy.yv = Math.sin(Math.atan2(enemy.yv, enemy.xv)) * enemy.speed;
    }
    if (enemytype === 'boomerang') {
        enemy.throwTimer -= dt;
        if (enemy.throwTimer <= 0) {
            enemy.throwTimer += enemy.throwCooldown;
            enemy.boomerangs.push({
                x: enemy.x,
                y: enemy.y,
                angle: enemy.throwAngle,
                xv: enemy.boomerangSpeed * Math.cos(enemy.throwAngle),
                yv: enemy.boomerangSpeed * Math.sin(enemy.throwAngle),
                radius: enemy.boomerangRadius,
                mergeTimer: 0.5,
            });

            if (enemy.shootAngles) {
                enemy.shootIndex++;
                if (enemy.shootIndex > enemy.shootAngles.length - 1) {
                    enemy.shootIndex = 0;
                }
                enemy.throwAngle = enemy.shootAngles[enemy.shootIndex];
            } else {
                enemy.throwAngle =
                    Math.sin(enemy.throwAngle++) * 10000 -
                    Math.floor(Math.sin(enemy.throwAngle++) * 10000);
            }
        }
        enemy.boomerangs.forEach((boomerang, i) => {
            boomerang.x += boomerang.xv * dt;
            boomerang.y += boomerang.yv * dt;
            boomerang.mergeTimer -= dt;

            // wall bounding
            if (
                boomerang.x + boomerang.radius >=
                enemy.bound.x + enemy.bound.w
            ) {
                boomerang.xv = -boomerang.xv;
                boomerang.x =
                    (enemy.bound.x + enemy.bound.w) * 2 -
                    boomerang.x -
                    boomerang.radius * 2;
            } else if (boomerang.x - boomerang.radius <= enemy.bound.x) {
                boomerang.xv = -boomerang.xv;
                boomerang.x =
                    enemy.bound.x * 2 - boomerang.x + boomerang.radius * 2;
            }

            if (
                boomerang.y + boomerang.radius >=
                enemy.bound.y + enemy.bound.h
            ) {
                boomerang.yv = -boomerang.yv;
                boomerang.y =
                    (enemy.bound.y + enemy.bound.h) * 2 -
                    boomerang.y -
                    boomerang.radius * 2;
            } else if (boomerang.y - boomerang.radius <= enemy.bound.y) {
                boomerang.yv = -boomerang.yv;
                boomerang.y =
                    enemy.bound.y * 2 - boomerang.y + boomerang.radius * 2;
            }
            // collision
            if (
                Math.sqrt(
                    (boomerang.x - enemy.x) ** 2 + (boomerang.y - enemy.y) ** 2
                ) < Math.max(10, enemy.radius - enemy.boomerangRadius) &&
                boomerang.mergeTimer <= 0
            ) {
                enemy.boomerangs.splice(i, 1);
            }

            // homing
            const dX = enemy.x - boomerang.x;
            const dY = enemy.y - boomerang.y;
            const targetAngle = Math.atan2(dY, dX);
            const dif = targetAngle - boomerang.angle;
            const angleDif = Math.atan2(Math.sin(dif), Math.cos(dif));
            const angleIncrement = 0.04;
            if (Math.abs(angleDif) >= angleIncrement) {
                if (angleDif < 0) {
                    boomerang.angle -= angleIncrement * (20 / 30);
                } else {
                    boomerang.angle += angleIncrement * (20 / 30);
                }
            }

            boomerang.xv = Math.cos(boomerang.angle) * enemy.boomerangSpeed;
            boomerang.yv = Math.sin(boomerang.angle) * enemy.boomerangSpeed;
        });
    }
    if (enemytype === 'polygon') {
        // rotation
        if (enemy.rotateSpeed !== 0) {
            enemy.rotateAngle += enemy.rotateSpeed * dt;
            enemy.points = [];
            for (let i = 0; i <= enemy.sides; i++) {
                enemy.points.push([
                    -enemy.size *
                        Math.sin(
                            (i * 2 * Math.PI) / enemy.sides + enemy.rotateAngle
                        ),
                    -enemy.size *
                        Math.cos(
                            (i * 2 * Math.PI) / enemy.sides + enemy.rotateAngle
                        ),
                ]);
            }
        }
    }
    if (enemytype === 'dasher') {
        //idk how to make enemy lol
        enemy.time += dt * 1000;

        enemy.radius =
            (enemy.baseRadius * (1 + (Math.sin(enemy.time / 500) + 1))) / 2;
        enemy.x += enemy.xv * dt * (Math.cos(enemy.time / 500) + 1);
        enemy.y += enemy.yv * dt * (Math.cos(enemy.time / 500) + 1);

        if (enemy.x + enemy.radius >= enemy.bound.x + enemy.bound.w) {
            enemy.xv = -enemy.xv;
            enemy.x =
                (enemy.bound.x + enemy.bound.w) * 2 -
                enemy.x -
                enemy.radius * 2;
        } else if (enemy.x - enemy.radius <= enemy.bound.x) {
            enemy.xv = -enemy.xv;
            enemy.x = enemy.bound.x * 2 - enemy.x + enemy.radius * 2;
        }
        if (enemy.y + enemy.radius >= enemy.bound.y + enemy.bound.h) {
            enemy.yv = -enemy.yv;
            enemy.y =
                (enemy.bound.y + enemy.bound.h) * 2 -
                enemy.y -
                enemy.radius * 2;
        } else if (enemy.y - enemy.radius <= enemy.bound.y) {
            enemy.yv = -enemy.yv;
            enemy.y = enemy.bound.y * 2 - enemy.y + enemy.radius * 2;
        }
    } else if (enemytype === 'rain') {
        simulateRainEnemy(dt, enemy)
    } else if (enemytype === 'e2dasher') {
        enemy.x += enemy.xv * dt * enemy.dashDistance;
        enemy.y += enemy.yv * dt * enemy.dashDistance;
        if (enemy.x + enemy.radius >= enemy.bound.x + enemy.bound.w) {
            enemy.xv = -enemy.xv;
            enemy.x =
                (enemy.bound.x + enemy.bound.w) * 2 -
                enemy.x -
                enemy.radius * 2;
        } else if (enemy.x - enemy.radius <= enemy.bound.x) {
            enemy.xv = -enemy.xv;
            enemy.x = enemy.bound.x * 2 - enemy.x + enemy.radius * 2;
        }
        if (enemy.y + enemy.radius >= enemy.bound.y + enemy.bound.h) {
            enemy.yv = -enemy.yv;
            enemy.y =
                (enemy.bound.y + enemy.bound.h) * 2 -
                enemy.y -
                enemy.radius * 2;
        } else if (enemy.y - enemy.radius <= enemy.bound.y) {
            enemy.yv = -enemy.yv;
            enemy.y = enemy.bound.y * 2 - enemy.y + enemy.radius * 2;
        }

        // simulating dash
        if (enemy.dashTimer <= (3 / 4) * enemy.secondCooldown) {
            enemy.dashDistance *= enemy.friction;
        }
        enemy.dashTimer -= dt;
        if (enemy.dashTimer <= 0) {
            if (enemy.coolType) {
                enemy.dashDistance = enemy.firstSpeed;
                enemy.dashTimer = enemy.firstCooldown;
            } else {
                enemy.dashDistance = enemy.secondSpeed;
                enemy.dashTimer = enemy.secondCooldown;
            }
            enemy.coolType = !enemy.coolType;
        }
    } else if (enemytype === 'oval' || enemytype === 'growingoval') {
        if (enemytype === 'growingoval') {
            if (enemy.growingX) {
                enemy.r1 += enemy.growSpeedX * dt;
                if (enemy.r1 > enemy.maxX) {
                    enemy.growingX = false;
                    let overGrowth = enemy.r1 - enemy.maxX;
                    enemy.r1 -= overGrowth * 2;
                }
            } else {
                enemy.r1 -= enemy.growSpeedX * dt;
                if (enemy.r1 < enemy.minX) {
                    enemy.growingX = true;
                    let underGrowth = enemy.r1 - enemy.minX;
                    enemy.r1 += underGrowth * 2;
                }
            }
            if (enemy.growingY) {
                enemy.r2 += enemy.growSpeedY * dt;
                if (enemy.r2 > enemy.maxY) {
                    enemy.growingY = false;
                    let overGrowth = enemy.r2 - enemy.maxY;
                    enemy.r2 -= overGrowth * 2;
                }
            } else {
                enemy.r2 -= enemy.growSpeedY * dt;
                if (enemy.r2 < enemy.minY) {
                    enemy.growingY = true;
                    let underGrowth = enemy.r2 - enemy.minY;
                    enemy.r2 += underGrowth * 2;
                }
            }
        }
        enemy.x += enemy.xv * dt;

        if (enemy.x + enemy.r1 >= enemy.bound.x + enemy.bound.w) {
            enemy.xv = -enemy.xv;
            enemy.x =
                (enemy.bound.x + enemy.bound.w) * 2 - enemy.x - enemy.r1 * 2;
        } else if (enemy.x - enemy.r1 <= enemy.bound.x) {
            enemy.xv = -enemy.xv;
            enemy.x = enemy.bound.x * 2 - enemy.x + enemy.r1 * 2;
        }
        enemy.y += enemy.yv * dt;
        if (enemy.y + enemy.r2 >= enemy.bound.y + enemy.bound.h) {
            enemy.yv = -enemy.yv;
            enemy.y =
                (enemy.bound.y + enemy.bound.h) * 2 - enemy.y - enemy.r2 * 2;
        } else if (enemy.y - enemy.r2 <= enemy.bound.y) {
            enemy.yv = -enemy.yv;
            enemy.y = enemy.bound.y * 2 - enemy.y + enemy.r2 * 2;
        }
    } else if (enemytype === 'enemymove') {
        simulateMovingEnemy(dt, enemy);
    } else if (enemytype === 'followaxis') {
        const closest = {
            dist: 1000000,
            id: -1,
        };
        let id = 0;
        for (let pid of Object.keys(players)) {
            const p = players[pid];
            if (intersectingCircleRect(p, enemy.bound, true)) {
                const distX = p.x - enemy.x;
                const distY = p.y - enemy.y;
                const dist = distX ** 2 + distY ** 2;
                if (dist < closest.dist) {
                    closest.dist = dist;
                    closest.id = p.id;
                }
            }
            id++;
        }
        if (closest.id !== -1) {
            if (enemy.axis) {
                // follow x axis
                enemy.x = players[closest.id].x;
            } else {
                // follow y axis
                enemy.y = players[closest.id].y;
            }
        }
    } else if(enemytype === 'switchaccel'){
        if(enemy.startingDirection === true){
            enemy.speed += dt*enemy.accelAmount;
            if(enemy.speed >= enemy.secondSpeed){
                enemy.startingDirection = false;
                const excess = enemy.speed-enemy.secondSpeed;
                enemy.speed = enemy.secondSpeed-excess;
            }
        } else {
            enemy.speed -= dt*enemy.accelAmount;
            if(enemy.speed <= enemy.firstSpeed){
                enemy.startingDirection = true;
                const excess = enemy.firstSpeed-enemy.speed;
                enemy.speed = enemy.firstSpeed+excess;
            }
        }
        
        enemy.xv = enemy.normalized.xv*enemy.speed;
        enemy.yv = enemy.normalized.yv*enemy.speed;

        let touchedBound = false;
        enemy.x += enemy.xv * dt;
		if (enemy.x + enemy.radius >= enemy.bound.x + enemy.bound.w) {
            enemy.xv = -enemy.xv;
            enemy.x =
                (enemy.bound.x + enemy.bound.w) * 2 -
                enemy.x -
                enemy.radius * 2;
            touchedBound = true;
        } else if (enemy.x - enemy.radius <= enemy.bound.x) {
            enemy.xv = -enemy.xv;
            enemy.x = enemy.bound.x * 2 - enemy.x + enemy.radius * 2;
            touchedBound = true;
        }
        enemy.y += enemy.yv * dt;
        if (enemy.y + enemy.radius >= enemy.bound.y + enemy.bound.h) {
            enemy.yv = -enemy.yv;
            enemy.y =
                (enemy.bound.y + enemy.bound.h) * 2 -
                enemy.y -
                enemy.radius * 2;
            touchedBound = true;
        } else if (enemy.y - enemy.radius <= enemy.bound.y) {
            enemy.yv = -enemy.yv;
            enemy.y = enemy.bound.y * 2 - enemy.y + enemy.radius * 2;
            touchedBound = true;
        }
        if(touchedBound === true){
            enemy.angle = Math.atan2(enemy.yv, enemy.xv);
            enemy.normalized = {
                xv: Math.cos(enemy.angle),
                yv: Math.sin(enemy.angle),
            }
        }
    } else if (enemytype === 'turning') {
        enemy.angle = Math.atan2(enemy.yv, enemy.xv);
        enemy.angle += dt * enemy.changeDir;
        enemy.xv = Math.cos(enemy.angle) * enemy.speed;
        enemy.yv = Math.sin(enemy.angle) * enemy.speed;
        enemy.x += enemy.xv * dt;

        if (enemy.x + enemy.radius >= enemy.bound.x + enemy.bound.w) {
            enemy.xv = -enemy.xv;
            enemy.x =
                (enemy.bound.x + enemy.bound.w) * 2 -
                enemy.x -
                enemy.radius * 2;
            enemy.changeDir = -enemy.changeDir;
        } else if (enemy.x - enemy.radius <= enemy.bound.x) {
            enemy.xv = -enemy.xv;
            enemy.x = enemy.bound.x * 2 - enemy.x + enemy.radius * 2;
            enemy.changeDir = -enemy.changeDir;
        }
        enemy.y += enemy.yv * dt;
        if (enemy.y + enemy.radius >= enemy.bound.y + enemy.bound.h) {
            enemy.yv = -enemy.yv;
            enemy.y =
                (enemy.bound.y + enemy.bound.h) * 2 -
                enemy.y -
                enemy.radius * 2;
            enemy.changeDir = -enemy.changeDir;
        } else if (enemy.y - enemy.radius <= enemy.bound.y) {
            enemy.yv = -enemy.yv;
            enemy.y = enemy.bound.y * 2 - enemy.y + enemy.radius * 2;
            enemy.changeDir = -enemy.changeDir;
        }
    } else if (enemytype === 'oscillating') {
        for(let i = 0; i < enemy.points.length; i++){
            const p = enemy.points[i];
            p.x += p.xv * dt;
            if (p.x >= enemy.bound.x + enemy.bound.w) {
                p.xv = -p.xv;
                p.x =
                    (enemy.bound.x + enemy.bound.w) * 2 - p.x;
            } else if (p.x <= enemy.bound.x) {
                p.xv = -p.xv;
                p.x = enemy.bound.x * 2 - p.x;
            }
            p.y += p.yv * dt;
            if (p.y >= enemy.bound.y + enemy.bound.h) {
                p.yv = -p.yv;
                p.y =
                    (enemy.bound.y + enemy.bound.h) * 2 - p.y;
            } else if (p.y <= enemy.bound.y) {
                p.yv = -p.yv;
                p.y = enemy.bound.y * 2 - p.y;
            }
        }
        simulateOscillatingEnemy(dt, enemy);
    } else if(enemytype === 'flower'){
        simulateNormalEnemy(enemy, dt);
        for(let clone of enemy.clones){
            clone.angle += enemy.rotateSpeed * dt;
            clone.x = enemy.x + Math.random() + Math.cos(clone.angle) * enemy.clonesDistance * (clone.layer+1);
            clone.y = enemy.y + Math.random() + Math.sin(clone.angle) * enemy.clonesDistance * (clone.layer+1);
            if(enemy.growingMultiple != undefined){
                if (clone.growing.state) {
                    clone.growing.radius += enemy.growingSpeed * dt;
                    if (clone.growing.radius > enemy.growingMultiple*enemy.clonesRadius) {
                        clone.growing.state = false;
                        let overGrowth = clone.growing.radius - enemy.growingMultiple*enemy.clonesRadius;
                        clone.growing.radius -= overGrowth * 2;
                    }
                } else {
                    clone.growing.radius -= enemy.growingSpeed * dt;
                    if (clone.growing.radius < enemy.clonesRadius) {
                        clone.growing.state = true;
                        let underGrowth = enemy.clonesRadius - clone.growing.radius;
                        clone.growing.radius += underGrowth * 2;
                    }
                }
            }
        }
    } else if (enemytype === 'jump') {
        if (enemy.jumping) {
            //super.simulate(dt*enemy.z/10);

            enemy.x += (dt * enemy.xv * enemy.z) / 10;
            enemy.y += (dt * enemy.yv * enemy.z) / 10;

            if (enemy.x + enemy.radius >= enemy.bound.x + enemy.bound.w) {
                enemy.xv = -enemy.xv;
                enemy.x =
                    (enemy.bound.x + enemy.bound.w) * 2 -
                    enemy.x -
                    enemy.radius * 2;
            } else if (enemy.x - enemy.radius <= enemy.bound.x) {
                enemy.xv = -enemy.xv;
                enemy.x = enemy.bound.x * 2 - enemy.x + enemy.radius * 2;
            }
            if (enemy.y + enemy.radius >= enemy.bound.y + enemy.bound.h) {
                enemy.yv = -enemy.yv;
                enemy.y =
                    (enemy.bound.y + enemy.bound.h) * 2 -
                    enemy.y -
                    enemy.radius * 2;
            } else if (enemy.y - enemy.radius <= enemy.bound.y) {
                enemy.yv = -enemy.yv;
                enemy.y = enemy.bound.y * 2 - enemy.y + enemy.radius * 2;
            }

            enemy.vz -= enemy.gravity * dt;
            enemy.z += enemy.vz * dt;
            enemy.radius = enemy.baseRadius + enemy.z;
            if (enemy.z < 0) {
                enemy.z = 0;
                enemy.jumping = false;
            }
        } else {
            enemy.timer += dt;
            if (enemy.timer >= enemy.maxTimer) {
                enemy.timer = 0;
                enemy.jumping = true;
                enemy.vz = enemy.jumpHeight;
            }
        }
    } else if (enemytype === 'wavy') {
        enemy.timer -= dt;
        if (enemy.timer < 0) {
            enemy.timer = enemy.maxTimer;
            enemy.dir *= -1;
        }
        enemy.angle = Math.atan2(enemy.yv, enemy.xv);
        enemy.angle += enemy.dir * dt * 2;
        enemy.xv = Math.cos(enemy.angle) * enemy.speed;
        enemy.yv = Math.sin(enemy.angle) * enemy.speed;

        enemy.x += enemy.xv * dt;

        if (enemy.x + enemy.radius >= enemy.bound.x + enemy.bound.w) {
            enemy.xv = -enemy.xv;
            enemy.x =
                (enemy.bound.x + enemy.bound.w) * 2 -
                enemy.x -
                enemy.radius * 2;
        } else if (enemy.x - enemy.radius <= enemy.bound.x) {
            enemy.xv = -enemy.xv;
            enemy.x = enemy.bound.x * 2 - enemy.x + enemy.radius * 2;
        }

        enemy.y += enemy.yv * dt;

        if (enemy.y + enemy.radius >= enemy.bound.y + enemy.bound.h) {
            enemy.yv = -enemy.yv;
            enemy.y =
                (enemy.bound.y + enemy.bound.h) * 2 -
                enemy.y -
                enemy.radius * 2;
        } else if (enemy.y - enemy.radius <= enemy.bound.y) {
            enemy.yv = -enemy.yv;
            enemy.y = enemy.bound.y * 2 - enemy.y + enemy.radius * 2;
        }
    } else if (enemytype === 'fire') {
        // siming if we're not pausing
        if (enemy.timer > enemy.pauseTime) {
            simulateNormalEnemy(enemy, dt);
        }
        // spawning new fire if neccesary
        enemy.timer -= dt;
        if (enemy.timer <= 0) {
            for (let i = 0; i < enemy.fireAmount; i++) {
                simulateNormalEnemy(
                    enemy,
                    (enemy.fireDistance * (i + 1)) / enemy.fireAmount
                );
                enemy.fire.push({
                    x: enemy.x,
                    y: enemy.y,
                    life: enemy.fireLife,
                    radius: enemy.radius,
                });
                simulateNormalEnemy(
                    enemy,
                    (-enemy.fireDistance * (i + 1)) / enemy.fireAmount
                );
            }
            enemy.timer += enemy.maxTime;
        }

        // simulating fire
        enemy.fire.forEach((fire, index) => {
            fire.x += dt * (Math.random() * 100 - 50);
            fire.y += dt * (Math.random() * 100 - 50);
            fire.life -= dt;
            if (fire.life < 0) {
                enemy.fire.splice(index, 1);
            }
        });
    } else if (enemytype === 'bomb') {
        let toBomb = false;
        enemy.x += enemy.xv * dt;

        if (enemy.x + enemy.radius >= enemy.bound.x + enemy.bound.w) {
            enemy.xv = -enemy.xv;
            enemy.x =
                (enemy.bound.x + enemy.bound.w) * 2 -
                enemy.x -
                enemy.radius * 2;
            toBomb = true;
        } else if (enemy.x - enemy.radius <= enemy.bound.x) {
            enemy.xv = -enemy.xv;
            enemy.x = enemy.bound.x * 2 - enemy.x + enemy.radius * 2;
            toBomb = true;
        }

        enemy.y += enemy.yv * dt;

        if (enemy.y + enemy.radius >= enemy.bound.y + enemy.bound.h) {
            enemy.yv = -enemy.yv;
            enemy.y =
                (enemy.bound.y + enemy.bound.h) * 2 -
                enemy.y -
                enemy.radius * 2;
            toBomb = true;
        } else if (enemy.y - enemy.radius <= enemy.bound.y) {
            enemy.yv = -enemy.yv;
            enemy.y = enemy.bound.y * 2 - enemy.y + enemy.radius * 2;
            toBomb = true;
        }

        if (toBomb) {
            for (let ii = 0; ii < enemy.bombNumber; ii++) {
                let angle = Math.random() * Math.PI * 2;
                let vmult = Math.random();
                // eventually have all of these tied to a param
                enemy.bombs.push({
                    x: enemy.x,
                    y: enemy.y,
                    xv: Math.cos(angle) * enemy.bombSpeed * vmult,
                    yv: Math.sin(angle) * enemy.bombSpeed * vmult,
                    life: enemy.bombLife,
                    radius: enemy.bombRadius,
                });
            }
        }

        // simulating and updating bomb fragments
        enemy.bombs.forEach((bomb, index) => {
            bomb.xv *= enemy.bombDecay;
            bomb.yv *= enemy.bombDecay;
            bomb.life -= dt;
            if (bomb.life < 0) {
                enemy.bombs.splice(index, 1);
            }
            bomb.x += bomb.xv * dt;
            bomb.y += bomb.yv * dt;
            if (bomb.x + bomb.radius >= enemy.bound.x + enemy.bound.w) {
                bomb.xv = -bomb.xv;
                bomb.x =
                    (enemy.bound.x + enemy.bound.w) * 2 -
                    bomb.x -
                    bomb.radius * 2;
            } else if (bomb.x - bomb.radius <= enemy.bound.x) {
                bomb.xv = -bomb.xv;
                bomb.x = enemy.bound.x * 2 - bomb.x + bomb.radius * 2;
            }

            if (bomb.y + bomb.radius >= enemy.bound.y + enemy.bound.h) {
                bomb.yv = -bomb.yv;
                bomb.y =
                    (enemy.bound.y + enemy.bound.h) * 2 -
                    bomb.y -
                    bomb.radius * 2;
            } else if (bomb.y - bomb.radius <= enemy.bound.y) {
                bomb.yv = -bomb.yv;
                bomb.y = enemy.bound.y * 2 - bomb.y + bomb.radius * 2;
            }
        });
    } else if (enemytype === 'accelerating') {
        if (enemy.xv > 0) {
            enemy.xv += enemy.accelAmount * dt;
        } else {
            enemy.xv -= enemy.accelAmount * dt;
        }
        if (enemy.yv > 0) {
            enemy.yv += enemy.accelAmount * dt;
        } else {
            enemy.yv -= enemy.accelAmount * dt;
        }
        enemy.x += enemy.xv * dt;
        if (enemy.x + enemy.radius >= enemy.bound.x + enemy.bound.w) {
            enemy.xv = -enemy.xv;
            enemy.x =
                (enemy.bound.x + enemy.bound.w) * 2 -
                enemy.x -
                enemy.radius * 2;
        } else if (enemy.x - enemy.radius <= enemy.bound.x) {
            enemy.xv = -enemy.xv;
            enemy.x = enemy.bound.x * 2 - enemy.x + enemy.radius * 2;
        }
        enemy.y += enemy.yv * dt;
        if (enemy.y + enemy.radius >= enemy.bound.y + enemy.bound.h) {
            enemy.yv = -enemy.yv;
            enemy.y =
                (enemy.bound.y + enemy.bound.h) * 2 -
                enemy.y -
                enemy.radius * 2;
        } else if (enemy.y - enemy.radius <= enemy.bound.y) {
            enemy.yv = -enemy.yv;
            enemy.y = enemy.bound.y * 2 - enemy.y + enemy.radius * 2;
        }
    } else if (enemytype === 'memory') {
        enemy.timer -= dt;
        if (enemy.timer < 0) {
            enemy.on = !enemy.on;
            if (enemy.on) {
                enemy.timer += enemy.time;
            } else {
                enemy.timer += enemy.timeOff;
            }
        }
        if (enemy.on) {
            enemy.x += (enemy.xv * dt * enemy.timer) / enemy.time;
            if (enemy.x + enemy.radius >= enemy.bound.x + enemy.bound.w) {
                enemy.xv = -enemy.xv;
                enemy.x =
                    (enemy.bound.x + enemy.bound.w) * 2 -
                    enemy.x -
                    enemy.radius * 2;
            } else if (enemy.x - enemy.radius <= enemy.bound.x) {
                enemy.xv = -enemy.xv;
                enemy.x = enemy.bound.x * 2 - enemy.x + enemy.radius * 2;
            }
            enemy.y += (enemy.yv * dt * enemy.timer) / enemy.time;
            if (enemy.y + enemy.radius >= enemy.bound.y + enemy.bound.h) {
                enemy.yv = -enemy.yv;
                enemy.y =
                    (enemy.bound.y + enemy.bound.h) * 2 -
                    enemy.y -
                    enemy.radius * 2;
            } else if (enemy.y - enemy.radius <= enemy.bound.y) {
                enemy.yv = -enemy.yv;
                enemy.y = enemy.bound.y * 2 - enemy.y + enemy.radius * 2;
            }
        }
    } else if (enemytype === 'turret') {
        enemy.x += enemy.xv * dt;
        if (enemy.x + enemy.radius >= enemy.bound.x + enemy.bound.w) {
            enemy.xv = -enemy.xv;
            enemy.x =
                (enemy.bound.x + enemy.bound.w) * 2 -
                enemy.x -
                enemy.radius * 2;
        } else if (enemy.x - enemy.radius <= enemy.bound.x) {
            enemy.xv = -enemy.xv;
            enemy.x = enemy.bound.x * 2 - enemy.x + enemy.radius * 2;
        }
        enemy.y += enemy.yv * dt;
        if (enemy.y + enemy.radius >= enemy.bound.y + enemy.bound.h) {
            enemy.yv = -enemy.yv;
            enemy.y =
                (enemy.bound.y + enemy.bound.h) * 2 -
                enemy.y -
                enemy.radius * 2;
        } else if (enemy.y - enemy.radius <= enemy.bound.y) {
            enemy.yv = -enemy.yv;
            enemy.y = enemy.bound.y * 2 - enemy.y + enemy.radius * 2;
        }

        // spawning a new bullet if neccesary
        enemy.timer -= dt;
        if (enemy.timer <= 0) {
            enemy.timer += enemy.shootSpeed;
            // creating a new projectile
            if (enemy.shootDirections[enemy.csd] !== 'none') {
                enemy.projectiles.push({
                    x: enemy.x,
                    y: enemy.y,
                    angle: enemy.shootDirections[enemy.csd],
                });
            }
            enemy.csd++;
            if (enemy.csd >= enemy.shootDirections.length) {
                enemy.csd = 0;
            }
        }
        // simulating projectiles
        for (let p in enemy.projectiles) {
            enemy.projectiles[p].x +=
                Math.cos(enemy.projectiles[p].angle) * enemy.pSpeed * dt;
            enemy.projectiles[p].y +=
                Math.sin(enemy.projectiles[p].angle) * enemy.pSpeed * dt;

            // checking collisions to kill bullets outside of bounds
            let dead = false;
            if (
                enemy.projectiles[p].x + enemy.pRadius >=
                enemy.bound.x + enemy.bound.w
            ) {
                dead = true;
            } else if (
                enemy.projectiles[p].x - enemy.pRadius <=
                enemy.bound.x
            ) {
                dead = true;
            }
            if (
                enemy.projectiles[p].y + enemy.pRadius >=
                enemy.bound.y + enemy.bound.h
            ) {
                dead = true;
            } else if (
                enemy.projectiles[p].y - enemy.pRadius <=
                enemy.bound.y
            ) {
                dead = true;
            }
            if (dead) {
                // take out the projectile on the array
                enemy.deadProjectiles.push({
                    ...enemy.projectiles[p],
                    life: 1,
                });
                enemy.projectiles.splice(p, 1);
            }
        }
        for (let p in enemy.deadProjectiles) {
            enemy.deadProjectiles[p].x +=
                Math.cos(enemy.deadProjectiles[p].angle) * enemy.pSpeed * dt;
            enemy.deadProjectiles[p].y +=
                Math.sin(enemy.deadProjectiles[p].angle) * enemy.pSpeed * dt;

            // checking collisions to kill bullets outside of bounds
            enemy.deadProjectiles[p].life -= dt*3.5;
            if (enemy.deadProjectiles[p].life < 0) {
                enemy.deadProjectiles.splice(p, 1);
            }
        }
    } else if (enemytype === 'tp') {
        enemy.teleportTimer += dt;
        if (enemy.teleportTimer >= enemy.teleportTime) {
            enemy.teleportTimer -= enemy.teleportTime;
            enemy.x = enemy.previewX;
            enemy.y = enemy.previewY;
        }

        enemy.previewX += enemy.xv * dt;

        if (enemy.previewX + enemy.radius >= enemy.bound.x + enemy.bound.w) {
            enemy.xv = -enemy.xv;
            enemy.previewX =
                (enemy.bound.x + enemy.bound.w) * 2 -
                enemy.previewX -
                enemy.radius * 2;
        } else if (enemy.previewX - enemy.radius <= enemy.bound.x) {
            enemy.xv = -enemy.xv;
            enemy.previewX =
                enemy.bound.x * 2 - enemy.previewX + enemy.radius * 2;
        }
        enemy.previewY += enemy.yv * dt;
        if (enemy.previewY + enemy.radius >= enemy.bound.y + enemy.bound.h) {
            enemy.yv = -enemy.yv;
            enemy.previewY =
                (enemy.bound.y + enemy.bound.h) * 2 -
                enemy.previewY -
                enemy.radius * 2;
        } else if (enemy.previewY - enemy.radius <= enemy.bound.y) {
            enemy.yv = -enemy.yv;
            enemy.previewY =
                enemy.bound.y * 2 - enemy.previewY + enemy.radius * 2;
        }
    } else if (enemytype === 'growing') {
        if (enemy.growing) {
            enemy.radius += dt * enemy.growSpeed;
            if (enemy.radius > enemy.maxRadius) {
                enemy.growing = false;
                let overGrowth = enemy.radius - enemy.maxRadius;
                enemy.radius -= overGrowth;
            }
        } else {
            enemy.radius -= dt * enemy.growSpeed;
            if (enemy.radius < enemy.minRadius) {
                enemy.growing = true;
                let underGrowth = enemy.minRadius - enemy.radius;
                enemy.radius += underGrowth;
            }
        }

        enemy.x += enemy.xv * dt;
        if (enemy.x + enemy.radius >= enemy.bound.x + enemy.bound.w) {
            enemy.xv = -enemy.xv;
            enemy.x =
                (enemy.bound.x + enemy.bound.w) * 2 -
                enemy.x -
                enemy.radius * 2;
        } else if (enemy.x - enemy.radius <= enemy.bound.x) {
            enemy.xv = -enemy.xv;
            enemy.x = enemy.bound.x * 2 - enemy.x + enemy.radius * 2;
        }
        enemy.y += enemy.yv * dt;
        if (enemy.y + enemy.radius >= enemy.bound.y + enemy.bound.h) {
            enemy.yv = -enemy.yv;
            enemy.y =
                (enemy.bound.y + enemy.bound.h) * 2 -
                enemy.y -
                enemy.radius * 2;
        } else if (enemy.y - enemy.radius <= enemy.bound.y) {
            enemy.yv = -enemy.yv;
            enemy.y = enemy.bound.y * 2 - enemy.y + enemy.radius * 2;
        }
    } else {
        enemy.x += enemy.xv * dt;

        if (enemy.x + enemy.radius >= enemy.bound.x + enemy.bound.w) {
            enemy.xv = -enemy.xv;
            enemy.x =
                (enemy.bound.x + enemy.bound.w) * 2 -
                enemy.x -
                enemy.radius * 2;
        } else if (enemy.x - enemy.radius <= enemy.bound.x) {
            enemy.xv = -enemy.xv;
            enemy.x = enemy.bound.x * 2 - enemy.x + enemy.radius * 2;
        }
        enemy.y += enemy.yv * dt;
        if (enemy.y + enemy.radius >= enemy.bound.y + enemy.bound.h) {
            enemy.yv = -enemy.yv;
            enemy.y =
                (enemy.bound.y + enemy.bound.h) * 2 -
                enemy.y -
                enemy.radius * 2;
        } else if (enemy.y - enemy.radius <= enemy.bound.y) {
            enemy.yv = -enemy.yv;
            enemy.y = enemy.bound.y * 2 - enemy.y + enemy.radius * 2;
        }
    }
}

window.runCollision = function (
    player,
    enemy,
    obstacles,
    safes,
    npcs,
    players
) {
    if (onHole) {
        onHole = false;
        return;
    }
    if (player.dead) {
        for (let o of obstacles) {
            if (o.type === 'deadpusher') {
                boundPlayerObstacle(player, o);
            }
        }
    }
    if (player.dead || player.god) return;
    // let lastpu = {};
    // for(let id of Object.keys(player.powerups)){
    //     lastpu[id] = player.powerups[id];
    // }
    const lastInv = player.powerups.inv;
    for (let i = 0; i < enemy.length; i++) {
        const ene = enemy[i];
        if(ene.inView === false){
            continue;
        }
        const enetype = ene.type;
        if (ene.deadTimer !== undefined) continue;
        if(ene.radius === 0) continue;
        if (enetype === 'square') {
            if (
                !player.dead &&
                intersectingCircleRect(player, {
                    ...ene,
                    x: ene.x - ene.size / 2,
                    y: ene.y - ene.size / 2,
                    w: ene.size,
                    h: ene.size,
                })
            ) {
                if (player.powerups.inv > 0) {
                    player.powerups.inv -= dt;
                } else {
                    player.dead = true;
                }
            }
        } else if (enetype === 'toxic') {
            if (!player.dead && intersectingCircle(player, ene)) {
                player.powerups.inv = 0;
                player.dead = true;
            }
        } else if (enetype === 'tpplayer') {
            if (!player.tpTimer) {
                player.tpTimer = 0;
            }
            if (intersectingCircle(player, ene)) {
                if (player.tpTimer <= 0) {
                    player.tpTimer = 0.5;
                    player.x = ene.other.x;
                    player.y = ene.other.y;
                }
            } else if (intersectingCircle(player, ene.other)) {
                if (player.tpTimer <= 0) {
                    player.tpTimer = 0.5;
                    player.x = ene.x;
                    player.y = ene.y;
                }
            }
        } else if (enetype === 'polygon') {
            let pts = [];
            for (let p = 0; p < ene.points.length; p++) {
                pts[p] = [ene.points[p][0] + ene.x, ene.points[p][1] + ene.y];
            }
            if (
                !player.dead &&
                boundPlayerPolygon(player, {
                    ...ene,
                    x: ene.x - ene.size / 2,
                    y: ene.y - ene.size / 2,
                    w: ene.size,
                    h: ene.size,
                    points: pts,
                })
            ) {
                if (player.powerups.inv > 0) {
                    player.powerups.inv -= dt;
                } else {
                    player.dead = true;
                }
            }
        } else if (ene.type == 'boomerang') {
            if (!player.dead && intersectingCircle(player, ene)) {
                if (player.powerups.inv > 0) {
                    player.powerups.inv -= dt;
                } else {
                    player.dead = true;
                }
            }
            for (let b in ene.boomerangs) {
                if (
                    !player.dead &&
                    intersectingCircle(player, ene.boomerangs[b])
                ) {
                    if (player.powerups.inv > 0) {
                        player.powerups.inv -= dt;
                    } else {
                        player.dead = true;
                    }
                }
            }
        } else if (ene.type == 'forcestop') {
            if (!player.dead && intersectingCircle(player, ene)) {
                player.forceStop = true;
            }
        } else if (ene.type == 'forcemove') {
            if (!player.dead && intersectingCircle(player, ene)) {
                player.forceMove = true;
                let pdirection = Math.atan2(player.yv, player.xv);
                player.lastXV = Math.cos(pdirection) * player.speed;
                player.lastYV = Math.sin(pdirection) * player.speed;
            }
        } else if (ene.type == 'oval' || ene.type == 'growingoval') {
            // fuck this collision detection ;-;
            let pts = [];
            for (
                let a = 0;
                a < 360;
                a += Math.max(10, 1000 / Math.sqrt(ene.r1 * ene.r2))
            ) {
                let radians = (a * Math.PI) / 180;
                pts.push({
                    x: Math.cos(radians) * ene.r1 + ene.x - player.x,
                    y: Math.sin(radians) * ene.r2 + ene.y - player.y,
                });
            }
            // normal circle-point collision with the player
            for (let p in pts) {
                if (Math.sqrt(pts[p].x ** 2 + pts[p].y ** 2) < player.radius) {
                    if (player.powerups.inv > 0) {
                        player.powerups.inv -= dt;
                        break;
                    } else {
                        player.dead = true;
                        break;
                    }
                }
            }
        } else if (enetype === 'flashlight') {
            if (!player.dead && intersectingCircle(player, ene)) {
                if (player.powerups.inv > 0) {
                    player.powerups.inv -= dt;
                } else {
                    player.dead = true;
                }
            }
            let dx = ene.x - player.x;
            let dy = ene.y - player.y;
            let angle = Math.atan2(-dy, -dx); // dont ask me why it works
            let enemyAngle = Math.atan2(ene.yv, ene.xv);
            if (ene.yv === 0 && ene.xv === 0) {
                // nonmovingflashlight
                enemyAngle = ene.flashlightDir;
            }
            if (Math.abs(angle - enemyAngle) < ene.flAngle / 2) {
                let flashlightToCircle = {
                    x: ene.x,
                    y: ene.y,
                    radius: ene.flSize * 0.8,
                };
                if (
                    !player.dead &&
                    intersectingCircle(player, flashlightToCircle)
                ) {
                    if (player.powerups.inv > 0) {
                        player.powerups.inv -= dt;
                    } else {
                        player.dead = true;
                    }
                }
            }
        } else if (enetype === 'memory') {
            if (!player.dead && intersectingCircle(player, ene) && ene.on) {
                if (player.powerups.inv > 0) {
                    player.powerups.inv -= dt;
                } else {
                    player.dead = true;
                }
            }
        } else if (enetype === 'outline') {
            let oldist = Math.sqrt(
                (ene.x - player.x) ** 2 + (ene.y - player.y) ** 2
            );
            if (
                !player.dead &&
                oldist < ene.radius + player.radius &&
                oldist > ene.radius - player.radius
            ) {
                if (player.powerups.inv > 0) {
                    player.powerups.inv -= dt;
                } else {
                    player.dead = true;
                }
            }
        } else if (enetype === 'jump') {
            if (!player.dead && intersectingCircle(player, ene) && ene.z <= 0) {
                if (player.powerups.inv > 0) {
                    player.powerups.inv -= dt;
                } else {
                    player.dead = true;
                }
            }
        } else if (enetype === 'enemyobstacle' || enetype === 'sticky') {
            if (ene.toKill && intersectingCircle(player, ene)) {
                if (player.powerups.inv > 0) {
                    player.powerups.inv -= dt;
                } else {
                    player.dead = true;
                }
            }
        } else if (enetype === 'flower') {
            if (!player.dead && intersectingCircle(player, ene)) {
                if (player.powerups.inv > 0) {
                    player.powerups.inv -= dt;
                } else {
                    player.dead = true;
                }
            }
            for (let j = 0; j < ene.clones.length; j++) {
                let clonerad = ene.clonesRadius;
                let clone = ene.clones[j];
                if (ene.growingMultiple != undefined) {
                    clonerad = clone.radius;
                }
                let cloneToCircle = {
                    x: clone.x,
                    y: clone.y,
                    radius: clonerad,
                };
                if (!player.dead && intersectingCircle(player, cloneToCircle)) {
                    if (ene.clonesEffect == 'slow') {
                        player.xv /= ene.effectMagnitude;
                        player.yv /= ene.effectMagnitude;
                    } else if (ene.clonesEffect == 'size') {
                        player.radius = ene.effectMagnitude;
                    } else if (ene.clonesEffect == 'grav') {
                        let dx = ene.x - player.x;
                        let dy = ene.y - player.y;
                        let distance = Math.sqrt(dx * dx + dy * dy);
                        distance *= ene.effectMagnitude;
                        let angle = Math.atan2(dy, dx);
                        player.grav.x =
                            player.grav.x / 2 +
                            (Math.cos(angle) * Math.min(distance, 200)) / 2;
                        player.grav.y =
                            player.grav.y / 2 +
                            (Math.sin(angle) * Math.min(distance, 200)) / 2;
                    } else if (ene.clonesEffect === 'vinette') {
                        window.vinette = [
                            ene.effectMagnitude[0],
                            ene.effectMagnitude[1],
                            ene.effectMagnitude[2],
                        ];
                    } else {
                        if (player.powerups.inv > 0) {
                            player.powerups.inv -= dt;
                        } else {
                            player.dead = true;
                        }
                    }
                }
            }
        } else if (enetype === 'turret') {
            if (!player.dead) {
                if (intersectingCircle(player, ene)) {
                    if (player.powerups.inv > 0) {
                        player.powerups.inv -= dt;
                    } else {
                        player.dead = true;
                    }
                }
                for (let p in ene.projectiles) {
                    let projectileToCircle = {
                        x: ene.projectiles[p].x,
                        y: ene.projectiles[p].y,
                        radius: ene.pRadius,
                    };
                    if (intersectingCircle(player, projectileToCircle)) {
                        if (player.powerups.inv > 0) {
                            player.powerups.inv -= dt;
                        } else {
                            player.dead = true;
                        }
                    }
                }
            }
        } else if (enetype === 'bomb') {
            if (!player.dead) {
                if (intersectingCircle(player, ene)) {
                    if (player.powerups.inv > 0) {
                        player.powerups.inv -= dt;
                    } else {
                        player.dead = true;
                    }
                }
                for (let b in ene.bombs) {
                    if (intersectingCircle(player, ene.bombs[b])) {
                        if (player.powerups.inv > 0) {
                            player.powerups.inv -= dt;
                        } else {
                            player.dead = true;
                        }
                    }
                }
            }
        } else if (enetype === 'fire') {
            if (!player.dead) {
                if (intersectingCircle(player, ene)) {
                    if (player.powerups.inv > 0) {
                        player.powerups.inv -= dt;
                    } else {
                        player.dead = true;
                    }
                }
                for (let f in ene.fire) {
                    if (intersectingCircle(player, ene.fire[f])) {
                        if (player.powerups.inv > 0) {
                            player.powerups.inv -= dt;
                        } else {
                            player.dead = true;
                        }
                    }
                }
            }
        } else if (!player.dead && intersectingCircle(player, ene)) {
            if (enetype === 'switch' && ene.currentSwitch) {
                if (player.powerups.inv > 0) {
                    player.powerups.inv -= dt;
                } else {
                    player.dead = true;
                }
            } else if (enetype === 'gaura') {
                //player.dead = true;
                let dx = ene.x - player.x;
                let dy = ene.y - player.y;
                let distance = Math.sqrt(dx * dx + dy * dy);
                distance *= ene.auraStrength;
                let angle = Math.atan2(dy, dx);
                player.grav.x =
                    player.grav.x / 2 +
                    (Math.cos(angle) * Math.min(distance, 200)) / 2;
                player.grav.y =
                    player.grav.y / 2 +
                    (Math.sin(angle) * Math.min(distance, 200)) / 2;
            } else if (enetype === 'nokill') {
                //player.dead = true;
                boundPlayerCircularObstacle(player, ene);
            } else if (enetype === 'wind') {
                player.grav.x =
                    player.grav.x / 2 +
                    Math.cos(Math.atan2(ene.yv, ene.xv)) * ene.strength;
                player.grav.y =
                    player.grav.y / 2 +
                    Math.sin(Math.atan2(ene.yv, ene.xv)) * ene.strength;
            } else if (enetype === 'slower') {
                if (!player.speedMults.includes(ene.speedMult)) {
                    player.speedMults.push(ene.speedMult);
                }
            } else if (
                enetype === 'growing' &&
                ene.bounceAmount !== undefined &&
                ene.bounceAmount !== null
            ) {
                let dx = player.x - ene.x;
                let dy = player.y - ene.y;
                let distance = Math.sqrt(dx * dx + dy * dy);
                let angle = Math.atan2(dy, dx);
                player.xv = Math.cos(angle) * ene.bounceAmount;
                player.yv = Math.sin(angle) * ene.bounceAmount;
            } else if (enetype === 'shh') {
                if (ene.impostor) {
                    player.dead = true;
                }
                player.hat.src = '/gfx/shh.png';
            } else if (ene.type !== 'switch' && ene.type != 'rchange' && ene.type !== 'enemygrav') {
                if (player.powerups.inv > 0) {
                    player.powerups.inv -= dt;
                } else {
                    player.dead = true;
                }
            }
        }
    }
    
    if(player.powerups.inv !== lastInv){
        send({powerups: player.powerups});
    }
    // bullets
    if (player.powerups.gun.state || player.bullets.length > 0) {
        // bullet collisions
        player.bullets.forEach((bullet, index) => {
            for (let i in enemy) {
                const ene = enemy[i];
                if (intersectingCircle(bullet, ene)) {
                    if(ene.type === 'reflectbullet' && ene.health > 0 && ene.deadTimer === undefined){
                        boundPlayerCircularObstacle(bullet, ene);
                        bullet.angle += Math.PI;
                        ene.health--;
                        send({ bullets: player.bullets });
                    } else {
                        if (bullet.type === 'normal') {
                            enemy[i].deadTimer = player.powerups.gun.effectTime||3;
                        } else if (bullet.type === 'push') {
                            boundPlayerCircularObstacle(ene, bullet);
                        } else if (bullet.type === 'stun') {
                            enemy[i].stopTimer = player.powerups.gun.effectTime||3;
                        }
                        if(ene.type === 'reflectbullet'){
                            ene.health = ene.maxHealth;
                        }
                    }
                }
            }
        });
    }

    if (player.powerups.gunslinger) {
        if (player.dead) {
            player.powerups.gunslinger = false;
            send({ powerups: player.powerups });
        }
        for (let i in enemy) {
            const ene = enemy[i];
            const cursor = { x: mouse.x, y: mouse.y, radius: 10 };
            const off = offset(ene.x, ene.y);
            if (intersectingCircle(cursor, { ...ene, x: off.x, y: off.y })) {
                send({ killEnemy: true, id: i });
                enemy[i].deadTimer = 3;
            }
        }
        let lastgsc = player.gunslingerCursor;
        player.gunslingerCursor = { x: window.mouse.x, y: window.mouse.y };
        window.gunslingerCursors[player.id] = player.gunslingerCursor;
        if (lastgsc != player.gunslingerCursor) {
            const cuoff = inverseOffset(
                player.gunslingerCursor.x,
                player.gunslingerCursor.y
            );
            send({ gsc: { x: cuoff.x, y: cuoff.y } });
        }
    }

    // // optimize powerups more in the future. Dont just send the whole thing only send the things that changed with something like this object.keys implementation
    // for(let id of Object.keys(player.powerups)){
    //     if(lastpu[id] !== player.powerups[id]){
    //         send({ powerups: player.powerups });
    //         break;
    //     }
    // }

    let onSafe = false;
    
    if(player.zMode){
        player.lastZPos = [player.x, player.y];
    }

    // new (sorted loops)
    for (let i = 0; i < (sortedObstacles.portal??[]).length; i++) {
        const obj = sortedObstacles.portal[i];
        if(obj.inView === false){
            continue;
        }
        if (intersectingCircleRect(player, obj)) {
            insideCircleSnap = false;
            if (!goingToNewWorld) {
                let volume = globalVolume;
                if (obj.musicPath === '/sounds/aiae.mp3') {
                    volume = 0.3;
                }
                if(obj.name === 'Hub'){
                    changeMusic(
                        window.hubMusicPath,
                        0,
                        1
                    );
                } else {
                    changeMusic(
                        obj.musicPath ?? '/sounds/drip.mp3',
                        0,
                        volume
                    );   
                }
                if (obj.name === 'Comet of Mini Extra Tests Hard') {
                    send({ world: 'CoMETHard' });
                } else {
                    send({ world: obj.acronym });
                }
                // to prevent ship/ powerups in another world bug
                setTimeout(() => {
                    send({powerups: player.powerups})
                    send({ship: player.ship});
                }, 400)

                goingToNewWorld = true;
            }
        }
    }

    for (let i = 0; i < (sortedObstacles.check??[]).length; i++) {
        const obj = sortedObstacles.check[i];
        if(obj.inView === false){
            continue;
        }
        if (
            !obj.collected &&
            intersectingCircleRect(
                player,
                obj
            )
        ) {
            obj.collected = true;
            send({
                checkpoint: {
                    x: obj.x + obj.w / 2,
                    y: obj.y + obj.h / 2,
                },
            });
        }
    }
    
    for (let i = 0; i < (sortedObstacles.tps??[]).length; i++) {
        const obj = sortedObstacles.tps[i];
        if(obj.inView === false){
            continue;
        }
        if (
            intersectingCircleRect(
                player,
                obj
            )
        ) {
            player.x = obj.tpx;
            player.y = obj.tpy;
            player.isTyping = false;
            player.grav.x = 0;
            player.grav.y = 0;
            player.xv = 0;
            player.yv = 0;
            insideCircleSnap = false;
            // Tp whoosh sound
            if (sw.currentTime > 0) {
                sw.currentTime = 0;
            }
            sw.play();
            if (obj.changeColor) {
                if (obj.bgColor != undefined) {
                    window.backgroundColor = obj.bgColor;
                }
                if (obj.tileColor != undefined) {
                    window.tileColor = obj.tileColor;
                }
            }
        }
    }
    
    for (let i = 0; i < (sortedObstacles.square??[]).length; i++) {
        const obj = sortedObstacles.square[i];
        if(obj.inView === false){
            continue;
        }
        boundPlayerObstacle(player, obj)
    }

    for (let i = 0; i < (sortedObstacles.doors??[]).length; i++) {
        const obj = sortedObstacles.doors[i];
        if(obj.inView === false){
            continue;
        }
        if(obj.active){
            boundPlayerObstacle(player, obj);
        }
    }

    for (let i = 0; i < (sortedObstacles.circles??[]).length; i++) {
        const obj = sortedObstacles.circles[i];
        if(obj.inView === false){
            continue;
        }
        const value = boundPlayerCircularObstacle(player, obj)
        if (value) {
            onSafe = value;
        }
    }

    for (let i = 0; i < (sortedObstacles.polys??[]).length; i++) {
        const obj = sortedObstacles.polys[i];
        if(obj.inView === false){
            continue;
        }
        const value = boundPlayerPolygon(player, obj);
        if (value) {
            onSafe = value;
        }
    }

    for (let i = 0; i < (sortedObstacles.breakable??[]).length; i++) {
        const obj = sortedObstacles.breakable[i];
        if(obj.inView === false){
            continue;
        }
        if(obj.currentStrength > 0){
            boundPlayerObstacle(player, obj);
        }
    }

    for (let i = 0; i < (sortedObstacles.bouncybreakable??[]).length; i++) {
        const obj = sortedObstacles.bouncybreakable[i];
        if(obj.inView === false){
            continue;
        }
        if(obj.currentStrength > 0){
            boundPlayerObstacle(player, obj);
        }
    }

    for (let i = 0; i < (sortedObstacles.switch??[]).length; i++) {
        const obj = sortedObstacles.switch[i];
        if(obj.inView === false){
            continue;
        }
        if(obj.state){
            boundPlayerObstacle(player, obj);
        }
    }

    for (let i = 0; i < (sortedObstacles.morphnormal??[]).length; i++) {
        const obj = sortedObstacles.morphnormal[i];
        if(obj.inView === false){
            continue;
        }
        if (obj.active) {
            boundPlayerObstacle(player, obj);
        }
    }

    for (let i = 0; i < (sortedObstacles.coindoor??[]).length; i++) {
        const obj = sortedObstacles.coindoor[i];
        if(obj.inView === false){
            continue;
        }
        if(obj.currentCoins > 0){
            boundPlayerObstacle(player, obj);
        }
    }

    for (let i = 0; i < (sortedObstacles.custom??[]).length; i++) {
        const obj = sortedObstacles.custom[i];
        if(obj.inView === false){
            continue;
        }
        if(obj.collidable != false){
            boundPlayerObstacle(player, obj);
        }
    }

    for (let i = 0; i < (sortedObstacles.cookie??[]).length; i++) {
        const obj = sortedObstacles.cookie[i];
        if(obj.inView === false){
            continue;
        }
        if((getCookie(obj.cookie) !== obj.value || (obj.value == 'any' && getCookie(obj.cookie == '')))){
            boundPlayerObstacle(player, obj);
        }
    }

    for (let i = 0; i < (sortedObstacles.bezier??[]).length; i++) {
        const obj = sortedObstacles.bezier[i];
        if(obj.inView === false){
            continue;
        }
        boundPlayerPolygon(player, obj.polygon);
    }

    for (let i = 0; i < (sortedObstacles.roundedcorners??[]).length; i++) {
        const obj = sortedObstacles.roundedcorners[i];
        if(obj.inView === false){
            continue;
        }
        // bounding by all the obj's circles and rects
        for (let circle of obj.circles) {
            boundPlayerCircularObstacle(player, {
                ...circle,
                type: 'circle-normal',
            });
        }
        for (let rect of obj.rects) {
            boundPlayerObstacle(player, { ...rect, type: 'normal' });
        }
    }

    for (let i = 0; i < (sortedObstacles.roundedlava??[]).length; i++) {
        const obj = sortedObstacles.roundedlava[i];
        if(obj.inView === false){
            continue;
        }
        // bounding by all the obj's circles and rects
        for (let circle of obj.circles) {
            boundPlayerCircularObstacle(player, {
                ...circle,
                r: circle.radius,
                type: 'circle-lava',
            });
        }
        for (let rect of obj.rects) {
            boundPlayerObstacle(player, { ...rect, type: 'lava' });
        }
    }

    for (let i = 0; i < (sortedObstacles['z-mode']??[]).length; i++) {
        const obj = sortedObstacles['z-mode'][i];
        if(obj.inView === false){
            continue;
        }
        // bounding by all the obj's circles and rects
        if (intersectingCircleRect(player, obj)) {
            player.zMode = obj.state;
        }
    }

    for (let i = 0; i < (sortedObstacles.ovals??[]).length; i++) {
        const obj = sortedObstacles.ovals[i];
        if(obj.inView === false){
            continue;
        }
        boundPlayerOval(player, obj);
    }

    for (let i = 0; i < (sortedObstacles.rotating??[]).length; i++) {
        const obj = sortedObstacles.rotating[i];
        if(obj.inView === false){
            continue;
        }
        boundPlayerRotatingObstacle(player, obj);
    }

    for (let i = 0; i < (sortedObstacles.rotatepause??[]).length; i++) {
        const obj = sortedObstacles.rotatepause[i];
        if(obj.inView === false){
            continue;
        }
        boundPlayerRotatingObstacle(player, obj);
    }

    for (let i = 0; i < (sortedObstacles.fulldeath??[]).length; i++) {
        const obj = sortedObstacles.fulldeath[i];
        if(obj.inView === false){
            continue;
        }
        if (intersectingCircleRect({...player, radius: -player.radius}, obj)) {
            player.dead = true;
        }
    }

    for (let i = 0; i < (sortedObstacles.dirnormal??[]).length; i++) {
        const obj = sortedObstacles.dirnormal[i];
        if(obj.inView === false){
            continue;
        }
        if (!obj.active && (
                (obj.dir === 'up' && player.y + player.radius < obj.y) ||
                (obj.dir === 'down' && player.y - player.radius > obj.y + obj.h) ||
                (obj.dir === 'left' && player.x + player.radius > obj.x) ||
                (obj.dir === 'right' && player.x - player.radius < obj.x + obj.w)
            )) {
            obj.active = true;
            obj.activeTimer = 0;
        }
        if (obj.active) {
            boundPlayerObstacle(player, obj)
        }
    }

    for (let i = 0; i < (sortedObstacles.pushboxreset??[]).length; i++) {
        const obj = sortedObstacles.pushboxreset[i];
        if(obj.inView === false){
            continue;
        }
        if (intersectingCircleRect(player, obj)) {
            let reset = false;
            for (const o of obstacles) {
                if (o.type !== 'pushboxreset' && o.resetId != undefined && o.resetId > -1
                    && (o.x !== o.initX || o.y !== o.initY))  {
                    o.x = o.initX;
                    o.y = o.initY;
                    reset = true;
                }
            }
            if (reset) {
                // audios[buttonPath].currentTime = 0;
                // audios[buttonPath].play()
                playAudio(buttonPath, 0.05);
            }
        }
    }

    for (let i = 0; i < (sortedObstacles.circularpushbox??[]).length; i++) {
        const obj = sortedObstacles.circularpushbox[i];
        if(obj.inView === false){
            continue;
        }
        const weight = obj.weight;
        const csat = returnIntersectingCircles(player, obj);
        if (csat != false) {
            obj.x += csat.overlapV.x * ((100-weight) / 100);
            obj.y += csat.overlapV.y * ((100-weight)/100);
        }
        obj.id = Math.random()
        for (const obj2 of obstacles) {
            if (obj2.type === 'lava') {
                const collisionSAT2 = returnIntersectingCircleRect(obj, obj2);
                if (collisionSAT2 != false) {
                    // reset
                    obj.x = obj.initX;
                    obj.y = obj.initY;
                }
            }
            if (obj2.type === 'normal') {
                const csat2 = returnIntersectingCircleRect(obj, obj2);
                if (csat2 != false) {
                    obj.x += csat2.overlapV.x;
                    obj.y += csat2.overlapV.y;
                }
            }
            if (obj2.type === 'pushbox') {
                const csat2 = returnIntersectingCircleRect(obj, obj2)
                if (csat2 != false) {
                     obj2.x -=
                        csat2.overlapV.x *
                        ((100 - obj2.weight) / 100);
                    obj2.y -=
                        csat2.overlapV.y *
                        ((100 - obj2.weight) / 100);
                }
            }
            if (obj2.type === 'circularpushbox' && obj.id !== obj2.id) {
                const csat2 = returnIntersectingCircles(obj, obj2);
                if (csat2 != false) {
                    obj2.x +=
                        csat2.overlapV.x *
                        ((100 - obj2.weight) / 100);
                    obj2.y +=
                        csat2.overlapV.y *
                        ((100 - obj2.weight) / 100);
                }
            }
        }
         delete obj.id;
        const collisionSAT3 = returnIntersectingCircles(
            player,
            obj
        );
        if (collisionSAT3 != false) {
            // obj.x -= collisionSAT3.overlapV.x ;
            // obj.y -= collisionSAT3.overlapV.y ;
            // player.x += collisionSAT3.overlapV.x  * ((100-weight) / 100);
            // player.y += collisionSAT3.overlapV.y  * ((100-weight) / 100);
            player.xv *= weight / 100;
            player.yv *= weight / 100;
        }
         const collisionSAT4 = returnIntersectingCircles(
            player,
            obj
        );
        if (collisionSAT4 != false) {
            // obj.x -= collisionSAT3.overlapV.x ;
            // obj.y -= collisionSAT3.overlapV.y ;
            player.x -= collisionSAT4.overlapV.x
            player.y -= collisionSAT4.overlapV.y
        }

        // for (const obj2 of obstacles) {
//                 if (obj2.type === 'lava') {
//                     const collisionSAT2 = returnIntersectingRectRect(obj, obj2);
//                     if (collisionSAT2 != false) {
//                         // reset
//                         obj.x = obj.initX;
//                         obj.y = obj.initY;
//                     }
//                 }
//                 if (
//                     obj2.type === 'normal' ||
//                     ((obj2.type === 'pushbox' || obj2.type === 'circularpushbox') && obj2.id !== obj.id)
//                 ) {
        // 		let collisionSAT2 = false;
        // 		if (obj2.type === 'circularpushbox' && obj2.type !== 'normal') {
        // 			collisionSAT2 = returnIntersectingCircles(obj, obj2)
        // 		} else {
//                     	 collisionSAT2 = returnIntersectingCircleRect(obj, obj2);
        // 		}
//                     if (collisionSAT2 != false) {
//                         if (obj2.type === 'pushbox' || obj2.type === 'circularpushbox') {
//                             obj2.x +=
//                                 collisionSAT2.overlapV.x *
//                                 ((100 - obj2.weight) / 100);
//                             obj2.y +=
//                                 collisionSAT2.overlapV.y *
//                                 ((100 - obj2.weight) / 100);
//                         } else {
//                             obj.x -= collisionSAT2.overlapV.x;
//                             obj.y -= collisionSAT2.overlapV.y;
//                         }
//                     }
//                 }
//             }
//             delete obj.id;
        //  const collisionSAT3 = returnIntersectingCircles(
//                 player,
//                 obj
//             );
//             if (collisionSAT3 != false) {
//                 // obj.x -= collisionSAT.overlapV.x ;
//                 // obj.y -= collisionSAT.overlapV.y ;
//                 player.x += collisionSAT3.overlapV.x;
//                 player.y += collisionSAT3.overlapV.y;
//                 player.xv *= weight / 100;
//                 player.yv *= weight / 100;
//             }
        if (
            !obj.lastPos ||
            obj.lastPos.x !== obj.x ||
            obj.lastPos.y !== obj.y
        ) {
            // send pusher
            if (
                obj.x === obj.initX &&
                obj.y === obj.initY
            ) {
                send({
                    removepusher: obj.pusherId,
                });
            } else {
                send({
                    pusher: {
                        x: obj.x,
                        y: obj.y,
                        pusherId: obj.pusherId,
                    },
                });
            }
        }
        obj.lastPos = {
            x: obj.x,
            y: obj.y,
        };
    }

    for (let i = 0; i < (sortedObstacles.pushbox??[]).length; i++) {
        const obj = sortedObstacles.pushbox[i];
        if(obj.inView === false){
            continue;
        }
        // weight contstraint -> [1, 100]
        // const weight = (Date.now() / 100) % 50;
        const weight = obj.weight;

        const collisionSAT = returnIntersectingCircleRect(
            player,
            obj
        );
        if (collisionSAT != false) {
            obj.x -=
                collisionSAT.overlapV.x * ((100 - weight) / 100);
            obj.y -=
                collisionSAT.overlapV.y * ((100 - weight) / 100);

            // player.xv *= (weight / 100);
            // player.yv *= (weight / 100);
            // player.x += collisionSAT.overlapV.x ;
            // player.y += collisionSAT.overlapV.y ;
        }
        obj.id = Math.random();
        for (const obj2 of obstacles) {
            if (obj2.type === 'lava') {
                const collisionSAT2 = returnIntersectingRectRect(obj, obj2);
                if (collisionSAT2 != false) {
                    // reset
                    obj.x = obj.initX;
                    obj.y = obj.initY;
                }
            }
            if (
                obj2.type === 'normal' ||
                ((obj2.type === 'pushbox' ) && obj2.id !== obj.id)
            ) {
                let collisionSAT2 = false;
                    collisionSAT2 = returnIntersectingRectRect(obj, obj2);
                if (collisionSAT2 != false) {
                    if (obj2.type === 'pushbox' ) {
                        obj2.x +=
                            collisionSAT2.overlapV.x *
                            ((100 - obj2.weight) / 100);
                        obj2.y +=
                            collisionSAT2.overlapV.y *
                            ((100 - obj2.weight) / 100);
                    } else {
                        obj.x -= collisionSAT2.overlapV.x;
                        obj.y -= collisionSAT2.overlapV.y;
                    }
                }
            }
            if (obj2.type === 'circularpushbox') {
                let csat2 = returnIntersectingCircleRect(obj2, obj);
                if (csat2 != false) {
                    obj2.x +=
                        csat2.overlapV.x *
                        ((100 - obj2.weight) / 100);
                    obj2.y +=
                        csat2.overlapV.y *
                        ((100 - obj2.weight) / 100);
                }
            }
        }
        delete obj.id;
        const collisionSAT3 = returnIntersectingCircleRect(
            player,
            obj
        );
        if (collisionSAT3 != false) {
            // obj.x -= collisionSAT.overlapV.x ;
            // obj.y -= collisionSAT.overlapV.y ;
            player.x += collisionSAT3.overlapV.x;
            player.y += collisionSAT3.overlapV.y;
            player.xv *= weight / 100;
            player.yv *= weight / 100;
        }

        if (
            !obj.lastPos ||
            obj.lastPos.x !== obj.x ||
            obj.lastPos.y !== obj.y
        ) {
            // send pusher
            if (
                obj.x === obj.initX &&
                obj.y === obj.initY
            ) {
                send({
                    removepusher: obj.pusherId,
                });
            } else {
                send({
                    pusher: {
                        x: obj.x,
                        y: obj.y,
                        pusherId: obj.pusherId,
                    },
                });
            }
        }
        obj.lastPos = {
            x: obj.x,
            y: obj.y,
        };
    }

    for (let i = 0; i < (sortedObstacles.color??[]).length; i++) {
        const obj = sortedObstacles.color[i];
        if(obj.inView === false){
            continue;
        }
        if (intersectingCircleRect(player, obj)) {
            window.backgroundColor = obj.bgColor;
            window.tileColor = obj.tileColor;
        }
    }

    for (let i = 0; i < (sortedObstacles.story??[]).length; i++) {
        const obj = sortedObstacles.story[i];
        if(obj.inView === false){
            continue;
        }
        if (
            intersectingCircleRect(
                player,
                obj
            )
        ) {
            return true;
        }
    }

    for (let i = 0; i < (sortedObstacles.musicchange??[]).length; i++) {
        const obj = sortedObstacles.musicchange[i];
        if(obj.inView === false){
            continue;
        }
        if(
            intersectingCircleRect(player, obj) &&
            (bg === undefined || bg.src.split('sounds/')[1].replaceAll('%20', ' ') !== obj.musicPath.split('sounds/')[1]) &&
            !goingToNewWorld
        ) {
            // add fade to audio sometime soon
            changeMusic(obj.musicPath ?? '/sounds/drip.mp3', obj.startTime??0, obj.volume??1);
        }
    }

    for (let i = 0; i < (sortedObstacles.winpad??[]).length; i++) {
        const obj = sortedObstacles.winpad[i];
        if(obj.inView === false){
            continue;
        }
        if (intersectingCircleRect(player, obj)) {
            shouldUpdateTimer = false;
            if (window.won) {
                if (!goingToNewWorld) {
                    send({ world: 'Hub' });
                    changeMusic(hubMusicPath);
                    window.backgroundColor = '#1f2229';
                    window.tileColor = '#323645';
                    goingToNewWorld = true;
                    window.won = false;
                }
            } else {
                if (!goingToNewWorld) {
                    if (player.strokes && player.strokes > 0) {
                        send({
                            world: 'Winroom',
                            win: true,
                            time: String(window.timer).toRenderTime(),
                            strokes: player.strokes,
                        });
                    } else {
                        send({
                            world: 'Winroom',
                            win: true,
                            time: String(window.timer).toRenderTime(),
                        });
                    }
                    changeMusic('/sounds/showtime.mp3');
                    window.won = true;
                    goingToNewWorld = true;
                }
            }
            // to prevent ship/ powerups in another world bug
            setTimeout(() => {
                send({powerups: player.powerups})
                send({ship: player.ship});
            }, 400)
        }
    }

    for (let i = 0; i < (sortedObstacles.safecollisions??[]).length; i++) {
        const obj = sortedObstacles.safecollisions[i];
        if(obj.inView === false){
            continue;
        }
        if(intersectingCircleRect(player, obj)) {
            onSafe = true;
        }
    }

    for (let i = 0; i < (sortedObstacles.rotatingsafe??[]).length; i++) {
        const obj = sortedObstacles.rotatingsafe[i];
        if(obj.inView === false){
            continue;
        }
        if(boundPlayerRotatingObstacle(player, obj)) {
            onSafe = true;
        }
    }

    for (let i = 0; i < (sortedObstacles['circle-sentry']??[]).length; i++) {
        const obj = sortedObstacles['circle-sentry'][i];
        if(obj.inView === false){
            continue;
        }
        boundPlayerCircularObstacle(player, obj);
        boundPlayerRotatingObstacle(player, {
            ...obj.laser,
            angle: obj.angle,
            type: 'rotate-lava',
        });
    }

    for (let i = 0; i < (sortedObstacles['circle-turret-sentry']??[]).length; i++) {
        const obj = sortedObstacles['circle-turret-sentry'][i];
        if(obj.inView === false){
            continue;
        }
        boundPlayerCircularObstacle(player, obj);
        for(let i = 0; i < obj.bullets.length; i++){
            if(intersectingCircle(player, {...obj.bullets[i], radius: obj.bulletRadius})){
                player.dead = true;
            }
        }
    }

    if(player.zMode && player.lastZPos){
        player.x = player.lastZPos[0];
        player.y = player.lastZPos[1];
    }

    for (let i = 0; i < safes.length; i++) {
        if (intersectingCircleRect(player, safes[i])) {
            onSafe = true;
        }
    }

    if (player.powerups.gun.state || player.bullets.length > 0) {
        if (player.dead && !onSafe) {
            player.powerups.gun.state = false;
            send({ powerups: player.powerups });
        }
        if (!player.powerups.gun.state) {
            player.bullets = [];
            send({ bullets: player.bullets });
        }
    }

    for (let i = 0; i < npcs.length; i++) {
        boundPlayerCircularObstacle(player, { ...npcs[i], radius: npcs[i].r });
    }
    player.onSafe = onSafe;

    if (onSafe) {
        player.dead = false;
    }

    if(player.safe){
        player.safe = false;
        player.dead = false;
    }

    if (player.dead) {
        //player.ship = false;
        //send({ ship: false });
        send({ dead: true });
    }
};
window.goingToNewWorld = false;

function intersectingCircleRect(circle, rect, genCircleSat = false) {
    const distX = Math.abs(circle.x - rect.x - rect.w / 2);
    const distY = Math.abs(circle.y - rect.y - rect.h / 2);
    debug.cTests[1]++;
	if (circle.r !== undefined) { circle.radius = circle.r }
    if (
        distX < rect.w / 2 + circle.radius &&
        distY < rect.h / 2 + circle.radius
    ) {
        let circleSat;
		if (circle.sat != undefined && !genCircleSat) {
			circleSat = circle.sat;
		} else {
			 circleSat = new SAT.Circle(
                new SAT.Vector(circle.x, circle.y),
                circle.radius
            );
		}
        // if (genCircleSat) {
        //     circleSat = new SAT.Circle(
        //         new SAT.Vector(circle.x, circle.y),
        //         circle.radius
        //     );
        // } else {
        //     circleSat = circle.sat;
        // }
        const res = new SAT.Response();
        const boxSat = new SAT.Box(
            new SAT.Vector(rect.x, rect.y),
            rect.w,
            rect.h
        ).toPolygon();
        const collision = SAT.testPolygonCircle(boxSat, circleSat, res);
        debug.cTests[0]++;
        if (collision) {
            return true;
        }
    }
    return false;
}

function returnIntersectingCircles(circle1, circle2) {
	if (intersectingCircle(circle1, circle2)) {
		const c1 = new SAT.Circle(new SAT.Vector(circle1.x, circle1.y), circle1.radius ?? circle1.r);
		const c2 = new SAT.Circle(new SAT.Vector(circle2.x, circle2.y), circle2.radius ?? circle2.r);
		const res = new SAT.Response();
		const collision = SAT.testCircleCircle(c1, c2, res);
		if (collision) {
			return res;
		}
	}
	return false;
}

function returnIntersectingCircleRect(circle, rect, genCircleSat = false) {
    const distX = Math.abs(circle.x - rect.x - rect.w / 2);
    const distY = Math.abs(circle.y - rect.y - rect.h / 2);
    debug.cTests[1]++;
	if (circle.r != undefined) circle.radius = circle.r
    if (
        distX < rect.w / 2 + circle.radius &&
        distY < rect.h / 2 + circle.radius
    ) {
        let circleSat;
		if (circle.sat != undefined && !genCircleSat) {
			circleSat = circle.sat;
		} else {
			 circleSat = new SAT.Circle(
                new SAT.Vector(circle.x, circle.y),
                circle.radius
            );
		}
        const res = new SAT.Response();
        const boxSat = new SAT.Box(
            new SAT.Vector(rect.x, rect.y),
            rect.w,
            rect.h
        ).toPolygon();
        const collision = SAT.testPolygonCircle(boxSat, circleSat, res);
        debug.cTests[0]++;
        if (collision) {
            return res;
        }
    }
    return false;
}

function returnBoundPlayerPolygon(player, polygon) {
    let touching = false;
    let OnSafe = false;
    for (let i = 0; i < polygon.points.length; i++) {
        if (i === 0) {
            if (
                lineCircleCollide(
                    polygon.points[polygon.points.length - 1],
                    polygon.points[0],
                    player,
                    player.radius
                )
            ) {
                touching = true;
                break;
            }
        } else if (i === polygon.points.length) {
            if (
                lineCircleCollide(
                    polygon.points[i],
                    polygon.points[0],
                    player,
                    player.radius
                )
            ) {
                touching = true;
                break;
            }
        } else {
            if (
                lineCircleCollide(
                    polygon.points[i - 1],
                    polygon.points[i],
                    player,
                    player.radius
                )
            ) {
                touching = true;
                break;
            }
        }
    }
    if (!touching && polygon.type != 'poly-safe') {
        return false;
    }
    const polySat = new SAT.Polygon(new SAT.Vector(0, 0), [
        ...polygon.points.map(([x, y]) => new SAT.Vector(x, y)),
    ]);
    const res = new SAT.Response();
    const playersat =
        player.sat ||
        new SAT.Circle(new SAT.Vector(player.x, player.y), player.radius);
    const collision = SAT.testPolygonCircle(polySat, playersat, res);
    if (collision) {
        return res;
    } else {
        return false;
    }
}

function returnIntersectingRectRect(rect1, rect2) {
    // optimiztion could be done
    const r1 = new SAT.Box(
        new SAT.Vector(rect1.x, rect1.y),
        rect1.w,
        rect1.h
    ).toPolygon();
    const r2 = new SAT.Box(
        new SAT.Vector(rect2.x, rect2.y),
        rect2.w,
        rect2.h
    ).toPolygon();
    const res = new SAT.Response();
    const collision = SAT.testPolygonPolygon(r1, r2, res);
    if (collision) {
        return res;
    }
    return false;
}


function intersectingCircle(circle1, circle2) {
	const c1R = circle1.radius ?? circle1.r;
	const c2R = circle2.radius ?? circle2.r;
    return (
        (circle1.x - circle2.x) * (circle1.x - circle2.x) +
            (circle1.y - circle2.y) * (circle1.y - circle2.y) <
        (c1R+c2R) * (c1R+c2R)
    );
}

function getCookie(cname) {
    let name = cname + '=';
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(';');
    for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return '';
}

// seeding
function mulberry32(a) {
    var t = (a += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}

function simulateNormalEnemy(enemy, dt) {
    enemy.x += enemy.xv * dt;
    if (enemy.x + enemy.radius >= enemy.bound.x + enemy.bound.w) {
        enemy.xv = -enemy.xv;
        enemy.x =
            (enemy.bound.x + enemy.bound.w) * 2 - enemy.x - enemy.radius * 2;
    } else if (enemy.x - enemy.radius <= enemy.bound.x) {
        enemy.xv = -enemy.xv;
        enemy.x = enemy.bound.x * 2 - enemy.x + enemy.radius * 2;
    }
    enemy.y += enemy.yv * dt;
    if (enemy.y + enemy.radius >= enemy.bound.y + enemy.bound.h) {
        enemy.yv = -enemy.yv;
        enemy.y =
            (enemy.bound.y + enemy.bound.h) * 2 - enemy.y - enemy.radius * 2;
    } else if (enemy.y - enemy.radius <= enemy.bound.y) {
        enemy.yv = -enemy.yv;
        enemy.y = enemy.bound.y * 2 - enemy.y + enemy.radius * 2;
    }
}


function simulateOscillatingEnemy(dt, enemy) {
    let nextPointIndex = enemy.currentPoint + 1;
    if (nextPointIndex >= enemy.points.length) {
        nextPointIndex = 0;
    }
    enemy.pointTo = enemy.points[nextPointIndex];
    enemy.pointOn = enemy.points[enemy.currentPoint];
    enemy.angle = Math.atan2(
        enemy.pointTo.y - enemy.y,
        enemy.pointTo.x - enemy.x
    );
    enemy.xv = Math.cos(enemy.angle) * enemy.speed;
    enemy.yv = Math.sin(enemy.angle) * enemy.speed;
    enemy.x += enemy.xv * dt;
    enemy.y += enemy.yv * dt;
    let timeRemain = 0;
    let over = false;
    if (Math.abs(enemy.yv) > Math.abs(enemy.xv)) {
        if (enemy.pointTo.y > enemy.pointOn.y) {
            if (enemy.y > enemy.pointTo.y) {
                over = true;
            }
        } else {
            if (enemy.y < enemy.pointTo.y) {
                over = true;
            }
        }
    } else {
        if (enemy.pointTo.x > enemy.pointOn.x) {
            if (enemy.x > enemy.pointTo.x) {
                over = true;
            }
        } else {
            if (enemy.x < enemy.pointTo.x) {
                over = true;
            }
        }
    }
    if (over == true) {
        enemy.currentPoint++;
        if (enemy.currentPoint > enemy.points.length - 1) {
            enemy.currentPoint = 0;
        }
        timeRemain = Math.sqrt(
            Math.pow(enemy.y - enemy.pointTo.y, 2) +
                Math.pow(enemy.x - enemy.pointTo.x, 2)
        );
        enemy.x = enemy.pointTo.x;
        enemy.y = enemy.pointTo.y;
        timeRemain /= enemy.speed;

        simulateOscillatingEnemy(timeRemain, enemy);
    }
}

function simulateMovingEnemy(dt, enemy) {
    let nextPointIndex = enemy.currentPoint + 1;
    if (nextPointIndex >= enemy.points.length) {
        nextPointIndex = 0;
    }
    let nextPoint = enemy.points[nextPointIndex];
    let currentPoint = enemy.points[enemy.currentPoint];
    enemy.pointTo = { x: nextPoint[0], y: nextPoint[1] };
    enemy.pointOn = { x: currentPoint[0], y: currentPoint[1] };
    enemy.angle = Math.atan2(
        enemy.pointTo.y - enemy.pointOn.y,
        enemy.pointTo.x - enemy.pointOn.x
    );
    enemy.xv = Math.cos(enemy.angle) * enemy.speed;
    enemy.yv = Math.sin(enemy.angle) * enemy.speed;
    enemy.x += enemy.xv * dt;
    enemy.y += enemy.yv * dt;
    let timeRemain = 0;
    let over = false;
    if (Math.abs(enemy.yv) > Math.abs(enemy.xv)) {
        if (enemy.pointTo.y > enemy.pointOn.y) {
            if (enemy.y > enemy.pointTo.y) {
                over = true;
            }
        } else {
            if (enemy.y < enemy.pointTo.y) {
                over = true;
            }
        }
    } else {
        if (enemy.pointTo.x > enemy.pointOn.x) {
            if (enemy.x > enemy.pointTo.x) {
                over = true;
            }
        } else {
            if (enemy.x < enemy.pointTo.x) {
                over = true;
            }
        }
    }
    if (over == true) {
        enemy.currentPoint++;
        if (enemy.currentPoint > enemy.points.length - 1) {
            enemy.currentPoint = 0;
        }
        timeRemain = Math.sqrt(
            Math.pow(enemy.y - enemy.pointTo.y, 2) +
                Math.pow(enemy.x - enemy.pointTo.x, 2)
        );
        enemy.x = enemy.pointTo.x;
        enemy.y = enemy.pointTo.y;
        timeRemain /= enemy.speed;
        enemy.pointOn = enemy.points[enemy.state];

        simulateMovingEnemy(timeRemain, enemy);
    }
}

function simulateRainEnemy(dt, enemy){
    if (enemy.toWait) {
        enemy.timer += dt;
        if (enemy.timer >= enemy.waitTimer) {
            let timeRemain = enemy.timer - enemy.waitTimer;
            enemy.timer = 0;
            enemy.toWait = !enemy.toWait;
            simulateRainEnemy(timeRemain, enemy);
        }
    } else {
        enemy.x += enemy.xv * dt;
        enemy.y += enemy.yv * dt;
    }
    if (enemy.toWarp) {
        if(enemy.toWait){
            return;
        }
        if(enemy.direction === 'horizontal'){
            if (enemy.x + enemy.radius >= enemy.bound.x + enemy.bound.w) {
                enemy.x = enemy.radius + enemy.bound.x;
                enemy.toWait = true;
            } else if (enemy.x - enemy.radius <= enemy.bound.x) {
                enemy.x = enemy.bound.x + enemy.bound.w - enemy.radius;
                enemy.toWait = true;
            }
        } else {
            if (enemy.y + enemy.radius >= enemy.bound.y + enemy.bound.h) {
                enemy.y = enemy.bound.y + enemy.radius;
                enemy.toWait = true;
            } else if (enemy.y - enemy.radius <= enemy.bound.y) {
                enemy.y = enemy.bound.y + enemy.bound.h - enemy.radius;
                enemy.toWait = true;
            }
        }
    } else {
        if(enemy.direction === 'horizontal'){
            if (enemy.x + enemy.radius >= enemy.bound.x + enemy.bound.w) {
                enemy.xv = -enemy.xv;
                enemy.x =
                    (enemy.bound.x + enemy.bound.w) * 2 -
                    enemy.x -
                    enemy.radius * 2;
                enemy.toWait = true;
            } else if (enemy.x - enemy.radius <= enemy.bound.x) {
                enemy.xv = -enemy.xv;
                enemy.x = enemy.bound.x * 2 - enemy.x + enemy.radius * 2;
                enemy.toWait = true;
            }
        } else {
            if (enemy.y + enemy.radius >= enemy.bound.y + enemy.bound.h) {
                enemy.yv = -enemy.yv;
                enemy.y =
                    (enemy.bound.y + enemy.bound.h) * 2 -
                    enemy.y -
                    enemy.radius * 2;
                enemy.toWait = true;
            } else if (enemy.y - enemy.radius <= enemy.bound.y) {
                enemy.yv = -enemy.yv;
                enemy.y = enemy.bound.y * 2 - enemy.y + enemy.radius * 2;
                enemy.toWait = true;
            }
        }
    }
}

function checkAngleBetween(n, a, b) {
    // in radians
    n *= 180 / Math.PI;
    a *= 180 / Math.PI;
    b *= 180 / Math.PI;
    n = (360 + (n % 360)) % 360;
    a = (3600000 + a) % 360;
    b = (3600000 + b) % 360;

    if (a < b) return a <= n && n <= b;
    return a <= n || n <= b;
}

function checkAngleBetweenInDegrees(n, a, b) {
    // in radians
    n = (360 + (n % 360)) % 360;
    a = (3600000 + a) % 360;
    b = (3600000 + b) % 360;

    if (a < b) return a <= n && n <= b;
    return a <= n || n <= b;
}

function deepCompareObjects(a,b){
    if(!a || !b) return false;
    for ( let p in a ) {
        if (a[p] === b[p]) continue;

        if(b[p] === undefined) return false;

        if (typeof(a[p]) !== "object") return false;
        // Numbers, Strings, Functions, Booleans must be strictly equal

        if (!deepCompareObjects(a[p],  b[p])) return false;
        // Objects and Arrays must be tested recursively
        
    }
    for (let p in b){
        if(a[p] === undefined) return false;
    }
    return true;
}