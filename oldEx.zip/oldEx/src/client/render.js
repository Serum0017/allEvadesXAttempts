function renderPlayers(players) {
    for (const playerId of Object.keys(players)) {
        players[playerId].renderTrail();
    }
    for (const playerId of Object.keys(players)) {
        players[playerId].render();
    }
    for (let i in me().clones) {
        renderClone(me().clones[i], me());
    }
    for (let i in window.otherClones) {
        let woc = window.otherClones[i];
        if (woc !== undefined) {
            for (let j in woc) {
                if (woc[j] !== undefined && woc[j].parentId !== selfId) {
                    renderClone(woc[j], players[woc[j].parentId]);
                }
            }
        }
    }
}
window.renderScale = 1;
function generateConveyorImage(image, canvas) {
    const canv = document.createElement('canvas');
    const cx = canv.getContext('2d');
    if(window.renderScale < 0.1){
        return canv;
    }
    canv.width = canvas.width/window.renderScale + 100;
    canv.height = canvas.height/window.renderScale + 100;
	try { 
	    for (let i = 0; i < canv.width/50; i++) {
	        for (let j = 0; j < canv.height/50; j++) {
	            // lol this should work
	            cx.drawImage(image, i * 50, j * 50);
	        }
	    }
	} catch (err) {
		console.error(err);
		console.log('temp error^, conveyor images are generated before they are done loading')
	}
    cx.imageSmoothingEnabled = false;
    return canv;
}

let toReloadVideos = false;
function renderVideo(players) {
    // ideally we would check if player.hat == some string (that represents a video in the src), update the video.src, and then draw it to the player every frame
    // for(let i in players){
    //     if(!players[i].hat.src.includes('video')) continue;
    //     if(!window.videos.includes(players[i].hat.src)){
    //         // create a new video element
    //         /*
    //         <video id="video" crossorigin="anonymous" controls loop autoplay width="250">
    //                 <source src="gfx/videos/wide putin walking.mp4" type="video/mp4">
    //         </video>
    //         */
    //         const v = document.createElement('video');
    //         v.src = players[i].hat.src;
    //         v.controls = true;
    //         v.autoplay = true;
    //         v.loop = true;
    //         v.crossOrigin = "anonymous";
    //         v.muted = true;
    //         v.style.visibility = 'hidden';
    //         v.id = players[i].hat.src;
    //         v.load();
    //         window.videos.push(players[i].hat.src);
    //         ref.gui.appendChild(v);
    //         //video.width = 320; // in px
    //     }
    //     let video = document.getElementById(players[i].hat.src);
    //     // drawing
    //     ctx.save();
    //     let player = players[i];
    //     ctx.beginPath()
    //     let playerOffset = offset(player.renderX||player.x,player.renderY||player.y);
    //     if(players[i].id == me().id) playerOffset = {x: canvas.width/2, y: canvas.height/2};
    //      ctx.arc(playerOffset.x,playerOffset.y,player.renderRadius,0,Math.PI*2);
    //     ctx.clip();
    //     let ratio = video.videoWidth/video.videoHeight;
    //     ctx.drawImage(video,playerOffset.x-player.renderRadius-20*player.renderRadius/24.5,playerOffset.y-player.renderRadius,player.renderRadius*ratio*2,player.renderRadius*2);
    //     ctx.closePath();
    //     ctx.restore();
    // }
    // ctx.restore();
    // // workaround bug where videos not loading when document not active >:(
    // if(!document.active){
    //     toReloadVideos = true;
    // } else if(document.active){
    //     if(toReloadVideos){
    //         setTimeout(() => {
    //             for(let i in players){
    //                 document.getElementById(players[i].hat.src).load();
    //             }
    //         }, 100)
    //         toReloadVideos = false;
    //     }
    // }
}

// ok now render conveyor

function renderClone(clone, parent) {
    if (!clone || !parent) return;
    const pos = offset(clone.x, clone.y);
    const cloneRad =
        clone.renderRadius != undefined ? clone.renderRadius : clone.radius;
    /*if(clone.tagged){
        const pos = offset(clone.server.x, clone.server.y);
    }*/ // <- leave clone in for clone tag later
    // ctx.fillStyle = 'black';
    ctx.fillStyle = 'black';
    ctx.globalAlpha = 0.65;
    // if (clone.onSafe) {
    // ctx.fillStyle = 'rgb(50, 35, 35)'
    // }
    if (clone.dead) {
        ctx.fillStyle = 'rgb(255, 0, 0)';
    }
    // ctx.shadowColor = '#7e00de';
    // ctx.shadowBlur = 15;

    ctx.beginPath();
    ctx.arc(pos.x, pos.y, cloneRad, 0, Math.PI * 2);
    ctx.fill();

    /*if(clone.ship !== false){
        ctx.strokeStyle = '#ff00f7';
        ctx.lineCap = "round";
        ctx.lineWidth = 5;
        ctx.translate(pos.x,pos.y);
        ctx.rotate(clone.ship);
        ctx.moveTo(0,0);
        ctx.lineTo(0,cloneRad);
        ctx.stroke();
        ctx.rotate(-clone.ship);
        ctx.translate(-pos.x,-pos.y);
    }*/

    if (showHat) {
        try {
            ctx.drawImage(
                parent.hat,
                pos.x - (80 * (cloneRad / 25)) / 2,
                pos.y - (80 * (cloneRad / 25)) / 2,
                80 * (cloneRad / 25),
                80 * (cloneRad / 25)
            );
        } catch (e) {
            console.log(`clone hat not loaded!`);
        }
    }

    ctx.shadowBlur = 0;
    ctx.fillStyle = 'white';
    ctx.font = `${18 * ((cloneRad + 0.5) / 25)}px Inter-Thick`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(parent.name, pos.x, pos.y + cloneRad + cloneRad / 2);
    ctx.closePath();
    // clones dont have powerups lol
    // NOT ANYMORE!
    // I herby decree that clones should be entitled to all liberties granted to humanoids
    if (clone.powerups.rev && clone.powerups.rev > 0) {
        const poffset =
            (Math.max(0, clone.powerups.inv ?? 0) *
                20 *
                clone.renderRadius) /
            clone.defaultRadius;
        ctx.beginPath();
        if (
            (clone.powerups.rev * clone.renderRadius) / 3 + poffset >
            clone.renderRadius
        ) {
            scale =
                clone.renderRadius /
                ((clone.powerups.rev * clone.renderRadius) / 3 + poffset);
        }
        ctx.arc(
            pos.x,
            pos.y,
            ((clone.powerups.rev * clone.renderRadius) / 3 + poffset) *
                scale,
            0,
            Math.PI * 2
        );
        ctx.fillStyle = '#05962b';
        //ctx.lineWidth = clone.powerups.rev*2;
        ctx.fill();
        ctx.closePath();
        ctx.globalAlpha = 1;
    }

    if (clone.powerups.inv && clone.powerups.inv > 0) {
        ctx.beginPath();
        // if(clone.powerups.inv*20*clone.renderRadius/24.5 > clone.renderRadius){
        //     scale = Math.min(scale, clone.renderRadius/(clone.powerups.inv*20*clone.renderRadius/24.5))
        // }
        ctx.arc(
            pos.x,
            pos.y,
            (clone.powerups.inv / clone.powerups.invMax) *
                clone.renderRadius *
                0.6 /*(clone.powerups.inv*20*clone.renderRadius/24.5)*scale*/,
            0,
            Math.PI * 2
        );
        ctx.fillStyle = '#383838';
        // ctx.globalAlpha = clone.powerups.inv/clone.renderRadius*25;
        //ctx.lineWidth = clone.powerups.inv*20;
        ctx.fill();
        ctx.closePath();
        ctx.globalAlpha = 1;
    }

    if (clone.powerups.grapple.state) {
        ctx.beginPath();
        // ctx.strokeStyle = '#c9c9c9';
        ctx.strokeStyle = '#969696';
        if (clone.powerups.grapple.grappling) {
            ctx.strokeStyle = 'white';
        }
        // if(!clone.powerups.grapple.grappling && clone.id === selfId){
        //     ctx.strokeStyle = 'red';
        // }
        ctx.globalAlpha = 0.75;
        ctx.lineWidth = 6;
        ctx.arc(pos.x, pos.y, clone.renderRadius / 2, 0, Math.PI * 2);
        ctx.stroke();
        ctx.closePath();
        ctx.strokeStyle = '#969696';
        ctx.globalAlpha = 1;
    }

    if (
        (clone.powerups.gun && clone.powerups.gun.state != false) ||
        clone.bullets.length > 0
    ) {
        if (clone.powerups.gun.type == 'normal') {
            ctx.fillStyle = '#bd8b0d';
        } else if (clone.powerups.gun.type == 'stun') {
            ctx.fillStyle = 'purple';
        } else if (clone.powerups.gun.type == 'push') {
            ctx.fillStyle = '#458dc4';
        } else if (clone.powerups.gun.type == 'pvp') {
            ctx.fillStyle = 'red'; //"#C71111";
            if (clone.id === selfId) {
                ctx.fillStyle = '#0d40fc'; //'#002aff'//'blue'//'#002aff';//'#132FD2'
            }
            // if (clone.powerups.gun.currentCooldown > 0) {
            // 	ctx.fillStyle = '#b30000';
            // 	// ctx.globalAlpha = 0.5;
            // }
        }
        if (clone.powerups.gun.state) {
            ctx.beginPath();
            ctx.arc(
                pos.x,
                pos.y,
                clone.renderRadius / 1.7,
                0,
                Math.PI * 2
            );
            ctx.fill();
            ctx.translate(pos.x, pos.y);
            ctx.rotate(clone.powerups.gun.angle);
            ctx.fillRect(
                -clone.renderRadius / 2.4,
                clone.renderRadius / 2.4,
                clone.renderRadius / 1.2,
                clone.renderRadius / 1.25
            );
            ctx.rotate(-clone.powerups.gun.angle);
            ctx.translate(-pos.x, -pos.y);
            // ctx.closePath();
        }
        ctx.globalAlpha = 1;
        for (let i in clone.bullets) {
            let bpos = offset(clone.bullets[i].x, clone.bullets[i].y);
            if (clone.bullets[i].life <= 0.5) {
                ctx.globalAlpha = clone.bullets[i].life / 0.5;
            }
            // console.log(ctx.fillStyle, ctx.globalAlpha, clone.bullets[i].life)
            ctx.beginPath();
            ctx.arc(
                bpos.x,
                bpos.y,
                clone.bullets[i].radius,
                0,
                Math.PI * 2
            );
            ctx.fill();
            ctx.strokeStyle = 'black';
            ctx.lineWidth = 2;
            ctx.stroke();
            ctx.globalAlpha = 1;
        }
        // ctx.globalAlpha = 1;
    }
    //let scale = 1;
    /*if (clone.powerups.inv && clone.powerups.inv > 0) {
        ctx.beginPath();
        ctx.arc(pos.x, pos.y, clone.powerups.inv*20, 0, Math.PI * 2);
        ctx.fillStyle = '#383838';
        ctx.globalAlpha = clone.powerups.inv/clone.radius*25;
        ctx.lineWidth = clone.powerups.inv*20;
        ctx.fill();
        ctx.closePath();
        ctx.globalAlpha = 1;
    }*/
    ctx.globalAlpha = 1;
}
let upArrowPattern = null;
let downArrowPattern = null;
let leftArrowPattern = null;
let rightArrowPattern = null;

function renderTimers() {
    ctx.fillStyle = 'white';
    ctx.font = '75px Inter';
    ctx.textBaseline = 'middle';
    ctx.textAlign = 'center';
    ctx.strokeStyle = 'black';
    ctx.lineWidth = 1;
    let y = 75;
    window.timers.forEach((t) => {
        ctx.fillText(t, canvas.width / 2, y);
        // ctx.strokeText(t, canvas.width / 2, y);
        y += 100;
    });
}

function renderMinimap(players, arena) {
    ctx.fillStyle = 'white';
    ctx.globalAlpha = 0.05;
    const width = arena.width / 50;
    const height = arena.height / 50;
    ctx.fillRect(0, canvas.height - height, width, height);
    ctx.globalAlpha = 1;
    for (const { renderX, renderY, radius, dead, world } of Object.values(
        players
    )) {
        ctx.beginPath();
        ctx.fillStyle = 'black';
        if (dead) {
            ctx.fillStyle = 'red';
        }
        ctx.arc(
            (renderX / arena.width) * width,
            canvas.height - height + (renderY / arena.height) * height,
            5,
            0,
            Math.PI * 2
        );
        ctx.fill();
    }
    ctx.globalAlpha = 1;
}

function renderDebug(debug) {
    try {
        ctx.fillStyle = 'white';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.font = '18px Inter';
        ctx.fillText(
            `Ping: ${debug.ping}ms | ServerFps: ${
                debug.serverFps
            }FPS | Update Time: ${Math.round(
                debug.updateTimeD
            )}ms/s | Render Time: ${Math.round(
                debug.renderTimeD
            )}ms/s | Sent: ${debug.sentTimeD}/60 (${(
                upstreambytesR / 1000
            ).toFixed(2)}KB/sec) | ${debug.fpsDisplay}FPS | Culled: ${
                debug.rendered
            } / ${debug.totalRender} | Down: (${(
                downstreambytesR / 1000
            ).toFixed(2)}KB/sec)`,
            canvas.width / 2,
            canvas.height - 35
        );
        // window.rpoints.forEach(({x, y}) => {
        // 	ctx.fillStyle = 'green';
        // 	const p = offset(x, y);
        // 	ctx.beginPath();
        // 	ctx.arc(p.x, p.y, 5, 0, Math.PI * 2);
        // 	ctx.fill()
        // })
        // window.rpoints = [];
    } catch (e) {
        console.log('debug render error: ' + e);
    }
}

function drawLeaderboard(leaderboard, players) {
    //   // leaderboard props: [id, world, name]
    //   let deadPlayers = [];
    //   ctx.fillStyle = 'white';
    //   ctx.fillText("Leaderboard", canvas.width - 105, 30);
    //   // get my world by comparing it to ids
    //   let myWorld = undefined;
    //   for(let i = 0; i < leaderboard.length; i++){
    //     if(leaderboard[i][0] == selfId){
    //       myWorld = leaderboard[i][1];
    //       break;
    //     }
    //   }
    //   ctx.fillText(myWorld, canvas.width - 105, 80);
    //   let currentSpacing = 110;
    //   // render all other players in our world first
    //   for(let j in players){
    //     if(players[j].dead == true){
    //       ctx.fillStyle = 'red';
    //     } else {
    //       ctx.fillStyle = 'white';
    //     }
    //     for(let i = 0; i < leaderboard.length; i++){
    //       // checking if they are in our world
    //       if(myWorld === leaderboard[i][1]){
    //         ctx.textAlign = 'center';
    //         ctx.font = '24px Inter';
    //         ctx.fillText(players[j].name, canvas.width - 105, currentSpacing);
    //         currentSpacing += 30;
    //         // prevent duplicates
    //         break;
    //       }
    //     }
    //   }
    //   currentSpacing += 15;
    //   // doing the same thing but for players not in our world
    //   for(let i = 0; i < leaderboard.length; i++){
    //     for(let j in players){
    //       if(myWorld !== leaderboard[i][1]){
    //         ctx.fillStyle = 'white';
    //         ctx.textAlign = 'center';
    //         ctx.font = '24px Inter';
    //         ctx.fillText(leaderboard[i][1] + ' - '+leaderboard[i][2], canvas.width - 105, currentSpacing);
    //         currentSpacing += 30;
    //       }
    //       break;
    //     }
    //   }
    //   ctx.fillStyle = "rgba(255, 255, 255, 0.05)";
    //   ctx.fillRect(canvas.width - 210, 20, 200, currentSpacing - 20);
}

// function intersectLineCanvas(line, canvasX, canvasY, canvasW, canvasH) {
//     // const lineX = Math.min(line.start.x, line.end.x);
//     // const lineY = Math.min(line.start.y, line.end.y);
//     // const lineW = Math.abs(line.start.x - line.end.x);
//     // const lineH = Math.abs(line.start.y - line.end.y);
//     // return (lineX < canvasX + canvasW &&
//     //     lineX + lineW > canvasX) &&
//     //     (lineY < canvasY + canvasH &&
//     //     lineY + lineH > canvasY);
// }

function renderLighting() {
    ctx.globalAlpha = 1;
    sctx.clearRect(0, 0, canvas.width, canvas.height);
    sctx.save();
    sctx.fillStyle = 'rgba(0, 0, 0, 1)';
    sctx.globalAlpha = raycastvision ? 1 : lighting; // 0.5;//lighting;
    sctx.fillRect(0, 0, canvas.width, canvas.height);
    sctx.globalAlpha = 1;
    sctx.globalCompositeOperation = 'destination-out';

    if (raycastvision) {
        const canvasOffset = inverseOffset(0,0);
        sctx.globalAlpha = 1;
        sctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
        sctx.beginPath();
        let points = raycastvision
            ? Ray.getPoints(
                new Vec(me().renderX, me().renderY),
                uniqueRayPoints,
                window.rayLines.filter(line => line.obj.inView),//rayLines.filter((line) => {return line.obj.inView}),
                  //rayLines.filter(line => intersectLineCanvas(line, canvasOffset.x, canvasOffset.y, canvas.width, canvas.height)),
                me().renderRadius
              )
            : [];
        for (const { x, y } of points) {
            const pos = offset(x, y);
            sctx.lineTo(pos.x, pos.y);
        }
        sctx.closePath();
        sctx.fill();
    }
    // if (!raycastvision) {
    for (const { renderX, renderY, renderRadius } of Object.values(players)) {
        const { x, y } = offset(renderX, renderY);
        const lightVision = 50;
        const lightgrad = ctx.createRadialGradient(
            x,
            y,
            renderRadius,
            x,
            y,
            renderRadius + lightVision
        );
        lightgrad.addColorStop(0, `rgba(255, 255, 255, 0.3)`);
        lightgrad.addColorStop(1, `rgba(255, 255, 255, 0)`);
        // lightgrad.addColorStop(1, `rgba(255, 255, 255, 0)`);
        sctx.fillStyle = lightgrad;
        sctx.beginPath();
        sctx.arc(x, y, renderRadius + lightVision, 0, Math.PI * 2);
        sctx.fill();
        const angle =
            Math.atan2(input.down - input.up, input.right - input.left) || 0;
        // if (!angle) continue;
        // if (renderX * renderY * renderRadius !== me().renderX * me().renderY * renderRadius) continue;
        // better temporary check
        // if (renderX * renderY !== me().renderX * me().renderY) continue; // temporary check
        if (input.up + input.down + input.right + input.left === 0) continue;
        // if (!angle) continue; // angle = 0 not render?
        // continue;
        // const flashlightVision = 650;
        // const flashSize = Math.PI / 5; // in radians
        // const flashgrad = ctx.createRadialGradient(x, y, renderRadius, x, y, renderRadius + flashlightVision);
        // flashgrad.addColorStop(0, 'rgba(255, 255, 255, 0.75)');
        // flashgrad.addColorStop(0, 'rgba(255, 255, 255, 0)');
        // sctx.fillStyle = flashgrad;
        // sctx.beginPath();
        // sctx.lineTo(x, y);
        // sctx.lineTo(x + Math.cos(angle - flashSize/2)*flashlightVision,
        // 			y + Math.sin(angle - flashSize/2)*flashlightVision);
        // sctx.lineTo(x + Math.cos(angle + flashSize/2)*flashlightVision,
        // 		   y+ Math.sin(angle + flashSize/2)*flashlightVision);
        // sctx.fill();
    }
    // }

    ctx.drawImage(shadowCanvas, 0, 0);
    sctx.restore();
}

// lexical
function renderLinks(obstacles) {
    function calculateEndLinks(id) {
        return doors
            .map((door, y) => {
                return { id: door.id, y };
            })
            .filter((i) => i.id === id)
            .map((i) => doors[i.y])
            .map((door) => {
                return { x: door.x + door.w / 2, y: door.y + door.h / 2 };
            });
    }
    const doors = obstacles.filter((ob) => ob.type === 'door');
    for (const obj of obstacles) {
        if (obj.type === 'button' || obj.type === 'bbutton') {
            calculateEndLinks(obj.id, doors).forEach(({ x, y }) => {
                const btnPos = offset(obj.x + obj.w / 2, obj.y + obj.h / 2);
                const doorPos = offset(x, y);
                ctx.strokeStyle = '#969696'; //'red'//'#2955cf';
                ctx.setLineDash([25, 35]);
                ctx.lineDashOffset = -time * 100;
                ctx.lineWidth = 5;
                ctx.globalAlpha = obj.active ? 0.8 : 0.3;
                // add linedashoffsets for link effect
                ctx.beginPath();
                ctx.lineTo(btnPos.x, btnPos.y);
                ctx.lineTo(doorPos.x, doorPos.y);
                ctx.stroke();
                ctx.globalAlpha = 1;
                ctx.setLineDash([]);
            });
        }
    }
}

function drawOverlay(player, enemies) { 
    let ir = 1;
    let or = 1;
    let o = 0.8;
    
    if (window.vinette != undefined && Array.isArray(window.vinette)) {
        ir = window.vinette[0];
        or = window.vinette[1];
        o = window.vinette[2];
    }
    
	sctx.globalAlpha = 1;
    sctx.clearRect(0, 0, canvas.width, canvas.height);
    //sctx.save();
    
    // filling
    sctx.beginPath();
    sctx.translate(
        -canvas.width / window.renderScale / 2 + canvas.width / 2,
        -canvas.height / window.renderScale / 2 + canvas.height / 2
    );
    const outerRadius = canvas.width * 0.6;
    const innerRadius = canvas.width * 0.1;
    const grd = sctx.createRadialGradient(
        canvas.width / window.renderScale / 2,
        canvas.height / window.renderScale / 2,
        (innerRadius * ir) / window.renderScale,
        canvas.width / window.renderScale / 2,
        canvas.height / window.renderScale / 2,
        (outerRadius * or) / window.renderScale
    );
    //grd.addColorStop(0, `rgba(${me().dead ? 150: 0},0,0,0)`);
    //grd.addColorStop(1, `rgba(${me().dead ? 150: 0},0,0,` + vOpacity * window.darkness + ')');
    if (me().deathTimer != undefined) {
        grd.addColorStop(0, `rgba(175,0,0,0)`);
        grd.addColorStop(1, `rgba(175,0,0,${o})`);
    } else {
        grd.addColorStop(
            0,
            `rgba(${window.vc.r},${window.vc.g},${window.vc.b},0)`
        );
        grd.addColorStop(
            1,
            `rgba(${window.vc.r},${window.vc.g},${window.vc.b},1)`
        );
    }
    sctx.globalAlpha = 1;
    sctx.fillRect(
        0,
        0,
        canvas.width / window.renderScale,
        canvas.height / window.renderScale
    );
    
    sctx.fillStyle = grd;
    //sctx.globalAlpha = Math.min(1, o);
    sctx.globalAlpha = 1;
    sctx.fill();
    
    sctx.closePath();
    sctx.translate(
        canvas.width / window.renderScale / 2 - canvas.width / 2,
        canvas.height / window.renderScale / 2 - canvas.height / 2
    );
    //sctx.globalCompositeOperation = 'destination-out';

    if(sortedObstacles.torch && sortedObstacles.torch.length > 0){
        for (let i = 0; i < (sortedObstacles['torch']??[]).length; i++) {// oh and there's still a bug with the db :(
            const obj = sortedObstacles['torch'][i];
            const off = offset(obj.x, obj.y);
            sctx.globalAlpha = 1;
            const lightgrad = sctx.createRadialGradient(
                off.x,
                off.y,
                obj.innerRadius,
                off.x,
                off.y,
                obj.outerRadius
            );
            const irRatio = obj.innerRadius/obj.outerRadius;
            lightgrad.addColorStop(irRatio, `rgba(${window.vc.r},${window.vc.g},${window.vc.b},0)`);
            lightgrad.addColorStop(1, `rgba(${window.vc.r},${window.vc.g},${window.vc.b},${Math.min(o,0.9)})`);
            // lightgrad.addColorStop(1, `rgba(255, 255, 255, 0)`);
            sctx.fillStyle = lightgrad;
            sctx.beginPath();
            sctx.arc(off.x, off.y, obj.outerRadius+1, 0, Math.PI * 2);
            sctx.fill();
        }
        sctx.closePath();
    }

    ctx.globalAlpha = 1;
    ctx.drawImage(shadowCanvas, 0, 0);
    
    if (
        (o > 1 || raycastvision) /*&&
        Math.round(window.renderScale * 100) / 100 == 1*/
    ) {
        // someday add lava slices
        if (!raycastvision) {
            //sctx.restore();
            for (let i = 0; i < (sortedObstacles.lava??[]).length; i++) {
                const obj = sortedObstacles.lava[i];
                if(obj.inView === false){
                    continue;
                }
                ctx.beginPath();
                let pos = offset(obj.x, obj.y);
                ctx.globalAlpha = Math.min(0.5,o-1);
                ctx.fillStyle = 'rgba(230, 230, 21, 0.5)';
                ctx.fillRect(pos.x, pos.y, obj.w, obj.h);
                ctx.closePath();
            }
            for (let i = 0; i < (sortedObstacles.morphlavamove??[]).length; i++) {
                const obj = sortedObstacles.morphlavamove[i];
                if(obj.inView === false){
                    continue;
                }
                ctx.beginPath();
                let pos = offset(obj.x, obj.y);
                ctx.globalAlpha = Math.min(0.5,o-1);
                ctx.fillStyle = 'rgba(230, 230, 21, 0.5)';
                ctx.fillRect(pos.x, pos.y, obj.w, obj.h);
                ctx.closePath();
            }
            for (let i = 0; i < (sortedObstacles.lavamove??[]).length; i++) {
                const obj = sortedObstacles.lavamove[i];
                if(obj.inView === false){
                    continue;
                }
                ctx.beginPath();
                let pos = offset(obj.x, obj.y);
                ctx.globalAlpha = Math.min(0.5,o-1);
                ctx.fillStyle = 'rgba(230, 230, 21, 0.5)';
                ctx.fillRect(pos.x, pos.y, obj.w, obj.h);
                ctx.closePath();
            }
            for (let i = 0; i < (sortedObstacles['move-pause-lava']??[]).length; i++) {
                const obj = sortedObstacles['move-pause-lava'][i];
                if(obj.inView === false){
                    continue;
                }
                ctx.beginPath();
                let pos = offset(obj.x, obj.y);
                ctx.globalAlpha = Math.min(0.5,o-1);
                ctx.fillStyle = 'rgba(230, 230, 21, 0.5)';
                ctx.fillRect(pos.x, pos.y, obj.w, obj.h);
                ctx.closePath();
            }
            for (let i = 0; i < (sortedObstacles['rotate-lava']??[]).length; i++) {
                const obj = sortedObstacles['rotate-lava'][i];
                if(obj.inView === false){
                    continue;
                }
                ctx.globalAlpha = Math.min(0.5,o-1);
                let pos = offset(obj.x, obj.y);
                ctx.fillStyle = 'rgba(230, 230, 21, 0.5)';
                const center = {
                    x: pos.x,
                    y: pos.y,
                };
                ctx.translate(center.x, center.y);
                ctx.rotate(degToRad(obj.angle));
                ctx.beginPath();
                ctx.rect(
                    -obj.w / 2,
                    -obj.h / 2,
                    obj.w,
                    obj.h
                );
                ctx.fill();
                ctx.strokeStyle = 'black';
                ctx.lineWidth = lineWidth;
                ctx.stroke();
                ctx.rotate(-degToRad(obj.angle));
                ctx.translate(-center.x, -center.y);
                const oldX = obj.x;
                const oldY = obj.y;
                obj.x -= obj.w / 2;
                obj.y -= obj.h / 2;
                obj.x = oldX;
                obj.y = oldY;
                ctx.closePath();
            }
            for (let i = 0; i < (sortedObstacles['rotate-pause-lava']??[]).length; i++) {
                const obj = sortedObstacles['rotate-pause-lava'][i];
                if(obj.inView === false){
                    continue;
                }
                ctx.globalAlpha = Math.min(0.5,o-1);
                let pos = offset(obj.x, obj.y);
                ctx.fillStyle = 'rgba(230, 230, 21, 0.5)';
                const center = {
                    x: pos.x,
                    y: pos.y,
                };
                ctx.translate(center.x, center.y);
                ctx.rotate(degToRad(obj.angle));
                ctx.beginPath();
                ctx.rect(
                    -obj.w / 2,
                    -obj.h / 2,
                    obj.w,
                    obj.h
                );
                ctx.fill();
                ctx.strokeStyle = 'black';
                ctx.lineWidth = lineWidth;
                ctx.stroke();
                ctx.rotate(-degToRad(obj.angle));
                ctx.translate(-center.x, -center.y);
                const oldX = obj.x;
                const oldY = obj.y;
                obj.x -= obj.w / 2;
                obj.y -= obj.h / 2;
                obj.x = oldX;
                obj.y = oldY;
                ctx.closePath();
            }
            for (let i = 0; i < (sortedObstacles['poly-lava']??[]).length; i++) {
                const obj = sortedObstacles['poly-lava'][i];
                if(obj.inView === false){
                    continue;
                }
                ctx.globalAlpha = Math.min(0.5,o-1);
                ctx.fillStyle = 'rgba(230, 230, 21, 0.5)';
                ctx.beginPath();
                for (const [x, y] of obj.points) {
                    const pos = offset(x, y);
                    ctx.lineTo(pos.x, pos.y);
                }
                const pos = offset(
                    obj.points[0][0],
                    obj.points[0][1]
                );
                ctx.lineTo(pos.x, pos.y);
                ctx.fill();
                ctx.closePath();
            }
            for (let i = 0; i < (sortedObstacles['circle-lava']??[]).length; i++) {
                const obj = sortedObstacles['circle-lava'][i];
                if(obj.inView === false){
                    continue;
                }
                ctx.globalAlpha = Math.min(0.5,o-1);
                let pos = offset(obj.x, obj.y);
                ctx.fillStyle = 'rgba(230, 230, 21, 0.5)';
                ctx.beginPath();
                ctx.arc(pos.x, pos.y, obj.r, 0, Math.PI * 2);
                ctx.fill();
                ctx.closePath();
            }
        }

        ctx.globalAlpha = 1;
        for (let i in enemies) {
            let ene = enemies[i];
            if (
                ene.type == 'flashlight' &&
                ene.flAngle != undefined &&
                ene.flSize !== undefined
            ) {
                
                ctx.beginPath();
                let pos = offset(ene.x, ene.y);
                var grad = ctx.createRadialGradient(
                    pos.x,
                    pos.y,
                    ene.radius,
                    pos.x,
                    pos.y,
                    ene.flSize - 1
                );
                grad.addColorStop(0, 'rgba(230, 230, 21, 0.5)');
                grad.addColorStop(1, 'rgba(230, 230, 21,0)');
                ctx.fillStyle = grad;
                ctx.moveTo(pos.x, pos.y);
                let angle = Math.atan2(ene.yv, ene.xv);
                if (ene.xv === 0 && ene.yv === 0) {
                    angle = ene.flashlightDir;
                }
                ctx.arc(
                    pos.x,
                    pos.y,
                    (ene.flSize * 1.5),
                    angle - ene.flAngle / 2,
                    angle + ene.flAngle / 2
                );
                ctx.lineTo(pos.x, pos.y);
                ctx.fill();
                ctx.closePath();
            }
        }
    }

    ctx.globalAlpha = 1;

    ctx.fillStyle = 'white';

    if (me() && me().dead) {
        ctx.fillStyle = 'white';
        ctx.font = '30px Inter';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        if (me().powerups.rev && me().powerups.rev > 0) {
            ctx.fillText('R to revive', canvas.width / 2, canvas.height - 85);
        } else {
            ctx.fillText('R to respawn', canvas.width / 2, canvas.height - 85);
        }
    }

    if (window.spectating) {
        ctx.fillStyle = 'white';
        ctx.font = '40px Inter';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('SPECTATING', canvas.width - 150, canvas.height - 40);
    }

    if (me().isTyping) {
        ctx.fillStyle = 'white';
        ctx.font = '40px Inter';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        if (me().mashing != undefined) {
            ctx.fillText(
                'Mash to be free!',
                canvas.width / 2,
                canvas.height - 40
            );
        } else {
            ctx.fillText(
                'Type all the text to be free!',
                canvas.width / 2,
                canvas.height - 40
            );
        }
        ctx.globalAlpha = 1;
    } else if (me().cameraChange !== undefined && me().cameraChange.canReturn === true) {
        ctx.fillStyle = 'white';
        ctx.font = '40px Inter';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(
            'Shift to return to normal camera.',
            canvas.width / 2,
            canvas.height - 40
        );
        ctx.globalAlpha = 1;
    } else if (useMouse && !window.usingController) {
        ctx.fillStyle = 'white';
        ctx.font = '40px Inter';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('MOUSE', canvas.width / 2, canvas.height - 40);
        ctx.globalAlpha = 1;
    }

    if (me().biteAnimTimer && me().biteAnimTimer > 0 && !me().dead) {
        ctx.globalAlpha = me().biteAnimTimer * 2;
        ctx.fillStyle = 'white';
        ctx.font = '40px Inter';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(
            `Ouch! Don't let your tail get bitten!`,
            canvas.width / 2,
            120
        );
        ctx.globalAlpha = 1;
    }

    if (!connected) {
        ctx.fillStyle = 'white';
        ctx.font = '40px Inter';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('DISCONNECTED', canvas.width - 170, canvas.height - 40);
    }

    /*if(window.mobile){
        ctx.fillStyle = 'white';
		ctx.font = '24px Inter';
		ctx.textAlign = 'center';
		ctx.textBaseline = 'middle';
        ctx.fillStyle = 'white';
        ctx.globalAlpha = 1;
        ctx.fillText(window.mouse.x + ' '+ window.mouse.y, canvas.width/2, canvas.height/2);
    }*/

    if (window.showPos) {
        ctx.fillStyle = 'white';
        ctx.font = '20px Inter';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        const pos = offset(me().renderX, me().renderY);
        ctx.fillText(
            `(${Math.round(me().x)}, ${Math.round(me().y)})`,
            pos.x,
            pos.y - me().radius * 1.5
        );
    }
    if (me().powerups.gun.state && me().powerups.gun.currentCooldown > 0) {
        const pos = offset(me().renderX, me().renderY);
        /*ctx.fillStyle = 'red';
		ctx.globalAlpha = 0.3;
		ctx.fillStyle ='red'
		ctx.fillRect(offsetX(me().renderX + me().renderRadius + 10), offsetY(me().renderY + 50) - 100, 25, 75);
		ctx.globalAlpha = 0.8;
		ctx.fillRect(offsetX(me().renderX + me().renderRadius + 10), offsetY(me().renderY + 50) - 25 - (me().powerups.gun.currentCooldown / me().powerups.gun.maxCooldown) * 75, 25, (me().powerups.gun.currentCooldown / me().powerups.gun.maxCooldown) * 75)*/
        //?
        // pos not defined?
        // ctx.beginPath();// tf
        //       ctx.fillStyle = '#401616';
        //       ctx.arc(pos.x, pos.y, (clone.renderRadius/1.7)*(me().powerups.gun.currentCooldown / me().powerups.gun.maxCooldown), 0, Math.PI*2);
        //       ctx.fill();
        //       ctx.closePath();
    }
    if (window.renderNoise !== false) {
        ctx.globalAlpha = window.renderNoise;
        window.renderNoise -= 0.01;
        if (window.renderNoise < 0) {
            window.renderNoise = false;
        }
        let excessX = window.noiseImage.width - canvas.width;
        let excessY = window.noiseImage.height - canvas.height;
        ctx.drawImage(
            window.noiseImage,
            -1 * Math.random() * excessX,
            -1 * Math.random() * excessY
        );
    }
    ctx.globalAlpha = 1;
    if (window.renderGlitch !== false) {
        if (Math.random() > 0.9) {
            if (window.renderGlitch == 'hyper') {
                generateGlitchEffect(30 + Math.random() * 50);
            } else {
                generateGlitchEffect(10);
                ctx.globalAlpha = 0.2;
            }
        }
        if (window.renderGlitch != 'hyper') {
            ctx.globalAlpha = 0.6;
        }
        renderGlitchEffect();
        ctx.globalAlpha = 1;
    }
    ctx.globalAlpha = 1;
    if (!me().raycasting && !me().ship) {
        try {
            // idek
            //.... e
            renderLighting();
        } catch (e) {
            //console.log('cant render lighting because: ' + e);
        }
    }
    // zone anim postponed until better ideas
    // idk just add support for touch events
    // that way u can use them on laptops with touchscreen
    //https://stackoverflow.com/questions/11381673/detecting-a-mobile-browser
    if (zoneAnim) {
        // const width = 500;
        // let y = canvas.height - 80;
        // let dis = (window.performance.now() - zoneT)/1000
        // console.log(dis)
        // ctx.globalAlpha = dis/3
        // // if (zoneT <= 0.5) {
        // // 	y = canvas.height - (dis/0.5) * 100;
        // // } else if (dis > 0.5 && dis <= 2.5) {
        // // 	y = canvas.height - 100;
        // // } else if (dis > 2.5) {
        // // 	y = canvas.height - 100 + ((dis-2.5)/0.5) * 100
        // // }
        // // its absolute though
        //       // console.log(x||0, canvas.height - 100, x||0 + width, canvas.height - 100);
        // // const grad = ctx.createLinearGradient(canvas.width / 2, canvas.height - 100, canvas.width / 2, canvas.height);
        // // grad.addColorStop(0, 'rgba(0, 0, 0, 0)');
        // // grad.addColorStop(1, 'rgba(0, 0, 0, 1)');
        // // ctx.fillStyle = grad;
        // // ctx.fillRect(canvas.width / 2 - width / 2, y, width, 100);
        // ctx.font = '40px Inter';
        // ctx.textAlign = 'center';
        // ctx.textBaseline = 'middle';
        // ctx.fillStyle = 'white'
        // ctx.fillText(`Entering Zone ${me().zone}`, canvas.width / 2, y + 40);// gtg
        // ctx.globalAlpha = 1;
        // k im gonna polish
        // what if it came from middle bottom instead
        // imma try that
    }
    // if (me().deathTimer != undefined) {
    // 	ctx.globalAlpha = 1;
    // 	ctx.filter = 'invert(75%)'
    // 	ctx.drawImage(skull, canvas.width - 175, canvas.height - 125, 75, 75);
    // 	ctx.filter = 'none';
    // }
}
function generateGlitchEffect(amount) {
    glitchEffects = [];
    for (let i = 0; i < amount; i++) {
        window.glitchEffects.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            w: Math.random() * 1000 - 500,
            h: Math.random() * 1000 - 500,
        });
    }
}
function renderGlitchEffect() {
    for (let i = 0; i < window.glitchEffects.length; i++) {
        let gpos = window.glitchEffects[i];
        ctx.drawImage(
            noiseImage,
            Math.floor(Math.random() * noiseImage.width),
            Math.floor(Math.random() * noiseImage.height),
            gpos.w,
            gpos.h,
            gpos.x,
            gpos.y,
            gpos.w,
            gpos.h
        );
    }
}
function renderPreview() {
    ctx.fillStyle = 'black';
    ctx.globalAlpha = 0.5; // lol idek what offset does
    if (window.firstPointX != undefined && window.firstPointY != undefined) {
        const pos = offset(firstPointX, firstPointY);
        ctx.fillRect(
            pos.x,
            pos.y,
            Math.round((mouse.x - pos.x) / snapDistance) * snapDistance,
            Math.round((mouse.y - pos.y) / snapDistance) * snapDistance
        );
    }
    // where do usend position to server, i obsserve
    // why is it firstPointX secondPoitX  that doesnt make any sense lol m<- that's the start pos of the obstacle
    // lol i used the same variable name as my test and ;-;
    // dont you mean firstPointY? <- that's the start pos of the obstacle
    // if(window.firstPointX != undefined && window.secondPointX != undefined){
    //     const pos = offset(window.firstPointX, window.secondPointX);
    //     const mousePos = offset(window.mouse.x, window.mouse.y);
    //     ctx.fillRect(pos.x,pos.y,mousePos.x,mousePos.y);
    // } // just comment the code inside lol, renderPrview undefined
}

function inViewFn(obstacle, pos) {
    return (
        pos.x + obstacle.w > (1-1/window.renderScale)*canvas.width/2 &&
        pos.x < (1+1/window.renderScale)*canvas.width/2 &&
        pos.y + obstacle.h > (1-1/window.renderScale)*canvas.height/2 &&
        pos.y < (1+1/window.renderScale)*canvas.height/2
    );
};

const cullingFunctions = {
    portal: function(obstacle, pos){
        let size = Math.max(obstacle.w, obstacle.h)*2;
        return (
            pos.x + obstacle.w > (1-1/window.renderScale)*canvas.width/2 &&
            pos.x < (1+1/window.renderScale)*canvas.width/2 &&
            pos.y + obstacle.h > (1-1/window.renderScale)*canvas.height/2 &&
            pos.y - obstacle.h < (1+1/window.renderScale)*canvas.height/2
        );
    },
    rotating: function(obstacle, pos){
        // true but wouldnt u need to make a circle that encapsulate a rect rather 
		// than the other way around
		// like a circle containg the box rather than a box containing the circle
		// gtg soon
        // circle around rotating square
        // ctx.strokeStyle = 'red';// ok lets hope this works
        // ctx.lineWidth = lineWidth * 3;
        // ctx.beginPath();
        // const off = offset(obstacle.pivotX, obstacle.pivotY);
        // ctx.arc(off.x,off.y,radius,0,Math.PI*2);
        // ctx.stroke();
        // ctx.closePath();
        const pivotOffset = offset(obstacle.pivotX, obstacle.pivotY);
        return (
            pivotOffset.x + obstacle.cullingRadius > (1-1/window.renderScale)*canvas.width/2 &&
            pivotOffset.x - obstacle.cullingRadius < (1+1/window.renderScale)*canvas.width/2 &&
            pivotOffset.y + obstacle.cullingRadius > (1-1/window.renderScale)*canvas.height/2 &&
            pivotOffset.y - obstacle.cullingRadius < (1+1/window.renderScale)*canvas.height/2
        );
    },
    circle: function(obstacle, pos){
        return (
            pos.x + obstacle.radius > (1-1/window.renderScale)*canvas.width/2 &&
            pos.x - obstacle.radius < (1+1/window.renderScale)*canvas.width/2 &&
            pos.y + obstacle.radius > (1-1/window.renderScale)*canvas.height/2 &&
            pos.y - obstacle.radius < (1+1/window.renderScale)*canvas.height/2
        );
    },
    circleR: function(obstacle, pos){
        return (
            pos.x + obstacle.r > (1-1/window.renderScale)*canvas.width/2 &&
            pos.x - obstacle.r < (1+1/window.renderScale)*canvas.width/2 &&
            pos.y + obstacle.r > (1-1/window.renderScale)*canvas.height/2 &&
            pos.y - obstacle.r < (1+1/window.renderScale)*canvas.height/2
        );
    },
    circleSentry: function(obstacle, pos){
        let width = Math.max(obstacle.laser.w*2,obstacle.laser.h*2,obstacle.r);
        let height = Math.max(obstacle.laser.w*2,obstacle.laser.h*2,obstacle.r);

        return (
            pos.x + width > (1-1/window.renderScale)*canvas.width/2 &&
            pos.x - width < (1+1/window.renderScale)*canvas.width/2 &&
            pos.y + height > (1-1/window.renderScale)*canvas.height/2 &&
            pos.y - height < (1+1/window.renderScale)*canvas.height/2
        );
    },
    circleTurretSentry: function(obstacle, pos){
        return true;

        // TODO
    },
    oval: function(obstacle, pos){
        return (
            pos.x + obstacle.radius > (1-1/window.renderScale)*canvas.width/2 &&
            pos.x - obstacle.radius < (1+1/window.renderScale)*canvas.width/2 &&
            pos.y + obstacle.radius2 > (1-1/window.renderScale)*canvas.height/2 &&
            pos.y - obstacle.radius2 < (1+1/window.renderScale)*canvas.height/2
        );
    },
    demo: function(obstacle, pos){
        const r = me().renderRadius;
        return (
            pos.x + r > (1-1/window.renderScale)*canvas.width/2 &&
            pos.x - r < (1+1/window.renderScale)*canvas.width/2 &&
            pos.y + r > (1-1/window.renderScale)*canvas.height/2 &&
            pos.y - r < (1+1/window.renderScale)*canvas.height/2
        );
    },
    grapple: function(obstacle, pos){
        return (
            pos.x + 20 > (1-1/window.renderScale)*canvas.width/2 &&
            pos.x - 20 < (1+1/window.renderScale)*canvas.width/2 &&
            pos.y + 20 > (1-1/window.renderScale)*canvas.height/2 &&
            pos.y - 20 < (1+1/window.renderScale)*canvas.height/2
        );
    },
    spring: function(obstacle, pos){
        for (let i = 0; i < obstacle.springs.length; i++) {
            let s = obstacle.springs[i];
            let spos = offset(s.x+obstacle.w/2, s.y+obstacle.h/2);
            let inView =
                spos.x + width > (1-1/window.renderScale)*canvas.width/2 &&
                spos.x - width < (1+1/window.renderScale)*canvas.width/2 &&
                spos.y + height > (1-1/window.renderScale)*canvas.height/2 &&
                spos.y - height < (1+1/window.renderScale)*canvas.height/2;
            if (inView === true) {
                return true;
            }
        }
        return (
            pos.x + obstacle.radius > (1-1/window.renderScale)*canvas.width/2 &&
            pos.x < (1+1/window.renderScale)*canvas.width/2 &&
            pos.y + obstacle.radius2 > (1-1/window.renderScale)*canvas.height/2 &&
            pos.y < (1+1/window.renderScale)*canvas.height/2
        );
    },
    poly: function(obstacle, pos){
        // const pointOffset = offset(obstacle.most.left, obstacle.most.top).x;
        // const pointWidth = obstacle.most.right - obstacle.most.left;
        // const pointHeight = obstacle.most.bottom - obstacle.most.top
        // return (
        //     pointOffset.x + pointWidth > (1-1/window.renderScale)*canvas.width/2 &&
        //     pointOffset.x - pointWidth < (1+1/window.renderScale)*canvas.width/2 &&
        //     pointOffset.y + pointHeight > (1-1/window.renderScale)*canvas.height/2 &&
        //     pointOffset.y - pointHeight < (1+1/window.renderScale)*canvas.height/2
        // );
        // const off = offset(obstacle.most.left, obstacle.most.top);
        // inView = inViewFn(
        //     obstacle, off
        // );
        const pointOffset = offset(obstacle.most.left, obstacle.most.top);
        return (
            pointOffset.x + obstacle.most.right - obstacle.most.left > (1-1/window.renderScale)*canvas.width/2 &&
            pointOffset.x < (1+1/window.renderScale)*canvas.width/2 &&
            pointOffset.y + obstacle.most.bottom - obstacle.most.top > (1-1/window.renderScale)*canvas.height/2 &&
            pointOffset.y < (1+1/window.renderScale)*canvas.height/2
        );
    },
}
function renderObstacles(obstacles) {
    let holes = []; // to render on top
    ctx.globalAlpha = 1;
    for (let i = 0; i < obstacles.length; i++) {
        const obstacle = obstacles[i];
        const pos = offset(obstacle.x, obstacle.y);
        const obstype = obstacle.type;
        
        // if((cullingFunctions[obstacle.renderType]??inViewFn)(obstacle, pos) === true){
        //     obstacle.inView = false;
        //     console.log(pos);
        //     continue;
        // }
        if(cullingFunctions[obstacle.renderType] !== undefined){
            if(cullingFunctions[obstacle.renderType](obstacle, pos) === false){
                obstacle.inView = false;
                continue;
            }
        } else if(inViewFn(obstacle, pos) === false){
            obstacle.inView = false;
            continue;
        }
        
        // let width = obstacle.w;
        // let height = obstacle.h;
        // if (obstacle.renderType === 'rotating') {
        //     let storageWidth = width;
        //     width *= Math.max(width * 2, height * 2);
        //     height = Math.max(storageWidth * 2, height * 2);
        // } else if (obstacle.renderType === 'circle') {
        //     width = obstacle.radius;
        //     height = obstacle.radius;
        // } else if (obstacle.renderType === 'circleR') {
        //     width = obstacle.r;
        //     height = obstacle.r;
        // } else if(obstype === 'circle-sentry'){
        //     width = Math.max(obstacle.laser.w*2,obstacle.laser.h*2,obstacle.r);
        //     height = Math.max(obstacle.laser.w*2,obstacle.laser.h*2,obstacle.r);
        // } else if (obstype === 'oval' || obstype === 'lava-oval') {
        //     width = obstacle.radius;
        //     height = obstacle.radius2;
        // } else if (obstype === 'demo') {
        //     width = me().renderRadius;
        //     height = me().renderRadius;
        // } else if (
        //     obstype === 'grapplepoint' ||
        //     obstype === 'movinggrapplepoint'
        // ) {
        //     width = 20;
        //     height = 20;
        // }
        // let inView = inViewFn(pos.x,pos.y,width,height);
        //     // pos.x + width > (1-1/rc)*canvas.width/2 &&
        //     // pos.x - width < (1+1/rc)*canvas.width/2 &&
        //     // pos.y + height > (1-1/rc)*canvas.height/2 &&
        //     // pos.y - height < (1+1/rc)*canvas.height/2;
        // // if (obstype === 'circle-sentry') {
        // // 	width += obstacle.w
        // // }
        // //top left: (1-1/rc)*canvas.width/2
        // //x: x - (camera.x) + canvas.width / 2 + xoff,
        // //y: y - (camera.y) + canvas.height / 2 + yoff,
        // if (obstacle.renderType === 'poly' || obstype === 'bezier') {
        //     if (obstype === 'bezier') {
        //         obstacle.points = obstacle.polygon.points;
        //     }
            
        //     if (showPos/*debugMode*/) {
        //         ctx.strokeStyle = 'red';
        //         ctx.lineWidth = 5;
        //         ctx.strokeRect(
        //             offset(obstacle.most.left, 0).x,
        //             offset(0, obstacle.most.top).y,
        //             obstacle.most.right - obstacle.most.left,
        //             obstacle.most.bottom - obstacle.most.top
        //         );
        //     }

        //     // console.log(mostLeft, mostRight, mostTop, mostBottom)
        //     inView = inViewFn(
        //         offset(obstacle.most.left, 0).x,
        //         offset(0, obstacle.most.top).y,
        //         obstacle.most.right - obstacle.most.left,
        //         obstacle.most.bottom - obstacle.most.top
        //     );
        // } else if (obstype === 'spring') {
        //     for (let i = 0; i < obstacle.springs.length; i++) {
        //         let s = obstacle.springs[i];
        //         let spos = offset(s.x+obstacle.w/2, s.y+obstacle.h/2);
        //         inView =
        //             spos.x + width > (1-1/window.renderScale)*canvas.width/2 &&
        //             spos.x - width < (1+1/window.renderScale)*canvas.width/2 &&
        //             spos.y + height > (1-1/window.renderScale)*canvas.height/2 &&
        //             spos.y - height < (1+1/window.renderScale)*canvas.height/2;
        //         if (inView === true) {
        //             i = obstacle.springs.length;
        //         }
        //     }
        // }
        obstacle.inView = true;
        debug.rendered++;

        ctx.fillStyle = window.backgroundColor;
        ctx.globalAlpha = 1;
        if (obstype === 'filter') {
            ctx.globalAlpha = 0;
            if (obstacle.touchingFilter === true) {
                ctx.filter = obstacle.filter;
            }
        }
        if (obstype === 'block') {
            ctx.fillStyle = obstacle.color;
        }
        if (obstype === 'trans') {
            ctx.globalAlpha = obstacle.opaq;
        }
        if (obstype === 'enemywall') {
            ctx.globalAlpha = 0.4;
        }
        if (obstype === 'enemytp') {
            ctx.fillStyle = '#38ab30';
            ctx.globalAlpha = 0.4;
        }
        if (obstype === 'deadmove') {
            ctx.fillStyle = '#9f32e3';
            if (obstacle.maxDecayTime !== null) {
                ctx.globalAlpha =
                    (0.15 * Math.max(obstacle.decayTime, 0)) /
                    obstacle.maxDecayTime;
            } else {
                ctx.globalAlpha = 0.15;
            }
        }
        if (obstype === 'mark') {
            ctx.fillStyle = 'red';
            ctx.globalAlpha = 0.4;
            if (me().deathTimer != undefined) {
                ctx.globalAlpha = 1;
            }
        }
        if (obstype === 'deadpusher') {
            ctx.fillStyle = window.backgroundColor;
            ctx.globalAlpha = 0.08;
            if (me().dead) {
                ctx.globalAlpha = 0.5;
            }
        }
        if (obstype === 'cure') {
            ctx.fillStyle = 'white';
            ctx.globalAlpha = 0.4;
            if (me().deathTimer != undefined) {
                ctx.globalAlpha = 1;
            }
        }
        if (obstype === 'bounce') {
            ctx.fillStyle = '#234acc';
        }
        if (obstype === 'wallboost') {
            ctx.fillStyle = '#bf7300';
        }
        if (obstype === 'air') {
            ctx.fillStyle = tileColor;
        }
        if (obstype === 'boost') {
            ctx.fillStyle = '#ab7130';
            ctx.globalAlpha = 0.4;
        }
        if (obstype === 'revive') {
            ctx.fillStyle = '#009307';
            ctx.globalAlpha = 0.1;
        }
        if (obstype === 'musicchange') {
            ctx.globalAlpha = 0;
        }
        if (obstype === 'boostpad') {
            ctx.fillStyle = '#5c32a8';
            ctx.globalAlpha = 0.5;
        }
        if (obstype === 'tornado') {
            ctx.fillStyle = '#c0bbc9';
            ctx.globalAlpha = 0.25;
        }
        if (obstype === 'rotatingspeedtrap') {
            ctx.globalAlpha = 0;
        }
        if (obstype === 'zoom') {
            ctx.globalAlpha = 0;
        }
        if (obstype === 'redirect' || obstype === 'iframeplayer') {
            ctx.globalAlpha = 0.8;
        }
        if (obstype === 'draw') {
            ctx.globalAlpha = 0.25;
            ctx.fillStyle = '#680094';
        }
        if (obstype === 'hideplayer'){
            ctx.globalAlpha = 0.1;
            ctx.fillStyle = 'black';
        }
        if (
            obstype === 'speedtrap' ||
            obstype === 'movingspeedtrap' ||
            obstype === 'rotatingspeedtrap'
        ) {
            ctx.fillStyle = '#ba1627';
            if (obstacle.maxSpeed !== undefined) {
                ctx.fillStyle = '#3276e3';
                if (obstacle.minSpeed != undefined) {
                    ctx.fillStyle = '#dde332';
                }
            }
            ctx.globalAlpha = 0.25;
        }
        if (obstype === 'timetrap') {
            // trap types:
            // death (default)
            // speed
            // size
            // normal
            // tp
            // safe
            // morph
            // conveyor?
            switch(obstacle.trapType){
                case 'death':
                    ctx.fillStyle = '#c70000';
                    break;
                case 'tp':
                    ctx.fillStyle = '#38ab30';
                    break;
                case 'size':
                    if (obstacle.radiusMult > 24.5) {
                        ctx.fillStyle = "#0e30ad";
                    } else {
                        ctx.fillStyle = "#1c1852";
                    }
                    break;
                case 'speed':
                    ctx.fillStyle = '#eb7900';
                    break;
                case 'normal':
                    ctx.fillStyle = window.backgroundColor;
                    break;
                case 'safe':
                    ctx.fillStyle = window.safeColor || '#8c8c8c';
                    break;
                case 'morph':
                    ctx.fillStyle = '#ab20f0';
                    break;
                case 'conveyor':
                    ctx.fillStyle = 'black';// tbd if this is going to be a real thing
                    // if so then fix rendering
                    break;
                default:
                    ctx.fillStyle = '#c70000';
            }
            ctx.globalAlpha = Math.max(
                0.2,
                (0.75 * obstacle.time) / obstacle.maxTime
            );
        } else if(obstype === 'tptrap') {
            ctx.fillStyle = '#38ab30';
            ctx.globalAlpha = Math.max(
                0.2,
                (0.75 * obstacle.time) / obstacle.maxTime
            );
        }
        if(obstype === 'resettimetraps'){
            ctx.fillStyle = 'grey';
            ctx.globalAlpha = 0.02;
        }
        if (obstype === 'nores'){
            ctx.globalAlpha = 0;
        }
        if (obstype === 'bonus' || obstype === 'circle-bonus'){
            if(obstacle.collected){
                ctx.globalAlpha = 0.15;
            } else {
                ctx.globalAlpha = .8;
            }
            ctx.fillStyle = '#2ead23';
        }
        if (obstype === 'enemyeffect') {
            ctx.fillStyle = 'hsl(' + Date.now() / 12 + ', 50%, 50%)';
            ctx.globalAlpha = 0.1;
        }
        if (
            obstype === 'roundedcorners' ||
            obstype === 'resetcoins' ||
            obstype === 'roundedlava' ||
            obstype === 'demo'
        ) {
            ctx.globalAlpha = 0;
        }
        if (obstype === 'hole') {
            ctx.fillStyle = window.tileColor;
            holes.push(i);
            ctx.globalAlpha = 0;
        }
        if (obstype === 'playercollide') {
            ctx.globalAlpha = 0.1;
            ctx.fillStyle = 'brown';
        }
        if (obstype === 'invert') {
            ctx.fillStyle = '#2f299e';
            let a = 0;
            if (obstacle.invertX) a += 0.1;
            if (obstacle.invertY) a += 0.1;
            ctx.globalAlpha = a;
        }
        if (obstype === 'tbutton') {
            continue;
        }
        if (obstype === 'zombie') {
            ctx.fillStyle = 'red';
            ctx.globalAlpha = 0.05;
        }
        if (obstype === 'door') {
            // ctx.strokeStyle = "#c4c4c4";
            ctx.globalAlpha = 1;
            if (!obstacle.active) {
                ctx.globalAlpha = 0.3;
            }
            // ctx.fillStyle = 'rgba(0, 0, 0, 0.5)'
            ctx.fillStyle = '#787878'; //window.backgroundColor;
        }
        if (obstype === 'circle-door') {
            ctx.strokeStyle = '#c4c4c4';
            if (!obstacle.active) {
                ctx.globalAlpha = 0.2;
            } else {
                ctx.closePath();
                ctx.beginPath();
                ctx.lineWidth = 8;
                ctx.arc(pos.x, pos.y, obstacle.radius, 0, Math.PI * 2);
                ctx.stroke();
                ctx.closePath();
                ctx.lineWidth = 1;
            }
            ctx.fillStyle = window.backgroundColor;
            ctx.arc(pos.x, pos.y, obstacle.radius, 0, Math.PI * 2);
            ctx.fill();

            // text
            ctx.fillStyle = 'black';
            ctx.textBaseline = 'middle';
            ctx.textAlign = 'center';
            ctx.strokeStyle = 'black';
            ctx.lineWidth = 1;
            ctx.globalAlpha = 0.3;
            ctx.font = `${obstacle.radius}px Inter`;
            ctx.fillText(obstacle.id, pos.x, pos.y);
            continue;
        }
        if (
            obstype === 'button' ||
            obstype === 'bbutton' ||
            obstype === 'rbutton' ||
            obstype === 'ttbutton' ||
            obstype === 'crowdbutton' ||
            obstype === 'enemybutton'
        ) {
            // ctx.fillStyle = 'black'//"#c4c4c4"//'#0652cc';
            ctx.globalAlpha = 0.8;
            if (!obstacle.active) {
                ctx.globalAlpha = 0.3;
            }

            ctx.fillStyle = 'white';
            if (obstacle.tempActive) {
                ctx.fillStyle = 'gray';
            }
            //backgroundColor;//'rgb(150, 150, 150)'
        }
        if (obstype === 'morphbutton' || obstype === 'morphbuttontimed' || obstype === 'morphmovereset') {
            if (obstacle.w === 0 && obstacle.h === 0){
                continue;
            }
            ctx.globalAlpha = 0.8;
            if (!obstacle.active) {
                ctx.globalAlpha = 0.3;
            }
            ctx.fillStyle = '#a229ff'
        }
        if (obstype === 'pushboxreset') {
            // ctx.fillStyle = '#ff1d19';
        }
        
        if (obstype === 'morphnormal') {
            ctx.globalAlpha = 1;
            if (!obstacle.active) {
                ctx.globalAlpha = 0;
            }
        }
        if (obstype === 'farrow') {
            if (!obstacle.active) {
                ctx.globalAlpha = 0.2;
            }
            ctx.drawImage(
                window.upArrowImage,
                pos.x + obstacle.w / 4,
                pos.y,
                obstacle.w / 2,
                obstacle.h / 2
            );
            ctx.drawImage(
                window.downArrowImage,
                pos.x + obstacle.w / 4,
                pos.y + obstacle.h / 2,
                obstacle.w / 2,
                obstacle.h / 2
            );
            ctx.drawImage(
                window.leftArrowImage,
                pos.x,
                pos.y + obstacle.h / 4,
                obstacle.w / 2,
                obstacle.h / 2
            );
            // lmao do class Line
            // finding skills go brr
            ctx.drawImage(
                window.rightArrowImage,
                pos.x + obstacle.w / 2,
                pos.y + obstacle.h / 4,
                obstacle.w / 2,
                obstacle.h / 2
            ); // tf its not there?
            ctx.setLineDash([15, 40]);
            ctx.lineDashOffset = -time * 150;
            ctx.strokeStyle = ctx.fillStyle;
            ctx.lineWidth = 2;
            ctx.lineCap = 'round';
            ctx.strokeRect(
                pos.x + 2,
                pos.y + 2,
                obstacle.w - 4,
                obstacle.h - 4
            );
            ctx.setLineDash([]);
            ctx.globalAlpha = 0.05;
        }
        if (obstype === 'custom') {
            // renders with the provided render function
            let renderExec = obstacle.render.replaceAll('this', 'obstacle');
            ctx.fillStyle = window.backgroundColor;
            ctx.font = '30px Inter';
            ctx.lineWidth = lineWidth;
            ctx.strokeStyle = 'black';
            try {
                eval(renderExec);
            } catch (e) {
                console.log('client rendering error: ' + e);
            }
            ctx.globalAlpha = 0;
            ctx.strokeStyle = 'black';
            ctx.lineWidth = lineWidth;
            ctx.fillStyle = window.backgroundColor;
            ctx.filter = 'none';
            ctx.font = '30px Inter';
        }
        if (obstype === 'golf') {
            ctx.fillStyle = '#54680D';
            ctx.globalAlpha = 0.5;
        }
        if (obstype === 'camerachange') {
            ctx.globalAlpha = 0;
        }
        if (obstype === 'idit') {
            ctx.fillStyle = '#3d2810';
            ctx.globalAlpha = 0.25;
        }
        if (obstype === 'cookie') {
            if (getCookie(obstacle.cookie) == obstacle.value) {
                ctx.globalAlpha = 0;
            }
        }
        if (obstype === 'coindoor') {
            ctx.fillStyle = 'black';
            let alpha = obstacle.currentCoins <= 0 ? 0.5 : 1;
            ctx.globalAlpha = alpha;
            // ctx.globalAlpha = alpha * 0.8;
        }
        if (obstype === 'mirror') {
            ctx.fillStyle = 'black';
            ctx.globalAlpha = 0.2;
        }
        if (obstype === 'pushboxreset') {
            ctx.fillStyle = '#ff1d19'
        }
        //          if (obstype === 'coindoor') {
        // 	ctx.fillStyle = 'black';
        // 	ctx.globalAlpha = 0.3;
        // }
        if (obstype === 'raycasting') {
            ctx.globalAlpha = 0;
        }
        if (obstype === 'z-mode') {
            ctx.globalAlpha = 0;
            ctx.fillStyle = '#04d4a7'
        }
        if (obstype === 'rotatecanvas') {
            ctx.globalAlpha = 0;
        }
        if (obstype === 'ship') {
            if (obstacle.state) {
                ctx.fillStyle = 'blue';
            } else {
                ctx.fillStyle = 'yellow';
            }
            ctx.globalAlpha = 0.3;
        }
        if (obstype === 'playerdraw'){
            ctx.fillStyle = '#cccccc';
        }
        if (obstype === 'gupu') {
            ctx.fillStyle = '#141414';
            ctx.globalAlpha = 0.3;
        }
        if (obstype === 'ampu') {
            ctx.fillStyle = '#75131d';
            ctx.globalAlpha = 0.3;
        }
        if (obstype === 'gun') {
            if (obstacle.state) {
                if (obstacle.gunType == 'normal') {
                    ctx.fillStyle = '#bd8b0d';
                } else if (obstacle.gunType == 'stun') {
                    ctx.fillStyle = 'purple';
                } else if (obstacle.gunType == 'push') {
                    ctx.fillStyle = '#458dc4';
                } else if (obstacle.gunType == 'pvp') {
                    ctx.fillStyle = 'red';
                }
            } else {
                ctx.fillStyle = '#6e7175';
            }
            ctx.globalAlpha = 0.3;
        }
        if (obstype === 'breakable') {
            ctx.fillStyle = window.backgroundColor;
            ctx.globalAlpha =
                obstacle.currentStrength / obstacle.maxStrength;
        }
        if (obstype === 'bouncybreakable') {
            ctx.fillStyle = '#234acc';
            ctx.globalAlpha =
                obstacle.currentStrength / obstacle.maxStrength;
        }
        if (obstype === 'switchlava') {
            if (obstacle.state) {
                if (obstacle.timer < 0.2 && obstacle.onTime > 0.2) {
                    ctx.globalAlpha = obstacle.timer / 0.2;
                }
            } else {
                ctx.globalAlpha = 0.3;
                if (obstacle.timer < 0.2 && obstacle.offTime > 0.2) {
                    ctx.globalAlpha =
                        0.9 * (1 - obstacle.timer / 0.2) + 0.1;
                }
            }
            ctx.fillStyle = '#c70000';
            if (!obstacle.collidable) {
                ctx.fillStyle = '#9e0000';
            }
        }
        if (obstype === 'lavadoor') {
            ctx.strokeStyle = '#c4c4c4';
            if (!obstacle.active) {
                ctx.globalAlpha = 0.2;
            } else {
                ctx.lineWidth = 8;
                ctx.strokeRect(pos.x, pos.y, obstacle.w, obstacle.h);
                ctx.lineWidth = 1;
            }
            ctx.fillStyle = '#c70000';
        }
        if (obstype === 'invpu') {
            ctx.fillStyle = '#292726';
            ctx.globalAlpha = 0.5; //Math.min(obstacle.amount,0.5);
        }
        if (obstype === 'raxis') {
            ctx.strokeStyle = 'white';
            ctx.lineWidth = 1;
            ctx.globalAlpha = 1;
            if (obstacle.rx) {
                // restricting x axis; draw lines on y axis
                for (let x = 0; x <= obstacle.w; x += 50) {
                    ctx.beginPath();
                    ctx.moveTo(pos.x + x, pos.y);
                    ctx.lineTo(pos.x + x, pos.y + obstacle.h);
                    ctx.stroke();
                    ctx.closePath();
                }
            }
            if (obstacle.ry) {
                for (let y = 0; y <= obstacle.h; y += 50) {
                    ctx.beginPath();
                    ctx.moveTo(pos.x, pos.y + y);
                    ctx.lineTo(pos.x + obstacle.w, pos.y + y);
                    ctx.stroke();
                    ctx.closePath();
                }
            }
            ctx.lineWidth = 1;
            ctx.strokeStyle = 'black';
            ctx.fillStyle = 'black';
            ctx.globalAlpha = 0;
        }
        if (obstype === 'zone') {
            ctx.globalAlpha = 0;
            ctx.fillStyle = backgroundColor;
        }
        if (obstype === 'revpu') {
            ctx.fillStyle = 'green';
            ctx.globalAlpha = Math.min(obstacle.amount, 0.5);
        }
        if (obstype === 'switchnormal') {
            if (obstacle.state) {
                if (obstacle.timer < 0.2 && obstacle.onTime > 0.2) {
                    ctx.globalAlpha = obstacle.timer / 0.2;
                }
            } else {
                ctx.globalAlpha = 0.3;
                if (obstacle.timer < 0.2 && obstacle.offTime > 0.2) {
                    ctx.globalAlpha =
                        0.9 * (1 - obstacle.timer / 0.2) + 0.1;
                }
            }
            // fade is essential
            // trust me
            ctx.fillStyle = window.backgroundColor;
        }
        if (obstype === 'movingsafe') {
            ctx.fillStyle = window.safeColor || '#8c8c8c';
            ctx.globalAlpha = 0.25;
        }
        if (obstype === 'coin') {
            ctx.fillStyle = '#d6d611';
            if (obstacle.collected) {
                ctx.globalAlpha = 0.2;
            } else {
                ctx.globalAlpha = 0.8;
            }
        }
        if (obstype === 'fulldeath') {
            //ctx.fillStyle = '#240606';
            ctx.fillStyle = '#9e0000';
            ctx.globalAlpha = 0.08;
        }
        if (obstype === 'vinette') {
            //ctx.fillStyle = "#212121";
            ctx.globalAlpha = 0;//.1;
        }
        if (obstype === 'snap' || obstype === 'circlesnap') {
            ctx.fillStyle = '#00008a';
            ctx.globalAlpha = 0.1;
        }
        if (obstype === 'frictionchanger') {
            if (obstacle.fric > 0.4) {
                ctx.fillStyle = '#0e30ad';
            } else {
                ctx.fillStyle = '#1c1852';
            }
            ctx.globalAlpha = 0.28;
        }
        if (obstype === 'size') {
            ctx.globalAlpha = 0;
        }
        if (obstype === 'clone') {
            if (Date.now() % 1000 > 500) {
                ctx.globalAlpha =
                    0.4 * ((1000 - (Date.now() % 1000)) / 500);
            } else {
                ctx.globalAlpha = 0.4 * ((Date.now() % 1000) / 500);
            }
            ctx.fillStyle = '#21464f';
        }
        if (obstype === 'grpu') {
            ctx.fillStyle = '#c9c9c9';
            ctx.globalAlpha = 0.5;
        }
        if (obstype === 'slip') {
            ctx.fillStyle = '#a83291';
            ctx.globalAlpha = 0.25;
        }
        if (obstype === 'check') {
            if (obstacle.collected) {
                ctx.fillStyle = '#0fba09';
                ctx.globalAlpha = 0.15;
            } else {
                ctx.fillStyle = '#05962b';
                ctx.globalAlpha = 0.8;
            }
        }
        if (obstype === 'push') {
            ctx.globalAlpha = 1;
        }
        if (obstype === 'dirnormal') {
            if (obstacle.active) {
                ctx.globalAlpha = 0.3 + Math.min(obstacle.activeTimer / 0.25, 1) * 0.7
            } else {
                ctx.globalAlpha = 0.3;
            }
        }
        if (obstype === 'wb') {
            ctx.fillStyle = '#7e96e0';
        }
        if (obstype === 'tp' || obstype === 'tpmove') {
            ctx.fillStyle = '#38ab30';
            ctx.globalAlpha = 1;
        }
        if (obstype === 'story') {
            ctx.fillStyle = '#087878';
            if (this.visble) {
                ctx.globalAlpha = 0.3;
            } else {
                ctx.globalAlpha = 0;
            }
        }
        if (
            obstype === 'lava' ||
            obstype === 'lavamove' ||
            obstype === 'morphlavamove' ||
            obstype == 'move-pause-lava' ||
            obstype === 'growinglava'
        ) {
            ctx.fillStyle = '#c70000';
            if (!obstacle.canCollide && obstacle.collidable == undefined) {
                ctx.fillStyle = '#9e0000';
            }
            if (obstacle.collidable != undefined && !obstacle.collidable) {
                ctx.fillStyle = '#9e0000';
            }
        }
        if (obstype === 'growing') {
            //ctx.fillStyle = "#0f0d0d";
        }
        if (obstype === 'color') {
            ctx.fillStyle = 'rgba(0,0,0,0)';
        }
        /*if (obstype === 'move') {
            ctx.fillStyle = "#13479c";
  }*/
        if (obstype === 'speed') {
            ctx.fillStyle = '#eba500';
            ctx.globalAlpha = 0.25;
        }
        if (obstype === 'mashing') {
            if (!obstacle.active) {
                ctx.globalAlpha = 0.2;
            }
            ctx.fillStyle = 'white';
            ctx.font = `${obstacle.w / 10}px Inter`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(
                obstacle.amount - obstacle.currentNum,
                pos.x + obstacle.w / 2,
                pos.y + obstacle.h / 2,
                (canvas.width * 2) / 3
            );
            /*const halfDist = ctx.measureText(textToDisplay).width/2;
            // try 1
            ctx.fillText(
                "_",
                pos.x+obstacle.w/2-halfDist,
                pos.y+obstacle.h/2
            );
            // try 2
            const charDimensions = ctx.measureText(textToDisplay.slice(0,1));
            ctx.fillRect(
                pos.x+obstacle.w/2-halfDist-charDimensions.width/2,
                pos.y+obstacle.h/2+obstacle.w/20,
                charDimensions.width,
                5
            );*/
            ctx.fillStyle = 'black';
            ctx.globalAlpha = 0.17;
            if (!obstacle.active) {
                ctx.globalAlpha = 0.05;
            }
        }
        if (obstype === 'typing') {
            if (!obstacle.active) {
                ctx.globalAlpha = 0.2;
            }
            ctx.fillStyle = 'white';
            ctx.font = `${obstacle.w / 10}px Inter`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';

            const aheadChar = Math.min(
                obstacle.text.length,
                obstacle.currentChar + 15
            );
            const textToDisplay =
                obstacle.text.slice(obstacle.currentChar, aheadChar) || '';
            ctx.fillText(
                textToDisplay,
                pos.x + obstacle.w / 2,
                pos.y + obstacle.h / 2,
                (canvas.width * 2) / 3
            );
            /*const halfDist = ctx.measureText(textToDisplay).width/2;
            // try 1
            ctx.fillText(
                "_",
                pos.x+obstacle.w/2-halfDist,
                pos.y+obstacle.h/2
            );
            // try 2
            const charDimensions = ctx.measureText(textToDisplay.slice(0,1));
            ctx.fillRect(
                pos.x+obstacle.w/2-halfDist-charDimensions.width/2,
                pos.y+obstacle.h/2+obstacle.w/20,
                charDimensions.width,
                5
            );*/
            ctx.fillStyle = 'black';
            ctx.globalAlpha = 0.17;
            if (!obstacle.active) {
                ctx.globalAlpha = 0.05;
            }
        }
        if (obstype === 'winpad') {
            ctx.fillStyle = 'hsl(' + Date.now() / 12 + ', 50%, 50%)';
        }
        if (
            obstype === 'grav' ||
            obstype === 'platformer' ||
            obstype === 'switchgrav'
        ) {
            try {
                if (obstype === 'switchgrav') {
                    obstacle.direction =
                        obstacle.dirs[obstacle.index].direction;
                }
                //const inView = (x, y, w, h) => x + w > 0 && x - w < canvas.width && y + h > 0 && y - h < canvas.height;
                if (obstacle.direction === 'up') {
                    // kk tell me when it works going to darrows
                    ctx.globalAlpha = 1;
                    ctx.closePath();
                    ctx.beginPath();
                    ctx.rect(pos.x, pos.y, obstacle.w, obstacle.h);
                    ctx.save();
                    ctx.clip();
                    const topoffset = (1-1/window.renderScale)/2;
                    ctx.drawImage(
                        window.upConveyorImage,
                        pos.x % 50 + topoffset*canvas.width - (topoffset*canvas.width) % 50 - 50,
                        pos.y % 50 + topoffset*canvas.height - (topoffset*canvas.height) % 50 - 50,
                    );
                    ctx.closePath();
                    ctx.restore();
                    // ctx.fillStyle = 'blue';
                } else if (obstacle.direction === 'down') {
                    /*
                    for (let i = 0; i < obstacle.w / 50; i++) {
                        let seen = false;
                        for (let j = 0; j < obstacle.h / 50; j++) {
                            if (inView(i * 50 + pos.x, j * 50 + pos.y, 50, 50)) {
                                seen = true;
                                ctx.drawImage(window.upArrowImage, i * 50 + pos.x, j * 50 + pos.y);
                            } else if (seen) {
                                break;
                            }
                        }
                    }*/
                    ctx.globalAlpha = 1;
                    ctx.closePath();
                    ctx.beginPath();
                    ctx.rect(pos.x, pos.y, obstacle.w, obstacle.h);
                    ctx.save();
                    ctx.clip();
                    const topoffset = (1-1/window.renderScale)/2;
                    ctx.drawImage(
                        window.downConveyorImage,
                        pos.x % 50 + topoffset*canvas.width - (topoffset*canvas.width) % 50 - 50,
                        pos.y % 50 + topoffset*canvas.height - (topoffset*canvas.height) % 50 - 50,
                    );
                    ctx.closePath();
                    ctx.restore();
                    ctx.fillStyle = 'red';
                } else if (obstacle.direction === 'left') {
                    ctx.globalAlpha = 1;
                    ctx.closePath();
                    ctx.beginPath();
                    ctx.rect(pos.x, pos.y, obstacle.w, obstacle.h);
                    ctx.save();
                    ctx.clip();
                    const topoffset = (1-1/window.renderScale)/2;
                    ctx.drawImage(
                        window.leftConveyorImage,
                        pos.x % 50 + topoffset*canvas.width - (topoffset*canvas.width) % 50 - 50,
                        pos.y % 50 + topoffset*canvas.height - (topoffset*canvas.height) % 50 - 50,
                    );
                    ctx.closePath();
                    ctx.restore();
                    ctx.fillStyle = 'green';
                } else if (obstacle.direction === 'right') {
                    ctx.globalAlpha = 1;
                    ctx.closePath();
                    ctx.beginPath();
                    ctx.rect(pos.x, pos.y, obstacle.w, obstacle.h);
                    ctx.save();
                    ctx.clip();
                    const topoffset = (1-1/window.renderScale)/2;
                    ctx.drawImage(
                        window.rightConveyorImage,
                        pos.x % 50 + topoffset*canvas.width - (topoffset*canvas.width) % 50 - 50,
                        pos.y % 50 + topoffset*canvas.height - (topoffset*canvas.height) % 50 - 50,
                    );
                    ctx.closePath();
                    ctx.restore();
                    ctx.fillStyle = 'red';
                }
            } catch(e){}
            ctx.fillStyle = backgroundColor;
            ctx.globalAlpha = 0.05;
        }
        if (obstype === 'particles') {
            ctx.fillStyle = obstacle.particleColor;
            ctx.globalAlpha = 1;
            for (let p in obstacle.particles) {
                ctx.globalAlpha =
                    obstacle.particles[p][3] / obstacle.particleLifespan;
                let ppos = offset(
                    obstacle.particles[p][0],
                    obstacle.particles[p][1]
                );
                ctx.beginPath();
                ctx.arc(
                    ppos.x,
                    ppos.y,
                    obstacle.particleSize,
                    0,
                    2 * Math.PI
                );
                ctx.fill();
                ctx.closePath();
            }
            ctx.globalAlpha = 0;
        }
        if (obstype === 'demo') {
            ctx.fillStyle = 'black';
            ctx.globalAlpha = 0.4;
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, me().renderRadius, 0, Math.PI * 2);
            ctx.fill();
            ctx.closePath();
            ctx.globalAlpha = 0;
        }
        if (obstype === 'circle-normal') {
            ctx.fillStyle = backgroundColor;
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, obstacle.radius, 0, Math.PI * 2);
            ctx.fill();
        } else if (obstype === 'circle-slice') {
            ctx.fillStyle = backgroundColor;
            ctx.beginPath();
            // console.log(obstacle.startAngle, obstacle.endAngle)
            ctx.arc(
                pos.x,
                pos.y,
                obstacle.radius,
                obstacle.startAngle,
                obstacle.endAngle
            );
            ctx.lineTo(pos.x, pos.y);
            ctx.fill();
        }
        if (obstype === 'circularpushbox') {
            ctx.fillStyle = backgroundColor;
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, obstacle.r, 0, Math.PI * 2);
            ctx.fill()
            ctx.globalAlpha = 0.1 + (obstacle.weight / 100) * 0.9;
            ctx.lineWidth = 1 + lineWidth * 2;
            ctx.strokeStyle = 'white';
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, obstacle.r - 4, 0, Math.PI * 2);
            ctx.stroke();
        }
        if (obstype === 'oval') {
            ctx.fillStyle = backgroundColor;
            ctx.beginPath();
            ctx.ellipse(
                pos.x,
                pos.y,
                obstacle.radius,
                obstacle.radius2,
                0,
                0,
                Math.PI * 2
            );
            ctx.fill();
            if (obstacle.closestPoint) {
                ctx.fillStyle = 'red';
                ctx.closePath();
                ctx.globalAlpha = 1;
                ctx.beginPath();
                let off = offset(
                    obstacle.closestPoint.x,
                    obstacle.closestPoint.y
                );
                ctx.arc(off.x, off.y, 15, 0, Math.PI * 2);
                ctx.fill();
                ctx.closePath();
            }
            if (obstacle.closestLine) {
                ctx.globalAlpha = 1;
                ctx.strokeStyle = 'red';
                ctx.beginPath();
                let of = offset(
                    obstacle.closestLine[0][0],
                    obstacle.closestLine[0][1]
                );
                ctx.moveTo(of.x, of.y);
                let of2 = offset(
                    obstacle.closestLine[1][0],
                    obstacle.closestLine[1][1]
                );
                ctx.lineTo(of2.x, of2.y);
                ctx.stroke();
                ctx.closePath();
            }
            ctx.globalAlpha = 0;
        }
        if (obstype === 'lava-oval') {
            ctx.fillStyle = '#c70000';
            if (!obstacle.canCollide) {
                ctx.fillStyle = '#9e0000';
            }
            ctx.strokeStyle = 'black';
            ctx.lineWidth = window.lineWidth;
            ctx.beginPath();
            ctx.ellipse(
                pos.x,
                pos.y,
                obstacle.radius,
                obstacle.radius2,
                0,
                0,
                Math.PI * 2
            );
            ctx.fill();
            ctx.stroke();
            ctx.closePath();
            ctx.globalAlpha = 0;
        } else if (obstype === 'circle-slice') {
            ctx.fillStyle = backgroundColor;
            ctx.beginPath();
            // console.log(obstacle.startAngle, obstacle.endAngle)
            ctx.arc(
                pos.x,
                pos.y,
                obstacle.radius,
                obstacle.startAngle,
                obstacle.endAngle
            );
            ctx.lineTo(pos.x, pos.y);
            ctx.fill();
        } else if (obstype === 'circle-coin') {
            ctx.beginPath();
            ctx.fillStyle = '#d6d611';
            if (obstacle.collected) {
                ctx.globalAlpha = 0.2;
            } else {
                ctx.globalAlpha = 0.8;
            }
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, obstacle.radius, 0, Math.PI * 2);
            ctx.fill();
        } else if (obstype === 'circle-hollow') {
            ctx.strokeStyle = backgroundColor;
            ctx.lineWidth = obstacle.radius - obstacle.innerRadius;
            ctx.beginPath();
            ctx.arc(
                pos.x,
                pos.y,
                obstacle.radius - ctx.lineWidth / 2,
                0,
                Math.PI * 2
            );
            ctx.stroke();
            ctx.closePath();
            ctx.lineWidth = lineWidth;
            ctx.strokeStyle = 'black';
        } else if (obstype === 'circle-hollow-slice') {
            ctx.lineCap = 'butt';
            ctx.strokeStyle = backgroundColor;
            ctx.lineWidth = obstacle.radius - obstacle.innerRadius;
            ctx.beginPath();
            ctx.arc(
                pos.x,
                pos.y,
                obstacle.radius - ctx.lineWidth / 2,
                obstacle.startAngle,
                obstacle.endAngle
            );
            ctx.stroke();
            ctx.closePath();
            ctx.lineWidth = lineWidth;
            ctx.strokeStyle = 'black';
            ctx.lineCap = 'round';
        } else if (obstype === 'circle-hollow-lava') {
            ctx.strokeStyle = '#c70000';
            ctx.lineWidth = obstacle.radius - obstacle.innerRadius;
            ctx.beginPath();
            ctx.arc(
                pos.x,
                pos.y,
                obstacle.radius - ctx.lineWidth / 2,
                0,
                Math.PI * 2
            );
            ctx.stroke();
            ctx.closePath();
            ctx.lineWidth = lineWidth;
            ctx.strokeStyle = 'black';

            // drawing outline
            ctx.fillStyle = '#c70000';
            ctx.lineWidth = lineWidth;
            ctx.strokeStyle = 'black';

            // outside
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, obstacle.radius, 0, Math.PI * 2);
            ctx.stroke();
            ctx.closePath();

            // inside
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, obstacle.innerRadius, 0, Math.PI * 2);
            ctx.stroke();
            ctx.closePath();
        } else if (obstype === 'circle-slice-lava') {
            ctx.fillStyle = '#c70000';
            ctx.lineWidth = lineWidth;
            ctx.strokeStyle = 'black';
            ctx.beginPath();
            // console.log(obstacle.startAngle, obstacle.endAngle)
            ctx.arc(
                pos.x,
                pos.y,
                obstacle.radius,
                obstacle.startAngle,
                obstacle.endAngle
            );
            ctx.lineTo(pos.x, pos.y);
            ctx.fill();
            ctx.stroke();
            ctx.closePath();

            // stroking end line (we already got start one)
            ctx.beginPath();
            ctx.moveTo(pos.x, pos.y);
            ctx.lineTo(
                pos.x + Math.cos(obstacle.startAngle) * obstacle.radius,
                pos.y + Math.sin(obstacle.startAngle) * obstacle.radius
            );
            ctx.stroke();
        } else if (obstype === 'circle-hollow-slice-lava') {
            // drawing hollow slice
            ctx.lineCap = 'butt';
            ctx.strokeStyle = '#c70000';
            ctx.lineWidth = obstacle.radius - obstacle.innerRadius;
            ctx.beginPath();
            ctx.arc(
                pos.x,
                pos.y,
                obstacle.radius - ctx.lineWidth / 2,
                obstacle.startAngle,
                obstacle.endAngle
            );
            ctx.stroke();
            ctx.closePath();
            ctx.lineWidth = lineWidth;
            ctx.strokeStyle = 'black';
            ctx.lineCap = 'round';
            ctx.closePath();
            // drawing outline
            ctx.fillStyle = '#c70000';
            ctx.lineWidth = lineWidth;
            ctx.strokeStyle = 'black';

            // outside
            ctx.beginPath();
            ctx.arc(
                pos.x,
                pos.y,
                obstacle.radius,
                obstacle.startAngle,
                obstacle.endAngle
            );
            ctx.stroke();
            ctx.closePath();

            // inside
            ctx.beginPath();
            ctx.arc(
                pos.x,
                pos.y,
                obstacle.innerRadius,
                obstacle.startAngle,
                obstacle.endAngle
            );
            ctx.stroke();
            ctx.closePath();

            // startAngle line
            ctx.beginPath();
            ctx.moveTo(
                pos.x + Math.cos(obstacle.startAngle) * obstacle.radius,
                pos.y + Math.sin(obstacle.startAngle) * obstacle.radius
            );
            ctx.lineTo(
                pos.x +
                    Math.cos(obstacle.startAngle) * obstacle.innerRadius,
                pos.y + Math.sin(obstacle.startAngle) * obstacle.innerRadius
            );
            ctx.stroke();
            ctx.closePath();

            // endAngle line
            ctx.beginPath();
            ctx.moveTo(
                pos.x + Math.cos(obstacle.endAngle) * obstacle.radius,
                pos.y + Math.sin(obstacle.endAngle) * obstacle.radius
            );
            ctx.lineTo(
                pos.x + Math.cos(obstacle.endAngle) * obstacle.innerRadius,
                pos.y + Math.sin(obstacle.endAngle) * obstacle.innerRadius
            );
            ctx.stroke();
            ctx.closePath();
        } else if (obstype === 'circle-hollow-slice-enemywall' || obstype === 'circle-hollow-slice-enemytp') {
            // drawing hollow slice
            ctx.lineCap = 'butt';
            ctx.globalAlpha = 0.4;
            if (obstype === 'circle-hollow-slice-enemywall'){
                ctx.strokeStyle = window.backgroundColor;
                ctx.fillStyle = window.backgroundColor;
            } else {
                ctx.fillStyle = '#38ab30';
                ctx.strokeStyle = '#38ab30';
            }
            
            ctx.lineWidth = obstacle.radius - obstacle.innerRadius;
            ctx.beginPath();
            ctx.arc(
                pos.x,
                pos.y,
                obstacle.radius - ctx.lineWidth / 2,
                obstacle.startAngle,
                obstacle.endAngle
            );
            ctx.stroke();
            ctx.closePath();
            ctx.globalAlpha = 1;
            ctx.lineWidth = lineWidth;
            ctx.lineCap = 'round';
            // drawing outline
            ctx.lineWidth = lineWidth;

            // outside
            ctx.beginPath();
            ctx.arc(
                pos.x,
                pos.y,
                obstacle.radius,
                obstacle.startAngle,
                obstacle.endAngle
            );
            ctx.stroke();
            ctx.closePath();

            // inside
            ctx.beginPath();
            ctx.arc(
                pos.x,
                pos.y,
                obstacle.innerRadius,
                obstacle.startAngle,
                obstacle.endAngle
            );
            ctx.stroke();
            ctx.closePath();

            // startAngle line
            ctx.beginPath();
            ctx.moveTo(
                pos.x + Math.cos(obstacle.startAngle) * obstacle.radius,
                pos.y + Math.sin(obstacle.startAngle) * obstacle.radius
            );
            ctx.lineTo(
                pos.x +
                    Math.cos(obstacle.startAngle) * obstacle.innerRadius,
                pos.y + Math.sin(obstacle.startAngle) * obstacle.innerRadius
            );
            ctx.stroke();
            ctx.closePath();

            // endAngle line
            ctx.beginPath();
            ctx.moveTo(
                pos.x + Math.cos(obstacle.endAngle) * obstacle.radius,
                pos.y + Math.sin(obstacle.endAngle) * obstacle.radius
            );
            ctx.lineTo(
                pos.x + Math.cos(obstacle.endAngle) * obstacle.innerRadius,
                pos.y + Math.sin(obstacle.endAngle) * obstacle.innerRadius
            );
            ctx.stroke();
            ctx.closePath();
            ctx.globalAlpha = 1;
        } else if (
            obstype === 'grapplepoint' ||
            obstype === 'movinggrapplepoint'
        ) {
            ctx.strokeStyle = '#c9c9c9';
            ctx.lineWidth = lineWidth * 3;
            ctx.globalAlpha = 0.5;
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, 10, 0, Math.PI * 2);
            ctx.stroke();
            ctx.globalAlpha = 1;
            ctx.closePath();
        } else if (obstype === 'poly-rail') {
            ctx.globalAlpha = 0.2;
            ctx.setLineDash([15, 25]);
            ctx.lineDashOffset = -time * 50;
            //ctx.arc(pos.x,pos.y,obstacle.radius,0,Math.PI*2);
            //ctx.fill();
            ctx.beginPath();
            ctx.fillStyle = '#55008a';
            ctx.strokeStyle = 'white';
            ctx.lineWidth = lineWidth;
            let startOffset = offset(
                obstacle.startPoint.x,
                obstacle.startPoint.y
            );
            ctx.arc(startOffset.x, startOffset.y, 18, 0, Math.PI * 2);
            ctx.stroke();
            ctx.closePath();
            ctx.beginPath();
            // console.log('poly render', obstacle)
            for (const [x, y] of obstacle.points) {
                const pos = offset(x, y);
                ctx.lineTo(pos.x, pos.y);
                // console.log(pos)
            }
            let endOffset = offset(
                obstacle.endPoint.x,
                obstacle.endPoint.y
            );
            ctx.arc(endOffset.x, endOffset.y, 18, 0, Math.PI * 2);
            ctx.stroke();
            ctx.setLineDash([]);
            ctx.globalAlpha = 1;
        } else if (obstacle.type.slice(0,4) === 'poly') {
            if (showPos/*debugMode*/) {
                ctx.strokeStyle = 'red';
                ctx.lineWidth = 5;
                ctx.strokeRect(
                    offset(obstacle.most.left, 0).x,
                    offset(0, obstacle.most.top).y,
                    obstacle.most.right - obstacle.most.left,
                    obstacle.most.bottom - obstacle.most.top
                );
            }
            ctx.fillStyle = backgroundColor;
            // make this a LUT soon
            if (obstype === 'poly-lava') {
                ctx.fillStyle = '#c70000';
                ctx.lineWidth = lineWidth;
                ctx.strokeStyle = 'black';
            }
            else if (obstype === 'poly-safe') {
                ctx.fillStyle = window.safeColor || '#8c8c8c';
                ctx.globalAlpha = 0.25;
            }
            else if (obstype === 'poly-bounce' || obstype === 'poly-bouncy-breakable'){
                ctx.fillStyle = '#234acc';
                if(obstype === 'poly-bouncy-breakable'){
                    ctx.globalAlpha = obstacle.currentStrength/obstacle.maxStrength;
                }
                ctx.strokeStyle = '#234acc'
            }
            else if (obstype === 'poly-breakable'){
                ctx.fillStyle = window.backgroundColor;
                ctx.globalAlpha = obstacle.currentStrength/obstacle.maxStrength;
                ctx.strokeStyle = window.backgroundColor;
            }
            else if (obstype === 'poly-enemywall' || obstype === 'poly-enemytp'){
                ctx.globalAlpha = 0.4;
                if (obstype === 'poly-enemytp') {
                    ctx.fillStyle = '#38ab30';
                }
            }
            else if (obstype === 'poly-wb') {
                ctx.fillStyle = '#7e96e0';
            }
            else if (obstype === 'poly-tp') {
                ctx.fillStyle = '#38ab30';
            }
            ctx.beginPath();
            // console.log('poly render', obstacle)
            for (const [x, y] of obstacle.points) {
                const pos = offset(x, y);
                ctx.lineTo(pos.x, pos.y);
                // console.log(pos)
            }
            const pos = offset(
                obstacle.points[0][0],
                obstacle.points[0][1]
            );
            ctx.lineTo(pos.x, pos.y);
            if (obstype !== 'poly-rail') {
                ctx.fill();
            }
            if (obstype === 'poly-bouncy-breakable' || obstype === 'poly-breakable'){
                ctx.fillStyle = 'black';
                ctx.globalAlpha *= 0.4;
                ctx.fill();
            }
            ctx.globalAlpha = 1;
            if (obstype === 'poly-lava' || obstype === 'poly-rail') {
                ctx.stroke();
            } else if(obstype !== 'poly-safe') {
                ctx.lineWidth = lineWidth;
                ctx.strokeStyle = ctx.fillStyle;
                ctx.stroke();
            } else if (obstype === 'poly-rail') {
                let endOffset = offset(
                    obstacle.endPoint.x,
                    obstacle.endPoint.y
                );
                ctx.arc(endOffset.x, endOffset.y, 18, 0, Math.PI * 2);
                ctx.setLineDash([]);
            }
            if (showPos) {
                for (let i = 0; i < obstacle.points.length; i++) {
                    const [x, y] = obstacle.points[i];
                    const pos = offset(x, y);
                    ctx.beginPath();
                    ctx.fillStyle = 'red';
                    ctx.arc(pos.x, pos.y, 5, 0, Math.PI * 2);
                    ctx.fill();
                    ctx.fillStyle = 'white';
                    ctx.font = '30px Inter';
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'middle';
                    ctx.fillText(i, pos.x, pos.y - 20);
                }
                ctx.strokeStyle = 'red';
                ctx.lineWidth = lineWidth;
                ctx.beginPath();
                for (const [x, y] of obstacle.points) {
                    const pos = offset(x, y);
                    ctx.lineTo(pos.x, pos.y);
                }
                const pos = offset(
                    obstacle.points[0][0],
                    obstacle.points[0][1]
                );
                ctx.lineTo(pos.x, pos.y);
                ctx.stroke();
            }
        } else if (obstype === 'bezier') {
            ctx.fillStyle = window.backgroundColor;
            ctx.beginPath();
            // bro ctx dum
            const p0 = offset(
                obstacle.curves[0].handles[0].x,
                obstacle.curves[0].handles[0].y
            );
            ctx.moveTo(p0.x, p0.y);
            for (let curve of obstacle.curves) {
                // bezier brekaing game// >== ?
                // no? im just supporting more points rn lol
                // it shouldn't break as is bc there isn't > 4 points
                if (curve.handles.length > 4) {
                    // higher degree bezier. Functions in js aren't supported for this so just make our own >:)
                    for (let a = 0; a < curve.points.length; a++) {
                        let o = offset(
                            curve.points[a].x,
                            curve.points[a].y
                        );
                        ctx.lineTo(o.x, o.y);
                    }
                }
                if (curve.handles.length === 4) {
                    // cubic
                    const p0 = offset(
                        curve.handles[0].x,
                        curve.handles[0].y
                    );
                    const p1 = offset(
                        curve.handles[1].x,
                        curve.handles[1].y
                    );
                    const p2 = offset(
                        curve.handles[2].x,
                        curve.handles[2].y
                    );
                    const p3 = offset(
                        curve.handles[3].x,
                        curve.handles[3].y
                    );

                    ctx.bezierCurveTo(p1.x, p1.y, p2.x, p2.y, p3.x, p3.y);
                } else if (curve.handles.length === 3) {
                    // quadratic
                    const p0 = offset(
                        curve.handles[0].x,
                        curve.handles[0].y
                    );
                    const p1 = offset(
                        curve.handles[1].x,
                        curve.handles[1].y
                    );
                    const p2 = offset(
                        curve.handles[2].x,
                        curve.handles[2].y
                    );
                    ctx.quadraticCurveTo(p1.x, p1.y, p2.x, p2.y);
                } else if (curve.handles.length === 2) {
                    // linear
                    const p0 = offset(
                        curve.handles[0].x,
                        curve.handles[0].y
                    );
                    const p1 = offset(
                        curve.handles[1].x,
                        curve.handles[1].y
                    );
                    ctx.lineTo(p1.x, p1.y);
                }
            }
            ctx.fill();
            ctx.closePath();
            if (showPos) {
                obstacle.points = obstacle.polygon.points;
                for (let i = 0; i < obstacle.points.length; i++) {
                    const [x, y] = obstacle.points[i];
                    const pos = offset(x, y);
                    ctx.beginPath();
                    ctx.fillStyle = 'red';
                    ctx.arc(pos.x, pos.y, 5, 0, Math.PI * 2);
                    ctx.fill();
                    ctx.fillStyle = 'white';
                    ctx.font = '30px Inter';
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'middle';
                    ctx.fillText(i, pos.x, pos.y - 20);
                }
            }
        } else if (obstype === 'circle-bounce') {
            ctx.fillStyle = '#234acc';
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, obstacle.radius, 0, Math.PI * 2);
            ctx.fill();
        } else if (obstype === 'circle-bonus') {
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, obstacle.radius, 0, Math.PI * 2);
            ctx.fill();
        } else if (obstype === 'growingcircle') {
            //ctx.fillStyle = "#0f0d0d";
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, obstacle.r, 0, Math.PI * 2);
            ctx.fill();
        } else if (
            obstype === 'growinglavacircle' ||
            obstype === 'circle-lava'
        ) {
            ctx.lineWidth = lineWidth;
            ctx.strokeStyle = 'black';
            ctx.fillStyle = '#c70000';
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, obstacle.r, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();
        } else if (obstype === 'circle-safe') {
            ctx.fillStyle = window.safeColor || '#8c8c8c';
            ctx.globalAlpha = 0.25;
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, obstacle.r, 0, Math.PI * 2);
            ctx.fill();
            ctx.globalAlpha = 1;
        } else if (obstype === 'circle-sentry') {
            ctx.translate(pos.x, pos.y);
            ctx.rotate((obstacle.angle * Math.PI) / 180);
            ctx.fillStyle = 'red';
            ctx.lineWidth = lineWidth * 2;
            ctx.strokeStyle = 'black';
            ctx.fillRect(
                -obstacle.laser.w / 2,
                -obstacle.laser.h / 2,
                obstacle.laser.w,
                obstacle.laser.h
            );
            ctx.strokeRect(
                -obstacle.laser.w / 2,
                -obstacle.laser.h / 2,
                obstacle.laser.w,
                obstacle.laser.h
            );
            ctx.rotate((-obstacle.angle * Math.PI) / 180);
            ctx.translate(-pos.x, -pos.y);
            ctx.closePath();
            ctx.fillStyle = backgroundColor;
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, obstacle.r, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = 'red';
            ctx.lineWidth = 7.5;
            ctx.beginPath();
            ctx.arc(
                pos.x,
                pos.y,
                Math.max(obstacle.r - 15, 0),
                0,
                Math.PI * 2
            );
            ctx.stroke();
        } else if(obstype === 'circle-turret-sentry') {
            ctx.translate(pos.x, pos.y);
            ctx.rotate(obstacle.angle-Math.PI/2);
            ctx.fillStyle = '#053564';
            ctx.lineWidth = lineWidth * 2;
            ctx.strokeStyle = 'black';
            ctx.globalAlpha = 0.5;
            ctx.fillRect(
                -obstacle.bulletRadius,
                0,
                obstacle.bulletRadius*2,
                obstacle.range
            );
            ctx.globalAlpha = 1;
            ctx.strokeRect(
                -obstacle.bulletRadius,
                0,
                obstacle.bulletRadius*2,
                obstacle.range
            );
            ctx.rotate(-obstacle.angle+Math.PI/2);
            ctx.translate(-pos.x, -pos.y);
            ctx.closePath();
            ctx.fillStyle = backgroundColor;
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, obstacle.r, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#053564';
            ctx.lineWidth = 7.5;
            ctx.beginPath();
            ctx.arc(
                pos.x,
                pos.y,
                Math.max(obstacle.r - 15, 0),
                0,
                Math.PI * 2
            );
            ctx.stroke();
            ctx.closePath();

            ctx.fillStyle = '#053564';
            ctx.strokeStyle = 'black';
            ctx.lineWidth = lineWidth;
            for(let p in obstacle.deadBullets){
                ctx.globalAlpha = obstacle.deadBullets[p].life;
                ctx.beginPath();
                const projpos = offset(obstacle.deadBullets[p].x, obstacle.deadBullets[p].y);
                ctx.arc(projpos.x, projpos.y, obstacle.bulletRadius, 0, Math.PI * 2);
                ctx.fill();
                ctx.stroke();
                ctx.closePath();
                ctx.globalAlpha = 1;
            }
            for(let p in obstacle.bullets){
                ctx.beginPath();
                const projpos = offset(obstacle.bullets[p].x, obstacle.bullets[p].y);
                ctx.arc(projpos.x, projpos.y, obstacle.bulletRadius, 0, Math.PI * 2);
                ctx.fill();
                ctx.stroke()
                ctx.closePath();
            }
        } else if (obstype === 'camera') {
            // ctx.fillStyle = window.safeColor || '#8c8c8c';
            ctx.strokeStyle = '#c2c2c2';
            ctx.lineWidth = 8;
            ctx.beginPath();
            ctx.arc(
                pos.x,
                pos.y,
                Math.max(obstacle.radius - 4, 0),
                0,
                Math.PI * 2
            );
            ctx.stroke();
            ctx.globalAlpha = 1;
            const lightgrad = ctx.createRadialGradient(
                pos.x,
                pos.y,
                obstacle.radius,
                pos.x,
                pos.y,
                obstacle.radius + 10
            );
            // lightgrad.addColorStop(0, `rgba(237, 200, 66, 0.5)`);
            // lightgrad.addColorStop(1, `rgba(237, 200, 66,0)`);
            lightgrad.addColorStop(0, 'rgba(255, 0, 0, 0.75)');
            lightgrad.addColorStop(1, 'rgba(255, 0, 0, 0)');

            ctx.strokeStyle = lightgrad;
            ctx.lineWidth = 15;
            ctx.beginPath();
            ctx.arc(
                pos.x,
                pos.y,
                obstacle.radius + 15 / 2 - 1,
                0,
                Math.PI * 2
            );
            ctx.stroke();
            ctx.fillStyle = '#7c94eb';
            ctx.globalAlpha = 0.5;
            const t = offset(obstacle.triggerX, obstacle.triggerY);
            ctx.fillRect(t.x, t.y, obstacle.triggerW, obstacle.triggerH);
            ctx.globalAlpha = 1;
        } else if (obstype === 'circle-tp') {
            ctx.fillStyle = '#38ab30';
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, obstacle.r, 0, Math.PI * 2);
            ctx.fill();
        } else if (obstype === 'portal') {
            ctx.drawImage(
                window.difficultyImages[obstacle.difficulty],
                pos.x,
                pos.y,
                obstacle.w,
                obstacle.h
            );
            if (obstacle.difficultyNumber != undefined) {
                let markingY =
                    pos.y +
                    obstacle.h * (1 - obstacle.difficultyNumber) +
                    5;
                if (markingY > pos.y + obstacle.h) {
                    markingY = pos.y + obstacle.h;
                }
                if (markingY < pos.y + 5) {
                    markingY = pos.y + 5;
                }
                ctx.translate(pos.x, markingY);
                ctx.fillStyle = 'black';
                ctx.fillRect(0, -5, obstacle.w / 5, 5);
                ctx.translate(-pos.x, -markingY);
            }
            ctx.globalAlpha = 1;
            ctx.font = `${obstacle.w / 3.5}px Inter`;
            ctx.fillStyle = 'white';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            if (!window.dontRenderPortalName) {
                ctx.fillText(
                    obstacle.acronym,
                    pos.x + obstacle.w / 2,
                    pos.y - obstacle.h / 4
                );
            }
        } else if (obstype === 'rotate-tp') {
            ctx.fillStyle = '#38ab30';
            const center = {
                x: pos.x,
                y: pos.y,
            };
            ctx.translate(center.x, center.y);
            ctx.rotate(degToRad(obstacle.angle));
            ctx.beginPath();
            ctx.rect(
                -obstacle.w / 2,
                -obstacle.h / 2,
                obstacle.w,
                obstacle.h
            );
            ctx.fill();
            ctx.rotate(-degToRad(obstacle.angle));
            ctx.translate(-center.x, -center.y);
        } else if (obstype === 'rotatingsafe') {
            ctx.fillStyle = window.safeColor || '#8c8c8c';
            ctx.globalAlpha = 0.25;
            const center = {
                x: pos.x,
                y: pos.y,
            };
            ctx.translate(center.x, center.y);
            ctx.rotate(degToRad(obstacle.angle));
            ctx.beginPath();
            ctx.rect(
                -obstacle.w / 2,
                -obstacle.h / 2,
                obstacle.w,
                obstacle.h
            );
            ctx.fill();
            ctx.rotate(-degToRad(obstacle.angle));
            ctx.translate(-center.x, -center.y);
            ctx.globalAlpha = 1;
            // ctx.strokeStyle = 'black';
            // ctx.lineWidth = 1;
            // ctx.stroke()
        } else if (
            obstype === 'rotate-pause-lava' ||
            obstype === 'rotate-lava'
        ) {
            ctx.fillStyle = '#c70000';
            if (!obstacle.canCollide) {
                ctx.fillStyle = '#9e0000';
            }
            const center = {
                x: pos.x,
                y: pos.y,
            };
            ctx.translate(center.x, center.y);
            ctx.rotate(degToRad(obstacle.angle));
            ctx.beginPath();
            ctx.rect(
                -obstacle.w / 2,
                -obstacle.h / 2,
                obstacle.w,
                obstacle.h
            );
            ctx.fill();
            ctx.strokeStyle = 'black';
            ctx.lineWidth = lineWidth;
            ctx.stroke();
            ctx.rotate(-degToRad(obstacle.angle));
            ctx.translate(-center.x, -center.y);
            const oldX = obstacle.x;
            const oldY = obstacle.y;
            obstacle.x -= obstacle.w / 2;
            obstacle.y -= obstacle.h / 2;
            // const points = [
            // 	rotatePoint(obstacle.x, obstacle.y, obstacle.pivotX, obstacle.pivotY, obstacle.angle, obstacle.distToPivot),
            // 	rotatePoint(obstacle.x + obstacle.w, obstacle.y, obstacle.pivotX, obstacle.pivotY, obstacle.angle, obstacle.distToPivot),
            // 	rotatePoint(obstacle.x + obstacle.w, obstacle.y + obstacle.h, obstacle.pivotX, obstacle.pivotY, obstacle.angle, obstacle.distToPivot),
            // 	rotatePoint(obstacle.x, obstacle.y + obstacle.h, obstacle.pivotX, obstacle.pivotY, obstacle.angle, obstacle.distToPivot),
            // ]
            // if (Math.random() < 0.05) {
            // 	console.log(points)
            // }
            // ctx.beginPath();
            // ctx.fillStyle = 'green';
            // ctx.lineWidth = 5;
            // points.forEach(({x, y}) => {
            // 	ctx.lineTo(offset(x).x, offset(0, y).y);
            // })
            // ctx.stroke()
            // ctx.fill();
            obstacle.x = oldX;
            obstacle.y = oldY;
        } else if (
            obstype === 'rotate-normal' ||
            obstype === 'rotate-pause'
        ) {
            ctx.fillStyle = backgroundColor;
            const center = {
                x: pos.x,
                y: pos.y,
            };
            ctx.translate(center.x, center.y);
            ctx.rotate(degToRad(obstacle.angle));
            ctx.beginPath();
            ctx.rect(
                -obstacle.w / 2,
                -obstacle.h / 2,
                obstacle.w,
                obstacle.h
            );
            ctx.fill();
            ctx.rotate(-degToRad(obstacle.angle));
            ctx.translate(-center.x, -center.y);
        } else {
            if (obstype === 'rotatingspeedtrap') {
                const center = {
                    x: pos.x,
                    y: pos.y,
                };
                ctx.translate(center.x, center.y);
                ctx.rotate(degToRad(obstacle.angle));
                ctx.beginPath();
                ctx.rect(
                    -obstacle.w / 2,
                    -obstacle.h / 2,
                    obstacle.w,
                    obstacle.h
                );
                ctx.fill();
                ctx.strokeStyle = 'black';
                ctx.lineWidth = lineWidth;
                ctx.stroke();
                ctx.rotate(-degToRad(obstacle.angle));
                ctx.translate(-center.x, -center.y);
                if (
                    obstacle.tpx != undefined &&
                    obstacle.tpy != undefined
                ) {
                    ctx.strokeStyle = 'green';
                    ctx.globalAlpha = 1;
                    ctx.lineWidth = lineWidth;
                }
                ctx.stroke();
                ctx.globalAlpha = 0;
            }
            ctx.beginPath();
            if (obstype === 'grav' || obstype === 'switchgrav') {
                ctx.globalAlpha = 0.1;
            } else if (obstype === 'platformer') {
                ctx.globalAlpha = 0.3;
            }
            /*if (obstype === 'move') {
                ctx.fillStyle = "#1f1b1b";
    }*/
            if (showPos) {
                ctx.globalAlpha = ctx.globalAlpha * 0.6;
            }
            // IMPORTANT RECTANLGE

            // if (obstype === 'normal') {
            // 	ctx.fillStyle = backgroundPattern;
            // 	ctx.translate(-pos.x, -pos.y);
            // 	// ctx.moveTo(camera.x, camera.y)
            // 	ctx.rect(pos.x + pos.x, pos.y + pos.y, obstacle.w, obstacle.h);
            // 	ctx.translate(pos.x, pos.y)
            // 	                // context.moveTo(Math.round(states.camera.x * fov + width / 2 + (a[s].pos.x - states.camera.x) * fov), Math.round(states.camera.y * fov + height / 2 + (a[s].pos.y - states.camera.y) * fov)),
            //             // context.rect(Math.round(states.camera.x * fov + width / 2 + (a[s].pos.x - states.camera.x) * fov), Math.round(states.camera.y * fov + height / 2 + (a[s].pos.y - states.camera.y) * fov), Math.round(a[s].size.x * fov), Math.round(a[s].size.y * fov));

            // } else {
            ctx.rect(pos.x, pos.y, obstacle.w, obstacle.h);
            // }
            ctx.fill();

            ctx.strokeStyle = ctx.fillStyle;
            if (obstype === 'morphbutton' || obstype === 'morphbuttontimed' || obstype === 'morphmovereset') {
                ctx.fillStyle = backgroundColor; //'rgb(12, 12, 12)'//"#c4c4c4"//'#0652cc';
                ctx.globalAlpha = 1;
                if (!obstacle.active) {
                    ctx.globalAlpha = 0.3;
                }
                ctx.fillRect(
                    pos.x + 7.5,
                    pos.y + 7.5,
                    obstacle.w - 15,
                    obstacle.h - 15
                );
                if (obstype === 'morphbuttontimed' && !obstacle.active) {
                    // timer counting down
                    let alpha = ctx.globalAlpha;
                    ctx.globalAlpha = 1;
                    // ctx.fillStyle = '#a229ff';
                    ctx.fillStyle = 'white'
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'middle';
                    ctx.font = '20px Inter';
                    ctx.fillText(Math.round(obstacle.timer),pos.x + obstacle.w / 2, pos.y + obstacle.h / 2)
                    ctx.globalAlpha = alpha;
                }
                if (obstype === 'morphmovereset') {
                    // timer counting down
                    let alpha = ctx.globalAlpha;
                    ctx.globalAlpha = 1;
                    // ctx.fillStyle = '#a229ff';
                    ctx.fillStyle = 'red'
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'middle';
                    ctx.font = '20px Inter';
                    ctx.fillText('!',pos.x + obstacle.w / 2, pos.y + obstacle.h / 2)
                    ctx.globalAlpha = alpha;
                }
            }
            if (obstype === 'pushboxreset') {
                let color = ctx.fillStyle;
                ctx.fillStyle = backgroundColor;
                ctx.globalAlpha = 1;
                 ctx.fillRect(
                    pos.x + 7.5,
                    pos.y + 7.5,
                    obstacle.w - 15,
                    obstacle.h - 15
                );
                 // ctx.globalAlpha = 0.5;
                
                    ctx.lineWidth = lineWidth;
                    ctx.strokeStyle = 'white';
                    ctx.strokeRect(
                        pos.x + 4 + 7.5,
                        pos.y + 4 + 7.5,
                        obstacle.w - 8 - 15,
                        obstacle.h - 8 - 15
                    );
                ctx.globalAlpha = 1;
                ctx.fillStyle = color;
                ctx.strokeStyle = color;
            }
            if (
                obstype === 'button' ||
                obstype === 'enemybutton' ||
                obstype === 'bbutton'
            ) {
                ctx.fillStyle = backgroundColor; //'rgb(12, 12, 12)'//"#c4c4c4"//'#0652cc';
                ctx.globalAlpha = 1;
                if (!obstacle.active) {
                    ctx.globalAlpha = 0.3;
                }
                ctx.fillRect(
                    pos.x + 7.5,
                    pos.y + 7.5,
                    obstacle.w - 15,
                    obstacle.h - 15
                );
                if (obstype === 'enemybutton') {
                    ctx.beginPath();
                    ctx.arc(
                        pos.x + obstacle.w / 2,
                        pos.y + obstacle.h / 2,
                        (obstacle.w + obstacle.h) / 4,
                        0,
                        Math.PI * 2
                    );
                    ctx.fillStyle = 'grey';
                    ctx.fill();
                    ctx.stroke();
                    ctx.closePath();
                }
                if (obstype === 'bbutton') {
                    ctx.globalAlpha = 0.5;
                    ctx.lineWidth = lineWidth;
                    ctx.strokeStyle = 'white';
                    ctx.strokeRect(
                        pos.x + 4 + 7.5,
                        pos.y + 4 + 7.5,
                        obstacle.w - 8 - 15,
                        obstacle.h - 8 - 15
                    );
                    // ctx.globalAlpha = 1;
                    ctx.globalAlpha = 1;
                    if (!obstacle.active) {
                        ctx.globalAlpha = 0.3;
                    }
                    //                ctx.strokeStyle = '#1c1c1c';
                    //                ctx.globalAlpha = 0.8;
                    // ctx.lineWidth = 1 + (lineWidth * 2);
                    // ctx.strokeRect(pos.x - 4, pos.y - 4, obstacle.w + 8, obstacle.h + 8);
                }
                // ctx.globalAlpha = 0.1;
                // ctx.fillRect(pos.x, pos.y, obstacle.w, obstacle.h);
                // ctx.globalAlpha = 1;
                // ctx.globalAlpha = ctx.globalAlpha;
                // ctx.strokeStyle = '#3b83f7';
                // ctx.lineWidth = 5;
                // ctx.strokeRect(pos.x + 2.5, pos.y + 2.5, obstacle.w - 5, obstacle.h - 5)
            }
            if (obstype === 'door') {
                /*ctx.strokeStyle = 'black'//backgroundColor;//'#1c1c1c'
                ctx.lineWidth = 4;*/
                ctx.setLineDash([]);
                ctx.strokeStyle = 'rgb(0, 0, 0)'; //'red'//'#2955cf';
                ctx.lineWidth = lineWidth * 2;
                ctx.globalAlpha = obstacle.active ? 1 : 0.5;
                ctx.strokeRect(pos.x, pos.y, obstacle.w, obstacle.h);
                ctx.globalAlpha = 1;
            }
            if (obstype === 'filter') {
                ctx.filter = 'none';
            }
            if (obstype === 'breakable') {
                ctx.fillStyle = 'black'; //'#1f1f1f';
                ctx.globalAlpha = 0.4 * ctx.globalAlpha;
                // multiply by ratio
                ctx.fillRect(pos.x, pos.y, obstacle.w, obstacle.h);
                ctx.globalAlpha = 1;
            }
            else if (obstype === 'bouncybreakable') {
                ctx.fillStyle = 'black'; //'#1f1f1f';
                ctx.globalAlpha = 0.4 * ctx.globalAlpha;
                // multiply by ratio
                ctx.fillRect(pos.x, pos.y, obstacle.w, obstacle.h);
                ctx.globalAlpha = 1;
            }
            else if (obstype === 'rotatingsafe' || obstype === 'movingsafe') {
                // ctx.strokeStyle = 'black'
                ctx.strokeStyle = ctx.fillStyle;
                ctx.globalAlpha = 1;
            }
            ctx.lineWidth = lineWidth;
            if (obstype === 'movingspeedtrap') {
                if (
                    obstacle.tpx != undefined &&
                    obstacle.tpy != undefined
                ) {
                    ctx.strokeStyle = 'green';
                    ctx.globalAlpha = 1;
                    ctx.lineWidth = lineWidth;
                }
            }
            if (obstype === 'coin') {
                ctx.fillRect(
                    pos.x - 0.5,
                    pos.y - 0.5,
                    obstacle.w + 1,
                    obstacle.h + 1
                );
            }
            if (obstacle.tempActive) {
                ctx.strokeStyle = 'gray';
            }
            if (
                obstacle.type !== 'coin' &&
                obstacle.type !== 'breakable' &&
                obstacle.type !== 'bouncybreakable' &&
                obstacle.type !== 'door' &&
                obstacle.type !== 'rotatingsafe' &&
                obstacle.type !== 'coindoor' &&
                obstacle.type !== 'movingsafe'
            ) {
                // ctx.lineWidth = 2;
                ctx.stroke();
            }
            ctx.globalAlpha = 1;

            if (obstype === 'mark') {
                let mindimension = Math.min(obstacle.w,obstacle.h);
                ctx.drawImage(skull, pos.x, pos.y, mindimension, mindimension);
            } else if(obstype === 'resettimetraps'){
                ctx.globalAlpha = 0.8;
                if(obstacle.lastIntersecting === true){
                    ctx.globalAlpha = 0.25;
                }
                let mindimension = Math.min(obstacle.w,obstacle.h);
                ctx.drawImage(resetimg, pos.x, pos.y, mindimension, mindimension);
            }else if (obstype === 'deadpusher') {
                ctx.globalAlpha = 0.2;
                if (me().dead) {
                    ctx.globalAlpha = 0.8;
                }
                ctx.drawImage(skull, pos.x, pos.y, obstacle.w, obstacle.h);
            }
            if (obstype === 'cure') {
                let mindimension = Math.min(obstacle.w,obstacle.h);
                ctx.drawImage(skull, pos.x, pos.y, mindimension, mindimension);
            }
            if (obstype === 'pushbox') {
                ctx.globalAlpha = 0.1 + (obstacle.weight / 100) * 0.9;
                ctx.lineWidth = 1 + lineWidth * 2;
                ctx.strokeStyle = 'white';
                ctx.strokeRect(
                    pos.x + 4,
                    pos.y + 4,
                    obstacle.w - 8,
                    obstacle.h - 8
                );
                ctx.globalAlpha = 1;
            }
            if (obstype === 'push') {
                ctx.strokeStyle = 'white';
                ctx.lineWidth = lineWidth;
                ctx.globalAlpha = 0.25;
                ctx.beginPath();
                ctx.lineTo(pos.x, pos.y);
                ctx.lineTo(pos.x + obstacle.w, pos.y + obstacle.h);
                ctx.stroke();
                ctx.beginPath();
                ctx.lineTo(pos.x + obstacle.w, pos.y);
                ctx.lineTo(pos.x, pos.y + obstacle.h);
                ctx.stroke();
                ctx.globalAlpha = 1;
                ctx.lineWidth = 3;
                if (obstacle.dir === 'left') {
                    ctx.beginPath();
                    ctx.lineTo(pos.x, pos.y);
                    ctx.lineTo(pos.x, pos.y + obstacle.h);
                    ctx.stroke();
                }
                if (obstacle.dir === 'up') {
                    ctx.beginPath();
                    ctx.lineTo(pos.x, pos.y);
                    ctx.lineTo(pos.x + obstacle.w, pos.y);
                    ctx.stroke();
                }
                if (obstacle.dir === 'right') {
                    ctx.beginPath();
                    ctx.lineTo(pos.x + obstacle.w, pos.y);
                    ctx.lineTo(pos.x + obstacle.w, pos.y + obstacle.h);
                    ctx.stroke();
                }
                if (obstacle.dir === 'down') {
                    ctx.beginPath();
                    ctx.lineTo(pos.x, pos.y + obstacle.h);
                    ctx.lineTo(pos.x + obstacle.w, pos.y + obstacle.h);
                    ctx.stroke();
                }
                // ctx.globalAlpha = 1;
            }
            if (obstype === 'revive') {
                ctx.strokeStyle = '#009307';
                ctx.lineWidth = lineWidth;
                ctx.globalAlpha = 0.2;
                ctx.stroke();
                ctx.strokeStyle = 'black';
                // ctx.lineWidth = 1;
                ctx.globalAlpha = 1;
            }
            if (obstype === 'coindoor') {
                let alpha = obstacle.currentCoins <= 0 ? 0.5 : 1;
                ctx.globalAlpha = alpha;
                ctx.fillStyle = '#d6d611';
                ctx.fillRect(
                    pos.x + obstacle.w / 4,
                    pos.y + obstacle.h / 4,
                    obstacle.w / 2,
                    obstacle.h / 2
                );
                ctx.fillStyle = '#484a00';
                // if (obstacle.currentCoins === 0) {
                //     ctx.fillStyle = 'black';
                // }
                // if (obstacle.currentCoins <= 0) {
                //     ctx.globalAlpha = 0.5;
                // }
                ctx.globalAlpha = 1;
                ctx.font = '20px Inter';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillText(
                    obstacle.currentCoins,
                    pos.x + obstacle.w / 2,
                    pos.y + obstacle.h / 2
                );
                ctx.globalAlpha = 1;
            }
            if (obstype === 'mirror') {
                ctx.globalAlpha = 0.2;
                ctx.fillStyle = 'black';
                ctx.fillRect(
                    pos.x + obstacle.offset.x,
                    pos.y + obstacle.offset.y,
                    obstacle.w,
                    obstacle.h
                );
                ctx.globalAlpha = 1;
            }
            if (obstype === 'spring') {
                ctx.strokeStyle = 'white';
                for (let i in obstacle.springs) {
                    ctx.beginPath();
                    const spring = obstacle.springs[i];
                    ctx.globalAlpha = Math.min(spring.strength / 500, 0.4); // max 200
                    let spos = offset(spring.x+obstacle.w/2, spring.y+obstacle.h/2);
                    ctx.moveTo(spos.x, spos.y);
                    ctx.lineTo(
                        pos.x + obstacle.w / 2,
                        pos.y + obstacle.h / 2
                    );
                    ctx.stroke();
                    ctx.closePath();
                }
                ctx.globalAlpha = 1;
            }
            if (obstype === 'redirect' || obstype === 'iframeplayer') {
                ctx.globalAlpha = 1;
                if(obstype === 'redirect'){
                    ctx.fillStyle = 'grey';
                } else {
                    ctx.fillStyle = '#802ea3';
                    if(obstacle.active){
                        ctx.globalAlpha = 0.3;
                    }
                }
                
                //let tsize = Math.min(obstacle.width, obstacle.height);
                ctx.font = '30px Inter';//`${tsize}px Inter`;
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillText(
                    '?',
                    pos.x + obstacle.w / 2,
                    pos.y + obstacle.h / 2
                );
                //ctx.globalAlpha = 1;
            }
            if (
                obstype === 'draw' &&
                obstacle.lastObsPos !== undefined &&
                obstacle.touchingPlayer
            ) {
                ctx.globalAlpha = 1;
                ctx.lineWidth = 8;
                ctx.strokeStyle = '#262626'; //'#440261';
                ctx.beginPath();
                let drawOffset = offset(
                    obstacle.lastObsPos[0],
                    obstacle.lastObsPos[1]
                );
                ctx.moveTo(drawOffset.x, drawOffset.y);
                ctx.lineTo(canvas.width / 2, canvas.height / 2);
                ctx.stroke();
                ctx.lineWidth = 1;
                /*ctx.setLineDash([15, 80]);
                ctx.lineDashOffset = -time * 100;
                ctx.strokeStyle = ctx.fillStyle;
                ctx.lineWidth = 2;
                ctx.lineCap = "round";
                ctx.strokeRect(pos.x + 2, pos.y + 2, obstacle.w - 4, obstacle.h - 4)
                ctx.setLineDash([]);*/
            } else if (
                obstype === 'draw' &&
                obstacle.lastObsPos !== undefined &&
                !obstacle.touchingPlayer
            ) {
                obstacle.lastObsPos = undefined;
            }
            /*if (obstype === 'grav' || obstype === 'platformer' || obstype === 'switchgrav') {
                if(obstype === 'switchgrav'){
                    obstacle.force = obstacle.dirs[obstacle.index].force; 
                }
                // this is what happens
                ctx.setLineDash([15, 80]);
                ctx.lineDashOffset = -time * obstacle.force/12;
                ctx.strokeStyle = ctx.fillStyle;
                ctx.lineWidth = 2;
                ctx.lineCap = "round";
                ctx.strokeRect(pos.x + 2, pos.y + 2, obstacle.w - 4, obstacle.h - 4)
                ctx.setLineDash([]);
            }*/
            if (
                (obstype === 'ship' ||
                    obstype === 'gun' ||
                    obstype === 'ampu' ||
                    obstype === 'gupu') &&
                obstacle.w > 0
            ) {
                ctx.setLineDash([15, 40]);
                ctx.lineDashOffset = -time * 150;
                ctx.strokeStyle = ctx.fillStyle;
                ctx.lineWidth = lineWidth;
                ctx.lineCap = 'round';
                ctx.strokeRect(
                    pos.x + 2,
                    pos.y + 2,
                    obstacle.w - 4,
                    obstacle.h - 4
                );
                ctx.setLineDash([]);
            }
            if (obstype === 'playerdraw'){
                ctx.strokeStyle = 'black';
                ctx.lineWidth = 50;
                ctx.lineCap = 'round';
                ctx.lineJoin = 'round';
                ctx.globalAlpha = 1;
                for(let line of obstacle.lines) {
                    if(line[2] < 2){
                        ctx.globalAlpha = line[2]/2;
                    } else {
                        ctx.globalAlpha = 1;
                    }
                    ctx.lineWidth = 49;
                    ctx.beginPath();
                    const firstOffset = offset(line[0][0],line[0][1]);
                    const secondOffset = offset(line[1][0],line[1][1])
                    ctx.moveTo(firstOffset.x, firstOffset.y);
                    ctx.lineTo(secondOffset.x, secondOffset.y);
                    ctx.stroke();
                    ctx.closePath();
                    line[2] -= dt;
                }
                obstacle.lines = obstacle.lines.filter(line => line[2] > 0 && Math.round(line[2]) !== 99);
                ctx.globalAlpha = 1;
                ctx.lineCap = 'butt';
            }
            if (
                obstype === 'fulldeath' &&
                obstacle.w > 0
            ) {
                ctx.globalAlpha = 0.6;
                ctx.setLineDash([15, 40]);
                ctx.lineDashOffset = -time * 150;
                ctx.strokeStyle = 'black';
                ctx.lineWidth = lineWidth;
                ctx.lineCap = 'round';
                ctx.strokeRect(
                    pos.x + 2,
                    pos.y + 2,
                    obstacle.w - 4,
                    obstacle.h - 4
                );
                ctx.setLineDash([]);
                ctx.globalAlpha = 1;
            }
            if (
                obstype === 'lava' ||
                obstype === 'lavamove' ||
                obstype === 'morphlavamove' ||
                obstype === 'growinglava' ||
                obstype == 'move-pause-lava' ||
                obstype === 'switchlava'
            ) {
                // if (obstype === 'switchlava' && !obstacle.state) {
                // 	ctx.globalAlpha = 0.3;
                // }
                ctx.strokeStyle = /*obstacle.state ? '#c70000' : */'black';
                ctx.lineWidth = lineWidth;
                ctx.stroke();
                ctx.globalAlpha = 1;
            }

            if (obstype === 'roundedcorners') {
                ctx.globalAlpha = 1;
                ctx.fillStyle = window.backgroundColor;
                roundedRect(
                    pos.x,
                    pos.y,
                    obstacle.w,
                    obstacle.h,
                    obstacle.roundRadius
                );
            } else if (obstype === 'roundedlava') {
                ctx.globalAlpha = 1;
                ctx.fillStyle = '#c70000';
                roundedRect(
                    pos.x,
                    pos.y,
                    obstacle.w,
                    obstacle.h,
                    obstacle.roundRadius
                );
                ctx.strokeStyle = 'black';
                ctx.lineWidth = lineWidth;
                strokeRoundedRect(
                    pos.x,
                    pos.y,
                    obstacle.w,
                    obstacle.h,
                    obstacle.roundRadius
                );
            }

            if (obstype === 'circlesnap') {
                ctx.globalAlpha = 0.2;
                ctx.setLineDash([15, 40]);
                ctx.lineDashOffset = -time * 20;
                //ctx.arc(pos.x,pos.y,obstacle.radius,0,Math.PI*2);
                //ctx.fill();
                ctx.fillStyle = '#55008a';
                ctx.strokeStyle = 'white';
                ctx.lineWidth = lineWidth;
                //console.log(obstacle.radius);
                // drawing 3 rings :D
                //ctx.beginPath();
                ctx.closePath();
                ctx.beginPath();
                ctx.arc(pos.x, pos.y, obstacle.radius, 0, Math.PI * 2);
                ctx.stroke();
                //ctx.fill();
                ctx.closePath();
                ctx.setLineDash([]);

                /*ctx.beginPath();
                ctx.arc(pos.x,pos.y,obstacle.radius+10,0,Math.PI*2);
                ctx.stroke();
                ctx.closePath();
                
                ctx.beginPath();
                ctx.arc(pos.x,pos.y,obstacle.radius-10,0,Math.PI*2);
                ctx.stroke();*/
                ctx.globalAlpha = 1;
                ctx.lineWidth = lineWidth;
            }

            if (obstype === 'snap') {
                // yes, ik that declaring 2 variables is redundant. I plan to add different snap distances for each axis in the future.
                let loopX = Math.floor(obstacle.w / obstacle.snapDistance);
                let loopY = Math.floor(obstacle.h / obstacle.snapDistance);
                ctx.fillStyle = '#55008a';
                ctx.strokeStyle = 'black';
                ctx.globalAlpha = 0.25;
                if (obstacle.snapX) {
                    for (let x = 0; x < loopX + 1; x++) {
                        ctx.strokeRect(
                            -5 + pos.x + x * obstacle.snapDistance,
                            -5 + pos.y,
                            10,
                            obstacle.h + 10
                        );
                    }
                }
                if (obstacle.snapY) {
                    for (let y = 0; y < loopY + 1; y++) {
                        ctx.strokeRect(
                            -5 + pos.x,
                            -5 + pos.y + y * obstacle.snapDistance,
                            obstacle.w + 10,
                            10
                        );
                    }
                }
                ctx.globalAlpha = 1;
            }

            if (obstype === 'ttbutton' && obstacle.active) {
                ctx.fillStyle = 'red';
                ctx.font = `${obstacle.w / 2}px Inter`;
                ctx.textBaseline = 'middle';
                ctx.textAlign = 'center';
                ctx.strokeStyle = 'black';
                ctx.lineWidth = 1;
                ctx.globalAlpha = 0.6;
                ctx.fillText(
                    Math.floor(obstacle.timer),
                    pos.x + obstacle.w / 2,
                    pos.y + obstacle.h / 2
                );
            }

            if (obstype === 'crowdbutton' && obstacle.playersOn) {
                ctx.fillStyle = 'blue';
                ctx.font = `${obstacle.w / 2}px Inter`;
                ctx.textBaseline = 'middle';
                ctx.textAlign = 'center';
                ctx.strokeStyle = 'black';
                ctx.lineWidth = 1;
                ctx.globalAlpha = 0.8;
                if (!obstacle.active) {
                    ctx.fillText(
                        obstacle.playersOn + `/` + obstacle.minPlayers,
                        pos.x + obstacle.w / 2,
                        pos.y + obstacle.h / 2
                    );
                } else {
                    ctx.font = `${obstacle.w / 4}px Inter`;
                    ctx.fillStyle = 'red';
                    ctx.fillText(
                        'Active!',
                        pos.x + obstacle.w / 2,
                        pos.y + obstacle.h / 2
                    );
                }
            }
            /*else if ((obstacle.type.includes('door') || obstacle.type.includes('button')) &&  obstacle.type != 'coindoor') {
                // all rectangular buttons and doors
                ctx.fillStyle = 'white';
                ctx.font = `${obstacle.w/2}px Inter`;
                ctx.textBaseline = 'middle';
                ctx.textAlign = 'center';
                ctx.strokeStyle = 'black';
                ctx.lineWidth = 1;
                ctx.globalAlpha = 0.3;
                ctx.fillText(obstacle.id,pos.x+obstacle.w/2,pos.y+obstacle.h/2);
                ctx.globalAlpha = 1;
            }*/
        }
        if (showPos === true) {
            let old = ctx.fillStyle;
            ctx.fillStyle = 'white';
            ctx.font = '50px Inter';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            if (obstacle.w != undefined && obstacle.h != undefined) {
                ctx.fillText(i, pos.x + obstacle.w / 2, pos.y + obstacle.h / 2);
            }
            if (obstacle.r != undefined || obstacle.radius != undefined) {
                ctx.fillText(i, pos.x, pos.y);
            }
            ctx.fillStyle = old;
        }
    }

    if (holes.length > 0) {
        for (const hole in holes) {
            // eventually will check for type once more holes exist
            const h = obstacles[hole];
            const off = offset(h.x, h.y);
            ctx.globalAlpha = 0.5;
            ctx.fillStyle = window.tileColor;
            ctx.fillRect(off.x, off.y, h.w, h.h);
        }
        ctx.globalAlpha = 1;
    }
    // ctx.beginPath();
    // ctx.globalAlpha = 1;
    // ctx.fillStyle = 'red';
    // ctx.arc((1-1/window.renderScale)*canvas.width/2,(1-1/window.renderScale)*canvas.height/2,100,0,Math.PI*2);
    // ctx.fill();
    // ctx.closePath();
}

function renderGhostPushers(pushers) {
    // TODO: culling
    for (let obstacle of pushers) {
        if (obstacle.playerId === me().id) {
            continue;
        }
        ctx.fillStyle = window.backgroundColor;
        ctx.globalAlpha = window.ghostOpaq;
        const pos = offset(obstacle.x, obstacle.y);
        //ctx.fillStyle = 'black';
        ctx.fillRect(pos.x, pos.y, obstacle.w, obstacle.h);
        if (obstacle.type === 'push') {
            ctx.strokeStyle = 'white';
            ctx.lineWidth = window.lineWidth;
            ctx.globalAlpha = window.ghostOpaq / 2;
            ctx.beginPath();
            ctx.lineTo(pos.x, pos.y);
            ctx.lineTo(pos.x + obstacle.w, pos.y + obstacle.h);
            ctx.stroke();
            ctx.beginPath();
            ctx.lineTo(pos.x + obstacle.w, pos.y);
            ctx.lineTo(pos.x, pos.y + obstacle.h);
            ctx.stroke();
            ctx.globalAlpha = window.ghostOpaq;
            ctx.lineWidth = 3;
            if (obstacle.dir === 'left') {
                ctx.beginPath();
                ctx.lineTo(pos.x, pos.y);
                ctx.lineTo(pos.x, pos.y + obstacle.h);
                ctx.stroke();
            }
            if (obstacle.dir === 'up') {
                ctx.beginPath();
                ctx.lineTo(pos.x, pos.y);
                ctx.lineTo(pos.x + obstacle.w, pos.y);
                ctx.stroke();
            }
            if (obstacle.dir === 'right') {
                ctx.beginPath();
                ctx.lineTo(pos.x + obstacle.w, pos.y);
                ctx.lineTo(pos.x + obstacle.w, pos.y + obstacle.h);
                ctx.stroke();
            }
            if (obstacle.dir === 'down') {
                ctx.beginPath();
                ctx.lineTo(pos.x, pos.y + obstacle.h);
                ctx.lineTo(pos.x + obstacle.w, pos.y + obstacle.h);
                ctx.stroke();
            }
        } else if (obstacle.type === 'pushbox') {
            ctx.globalAlpha = window.ghostOpaq / 2;
            ctx.lineWidth = 1 + lineWidth * 2; // it doesnt account for weight here
            ctx.strokeStyle = 'white';
            ctx.strokeRect(
                pos.x + 4,
                pos.y + 4,
                obstacle.w - 8,
                obstacle.h - 8
            );
            ctx.globalAlpha = 1;
        } else if(obstacle.type === 'circularpushbox'){
            ctx.globalAlpha = window.ghostOpaq / 2;
            ctx.fillStyle = backgroundColor;
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, obstacle.r, 0, Math.PI * 2);
            ctx.fill()
			// ye just comment it check disc after
            // ctx.globalAlpha = (0.1 + (obstacle.weight / 100) * 0.9) * window.ghostOpaq / 2;
            ctx.lineWidth = 1 + lineWidth * 2;
            ctx.strokeStyle = 'white';
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, obstacle.r - 4, 0, Math.PI * 2);
            ctx.stroke();
        }
    }
    ctx.globalAlpha = 1;
}

window.raycastingLines = [];

function computeRaycastingLines(){
    window.raycastingLines = [];
    const rectToLines = ({ x, y, w, h }) => {
        if(x === 0)x=1;
        if(y === 0)y=1;
        return [
            new Line(x, y, x + w, y),
            new Line(x, y + h, x + w, y + h),
            new Line(x, y, x, y + h),
            new Line(x + w, y, x + w, y + h),
        ];
    };
    for(let obstacle of obstacles){
        if(obstacle.inView === false){
            continue;
        }
        if(obstacle.x && obstacle.y && obstacle.w && obstacle.h){
            const lines = rectToLines(obstacle);
            for(let line of lines){
                window.raycastingLines.push(line);
            }
        }
    }
    const mapLines = [
        rectToLines({ x: 0, y: -1, w: arena.width, h: 1 }),
        rectToLines({ x: -1, y: 0, w: 1, h: arena.height }),
        rectToLines({ x: 0, y: arena.height, w: arena.width, h: 1 }),
        rectToLines({ x: arena.width, y: 0, w: 1, h: arena.height }),
    ];
    for(let border of mapLines){
        for(let line of border){
            window.raycastingLines.push(line);
        }
    }
}

const raycastingViewAngle = 120;
function renderRaycasting(player) {
    if (!player.rays) {
        player.rays = [];
        for (let i = 0; i <= canvas.width; i+=5) {
            // i is angle to player. Should be -75 to 75
            player.rays.push(new Ray3d((i/(canvas.width)-1/2)*raycastingViewAngle));
        }
    }

    let rectstodraw = [];
    ctx.fillStyle = 'black';
    ctx.globalAlpha = 1;
    for (let i = 0; i < player.rays.length; i++) {
        const intersectiondata = player.rays[i].calculateCollision(player);
        const intersectionPoint = intersectiondata[0];
        const intersectionType = intersectiondata[1];
        if (intersectionPoint != -1) {
            const ratio = canvas.height / 400;
            const height = canvas.height - intersectionPoint * ratio;
            //ctx.fillRect(i/player.rays.length*canvas.width,canvas.height/2-height/2,canvas.width/player.rays.length,height);
            const rectHeight = canvas.height-intersectionPoint;
            rectstodraw.push([
                (i / player.rays.length) * canvas.width,
                canvas.height/2-rectHeight/2,
                canvas.width / player.rays.length,
                rectHeight,
                Math.max(0,(400 - intersectionPoint)/400 - 0.2),
                intersectionType,
                canvas.height / 2 - height / 4,
            ]);
        }
    }
    /*for(let i in player.rays){
        player.rays[i].render2d();
    }*/
    ctx.fillStyle = 'black';
    ctx.globalAlpha = 1;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    while (rectstodraw.length > 0) {
        let re = rectstodraw.shift();
        ctx.globalAlpha = re[4];
        let obstype = re[5];
        if (obstype == 'winpad') {
            ctx.fillStyle = 'hsl(' + Date.now() / 12 + ', 50%, 50%)';
        } else if (obstype == 'lava') {
            ctx.fillStyle = '#c70000';
        } else if (obstype == 'check') {
            ctx.fillStyle = '#0fba09';
            ctx.globalAlpha = Math.min(0.2, ctx.globalAlpha);
        } else if (obstype == 'coin') {
            ctx.fillStyle = 'yellow';
            ctx.globalAlpha = 0.8; //Math.min(0.6, ctx.globalAlpha);
        } else if (obstype == 'tp') {
            ctx.fillStyle = '#38ab30';
        } else if (obstype == 'breakable') {
            ctx.fillStyle = window.backgroundColor;
            ctx.globalAlpha /= 2;
        } else if (obstype == 'coindoor') {
            ctx.fillStyle = window.backgroundColor;
            ctx.globalAlpha *= 0.8;
        } else {
            ctx.fillStyle = window.tileColor; //'white';
        }
        ctx.fillRect(re[0], re[1], re[2], re[3] / 2 + canvas.height / 2);
        if (obstype == 'breakable') {
            ctx.fillStyle = 'black'; //'#1f1f1f';
            ctx.globalAlpha *= 0.4;
            ctx.fillRect(re[0], re[1], re[2], re[3]);
        } else if (obstype == 'coindoor') {
            ctx.fillStyle = 'yellow'; //'#1f1f1f';
            ctx.globalAlpha *= 2;
            ctx.fillRect(re[0], re[6], re[2], re[3] / 2);
            // add coins prop?
        }
        ctx.globalAlpha = 1;
    }
}
class Ray3d {
    constructor(angle) {
        this.angle = (angle * Math.PI) / 180;
    }
    calculateCollision(player) {
        const data = this.checkCollision(player);
        if (data !== false){
            return data;
        }
        // return distance and obstacle type
        // for (let i = this.pointsDistance; i < 400; i += this.pointsDistance) {
        //     const x = player.x + Math.cos(this.angle) * i;
        //     const y = player.y + Math.sin(this.angle) * i;
        //     const data = this.checkPoint(x, y);
        //     if (data != false) {
        //         /*ctx.beginPath();
        //         ctx.fillStyle = 'blue';
        //         ctx.globalAlpha = 1;
        //         let raypos = offset(x,y);
        //         console.log(raypos);
        //         ctx.arc(raypos.x,raypos.y,30,0,Math.PI*2);
        //         ctx.fill();
        //         ctx.closePath();
        //         ctx.fillStyle = 'black';*/
        //         return [i, data]; // i is distance to wall
        //     }
        // }
        return [-1, 'normal'];
    }
    checkCollision(player){
        const thispt1 = {x: player.x, y: player.y};
        const thispt2 = {x: player.x + Math.cos(this.angle) * 400, y: player.y + Math.sin(this.angle) * 400};

        let minimumDistance = 400;
        let minimumType = null;
        for(let line of window.raycastingLines){
            const intersection = lineLineIntersection(line.start,line.end,thispt1,thispt2);
            // const intersection2 = lineLineIntersection(line.start+0.001,line.end+0.001,thispt1,thispt2)
            // const intersection3 = lineLineIntersection(line.start-0.001,line.end-0.001,thispt1,thispt2)
            if(intersection !== false /*&& intersection2 !== false && intersection3 !== false*/){
                let distance = Math.sqrt((player.x - intersection[0])**2+(player.y - intersection[1])**2)-player.radius;
                //intersection[0], intersection[1]
                const enemyType = this.checkPoint(intersection[0], intersection[1]);
                if(enemyType !== false && distance < minimumDistance){
                    minimumDistance = distance;
                    minimumType = enemyType;
                }
            }
        }
        if(minimumDistance < 400 && minimumType !== null){
            return [minimumDistance, minimumType];   
        }
        return false;
    }
    checkPoint(x, y) {
        for (let i in obstacles) {
            let obj = obstacles[i];
            if (
                obj.x != undefined &&
                obj.y != undefined &&
                obj.w != undefined &&
                obj.h != undefined &&
                (obj.type === 'normal' ||
                    obj.type === 'trans' ||
                    obj.type === 'move' ||
                    obj.type === 'winpad' ||
                    obj.type === 'tp' ||
                    obj.type === 'breakable' ||
                    obj.type === 'check' ||
                    obj.type === 'coindoor' ||
                    (obj.type === 'coin' && obj.collected != true) ||
                    obj.type ===
                        'lava') /*&& (['normal','trans' ,'push','wb','bounce','lava','lavamove','move','wallboost','growing','growinglava','breakable','switchlava','switch','coindoor','cookie'].includes(obj.type))*/
            ) {
                // if all 4 dimensions are there and player is bounded by the obs
                let wall = obj;
                if (
                    x >= wall.x &&
                    y >= wall.y &&
                    x <= wall.x + wall.w &&
                    y <= wall.y + wall.h
                ) {
                    return obj.type;
                }
            }
        }
        return false;
    }
    render2d() {
        ctx.beginPath();
        ctx.globalAlpha = 0.5;
        ctx.strokeStyle = 'white';
        ctx.moveTo(canvas.width / 2, canvas.height / 2);
        ctx.lineTo(
            canvas.width / 2 + Math.cos(this.angle) * 400,
            canvas.height / 2 + Math.sin(this.angle) * 400
        );
        ctx.stroke();
        ctx.strokeStyle = 'black';
        ctx.closePath();
        ctx.globalAlpha = 1;
    }
}

function lineLineIntersection(A,B,C,D) {
    const x1 = A.x;
    const y1 = A.y;
    const x2 = B.x;
    const y2 = B.y;
    const x3 = C.x;
    const y3 = C.y;
    const x4 = D.x;
    const y4 = D.y;

  // Check if none of the lines are of length 0
    if ((x1 === x2 && y1 === y2) || (x3 === x4 && y3 === y4)) {
        return false
    }

    denominator = ((y4 - y3) * (x2 - x1) - (x4 - x3) * (y2 - y1))

  // Lines are parallel
    if (denominator === 0) {
        return false
    }

    let ua = ((x4 - x3) * (y1 - y3) - (y4 - y3) * (x1 - x3)) / denominator
    let ub = ((x2 - x1) * (y1 - y3) - (y2 - y1) * (x1 - x3)) / denominator

  // is the intersection along the segments
    if (ua < 0 || ua > 1 || ub < 0 || ub > 1) {
        return false
    }

  // Return a object with the x and y coordinates of the intersection
    let x = x1 + ua * (x2 - x1)
    let y = y1 + ua * (y2 - y1)

    return [x, y];
}

function renderTimer() {
    if (window.showTimer) {
        ctx.fillStyle = 'black';
        ctx.globalAlpha = 1;
        // ctx.roundRect(canvas.width / 2 - 75, -5, 150, 40, 10).fill();
        ctx.fillStyle = 'white';
        // ctx.font = '25px monospace';
        ctx.font = '25px Inter';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(String(timer).toRenderTime(), canvas.width / 2, -5 + 20);
        ctx.globalAlpha = 1;
    }
}

function renderSafes(safes, state) {
    safes.forEach((e) => e.render(state));
}

function renderNpcs(npcs, player) {
    // already see the issue lol

    npcs.forEach((n) =>
        n.render(Math.sqrt((n.x - player.x) ** 2 + (n.y - player.y) ** 2))
    ); // should work...?
}

const offsetFns = {
    flower: function(e){
        return Math.abs(e.clonesDistance * e.layers);
    },
    flashlight: function(e){
        return e.flSize;
    },
    bomb: function(e){
        return e.bound.w > e.bound.h ? e.bound.w : e.bound.h;
    },
    fire: function(e){
        return e.bound.w > e.bound.h ? e.bound.w : e.bound.h;
    },
    boomerang: function(e){
        return e.bound.w > e.bound.h ? e.bound.w : e.bound.h;
    },
    split: function(e){
        return e.bound.w > e.bound.h ? e.bound.w : e.bound.h;
    },
    tpplayer: function(e){
        return e.bound.w > e.bound.h ? e.bound.w : e.bound.h;
    },
    oval: function(e){
        return Math.max(e.r1, e.r2) - e.radius;
    },
    turret: function(e){
        return e.bound.w > e.bound.h ? e.bound.w : e.bound.h + e.pSpeed*2+e.pRadius;
    },
    // sticky: function(e){
    //     if(e.stickParent === undefined) return 0;
    //     return Math.abs(e.stickParent.x-e.x)+Math.abs(e.stickParent.y-e.y);
    // },
    oscillating: function(e) {
        let maxDistance = 0;
        for(let i = 0; i < e.points.length; i++){
            const distanceX = Math.abs(e.points[i].x-e.x);
            const distanceY = Math.abs(e.points[i].y-e.y);
            if(distanceX > maxDistance){
                maxDistance = distanceX;
            }
            if(distanceY > maxDistance){
                maxDistance = distanceY;
            }
        }
        return maxDistance;
    }
}

function renderEnemy(enemy) {
    enemy.forEach((e) => {
        let pos = offset(e.x, e.y);
        let addOffset = 0;
        if(offsetFns[e.type] !== undefined){
            addOffset = offsetFns[e.type](e);
        }
        let inView =
            pos.x + e.radius + addOffset > (1-1/window.renderScale)*canvas.width/2 &&
            pos.x - e.radius - addOffset < (1+1/window.renderScale)*canvas.width/2 &&
            pos.y + e.radius + addOffset > (1-1/window.renderScale)*canvas.height/2 &&
            pos.y - e.radius - addOffset < (1+1/window.renderScale)*canvas.height/2;
        if (inView === true) {
            e.inView = true;
            debug.rendered++;
            if (e.type === 'shh') {
                ctx.drawImage(
                    window.nothingToSeeHere,
                    pos.x - e.radius,
                    pos.y - e.radius,
                    e.radius * 2,
                    e.radius * 2
                );
            } else {
                e.render();
            }
        } else {
            e.inView = false;
        }
    });
}

function renderTexts(texts, viewingStory) {
	ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    for (const txt of texts) {
		const { x, y, text, size, story, angle } = txt;
		let renderText = '';
		if (!window.canvasText) {
			const pos = offset(x, y);
			
			// todo: add text culling to prevent unnecessary texts
			if (txt.element == undefined) {
		        if (text.includes('{') && text.includes('}')) {
		            // has an object in it
		            let playerProp = text.match(/\{[\s\S]*?\}/g)[0]; // multiple props implementation later?
		            playerProp = playerProp.replaceAll('{', '').replaceAll('}', '');
		            const tx = text.replace(
		                / \{[\s\S]*?\}/g,
		                ` ${eval(playerProp) ?? ''}`
		            );
		            renderText = tx;
		        } else if (story == true) {
		            if (viewingStory == true) {
		                // ctx.fillText(text, 0, 0);
						renderText = text;
		            }
		        } else {
					renderText = text;
				}
				if (renderText === '') continue;
				txt.element = document.createElement('span');
				txt.element.innerText = renderText;
				txt.element.classList.add('gamey-text');
				txt.element.style.fontSize = `${size}px`
				txt.element.style.transform = `rotate(${angle}deg) translateY(-50%) translateX(-50%)`;
				ctx.font = `${size}px Inter`;
				const metrics = ctx.measureText(renderText)
				txt.element.tWidth = 0//metrics.width/2;
				txt.element.tHeight = 0;//metrics.actualBoundingBoxAscent + metrics.actualBoundingBoxDescent;
				txt.element.style.left = Math.round(pos.x - txt.element.tWidth) + 'px';
				txt.element.style.top = Math.round(pos.y - txt.element.tHeight) + 'px';
				txt.element.id = window.performance.now() - Math.random() * 500000000; // (impossible to sync, basically)
				ref.textLayer.appendChild(txt.element); 
				continue;
			} else {
				const x = (Math.round(pos.x - txt.element.tWidth)+(1-1/window.renderScale)*canvas.width) + 'px';
				const y = (Math.round(pos.y - txt.element.tHeight)+(1-1/window.renderScale)*canvas.height) + 'px';
				if (txt.element.style.left !== x) {
					console.log(txt.element.style.left, x)
					txt.element.style.left = x;
				}
				if (txt.element.style.top !== y) {
					txt.element.style.top = y;
				}
				let inHtml = false;
				for (const elem of Object.values(ref.textLayer)) {
					if (elem.id === txt.element.id) {
						inHtml = true;
						continue;
					}
				}
				if (!inHtml) {
					ref.textLayer.appendChild(txt.element); 
				}
			}
			continue;
		}
        const pos = offset(x, y);
        ctx.font = `${size}px Inter`;
        ctx.fillStyle = 'white';
        // const w = ctx.measureText(text).width;
        // const h = ctx.measureText(text).height;
        ctx.translate(pos.x, pos.y);
        ctx.rotate(degToRad(angle));
        ctx.shadowColor = ctx.fillStyle;
        ctx.shadowBlur = 0;
		
        if (text.includes('{') && text.includes('}')) {
            // has an object in it
            let playerProp = text.match(/\{[\s\S]*?\}/g)[0]; // multiple props implementation later?
            playerProp = playerProp.replaceAll('{', '').replaceAll('}', '');
            const tx = text.replace(
                / \{[\s\S]*?\}/g,
                ` ${eval(playerProp) ?? ''}`
            );
            renderText = tx;
        } else if (story == true) {
            if (viewingStory == true) {
                // ctx.fillText(text, 0, 0);
				renderText = text;
            }
        } else {
			renderText = text;
		}
		if (renderText != '') {
            ctx.fillText(renderText, 0, 0);
        }
        ctx.shadowBlur = 0;
        ctx.rotate(-degToRad(angle));
        ctx.translate(-pos.x, -pos.y);
    }
}

let tileImgs = {};

function createTileImg(scale, thicc) {
    const tileSize = 50;
    // const size =
    //     Math.round(Math.max(canvas.width, canvas.height) / tileSize) *
    //         tileSize +
    //     200;
    const canv = document.createElement('canvas');
    if(scale < 0.1){
        return canv;
    }
    
    const w = canvas.width/scale + tileSize;
    const h = canvas.height/scale + tileSize;
    
    const cx = canv.getContext('2d');
    canv.width = w//size / scale;
    canv.height = h//size / scale;
    cx.imageSmoothingEnabled = false;

    // tile background
    cx.globalAlpha = 0.75;
    cx.strokeStyle = backgroundColor;
    cx.lineWidth = thicc ? 4 : 2;
    for (let y = 0; y <= h; y += tileSize) {
        for (let x = 0; x <= w; x += tileSize) {
            cx.strokeRect(x, y, tileSize, tileSize);
        }
    }
    cx.globalAlpha = 1;
    return canv;
}

function renderTiles(arena, camera) {
    if (window.scaleChanged) {
        tileImgs = {};
        window.leftConveyorImage = generateConveyorImage(
            window.leftArrowImage,
            canvas
        );
        window.rightConveyorImage = generateConveyorImage(
            window.rightArrowImage,
            canvas
        );
        window.downConveyorImage = generateConveyorImage(
            window.downArrowImage,
            canvas
        );
        window.upConveyorImage = generateConveyorImage(window.upArrowImage, canvas);
        window.scaleChanged = false;
    }
    if (tileImgs[backgroundColor] === undefined || window.scaleChanged) {
        tileImgs[backgroundColor] = createTileImg(window.renderScale, window.renderScale < 0.4);
    }
    // render the image
    // draw it at the top left of the screen - some offset
    const img = tileImgs[backgroundColor];
    const pos = offset(camera.x, camera.y);
    const gridOffset = offset(-(1-1/window.renderScale)*canvas.width/2,-(1-1/window.renderScale)*canvas.height/2);
    //ctx.translate(pos.x , pos.y + (gridOffset.y % 50));
    ctx.drawImage(img, (1-1/window.renderScale)*canvas.width/2 + ((gridOffset.x/* + pos.x*/) % 50), (1-1/window.renderScale)*canvas.height/2 + ((gridOffset.y/* + pos.y*/) % 50));
    //ctx.translate(-pos.x - (gridOffset.x % 50), -pos.y - (gridOffset.y % 50));
}

function renderArena(arena) {
    ctx.fillStyle = window.tileColor; //#323645
    const pos = offset(0, 0);

    ctx.shadowColor = 'white';
    // ctx.shadowBlur = 10;
    ctx.strokeStyle = 'white';
    ctx.lineWidth = 4;
    ctx.fillRect(pos.x, pos.y, arena.width, arena.height);

    // ctx.fillStyle = "#323645";
    // ctx.fillRect(pos.x, pos.y, arena.width, 1500);

    // ctx.fillStyle = "#856a6a";
    // ctx.fillRect(pos.x, 1500 + pos.y, arena.width, 1500);

    // ctx.fillStyle = "#6e603c";
    // ctx.fillRect(pos.x, 3000 + pos.y, arena.width, 1000);

    // ctx.fillStyle = "#804949";
    // ctx.fillRect(pos.x, 4000 + pos.y, arena.width, 2000);

    // ctx.fillStyle = "#a63f3f";
    // ctx.fillRect(pos.x, 6000 + pos.y, arena.width, 1000);

    // ctx.fillStyle = "#872424";
    // ctx.fillRect(pos.x, 7000 + pos.y, arena.width, 1000);

    // ctx.fillStyle = "#541111";
    // ctx.fillRect(pos.x, 8000 + pos.y, arena.width, 1000);
    // ctx.stroke();
    // ctx.shadowBlur = 0;
}

CanvasRenderingContext2D.prototype.roundRect = function (x, y, w, h, r) {
    if (w < 2 * r) r = w / 2;
    if (h < 2 * r) r = h / 2;
    this.beginPath();
    this.moveTo(x + r, y);
    this.arcTo(x + w, y, x + w, y + h, r);
    this.arcTo(x + w, y + h, x, y + h, r);
    this.arcTo(x, y + h, x, y, r);
    this.arcTo(x, y, x + w, y, r);
    this.closePath();
    return this;
};
// lets make this a function? ok that works
String.prototype.toRenderTime = function () {
    /* extend the String by using prototypical inheritance */
    var milliseconds = Math.floor((this - Math.floor(this)) * 100);
    var seconds = Number(this); // don't forget the second param
    var hours = Math.floor(seconds / 3600);
    var minutes = Math.floor((seconds - hours * 3600) / 60);
    seconds = seconds - hours * 3600 - minutes * 60;
    minutes += hours * 60;

    // if (hours   < 10) {hours   = "0"+hours;}
    if (minutes < 10) {
        minutes = '0' + minutes;
    } else {
        minutes = Math.floor(minutes);
    }
    if (seconds < 10) {
        seconds = '0' + Math.floor(seconds);
    } else {
        seconds = Math.floor(seconds);
    }
    if (milliseconds < 10) {
        milliseconds = '0' + Math.floor(milliseconds);
    }

    var time =
        String(minutes) + ':' + String(seconds) + '.' + String(milliseconds);
    return time;
};

function roundedRect(x, y, width, height, radius) {
    ctx.beginPath();
    ctx.moveTo(x, y + radius);
    ctx.lineTo(x, y + height - radius);
    ctx.arcTo(x, y + height, x + radius, y + height, radius);
    ctx.lineTo(x + width - radius, y + height);
    ctx.arcTo(x + width, y + height, x + width, y + height - radius, radius);
    ctx.lineTo(x + width, y + radius);
    ctx.arcTo(x + width, y, x + width - radius, y, radius);
    ctx.lineTo(x + radius, y);
    ctx.arcTo(x, y, x, y + radius, radius);
    ctx.fill();
}

function strokeRoundedRect(x, y, width, height, radius) {
    ctx.beginPath();
    ctx.moveTo(x, y + radius);
    ctx.lineTo(x, y + height - radius);
    ctx.arcTo(x, y + height, x + radius, y + height, radius);
    ctx.lineTo(x + width - radius, y + height);
    ctx.arcTo(x + width, y + height, x + width, y + height - radius, radius);
    ctx.lineTo(x + width, y + radius);
    ctx.arcTo(x + width, y, x + width - radius, y, radius);
    ctx.lineTo(x + radius, y);
    ctx.arcTo(x, y, x, y + radius, radius);
    ctx.stroke();
}

function getCookie(cname) {
    let name = cname + '=';
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(';');
    for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return '';
}

/*function renderFaces(imageData){
    ctx.putImageData(imageData,0,0);
    ctx.setTransform(1,0,0.5,0.5,0,0);
    //renderCubeBG();
    
}

function renderCubeBG(){
    ctx.fillStyle = 'black';
    ctx.fillRect(-canvas.width,0,canvas.width,canvas.height);
    ctx.fillRect(-canvas.width,canvas.height,canvas.width*2,canvas.height*2);
}*/