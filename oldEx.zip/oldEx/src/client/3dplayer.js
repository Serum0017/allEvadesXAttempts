window.trailDifficulty = 'Terrorizing'
class ThreeDPlayer {
	constructor(player, init) {
		Object.assign(this, player);
        let otherFunctions = this.getAllMethodNames(player);
        // dynamically getting all functions
        for(let f of otherFunctions){
            if(!["constructor","__defineGetter__","__defineSetter__","hasOwnProperty","__lookupGetter__","__lookupSetter__","isPrototypeOf","propertyIsEnumerable","toString","valueOf","__proto__","toLocaleString"].includes(f) && this[f] === undefined){
                this[f] = player[f];
            }
        }
        this.body = init.body;
        this.body.castShadow = true;
        this.nameobj = init.nameobj;
        this.body.name = this.id;
        this.body.castShadow = true;
        this.collisionSphere = init.collisionSphere;
        this.threeCollisionSphere = init.threeCollisionSphere;
        this.z = init.z;
        this.zv = init.zv||0;
        this.server.z = this.z;
        this.renderZ = this.z;
        this.touchingGround = false;
        this.jumpForce = init.jumpForce;
        this.threeDgravity = init.threeDgravity||1;
        this.deadMaterial = new THREE.MeshBasicMaterial( { color: 0xff0000 } );
        this.aliveMaterial = new THREE.MeshBasicMaterial( { color: 0x000000 } ) 
        this.body.material = this.aliveMaterial;
	}
    measureText(string, font){
        const ca = document.createElement('canvas');
    	const cxt = ca.getContext('2d');
        cxt.font = font;
        return cxt.measureText(string);
    }
    getAllMethodNames(obj) {
        let methods = [];
        while (obj = Reflect.getPrototypeOf(obj)) {
            let keys = Reflect.ownKeys(obj)
            keys.forEach((k) => methods.push(k));
        }
        return methods;
    }
	respawn() {
		this.xv = 0;
		this.yv = 0;
        this.zv = 0;
		this.dead = false;
        this.body.material = this.aliveMaterial;
	}
	update(delt) {
		if (this.id !== selfId) {
			this.renderX = lerp(this.renderX, this.x, delt);
			this.renderY = lerp(this.renderY, this.y, delt);
            this.renderZ = lerp(this.renderZ, this.z, delt);
            if(this.renderX && this.renderY && this.renderZ){
                this.body.position.x = this.renderX;
                this.body.position.y = this.renderY;
                this.body.position.z = this.renderZ;   
            }
		} else if (this.id === selfId) { 
			this.renderX = this.x;
			this.renderY = this.y;
            this.renderZ = this.z;
		}
        this.nameobj.position.set(this.body.position.x, this.body.position.y+this.radius*1.5+10, this.body.position.z);
		if (Math.abs(this.renderRadius - this.radius) > 0.1) {
			this.renderRadius = lerp(this.renderRadius, this.radius, delt / 2)
		} else {
			this.renderRadius = this.radius;
		}
	}
	setData(pack) {
		if (pack.ping != undefined) {
			this.ping = pack.ping;
		}
		if (this.id !== selfId) {
			if (pack.x != undefined) {
				this.x = pack.x;
                this.body.position.x = pack.x;
			}
			if (pack.y != undefined) {
				this.y = pack.y;
                this.body.position.y = pack.y;
			}
            if (pack.z != undefined) {
				this.z = pack.z;
                this.body.position.z = pack.z;
			}
			if (pack.dead != undefined) {
				this.dead = pack.dead;
                if(this.dead){
                    this.body.material = this.deadMaterial;
                } else {
                    this.body.material = this.aliveMaterial;
                }
			}
            if (pack.powerups != undefined) {
    			this.powerups = pack.powerups;
    		}
            if (pack.bullets != undefined){
				const old = [...this.bullets];
                this.bullets = pack.bullets;
				if (this.bullets.length <= 0) return;
				const bullet = this.bullets[this.bullets.length - 1];
				let unique = true;
				for (const oldBullet of old) {
					if (oldBullet.id === bullet.id) {
						// console.log(oldBullet.id, bullet.id)
						unique = false;
						return;
					}
				}
				
				bullet.x += (debug.ping/1000)*bullet.speed*Math.cos(bullet.angle);
				if (bullet.type === 'pvp') {
					if (bullet.x + bullet.radius >= 1000) {
						bullet.x = (1000 * 2) - bullet.x - bullet.radius * 2
						bullet.angle = Math.atan2(Math.sin(bullet.angle), -Math.cos(bullet.angle))
					} else if (bullet.x - bullet.radius <= 0) {
						bullet.x = (0 * 2) - bullet.x + bullet.radius * 2
						bullet.angle = Math.atan2(Math.sin(bullet.angle), -Math.cos(bullet.angle))
					}
				}
                bullet.y += (debug.ping/1000)*bullet.speed*Math.sin(bullet.angle);
				if (bullet.type === 'pvp') {
					if (bullet.y + bullet.radius >= 1000) {
						bullet.y = (1000 * 2) - bullet.y - bullet.radius * 2;
						bullet.angle = Math.atan2(-Math.sin(bullet.angle), Math.cos(bullet.angle));
					} else if (bullet.y - bullet.radius <= 0) {
						bullet.y = (0 * 2) - bullet.y + bullet.radius * 2;
						bullet.angle = Math.atan2(-Math.sin(bullet.angle), Math.cos(bullet.angle));
					}
				}
				bullet.life -= (debug.ping / 1000);
				// we are missing one
			}
		}
		if (pack.dev != undefined) {
			this.dev = pack.dev;
		}
		if (pack.x != undefined) {
			this.server.x = pack.x;
		}
		if (pack.y != undefined) {
			this.server.y = pack.y;
		}
        if (pack.z != undefined){
            this.server.z = pack.z;
        }
		if (pack.god != undefined) {
			this.god = pack.god;
		}
		if (pack.radius != undefined) {
			this.radius = pack.radius;
		}
        if (pack.ship != undefined) {
			this.ship = pack.ship;
		}
        if(pack.tagged != undefined){
            this.tagged = pack.tagged;
        }
		if (pack.deathchange != undefined && this.id !== me().id) {
			this.deathTimer = pack.deathTimer;
		}
	}
}