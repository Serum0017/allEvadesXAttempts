class Safe {
	constructor(init) {
		this.x = init.x;
		this.y = init.y;
		this.w = init.w;
		this.h = init.h;
        this.renderAbove = init.renderAbove;
	}
	render(state) {
		// render above by default
        if((this.renderAbove == state)){
            ctx.globalAlpha = 0.25;
            ctx.fillStyle = window.safeColor || '#8c8c8c';
            const e = offset(this.x, this.y);
            ctx.fillRect(e.x, e.y, this.w, this.h);
            ctx.globalAlpha = 1;
        }
	}
}