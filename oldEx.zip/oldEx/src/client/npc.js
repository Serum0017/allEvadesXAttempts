class Npc {
    constructor(init) {
        this.x = init.x;
        this.y = init.y;
        this.r = init.r;
        this.dialogue = init.dialogue;
        this.currentDialogue = 0;
        this.lastDist = Infinity;
        this.hat = new Image();
        if (init.hat != undefined) {
            this.hat.src = init.hat; //'/gfx/hats/santa-hat.png';
        }
        this.fade = false;
    }

    render(dist) {
        ctx.fillStyle = 'black';
        ctx.globalAlpha = 1;
        ctx.beginPath();
        const e = offset(this.x, this.y);
        ctx.arc(e.x, e.y, this.r, 0, Math.PI * 2);
        ctx.fill();
        ctx.closePath();

        // hat
        if (this.hat.src != undefined) {
            try {
                ctx.drawImage(
                    this.hat,
                    e.x - (80 * (this.r / 25)) / 2,
                    e.y - (80 * (this.r / 25)) / 2,
                    80 * (this.r / 25),
                    80 * (this.r / 25)
                );
            } catch(e){
                
            }
        }

        ctx.fillStyle = 'white';
        ctx.font = '20px "Inter"';
        if (dist < 200) {
            if (this.fade == false) {
                this.animation = 0;
                this.currentDialogue++;
                if (this.currentDialogue >= this.dialogue.length) {
                    this.currentDialogue = 0;
                }
            }
            this.fade = true;
            ctx.fillStyle = 'white';
            ctx.font = `${18 * ((this.r - 0.5) / 25)}px Inter-Thick`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            if (this.animation < 1) {
                ctx.globalAlpha = this.animation;
                this.animation += 0.05;
            }
            ctx.fillText(
                this.dialogue[this.currentDialogue],
                e.x,
                e.y - this.r - this.r / 2
            );
            ctx.globalAlpha = 1;
            this.lastDist = dist;
        } else if (this.lastDist < 200) {
            this.lastDist = Infinity;
            // we have exited
            this.animation = 0; // fade
        }
        if (dist > 200) {
            if (this.fade == true) {
                this.animation = 0;
            }
            this.fade = false;
            if (this.animation < 1) {
                ctx.fillStyle = 'white';
                ctx.font = `${18 * ((this.r - 0.5) / 25)}px Inter-Thick`;
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.globalAlpha = 1 - this.animation;
                this.animation += 0.05;
                ctx.fillText(
                    this.dialogue[this.currentDialogue],
                    e.x,
                    e.y - this.r - this.r / 2
                );
            } else {
                this.currentDialogue++;
                if (this.currentDialogue >= this.dialogue.length) {
                    this.currentDialogue = 0;
                }
            }
        }
        ctx.globalAlpha = 1;
    }
}
