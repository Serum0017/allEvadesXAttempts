let font;
let scene, renderer, world, camera3D;

window.toRender3D = false;

window.addEventListener('load', () => {
    const loader = new FontLoader();
    const ld = loader.load(
        // resource URL
        './3dfont.json',
    
        // onLoad callback
        function ( f ) {
            font = f;
        },
    );  
});


function init3D(arena, map){
    window.toRender3D = true;
    window.goingToNewWorld = false;
    renderer = new THREE.WebGLRenderer();
	// distinct libarry difference 
	// cannon -> physics, threejs -> for the
	// orthographic camera rendering
	// ideally the settings shoudl allow to change
	// the solver iterations
    world = new CANNON.World();
    world.solver.iterations = 20;// change if things get too laggy
    scene = new THREE.Scene();
    scene.background = new THREE.Color( 0xabaeb1 );
    
    renderer.setSize( window.innerWidth, window.innerHeight );
    // higher res; change if too laggy
    renderer.setPixelRatio(window.devicePixelRatio); // this shoudl be set to the canvas ratio 
	// but on the server side (client render) zerotix awakening
    let ratio = window.innerHeight/window.innerWidth;
    if(map.cameraZoom !== undefined){
        window.cameraZoom = map.cameraZoom;
    }
    camera3D = new THREE.OrthographicCamera( -window.cameraZoom/ratio, window.cameraZoom/ratio, window.cameraZoom, -window.cameraZoom, 0.01, 100000 );
    scene.add( camera3D );
    camera3D.rotation.x = 0;
    camera3D.rotation.z = 0;
    camera3D.position.set(0, 1000, 0); 

    renderer.shadowMap.enabled = true;

    let amblight = new THREE.AmbientLight( 0xffffff, 0.25 );
    scene.add( amblight );

    light = new THREE.DirectionalLight(0xffffff, 0.75);
    light.position.set( 0, 2, 0 );
    light.castShadow = true;
    scene.add( light );
    // light.shadow.mapSize.width = 512;
    // light.shadow.mapSize.height = 512;
    // light.shadow.camera3D.near = 0.5;
    // light.shadow.camera3D.far = 1200;
    
    renderer.domElement.id = '3drenderer';
    document.getElementById('3dcanvasplaceholder').appendChild( renderer.domElement );  
    
    window.in3D = true;
    tileImgs[window.backgroundColor] = create3DTileImg(arena);
    load3DGrid(tileImgs[window.backgroundColor].toDataURL('image/jpeg'),arena,tileImgs[window.backgroundColor]);
}

function remove3Dplayer(id){
    if(players[id] && players[id].body){
        remove3DEntity(players[id].body);
        render3D();
        if(players[id].collisionSphere){
            world.removeBody(players[id].collisionSphere);   
        }
        if(players[id].nameobj){
            scene.remove(players[id].nameobj);
        }
    }
    delete players[id];
}

function remove3DEntity(object) {
    var selectedObject = scene.getObjectByName(object.name);
    scene.remove( selectedObject );
}

function disable3D(){
    document.getElementById('3drenderer').remove();
    window.in3D = false;
    world = {};
    window.toRender3D = false;
    delete me().z;
}

function create3DPlayer(init){
    const geometry = new THREE.SphereGeometry( init.radius, 32, 16 );
    const material = new THREE.MeshStandardMaterial( { color: 0x000000 } );
    const sphere = new THREE.Mesh( geometry, material );
    sphere.position.set(init.x,init.y,init.z);
    sphere.name = init.id;
    sphere.castShadow = true;
    sphere.receiveShadow = false;
    scene.add(sphere);
    
    // parenting so that the player can rotate around the parent
    if(init.id == window.selfId){
        camera3D.position.set(init.x, init.y+1000, init.z);   
        camera3D.lookAt(init.x,init.y,init.z);
        camera3D.rotation.z = 0;
        sphere.add(camera3D);
    }
    
    // for collision
    const playerCollisionSphere = new THREE.Sphere( new THREE.Vector3( init.x, init.y, init.y ), init.radius );
    scene.add( sphere );
    let sphereshape = new CANNON.Sphere(init.radius);
    let collisionSphere = new CANNON.Body({ mass: 1, shape: sphereshape });
    collisionSphere.position.set(init.x, init.y, init.z);
    world.addBody(collisionSphere);

    // name
    init.name = 'Taste The Edge.'//'Serum';
    const textgeometry = new TextGeometry( init.name, {
		font: font,
		size: 20,
		height: 5,
		curveSegments: 12,
		//bevelEnabled: true,
		//bevelThickness: 1,
		//bevelSize: 2,
		//bevelOffset: 0,
		//bevelSegments: 5// ill mess with the settings later
	} );

    textgeometry.computeBoundingBox()
    textgeometry.center();

    const textmaterial = new THREE.MeshBasicMaterial( { color: 0xffffff } );

    const playername = new THREE.Mesh( textgeometry, textmaterial );
    
    scene.add(playername);
    
    return new Player({...init, dimensions: 3, threeCollisionSphere: playerCollisionSphere, collisionSphere: collisionSphere, body: sphere, nameobj: playername});
}

function initObstacles(obstacles){
    const materials = [];
    let i = 0;
    for(let obstacle of obstacles){
        if(obstacle.type === 'normal3D' || obstacle.type === 'lava3D' || obstacle.type === 'winpad3D'){
            const cubegeometry = new THREE.BoxGeometry( obstacle.w, obstacle.h, obstacle.d );
            let cubematerial = null;
            if(obstacle.type === 'lava3D'){
                if(obstacle.collidable){
                    cubematerial = new THREE.MeshStandardMaterial( { color: new THREE.Color(0xc70000) } );
                } else {
                    cubematerial = new THREE.MeshStandardMaterial( { color: new THREE.Color(0x9e0000) } );   
                }
            } else {
                cubematerial = new THREE.MeshStandardMaterial( { color: new THREE.Color(window.backgroundColor) } );  
            }

            // THREE.js
            const cube = new THREE.Mesh( cubegeometry, cubematerial );
            cube.position.set( obstacle.x, obstacle.y, obstacle.z );
            obstacle.body = cube;
            obstacle.collisionMesh = new THREE.Box3(
                new THREE.Vector3(),
                new THREE.Vector3()
            );
            obstacle.collisionMesh.setFromObject(cube);
            scene.add( cube );

            // CANNON.js
            let toAddBody = false;
            if(obstacle.type === 'normal3D'){
                toAddBody = true;
            } else if(obstacle.type === 'lava3D'){
                if(obstacle.collidable){
                    toAddBody = true;
                }
            }
            if(toAddBody){
                // cannon is sus liek this so they have to have half the dimensions of three.js to have the same size
                let colbox = new CANNON.Box(new CANNON.Vec3(obstacle.w/2, obstacle.h/2, obstacle.d/2));
                let boxbody = new CANNON.Body({
                    mass: 1,
                    shape: colbox,
                    type: CANNON.Body.KINEMATIC,
                });
                boxbody.position.set(obstacle.x, obstacle.y, obstacle.z);
                boxbody.fixedRotation = true;
                obstacle.collisionBody = boxbody;
                world.addBody(boxbody);
            }
        }
    }
}

function clamp3D(min,value,max){
    return Math.min(max,Math.max(min,value));
}

function simulate3D(player, arena, obstacles, input, dt, players, enemy, safes, npcs){
    if(!player.body || !player.threeCollisionSphere || !player.collisionSphere){
        return;
    }

    const camera3DSpeed = 0.02;
    
    if(input.cup){
        player.body.rotation.z -= camera3DSpeed;
    }
    if(input.cdown){
        player.body.rotation.z += camera3DSpeed;
    }
    if(input.cleft){
        player.body.rotation.y -= camera3DSpeed;
    }
    if(input.cright){
        player.body.rotation.y += camera3DSpeed;
    }
    player.body.rotation.z = clamp(0.3-Math.PI/2,player.body.rotation.z,-0.3+Math.PI/2);
    if(Math.abs(player.body.rotation.z < 0.3)){
        if(player.body.rotation.z < 0){
            player.body.rotation.z = -0.3;
        } else {
            player.body.rotation.z = 0.3;
        }
    }
    camera3D.lookAt(player.x,player.y,player.z);
    
    // player.nameobj.rotation.w = camera3D.quaternion.w;
    // player.nameobj.rotation.x = camera3D.quaternion.x;
    // player.nameobj.rotation.y = camera3D.quaternion.y;
    // player.nameobj.rotation.z = camera3D.quaternion.z;
    // console.log(camera3D.quaternion);

    if(player.dead){
        return;
    }
    player.input = input;
    const vector = camera3D.getWorldDirection(new THREE.Vector3(player.body.position.x,player.body.position.y,player.body.position.z));
    const theta = Math.atan2(vector.x,vector.z);
	let xspeed = 0;
    let yspeed = -player.threeDgravity;
    let zspeed = 0;
    if(input.right){
        zspeed+=Math.sin(theta)*player.speed;
        xspeed-=Math.cos(theta)*player.speed;
    }
    if(input.left){
        zspeed-=Math.sin(theta)*player.speed;
        xspeed+=Math.cos(theta)*player.speed;
    }
    if(input.up){
        zspeed-=Math.sin(theta-Math.PI/2)*player.speed;
        xspeed+=Math.cos(theta-Math.PI/2)*player.speed;
    }
    if(input.down){
        zspeed-=Math.sin(theta+Math.PI/2)*player.speed;
        xspeed+=Math.cos(theta+Math.PI/2)*player.speed;
    }
    if(input.action){
        if(player.touchingGround){
            player.touchingGround = false;
            player.yv += player.jumpForce;
        }
    }

    if (player.xv == undefined || player.yv == undefined || player.zv == undefined) {
		player.xv = 0;
		player.yv = 0;
        player.zv = 0;
	}

    if(input.shift){
        xspeed /= 2;
        zspeed /= 2;
    }
    
    player.xv += xspeed * dt;
	player.yv += yspeed * dt;
    player.zv += zspeed * dt;
    
    player.xv *= Math.pow(player.fric, dt * 60);
    player.yv *= Math.pow(0.99, dt * 60);
    player.zv *= Math.pow(player.fric, dt * 60);

 //    player.x += player.xv * (60 * dt);
	// player.y += player.yv * (60 * dt);
 //    player.z += player.zv * (60 * dt);

    if(player.y < player.radius){
        player.touchingGround = true;
        player.y = player.radius;
        player.body.position.y = player.radius;
        player.yv = 0;
        yspeed = 0;
    }

    player.x = clamp3D(player.radius,player.x,arena.width-player.radius);
    player.z = clamp3D(player.radius,player.z,arena.height-player.radius);
    
    player.collisionSphere.position.set(player.x, player.y, player.z);

    player.collisionSphere.velocity.set(player.xv * 60,player.yv * 60,player.zv * 60);
    
    player.threeCollisionSphere.center.set(player.x,player.y,player.z);
    // checking for intersection
    for(let obstacle of obstacles){
        if(obstacle.type === 'normal3D' || obstacle.type === 'lava3D' || obstacle.type === 'winpad3D'){
            if(player.threeCollisionSphere.intersectsBox(obstacle.collisionMesh)){
                player.touchingGround = true;
                player.yv = 0;
                if(obstacle.type === 'lava3D'){
                    player.dead = true;
                } else if(obstacle.type === 'winpad3D'){
                    if(!window.goingToNewWorld){
                        // winroom is 2d so we dont need any window.won stuff
                        send({ world: 'Winroom', win: true, time: String(window.timer).toRenderTime() });
                        if (bg.currentTime > 0) {
                            bg.currentTime = 0;
                        }
                        bg.loop = false;
                        //bg.src = '/sounds/victory theme.mp3';
                        bg.loop = true;
                        bg.play();
                        window.won = true;
                        window.goingToNewWorld = true;   
                    }
                }
            }

            // simulation
            if(obstacle.type === 'winpad3D'){
                obstacle.body.material.color.setHSL( Date.now() / 1200, 0.5, 0.5 );
            }
        }
    }

    world.step(dt);
    
    player.x = player.collisionSphere.position.x;
    player.y = player.collisionSphere.position.y;
    player.z = player.collisionSphere.position.z;

    if(player.id === selfId){
        player.body.position.x = player.x;
        player.body.position.y = player.y;
        player.body.position.z = player.z;
    } else {
        player.body.position.x = player.renderX;
        player.body.position.y = player.renderY;
        player.body.position.z = player.renderZ;
    }

    if(player.dead){
        send({dead: true});
        player.body.material = player.deadMaterial;
    } else if(player.body.material === player.deadMaterial){
        player.body.material = player.aliveMaterial;
    }
}

function load3DGrid(url,arena,img){
    const bgLoader = new THREE.TextureLoader();
    bgLoader.load(
        url,
    
        function(texture){
            texture.wrapS = THREE.RepeatWrapping;
            texture.wrapT = THREE.RepeatWrapping;
            texture.repeat.set(arena.width/img.width,arena.height/img.height)
            
            const floorMaterial = new THREE.MeshStandardMaterial( { map: texture, side: THREE.DoubleSide} );
            const floorGeometry = new THREE.PlaneGeometry(arena.width, arena.height, 100, 100);
            const floor = new THREE.Mesh(floorGeometry, floorMaterial);
			
            floor.receiveShadow = true;
            floor.position.x = arena.width/2;
            floor.position.z = arena.height/2;	
			// kk
            floor.rotation.x = Math.PI / 2;
            scene.add(floor);
            render3D();

            // CANNON.js
            let colplane = new CANNON.Box(new CANNON.Vec3(arena.width/2, 1/2, arena.height/2));
            let planebody = new CANNON.Body({ mass: 0, shape: colplane });
            planebody.position.set(arena.width/2, -1, arena.height/2);
            world.addBody(planebody);
        },
        undefined,
        function(err){
            console.log('error loading texture');
        }
    );   
}

let render3D = () => {
    renderer.render( scene, camera3D );
    if(window.in3D){
        requestAnimationFrame(render3D);   
    }
}

function create3DTileImg(arena) {
	const tileSize = 50;
	
	const canv = document.createElement('canvas');
	const cx = canv.getContext('2d');
	canv.width = arena.width;
	canv.height = arena.height;
    cx.imageSmoothingEnabled = false;

    cx.fillStyle = window.tileColor;
    cx.fillRect(0,0,canv.width,canv.height);
	
	// tile background
	cx.globalAlpha = 0.75;
	cx.strokeStyle = window.backgroundColor;
	cx.lineWidth = 2;
	for (let y = 0; y < arena.width; y += tileSize) {
		for (let x = 0; x < arena.height; x += tileSize) {
			cx.strokeRect(x, y, tileSize, tileSize);
		}
	}
	cx.globalAlpha = 1;
	return canv;
}