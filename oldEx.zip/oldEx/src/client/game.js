function loadDifficultyImage(difficulty) {
    window.difficultyImages[difficulty] = new Image();
    window.difficultyImages[difficulty].src = `./gfx/${difficulty}.png`;
}

let leaderboard = undefined;

window.canvas = document.querySelector('.canvas');
window.ctx = canvas.getContext('2d');
ctx.lineJoin = "round";
window.shadowCanvas = document.createElement('canvas');
window.in3D = false;
// shadowCanvas.classList.add('canvas')
window.sctx = shadowCanvas.getContext('2d');

window.rayCanvas = document.createElement('canvas');
window.rctx = rayCanvas.getContext('2d');

window.gunslingerCursors = [];

window.ghostOpaq = 0.25;

window.markers = [];

window.sortedObstacles = {};

window.dimensions = 2;
window.cameraZoom = 400;

window.sortedObstacles = {};

window.hidePlayer = false;

window.totalCoins = 0;

window.simTick = 0;
window.states = {};
window.removeOldStateTime = 0.25;

if (ref.editorFrame) {
    ref.editorFrame._scaleMult = 0.9;
}

window.canvasText = true;

ref.iframeplaceholder.click(function(){
    ref.iframeplaceholder.firstChild.focus();
});

// window.bgImg = new Image();
// window.bgImg.src = './gfx/gameBackground.png';
// window.backgroundPattern = ctx.createPattern(window.bgImg, 'repeat');

// document.body.appendChild(shadowCanvas)

// window.smokeCanvas = document.querySelector('.smokeCanvas')
// window.ctx2 = smokeCanvas.getContext('2d');
// let party = smokemachine(ctx2, [0, 0, 0])
//           // party.start()
//           party.setPreDrawCallback(function(dt){
// 	          party.addSmoke(Math.random() * innerWidth, Math.random() * innerHeight, 5)
//           })
// window.gameScale = 0;
window.scale = resize([
    canvas,
    window.shadowCanvas,
    ref.gui,
    rayCanvas,
    ref.editorFrame,
]);
window.mobile = checkMobile();

window.closeMessages = [];
window.closeIds = [];
window.onmessage = function(e){
    if(e.data === 'enterpress'){
        ref.chatDiv.classList.remove('hidden');
        ref.chat.focus();
        window.chatOpen = true;
        return;   
    }
    for(let i = 0; i < closeMessages.length; i++){
        if(closeMessages[i] === e.data){
            document.getElementById(closeIds[i]).remove();
            var child = e.lastElementChild; 
            closeIds.splice(i,1);
            closeMessages.splice(i,1);
            if(closeMessages.length === 0){
                me().insideIframe = false;
            }
        }
    }
}

function clearIframes() {
    let child = ref.iframeplaceholder.lastElementChild;
    while (child) {
        ref.iframeplaceholder.removeChild(child);
        child = ref.iframeplaceholder.lastElementChild;
    }
    players[selfId].insideIframe = false;
    window.closeMessages = [];
    window.closeIds = [];
    me().insideIframe = false;
}

// submit function
if (mobile) {
    ref.chat.addEventListener('keyup', function (event) {
        event.preventDefault();
        if (event.keyCode === 13) {
            trackKeys(
                { repeat: false, code: 'Enter', type: 'keydown' },
                input,
                true
            );
        }
    });
}
window.useMouse = false;
window.timers = [];

window.muted = []; // muted players

window.shouldRender = false;
window.showHat = true;
// bro what
window.glitchEffects = [];
window.renderGlitch = false;

window.unreadpings = 0;

window.raycastvision = false;

window.videos = [];

window.upArrowImage = new Image();
window.upArrowImage.src = './gfx/upArrow.png';
window.downArrowImage = new Image();
window.downArrowImage.src = './gfx/downArrow.png';
window.leftArrowImage = new Image();
window.leftArrowImage.src = './gfx/leftArrow.png';
window.rightArrowImage = new Image();
window.rightArrowImage.src = './gfx/rightArrow.png';
window.nothingToSeeHere = new Image();
window.nothingToSeeHere.src = './gfx/shh.png';

window.invertUpArrowImage = new Image();
window.invertUpArrowImage.src = './gfx/invertUpArrow.png';
window.invertDownArrowImage = new Image();
window.invertDownArrowImage.src = './gfx/invertDownArrow.png';
window.invertLeftArrowImage = new Image();
window.invertLeftArrowImage.src = './gfx/invertLeftArrow.png';
window.invertRightArrowImage = new Image();
window.invertRightArrowImage.src = './gfx/invertRightArrow.png';

// conveyor images
window.onload = function () {
    window.leftConveyorImage = generateConveyorImage(
        window.leftArrowImage,
        canvas
    );
    window.rightConveyorImage = generateConveyorImage(
        window.rightArrowImage,
        canvas
    );
    window.downConveyorImage = generateConveyorImage(
        window.downArrowImage,
        canvas
    );
    window.upConveyorImage = generateConveyorImage(window.upArrowImage, canvas);
    // window.backgroundPattern = ctx.createPattern(window.bgImg, 'repeat')
}; // hope it works D:
// ok
// still doenst work ;-;

window.skull = new Image();
window.skull.src = './gfx/skull.png';

window.resetimg = new Image();
window.resetimg.src = './gfx/circlereset.png'

window.bouncyImage = new Image();
window.bouncyImage.src = './gfx/bouncyEnemy.png';

window.noiseImage = new Image();
window.noiseImage.src = './gfx/red noise.png';
window.renderNoise = false;

window.difficultyImages = {};
loadDifficultyImage('Peaceful');
loadDifficultyImage('Moderate');
loadDifficultyImage('Difficult');
loadDifficultyImage('Hardcore');
loadDifficultyImage('Exhausting');
loadDifficultyImage('Relentless');
loadDifficultyImage('Agonizing');
loadDifficultyImage('Terrorizing');
loadDifficultyImage('Cataclysmic');
loadDifficultyImage('Grass');

window.scaleChanged = false;

window.recordInputs = false;
window.recordedInputs = [];

window.canvasRotation = 0;

window.runGame = function (data) {
    // this is what happens when the player enters the game

    send({ ping: Date.now() });

    document.querySelector('.grecaptcha-badge').style.display = 'none';
    window.spectating = false;
    window.spectateId = null;
    window.showPos = false;

    window.fps = 60; // example fps
    window.times = [];

    window.showServer = false;
    //   window.speedhack = 1;
    window.loaded = false;
    document.fonts.ready.then(function () {
        console.log(
            'finished loading fonts in ',
            Math.round(window.performance.now()),
            'ms'
        );
        window.loaded = true;
    });

    window.lineWidth = 2;

    window.showMinimap = false;

    window.debug = {
        updateTime: 0,
        updateTimeD: 0,
        renderTime: 0,
        renderTimeD: 0,
        ping: undefined,
        rendered: 0,
        sentTimes: 0,
        sentTimeD: 0,
        fpsDisplay: fps,
        cTests: [0, 0],
        cTestRender: [0, 0],
        frameDisplay: 0,
        serverFps: 0,
    };
    window.backgroundColor = data.bgColor;
    window.tileColor = data.tileColor;
    // window.backgroundColor = '#1f2229';
    // window.tileColor = '#323645';
    // document.body.style.backgroundColor = backgroundColor//'black';
    window.debugMode = false;
    window.showTimer = false;
    window.selfId = data.selfId;
    window.players = {};
    window.enemy = [];
    window.safes = [];
    let npcs = [];
    let texts = [];
	ref.textLayer.innerHTML = ''
    window.obstacles = [];
    window.portals = [];
    window.chatOpen = false;
    window.ior = 1;
    window.iir = 1;
    window.io = 0.5;
    window.vc = { r: 0, g: 0, b: 0 };
    // akeraking test
    window.firstPointX = undefined;
    window.firstPointY = undefined;
    window.obsType = { type: 'normal' };
    window.snapDistance = 25;
    window.resetMusic = false;

    window.secondPointX = 100;
    window.secondPointY = 100;

    const updateRate = 120;
    window.accum = 0;

    window.ghostpushers = {};
    window.mypushers = {};

    let viewingStory = false;

    window.input = {
        down: false,
        left: false,
        up: false,
        right: false,
        shift: false,
        action: false,
        // 3d camera
        cup: false,
        cdown: false,
        cright: false,
        cleft: false,
    };

    window.lockedInput = {};
    
    console.log('initial data', data);

    for (const init of data.players) {
        players[init.id] = new Player(init);
    }

    for (const init of data.texts) {
        texts.push(init);
    }

    for (const init of data.enemy) {
        enemy.push(new Enemy(init));
    }

    for (const init of data.safes) {
        safes.push(new Safe(init));
    }

    for (const init of data.npcs) {
        npcs.push(new Npc(init));
    }

    for (const init of data.obstacles) {
        let obstacle = init;
        if (obstacle.type === 'portal') {
            portals.push(init);
        } else {
            obstacles.push(init);
        }
    }

    sortObstacles(obstacles);

    window.darkness = 0.5;

    window.lighting = 0; //.75;
    window.arena = { width: data.arena.width, height: data.arena.height };
    window.camera = { x: 0, y: 0 };
    window.xoff = 0;
    window.yoff = 0;
    window.mouse = { x: canvas.width / 2, y: canvas.height / 2 };

    window.time = 0;

    // what happens when the player joins the game

    window.cachedOffsetX = 0;
    window.cachedOffsetY = 0;

    // do this every frame
    window.cacheOffset = function () {
        window.cachedOffsetX = - camera.x + canvas.width / 2 + xoff,
        window.cachedOffsetY = - camera.y + canvas.height / 2 + yoff
    }

    window.offset = function (x, y) {
        return {
            x: x + window.cachedOffsetX,// - camera.x + canvas.width / 2 + xoff,
            y: y + window.cachedOffsetY// - camera.y + canvas.height / 2 + yoff,
        };
    };

    window.inverseOffset = function (x, y) {
        return {
            x: x + camera.x - canvas.width / 2 - xoff,
            y: y + camera.y - canvas.height / 2 - yoff,
        };
    };

    window.offsetX = function (x) {
        return offset(x, 0).x;
    };

    window.offsetY = function (y) {
        return offset(0, y).y;
    };

    window.init = true;
    window.timer = 0;
    window.shouldUpdateTimer = false;
    // window.map = data.map;
    window.world = data.world;

    // zone animation stuff
    window.zoneT = 0;
    window.zoneAnim = false;

    window.otherClones = [];

    window.mg1countdownStart = false;
    window.mg1countTimer = 0;

    // computeLines()
    window.scale = resize([
        canvas,
        shadowCanvas,
        ref.gui,
        rayCanvas,
        ref.editorFrame,
    ]);

    ref.chatMessageDiv.addEventListener('mousedown', (e) => {
        e.stopPropagation();
    });

    window.processGameMessage = (data) => {
        //console.log(data)
        if (data.leaderboardChanged) {
            leaderboard = data.playerData; // [ [id, map, name ] ]
            // render on leaderboard
            const maps = leaderboard.map((p) => p[1]);
            let uniqueMaps = {};
            maps.forEach((map, i) => {
                if (uniqueMaps[map] == undefined) {
                    uniqueMaps[map] = [leaderboard[i]];
                } else {
                    uniqueMaps[map].push(leaderboard[i]);
                }
            });
            //console.log(uniqueMaps);
            ref.lb.innerHTML = '';
            for (const map of Object.keys(uniqueMaps)) {
                let playerStr = '';
                for (const [id, _, name, dead, color, zone] of uniqueMaps[
                    map
                ]) {
                    playerStr += `
						<div>
							<span ${
                                dead ? `style="opacity: 0.4;"` : ''
                            }><span class="player-name">${name.safe()}</span> [<span class="player-zone">${zone}</span>]${
                        window.muted.includes(name.safe())
                            ? ' <span style="color: red; font-family: Inter-Thick;">[MUTED]</span>'
                            : ''
                    }</span>
						</div>
					`;
                }
                //console.log('color', uniqueMaps[map][0][4])
                ref.lb.innerHTML += `
					<div class="lb-group">
						<span class="lb-name" style="color: ${uniqueMaps[map][0][4]} !important;">${map}</span>
						<div class="lb-players">
							${playerStr}
						</div>
					</div>
				`;
            }
            window.lastpdata = data.playerData;
            // important for muting/ unmuting idk
        }
        if (data.resetTimer !== undefined) {
            if (!data.resetTimer) {
                if (me().dead) {
                    shouldUpdateTimer = false;
                } else {
                    shouldUpdateTimer = true;
                }
            } else {
                timer = 0;
                shouldUpdateTimer = false;
            }
        }
        if (data.zone != undefined) {
            // new zone animation
            // if (zoneT > 0 && zoneAnim) {
            // 	// oh no
            // 	console.log('oh no whats happening', zoneT, zoneAnim)
            // }
            zoneT = window.performance.now();
            zoneAnim = true;
            // console.log(data.zone, zoneT, zoneAnim)
        }
        if (data.removePlayer) {
            if (window.dimensions === 3) {
                console.log(data.data);
                remove3Dplayer(data.data);
            }
            delete players[data.data];
            if (gunslingerCursors[data.data]) {
                delete gunslingerCursors[data.data];
            }
            if (window.ghostpushers[data.data]) {
                delete window.ghostpushers[data.data];
            }
        }
        if (data.pusher) {
            let obs;
            for (let o of obstacles) {
                if (
                    o.pusherId === data.pusher.pusherId &&
                    (o.type === 'pushbox' || o.type === 'circularpushbox')
                ) {
                    obs = o;
                }
            }
            if (obs !== null) {
                if (!window.ghostpushers[data.pusher.playerId]) {
                    window.ghostpushers[data.pusher.playerId] = {};
                }
                window.ghostpushers[data.pusher.playerId][
                    data.pusher.pusherId
                ] = { ...obs, ...data.pusher };
            }
        }
        if (data.removepusher) {
            if (window.ghostpushers[data.removepusher.playerId]) {
                delete window.ghostpushers[data.removepusher.playerId][
                    data.removepusher.pusherId
                ];
            }
        }
        if (data.drawLine){
            for(let obstacle of obstacles){
                if(obstacle.type === 'playerdraw'){
                    obstacle.lines.push(data.drawLine);
                }
            }
        }
        if (data.tailbite) {
            players[data.id].powerups.dragon.hp--;
            players[data.id].biteAnimTimer = 0.5;
            if (me().id == data.id) {
                if (me().powerups.dragon.hp <= 0) {
                    me().dead = true;
                    send({ dead: true });
                    send({ respawn: true });
                    me().powerups.dragon.state = false;
                    me().powerups.dragon.hp = 10; // max
                    send({ powerups: me().powerups });
                } else {
                    // knockback if it isnt fatal
                    let mouseAngle =
                        (Math.atan2(
                            mouse.y - canvas.height / 2,
                            mouse.x - canvas.width / 2
                        ) +
                            Math.PI / 2) %
                        (Math.PI * 2);
                    me().xv += Math.cos(mouseAngle) * 5;
                    me().yv += Math.sin(mouseAngle) * 5;
                }
            }
        }
        if (data.pong) {
            const last = obstacles.length - 1;
            obstacles[last].x = data.pong.x;
            obstacles[last].y = data.pong.y;
            obstacles[last].xv = data.pong.xv;
            obstacles[last].yv = data.pong.yv;
        }
        if (data.dead) {
            me().dead = true;
            send({ dead: true });
            me().powerups.gun.state = false;
            send({ powerups: me().powerups });
            me().powerups.gunslinger = false;
            send({ gsc: 'clear' });
        }
        if (data.bounce) {
            bouncePlayers(me(), players[data.id], data.effect);
        }
        if (data.renderNoise) {
            window.renderNoise = 1;
        }
        if (data.renderGlitch !== undefined) {
            window.renderGlitch = data.renderGlitch;
        }
        if (data.mg1countdownStart != undefined) {
            mg1countdownStart = true;
            mg1countTimer = data.mg1countdownStart - debug.ping / 1000;
        }
        if (data.killEnemy) {
            enemy[data.id].deadTimer = 3;
        }
        if (data.gsc) {
            if (data.gsc == 'clear') {
                delete gunslingerCursors[data.id];
            } else {
                gunslingerCursors[data.id] = data.gsc;
            }
        }
        if (data.ship !== undefined){
            if(me().id !== data.id){
                players[data.id].ship = data.ship;
            }
        }
        if (data.respawned) {
            me().x = data.x;
            me().y = data.y;
            if (data.z) {
                me().z = data.z;
            }
            if(me().insideIframe){
                clearIframes()
            };
            // nono
            // window.ior = 1;
            // window.iir = 1;
            // window.io = 0.5;
            // me().xv = 0;
            // me().yv = 0;
            me().respawn();
            me().clones = [];
            send({ clonePos: [] });
            me().renderRadius = me().radius / 4;
            camera.x = data.x;
            camera.y = data.y;
            me().isTyping = false;
            me().currentChar = 0;
            if(me().ship !== false){
                send({ship: false});
            }
            me().ship = false;
            me().powerups = {
                inv: 0,
                gun: {
                    state: false,
                    angle: 0,
                    currentCooldown: 0.3,
                    maxCooldown: 0.3,
                    speed: 300,
                    radius: 30,
                    life: 3,
                    type: 'normal',
                },
                dragon: {
                    state: false,
                    hp: 10,
                    angle: 0,
                },
                amogus: false,
                gunslinger: false,
                grapple: {
                    direction: 0,
                    state: false,
                    grappling: false,
                    length: 0,
                    originalLength: 0,
                    x: 0,
                    y: 0,
                },
            };
            for (let o in obstacles) {
                if (obstacles[o].type == 'typing') {
                    obstacles[o].currentChar = 0;
                    obstacles[o].active = true;
                    console.log('xd');
                }
                else if (obstacles[o].type == 'mashing') {
                    obstacles[o].currentNum = 0;
                    obstacles[o].active = true;
                }
                else if(obstacles[o].type === 'iframeplayer'){
                    obstacles[o].active = false;
                }
                else if(obstacles[o].type === 'circle-turret-sentry'){
                    obstacles[o].bullets = [];
                    obstacles[o].deadBullets = [];
                    obstacles[o].range = obstacles[o].bulletSpeed*obstacles[o].bulletLife+obstacles[o].bulletRadius;
                    obstacles[o].timer = obstacles[o].shootSpeed;
                }
            }
            // console.log(`spawned at (${data.x}, ${data.y})`);
        }
        if (data.respawnId !== undefined && players[data.respawnId]) {
            players[data.respawnId].renderRadius =
                players[data.respawnId].radius / 4;
            players[data.respawnId].x = data.teleport.x;
            players[data.respawnId].y = data.teleport.y;
            if (data.teleport.z) {
                players[data.respawnId].z = data.teleport.z;
            }
            players[data.respawnId].renderX = data.teleport.x;
            players[data.respawnId].renderY = data.teleport.y;
            if (data.teleport.z) {
                players[data.respawnId].renderZ = data.teleport.z;
            }
            players[data.respawnId].ship = false;
        }
        if (data.revive) {
            // const totalPing = (data?.revivePing ?? 0) + me().ping / 2;
            // const maxSimTime = simTick - Number(Object.keys(states)[0]);
            // const simTime = Math.min(
            //     Math.floor(totalPing * updateRate),
            //     maxSimTime
            // );
            // // console.log(simTime);
            // const state = states[simTick - simTime];
            // setObjToNext(me(), state.player);
            // obstacles = state.obstacles;
            // simTick -= simTime;
            // runPhysics(simTime / updateRate);
            // me().dead = false;
            // me().clones = [];
            // send({ clonePos: [] });
            // outdated revive system
        }
        if (data.add) {
            if (Array.isArray(data.add)) {
                obstacles.push(...data.add);
            } else {
                obstacles.push(data.add);
            }

            sortObstacles(obstacles);
        }
        /*if(data.crowdbuttons){
            console.log(data.crowdbuttons);
            console.log('cb data');
            for(let i in data.crowdbuttons){
                triggerButtonEffects(data.crowdbuttons[i].id,obstacles);
                for(let j in obstacles){
                    if(obstacles[j].type == 'crowdbutton' && obstacles[j].id == data.crowdbuttons[i].id){
                        obstacles[j].active = true;
                        obstacles[j].timer = data.crowdbuttons[i].timer;
                    }
                }
            }
        }*/
        if (data.del) {
            obstacles.splice(data.del - 1, 1);
        }
        if (data.addenemy) {
            for (const init of data.addenemy) {
                enemy.push(new Enemy(init));
            }
        }
        // .mapChange rn lol
        // k this is bsaically what im gonna do anyawys
        // yea lol just model it after this or
        /*
		
		what im sending to player {
  mapChange: true,
  state: {
    players: [ [Object], [Object] ],
    enemy: [],
    safes: [],
    arena: { width: 1000, height: 1000 },
    texts: [],
    obstacles: [
      [Object], [Object],
      [Object], [Object],
      [Object], [Object],
      [Object]
    ],
    bgColor: '#710505',
    tileColor: '#af0d0d',
    safeColor: undefined
  }
}

*/
        // when come back? lol its almost 10 for me
        //{"arena":{"width":1000,"height":1000},"enemy":[],"safes":[],"spawns":[],"playerSpawn":{"x":50,"y":50},"name":"ZMT","longName":"Zero Map Test","tileColor":"#af0d0d","bgColor":"#710505","difficulty":"Grass","texts":[],"obstacles":[{"x":300,"y":300,"w":200,"h":200,"type":"normal"},{"x":500,"y":600,"w":50,"h":50,"type":"normal"},{"x":200,"y":600,"w":50,"h":200,"type":"normal"},{"x":600,"y":500,"w":200,"h":100,"type":"normal"},{"x":600,"y":150,"w":200,"h":150,"type":"lava"},{"x":300,"y":100,"w":150,"h":50,"type":"lava"},{"x":900,"y":900,"w":100,"h":100,"type":"lava"}]}
        if (data.mapChange != undefined) {
            console.log(data);
            
            // cyu :c
            //console.log(data)
            window.backgroundColor = data.state.bgColor;
            document.body.style.backgroundColor = data.state.bgColor;
            window.tileColor = data.state.tileColor;
            window.safeColor = data.state.safeColor;
            window.lighting = data.state.lighting || 0;
            window.raycastvision = data.state.renderRaycasting || false;
            window.enemy = [];
            window.safes = [];
            npcs = [];
            texts = [];
			ref.textLayer.innerHTML = ''
            window.obstacles = [];
            window.portals = [];
            me().coins = 0;
            for (const init of data.state.texts) {
                texts.push(init);
            }

            for (const init of data.state.enemy) {
                enemy.push(new Enemy(init));
            }

            for (const init of data.state.safes) {
                safes.push(new Safe(init));
            }

            for (const init of data.state.npcs) {
                npcs.push(new Npc(init));
            }

            for (const init of data.state.obstacles) {
                let obstacle = init;
                if (obstacle.type === 'portal') {
                    portals.push(init);
                } else {
                    obstacles.push(init);
                }
            }

            sortObstacles(obstacles);
            // console.log('arena', data.state.arena )

            window.arena = {
                width: data.state.arena.width,
                height: data.state.arena.height,
            };
            if (window.raycastvision || me().raycasting) computeLines();
        }
        if (data.removeduelenemies) {
            enemy.forEach((e, i) => {
                if (e.type === 'accelerating') {
                    enemy.splice(i, 1);
                }
                //console.log('enemy removed: ' + i)
            });
        }
        if (data.removeallenemies) {
            enemy = [];
        }
        if (data.remove) {
            obstacles.pop();
        }
        if (data.replaceAllObstacles) {
            window.obstacles = data.replaceAllObstacles;
        }
        if (data.removeById) {
            obstacles.forEach(function (obs, index) {
                if (
                    obs.id &&
                    obs.id == data.removeById &&
                    obs.id != 'duelsTp2'
                ) {
                    window.obstacles.splice(index, 1);
                }
            });
        }
        if (data.u) {
            // update
            for (const id of Object.keys(data.p)) {
                // console.log(pack.id)
                players[id].setData(data.p[id]);
            }
        }
        if (data.tagged !== undefined) {
            if(data.tagged === true){
                for (const id of Object.keys(players)) {
                    // console.log(pack.id)
                    players[id].tagged = false;
                }
            }
            
            players[data.id].tagged = data.tagged;
            if(data.tagged === true){
                players[data.id].onTagCooldown = true;
                const tagId = data.id;
                setTimeout(() => {
                    delete players[tagId].onTagCooldown;
                }, 300)
            }
        }
        if (data.uc) {
            // update clones
            for (let i of data.clonePos) {
                // for every clone
                if (data.clonePos !== undefined && data.clonePos !== null) {
                    window.otherClones = data.clonePos;
                    //console.log(window.otherClones);
                }
            }
            /*
            for(let i in players){
                send(players[i].id, {
                    uc: true,
                    clonePos: players[i].clones,
                })
                console.log(players.clones);
            }
            */
        }
        if (data.chat) {
            if (!window.muted.includes(data.name)) {
                const div = document.createElement('div');
                if (!data.system) {
                    div.classList.add('chat-message');
                } else {
                    div.classList.add('system-message');
                    if (data.difficulty != undefined) {
                        div.classList.add(data.difficulty.toLowerCase());
                    }
                }
                div.innerHTML = `${
                    data.system
                        ? '<span class="rainbow">[SERVER]</span>'
                        : data.dev
                        ? '<span class="rainbow">[DEV]</span> '
                        : ''
                }${
                    data.guest ? '<span class="guest">' : ''
                }${data.name.safe()}: ${data.msg.safe()}${
                    data.guest ? '</span>' : ''
                }`;
                if (div.innerHTML.includes('@')) {
                    const inds = [];

                    for (let ind = 0; ind < div.innerHTML.length; ind++) {
                        if (div.innerHTML[ind] === '@') {
                            inds.push(ind);
                        }
                    }
                    for (let i in inds) {
                        let mentionIndex = inds[i] + 1;
                        if (
                            div.innerHTML
                                .slice(
                                    mentionIndex,
                                    mentionIndex + me().name.length
                                )
                                .toLowerCase() == me().name.toLowerCase()
                        ) {
                            div.classList.add('mention');
                            unreadpings++;
                        }
                    }
                }
                ref.chatMessageDiv.appendChild(div);
                ref.chatMessageDiv.scrollTop = ref.chatMessageDiv.scrollHeight;
            }
            if (unreadpings > 0) {
                document.title = `Evades X (${unreadpings})`;
                ref.favicon.href = './pings/ping.png';
				playAudio('/pings/ping.mp3')
            }
        }
        if (data.pung != undefined) {
            // dis
            const halfRRT = Math.round((Date.now() - data.pung) / 2);
            if (debug.ping == undefined) {
                // when we get something from server, we send a ping request and then
                // we run physics ahead the ping / 2
                // helps with syncin g a lot so its not too insane
                // acutally it makes u go more out of sync
                // but if u have two tabs open, its very identical
                // like 200 ping vs 0ms its more out of sync
                // leeme test with two tabs first
                let a = halfRRT; // but like why doesn't it work for my case? ;-;
                runPhysics(a);

                // now lets detect if the world we are in is hub, if so, then dont start timer
                if (init) {
                    fade(() => {
                        shouldRender = true;
                        ref.menu.classList.add('hidden');
                        ref.game.classList.remove('hidden');

                        ref.chat.onblur = () => {
                            if (!window.mobile) {
                                chatOpen = false;
                            }
                        };

                        changeMusic(window.hubMusicPath);

                        window.onmousedown = (e) => {
                            if (!ref.editorFrame.classList.contains('hidden')) {
                                ref.editorFrame.blur();
                                ref.editorFrame.classList.add('hidden');
                            } else if (ref.iframeplaceholder.hasChildNodes()) {
                                ref.iframeplaceholder.firstChild.focus();
                                e.stopPropagation();
                            } else {
                                if (
                                    me().boostCooldown &&
                                    me().boostCooldown < 0
                                ) {
                                    const angle =
                                        (Math.atan2(
                                            mouse.y - canvas.height / 2,
                                            mouse.x - canvas.width / 2
                                        ) +
                                            Math.PI / 2) %
                                        (Math.PI * 2);
                                    me().boostCooldown = 1;
                                    me().xv += 6 * Math.sin(angle);
                                    me().yv -= 6 * Math.cos(angle);
                                } else {
                                    if (!window.mobile) {
                                        useMouse = !useMouse;
                                    }
                                    input.up = false;
                                    input.down = false;
                                    input.left = false;
                                    input.right = false;
                                }
                            }
                            // input.shift = false;
                            e.preventDefault();
                        };

                        window.onmousemove = (event) => {
                            if (window.usingController) {
                                return;
                            }
                            const bound = canvas.getBoundingClientRect();
                            mouse.x = Math.round(
                                (event.pageX - bound.left) / scale
                            );
                            mouse.y = Math.round(
                                (event.pageY - bound.top) / scale
                            );
                            // mouse.x = event.pageX;
                            // mouse.y = event.pageY;
                        };
                        window.ontouchmove = (event) => {
                            event.preventDefault();
                            const touch = event.changedTouches[0];
                            const bound = canvas.getBoundingClientRect();
                            // mouse movement
                            mouse.x = Math.round(
                                (touch.pageX - bound.left) / scale
                            );
                            mouse.y = Math.round(
                                (touch.pageY - bound.top) / scale
                            );
                        };
                        if (window.mobile) {
                            window.ontouchstart = (event) =>
                                onTouchStart(event);
                            window.ontouchend = (event) => onTouchEnd(event);
                            // lol ill figure it out eventually
                            /*window.onkeydown = event => function(){
                                alert(window.mobileTyping);
                                if(!window.mobileTyping){
                                    // creating a button to send the msg if u start typing
                                    let btn = document.createElement("button");
                                    btn.innerHTML = "Send Message";
                                    btn.onclick = function () {
                                        window.mobileTyping = false;
                                        trackKeys({repeat: false, code: 'Enter', type: 'keydown'}, input, true);
                                    };
                                    document.querySelector('.chat-div').appendChild(btn);   
                                }
                                window.mobileTyping = true;
                            }*/
                            //ref.chatMessageDiv.onselect = alert('focused')//trackKeys('Enter', input);

                            //window.onkeydown = event => function(){
                            //alert('chat :D');
                            /*if(chatOpen){
                                    alert(event.code);
                                    trackKeys(event, input)   
                                }*/
                            //};
                        } else {
                            window.onkeydown = (event) =>
                                trackKeys(event, input);
                            window.onkeyup = (event) => trackKeys(event, input);
                        }

                        window.onresize = () => {
                            if (
                                window.dimensions === 3 &&
                                camera3D &&
                                renderer
                            ) {
                                const ratio =
                                    window.innerHeight / window.innerWidth;
                                camera3D.left = -window.cameraZoom / ratio;
                                camera3D.right = window.cameraZoom / ratio;
                                camera3D.top = window.cameraZoom;
                                camera3D.bottom = -window.cameraZoom;
                                camera3D.updateProjectionMatrix();
                                renderer.setSize(
                                    window.innerWidth,
                                    window.innerHeight
                                );
                            }
                            window.scale = resize([
                                canvas,
                                shadowCanvas,
                                ref.gui,
                                rayCanvas,
                                ref.editorFrame,
                            ]);
                        };
                    });
                    init = false;
                } else {
                    shouldRender = true;
                }
            }
            debug.ping = halfRRT;
            send({ pingResult: debug.ping });
        }
        if (data.newPlayer) {
            if (window.dimensions === 3) {
                remove3Dplayer(data.data.id);
            } else {
                delete players[data.data.id];
            }
            if (window.dimensions === 3) {
                players[data.data.id] = create3DPlayer({
                    ...data.data,
                    dimensions: 3,
                });
                render3D(arena);
            } else {
                players[data.data.id] = new Player(data.data);
            }
        }
        if (data.world != undefined) {
            window.world = data.world;
            if (data.world === 'Hub') {
                shouldUpdateTimer = false;
                timer = 0;
            } else if (data.world === 'Winroom') {
                shouldUpdateTimer = false;
            } else {
                timer = 0;
                shouldUpdateTimer = true;
            }
        }
        if (data.serverFps != undefined) {
            debug.serverFps = data.serverFps;
        }
        if (data.nw) {
            window.ghostpushers = {};
            window.mypushers = {};
            if (window.dimensions === 3) {
                disable3D();
            }
            if(me().insideIframe){
                clearIframes()
            };
            console.log(data);
            if (data.musicPath != undefined) {
                let volume = globalVolume;
                if (data.musicPath === '/sounds/aiae.mp3') {
                    volume = 0.3;
                }
                changeMusic(data.musicPath ?? '/sounds/drip.mp3', 0, volume);
            }
            // nw -> new world / change
            // data.state = everything
            // fade()
            window.renderScale = 1;
            window.scaleChanged = true;
            window.dimensions = data.state.dimensions || 2;
            window.backgroundColor = data.state.bgColor;
            window.tileColor = data.state.tileColor;
            window.safeColor = data.state.safeColor;
            window.arena = {
                width: data.state.arena.width,
                height: data.state.arena.height,
            };
            if (window.dimensions === 3) {
                init3D(arena, data.state);
                for (const init of data.state.obstacles) {
                    obstacles.push(init);
                }
                
                initObstacles(obstacles);
                for (const init of data.state.players) {
                    remove3Dplayer(init.id);
                    players[init.id] = create3DPlayer(
                        {
                            ...init,
                            dimensions: 3,
                        },
                        data.state.cameraZoom
                    );
                }
                render3D(arena);
            } else {
                createTileImg(1);
                // window.map = data.map;
                // document.body.style.backgroundColor = data.state.bgColor;
                debug.ping = undefined;
                shouldRender = false;
                send({ ping: Date.now() }); // so client can speedup
                // set everything
                selfId = data.state.selfId;
                window.players = {};
                window.enemy = [];
                window.goingToNewWorld = false;
                window.safes = [];
                npcs = [];
				ref.textLayer.innerHTML = ''
                texts = [];
                window.obstacles = [];
                window.portals = [];
                window.lighting = data.state.lighting || 0;
                window.window.raycastvision =
                    data.state.renderRaycasting || false;
                for (const init of data.state.players) {
                    players[init.id] = new Player(init);
                }

                for (const init of data.state.texts) {
                    texts.push(init);
                }

                for (const init of data.state.enemy) {
                    // bug if u go into a portal of the same world ur in then it doesnt make enemies appear ;-;
                    enemy.push(new Enemy(init));
                }

                for (const init of data.state.safes) {
                    safes.push(new Safe(init));
                }

                for (const init of data.state.npcs) {
                    npcs.push(new Npc(init));
                }

                for (const init of data.state.obstacles) {
                    let obstacle = init;
                    if (obstacle.type === 'portal') {
                        portals.push(init);
                    } else {
                        obstacles.push(init);
                    }
                }
                
                if (data.state.addedobstacles != undefined) {
                    for (const init of data.state.addedobstacles) {
                        let obstacle = init;
                        if (obstacle.type === 'portal') {
                            portals.push(init);
                        } else {
                            if (
                                obstacle.type === 'lava' &&
                                obstacle.canCollide != true &&
                                obstacle.canCollide != false
                            ) {
                                init.canCollide = true;
                            }
                            obstacles.push(init);
                        }
                    }
                    
                    /*for(let s = 0; s <= 1000; s++){
    					runObstaclePhysics(data.state.addedobstacles,data.state.mapDelta/1000,me())
    				}*/
                }

                sortObstacles(obstacles);
                window.camera = { x: 0, y: 0 };
                window.xoff = 0;
                window.yoff = 0;
                window.mouse = { x: canvas.width / 2, y: canvas.height / 2 };
                simTick = 0;
                states = {};
                if (window.raycastvision || me().raycasting) computeLines();
                for (const obj of obstacles) {
                    if (obj.type === 'musicchange') {
                        if (audios[obj.musicPath] === undefined) {
                            let volume = globalVolume;
                            if (data.musicPath === '/sounds/aiae.mp3') {
                                volume = 0.3;
                            }
                            console.log(
                                'new map... loading passive audio',
                                obj.musicPath
                            );
                            loadAudio(obj.musicPath, 0, volume);
                        } else {
                            console.log(
                                'already loaded passive audio',
                                obj.musicPath
                            );
                        }
                    } //else if(obj.type === 'bonus' || obj.type === 'circle-bonus'){
                    //     if (audios['/sounds/skill_point.mp3'] === undefined) {
                    //         loadAudio('/sounds/skill_point.mp3', 0, 0.1, '', false);
                    //     }
                    // }
                    else if(obj.type === 'slip'){
                        obj.collidable = false;
                    }
                }
            }
        }
    };

    window.fade = (func = () => {}) => {
        ref.overlay.classList.remove('fade-out');
        ref.overlay.classList.remove('fade-in');
        ref.overlay.classList.remove('hidden');
        ref.overlay.classList.add('fade-in');
        ref.overlay.onanimationend = () => {
            ref.overlay.classList.remove('fade-in');
            ref.overlay.classList.add('fade-out');
            func();
            ref.overlay.onanimationend = () => {
                ref.overlay.classList.add('hidden');
            };
        };
    };

    let lastTime = null;

    let frames = 0;

    function run(/*t = 0*/) {
        const t = window.performance.now();
        fpsTick(t);
        if (lastTime == null) {
            lastTime = t;
        }
        window.delta = t - lastTime;
        window.time += delta / 1000;
        window.delt = get_delta(delta);
        // if (shouldUpdateTimer) {
        //     window.timer += delta / 1000; //* window.speedhack;
        // }
        lastTime = t;
        if (connected) {
            update(delt);
        }
        if (shouldRender && loaded) {
            render();
        }
        if (unreadpings !== 0) {
            document.title = 'Evades X';
            ref.favicon.href = './favicon.png';
        }
        unreadpings = 0;
        // if (document.body.classList.contains('onMenu')) {
        // 	document.body.classList.remove('onMenu')
        // }
        if (
            document.body.style.backgroundColor !== backgroundColor &&
            ref.menu.classList.contains('hidden')
        ) {
            document.body.style.backgroundColor = backgroundColor;
            document.body.classList.remove('onMenu');
        }
		if (document.querySelector('.grecaptcha-badge').style.display != 'none') {
			document.querySelector('.grecaptcha-badge').style.display = 'none';
		}
        requestAnimationFrame(run);
    }
    window.onTab = true;
    document.addEventListener('visibilitychange', function (event) {
        if (document.hidden) {
            onTab = false;
			bg.oldVolume = bg.volume;
			bg.volume = bg.oldVolume / 2;
        } else {
            onTab = true;
			bg.volume = bg.oldVolume ?? bg.volume;
        }
    });

    setInterval(() => {
        if (!onTab) {
            window.delta = window.performance.now() - lastTime;
            lastTime = window.performance.now();
            // if (shouldUpdateTimer) {
            //     window.timer += delta / 1000; // * window.speedhack;
            // }
            if (mg1countdownStart) {
                mg1countTimer -= delta / 1000;
                if (mg1countTimer <= 0) {
                    send({ world: 'PoSR' });
                    mg1countdownStart = false;
                }
            }
            simulateGame();
        }
    }, 1000 / 60);

    setInterval(() => {
        // console.log(`${frames} Simulation Frames`);
        debug.frameDisplay = frames;
        frames = 0;
        debug.updateTimeD = debug.updateTime;
        debug.updateTime = 0;
        debug.renderTimeD = debug.renderTime;
        debug.renderTime = 0;
        debug.sentTimeD = debug.sentTimes;
        debug.sentTimes = 0;
        debug.fpsDisplay = fps;
        debug.cTestRender = [debug.cTests[0], debug.cTests[1]];
        debug.cTests[0] = 0;
        debug.cTests[1] = 0;
        upstreambytesR = upstreambytes;
        downstreambytesR = downstreambytes;
        upstreambytes = 0;
        downstreambytes = 0;
    }, 1000);

    setInterval(() => {
        send({ ping: Date.now() });
    }, 500);

    window.computeLines = function () {
        window.rayLines = [];
        const rectToLines = ({ x, y, w, h }) => {
            return [
                new Line(x, y, x + w, y),
                new Line(x, y + h, x + w, y + h),
                new Line(x, y, x, y + h),
                new Line(x + w, y, x + w, y + h),
            ];
        };
        for (const obj of obstacles) {
            if (obj.type === 'normal') {
                rectToLines(obj).forEach((line) => {
                    rayLines.push(line);
                    rayLines[rayLines.length-1].obj = obj;
                });
            }
            if (obj.type.startsWith('poly')) {
                let lastIndex = obj.points.length - 1;
                obj.points.forEach(([x, y], i) => {
                    rayLines.push(
                        new Line(
                            x,
                            y,
                            obj.points[lastIndex][0],
                            obj.points[lastIndex][1]
                        )
                    );
                    rayLines[rayLines.length-1].obj = obj;
                    lastIndex = i;
                });
            }
        }
        // for (const obj of portals) {
        // 	rectToLines(obj).forEach((line) => {
        // 		rayLines.push(line);
        // 	})
        // }
        const mapLines = [
            rectToLines({ x: 0, y: 0, w: arena.width, h: 1 }),
            rectToLines({ x: 0, y: 0, w: 1, h: arena.height }),
            rectToLines({ x: 0, y: arena.height, w: arena.width, h: 1 }),
            rectToLines({ x: arena.width, y: 0, w: 1, h: arena.height }),
        ];
        mapLines.forEach((lines) => {
            lines.forEach((line) => {
                rayLines.push(line);
                rayLines[rayLines.length-1].obj = {inView: true};
            });
        });
        let points = [];
        rayLines.forEach((line) => {
            points.push(line.start.copy(), line.end.copy());
        });
        let pointSet = {};
        const maxDist = Infinity;
        window.uniqueRayPoints = points.filter((point) => {
            const key = `${point.x},${point.y}`;
            if (key in pointSet) {
                return false; // not unique
            } else if (
                Math.abs(me().renderX - point.x) < maxDist &&
                Math.abs(me().renderY - point.y) < maxDist
            ) {
                pointSet[key] = true;
                return true;
            } else {
                return false;
            }
        });
    };

    function renderGame() {
        // testing iso
        // ctx.setTransform(2,0.5,0,1,-canvas.width/2,-canvas.height/2)
        renderArena(arena);
        if (window.showGrid) {
            renderTiles(arena, camera);
        }
        debug.rendered = 0;

        // ctx.stroke()
		// if (me().zMode) {
		// 	canvas.style.filter = 'saturate(120%)'
		// } else {
		// 	canvas.style.filter = 'none'
		// }
        renderLinks(obstacles);
        renderSafes(safes, false);
        renderEnemy(enemy);

        if (Object.keys(window.ghostpushers).length > 0) {
            for (let playerId of Object.keys(ghostpushers)) {
                // console.log(Object.values(ghostpushers[playerId]));
                renderGhostPushers(Object.values(ghostpushers[playerId]));
            }
        }
        
        renderObstacles(obstacles, window.ghostpushers);
        renderObstacles(portals);
        renderPlayers(players);
        renderSafes(safes, true);
        renderTexts(texts, viewingStory);
        renderNpcs(npcs, me());
        // ctx.strokeStyle = 'black';
        // ctx.lineWidth = 2;
        // for (const line of rayLines) {
        // 	const s = offset(line.start.x, line.start.y);
        // 	const e = offset(line.end.x, line.end.y);
        // 	ctx.beginPath();
        // 	ctx.lineTo(s.x, s.y);
        // 	ctx.lineTo(e.x, e.y);
        // 	ctx.stroke()
        // }
        // ctx.fillStyle = 'red'
        // for (const { x, y } of uniqueRayPoints) {
        // 	ctx.beginPath();
        // 	const pos = offset(x, y);
        // 	ctx.arc(pos.x, pos.y, 5, 0, Math.PI * 2);
        // 	ctx.fill()
        // }
        if (debugMode) {
            ctx.strokeStyle = 'black';
            ctx.lineWidth = 2;
            ctx.beginPath();
            // points.push(points[0])
            for (const { x, y } of points) {
                const pos = offset(x, y);
                ctx.lineTo(pos.x, pos.y);
            }
            ctx.closePath();
            // ctx.fill();
            ctx.globalAlpha = 1;
            ctx.stroke();
        }
        debug.totalRender = [...obstacles, ...portals, ...enemy].length;

        if (me().raycasting) {
            renderRaycasting(me());
        }
        // if (leaderboard !== undefined) {
        // 	drawLeaderboard(leaderboard, players);
        // }
        renderPreview();
        drawOverlay(me(), enemy);
        //renderVideo(players);
        // rendering gunslinger cursors
        if (gunslingerCursors.length > 0) {
            for (let cursor of gunslingerCursors) {
                if (cursor !== undefined && cursor !== null) {
                    if (gunslingerCursors[me().id] != cursor) {
                        const coff = offset(cursor.x, cursor.y);
                        ctx.beginPath();
                        ctx.fillStyle = 'red';
                        ctx.arc(coff.x, coff.y, 20, 0, Math.PI * 2);
                        ctx.fill();
                        ctx.closePath();
                    } else if (
                        mouse.x != canvas.width / 2 &&
                        me().powerups.gunslinger
                    ) {
                        ctx.beginPath();
                        ctx.fillStyle = 'blue';
                        ctx.arc(mouse.x, mouse.y, 20, 0, Math.PI * 2);
                        ctx.fill();
                        ctx.closePath();
                    }
                    //const coff = offset(cursor.x, cursor.y);
                    //console.log(coff);
                }
            }
        }
    }

    function render() {
        if (window.dimensions === 3) {
            return;
        }
        if (me() && !window.spectating) {
            camera.x = me().renderX;
            camera.y = me().renderY;
        }
        if (me().cameraChange != undefined) {
            camera.x = me().cameraChange.x;
            camera.y = me().cameraChange.y;
        }
        
        if (window.spectating && players[window.spectateId]) {
            camera.x = linearLerp(
                camera.x,
                players[window.spectateId].renderX,
                (delta / 1000) * 10
            );
            camera.y = linearLerp(
                camera.y,
                players[window.spectateId].renderY,
                (delta / 1000) * 10
            );
        }
        // also lame no ads ver ;-;
        const before = window.performance.now();
        ctx.fillStyle = backgroundColor;
        // ctx.globalAlpha = 0. 1;
        //context.save(),
        // context.translate(-e.camera.x * fov, -e.camera.y * fov),
        // context.fillStyle = t,
        // context.fillRect(e.camera.x * fov, e.camera.y * fov, width, height),
        // "hsl" == e.datas.backgroundColor[0] ? context.fillStyle = "hsl(".concat(e.datas.backgroundColor[1], ", 75%, 40%)") : context.fillStyle = "rgba(".concat(e.datas.backgroundColor[0], ", ").concat(e.datas.backgroundColor[1], ", ").concat(e.datas.backgroundColor[2], ", ").concat(e.datas.backgroundColor[3], ")"),
        // context.fillRect(e.camera.x * fov, e.camera.y * fov, width, height),
        // context.restore(),

        ctx.fillRect(0, 0, canvas.width, canvas.height);
   //      if (window.backgroundPattern == null && window.bgImg != null) {
			// try {
	  //           window.backgroundPattern = ctx.createPattern(
	  //               window.bgImg,
	  //               'repeat'
	  //           );
			// } catch(err) {
			// 	console.error(err);
			// 	console.log('error^ becuase background image doesnt exist')
			// }
   //          // window.bgImagePattern = document.createElement('canvas');
   //          // bgImagePattern.width = arena.width;
   //          // bgImagePattern.height = arena.height;
   //          // const bctx = bgImagePattern.getContext('2d');
   //          // window.backgroundPattern = bctx.createPattern(window.bgImg, 'repeat')
   //          // bctx.fillStyle = backgroundPattern;
   //          // bctx.fillRect(0, 0, arena.width, arena.height);
   //          console.log('generating background pattern');
   //      }
        // ctx.save()
        // ctx.translate(-camera.x, -camera.y);
        // // ctx.fillStyle = backgroundColor;
        // // ctx.fillRect(camera.x, camera.y, canvas.width, canvas.height);
        // ctx.fillStyle = backgroundPattern;
        // // ctx.globalAlpha = 0.5;
        // ctx.fillRect(camera.x, camera.y, canvas.width, canvas.height);
        // // ctx.globalAlpha = 1;

        // ctx.translate(camera.x, camera.y);
        // ctx.restore()
        // ctx.globalAlpha = 1;

        window.points = raycastvision
            ? Ray.getPoints(
                  new Vec(me().renderX, me().renderY),
                  uniqueRayPoints,
                  rayLines,
                  me().renderRadius
              )
            : [];

        // const points = Ray.getPoints(state.player.pos, uniquePoints, state.lines, state.player.radius);

        window.darkness = window.spectating ? 0.8 : 0.5;

        if (!connected) {
            window.darkness = 0.8;
        }

        // ctx.translate(canvas.width / 2 - (camera.x * gameScale), canvas.height / 2 - (camera.y * gameScale));
        // ctx.scale(gameScale, gameScale);
        ctx.save();
        ctx.setTransform(
            renderScale,
            0,
            0,
            renderScale,
            canvas.width / 2,
            canvas.height / 2
        );
        if(window.canvasRotation !== 0){
            ctx.rotate(window.canvasRotation);
        }
        ctx.translate(-canvas.width / 2, -canvas.height / 2);

        window.cacheOffset();
		
        renderGame();
        if(window.canvasRotation !== 0){
            // filling a big rectangle around the canvas so u cant see
            // other potentially culled parts
            ctx.lineWidth = Math.abs(canvas.width-canvas.height);
            ctx.strokeStyle = window.backgroundColor;
            ctx.strokeRect(
                -ctx.lineWidth/2,
                -ctx.lineWidth/2,
                canvas.width+ctx.lineWidth,
                canvas.height+ctx.lineWidth
            );
        }
        ctx.restore();
        if (renderScale >= 1 && showMinimap) {
            let mc = document.createElement('canvas');
            mc.width = canvas.width;
            mc.height = canvas.height;
            ctx = mc.getContext('2d');
            // ctx.filter = 'grayscale(100%)'
            ctx.fillStyle = backgroundColor;
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            let old = renderScale;
            renderScale *= 0.8;
            // renderScale = Math.max(renderScale * 0.7, 1)
            window.dontRenderPortalName = true;
            window.dontShowPlayerName = true;
            ctx.save();
            ctx.setTransform(
                renderScale,
                0,
                0,
                renderScale,
                canvas.width / 2,
                canvas.height / 2
            );
            ctx.translate(-canvas.width / 2, -canvas.height / 2);
            // renderGame()
            // altered render
            renderArena(arena);
            if (window.showGrid) {
                // renderTiles(arena, camera)
            }
            debug.rendered = 0;

            // ctx.stroke()

            // renderSafes(safes, false);
            // renderEnemy(enemy);
            // renderObstacles(obstacles);
            renderObstacles(portals);
            //       renderSafes(safes, true);
            // // renderTexts(texts, viewingStory);
            // renderNpcs(npcs, me());
            window.dontRenderPortalName = false;

            // ctx.strokeStyle = 'black';
            // ctx.lineWidth = 2;
            // for (const line of rayLines) {
            // 	const s = offset(line.start.x, line.start.y);
            // 	const e = offset(line.end.x, line.end.y);
            // 	ctx.beginPath();
            // 	ctx.lineTo(s.x, s.y);
            // 	ctx.lineTo(e.x, e.y);
            // 	ctx.stroke()
            // }
            // ctx.fillStyle = 'red'
            // for (const { x, y } of uniqueRayPoints) {
            // 	ctx.beginPath();
            // 	const pos = offset(x, y);
            // 	ctx.arc(pos.x, pos.y, 5, 0, Math.PI * 2);
            // 	ctx.fill()
            // }
            if (debugMode) {
                ctx.strokeStyle = 'black';
                ctx.lineWidth = 2;
                ctx.beginPath();
                // points.push(points[0])
                for (const { x, y } of points) {
                    const pos = offset(x, y);
                    ctx.lineTo(pos.x, pos.y);
                }
                ctx.closePath();
                // ctx.fill();
                ctx.globalAlpha = 1;
                ctx.stroke();
            }
            debug.totalRender = [...obstacles, ...portals, ...enemy].length;
            renderPlayers(players);
            window.dontShowPlayerName = false;
            if (me().raycasting) {
                renderRaycasting(me());
            }
            // drawOverlay(me(), enemy);
            ctx.restore();
            ctx = canvas.getContext('2d');

            ctx.drawImage(mc, 0, canvas.height - 180, 320, 180);
            renderScale = old;
        }

        // ctx.scale(1 / gameScale, 1 / gameScale);
        // ctx.translate(-(canvas.width / 2 - (camera.x * gameScale)), -(canvas.height / 2 - (camera.y * gameScale)));

        // renderMinimap(players, arena);
        renderTimer();
        renderTimers(); // timetraps and such
        if (debugMode) {
            renderDebug(debug);
        }
        // if (me() && !window.spectating) {
        // 	camera.x = me().renderX;
        // 	camera.y = me().renderY;
        // }
        //       if (me().cameraChange != undefined){
        //           camera.x = me().cameraChange.x;
        //           camera.y = me().cameraChange.y;
        //       }
        // if ((window.spectating && players[window.spectateId])) {
        // 	camera.x = linearLerp(camera.x, players[window.spectateId].renderX, (delta / 1000) * 10);
        // 	camera.y = linearLerp(camera.y, players[window.spectateId].renderY, (delta / 1000) * 10);
        // }
        debug.renderTime += window.performance.now() - before;
    }

    window.me = function () {
        return players[selfId];
    };

    window.lastSent = [null, null];
    window.cloneLastSent = null;

    window.rayLines = [];
    window.uniqueRayPoints = [];

    if (window.raycastvision) computeLines();

    let lastDeathTimer = undefined;
    let lastRadius = null;
    function update(delt) {
        if (zoneAnim) {
            if (window.performance.now() - zoneT >= 3000) {
                zoneAnim = false;
                // zoneT = 0;
            }
        }
        // zoom anim -> 1s go in, 2s stay, 1s go out

        if (mg1countdownStart) {
            mg1countTimer -= delta / 1000;
            if (mg1countTimer <= 0) {
                send({ world: 'PoSR' });
                mg1countdownStart = false;
            }
        }

        // this is where interpolation happens, put it heree?
        // isnt it globally in window..
        // ye ik
        // make another variable for it and interpolate to hpysics

        // global one is set in physics xD
        // but why can't we just do in physics and not have to worry about variable?
        // ik but we don;t have the 2 values to interpolate unless we want to define a new variabel
        simulateGame();

        if (shouldRender) {
            for (const playerId of Object.keys(players)) {
                players[playerId].update(delt);
            }
        }
        for (const e of enemy) {
            e.update(delt);
        }

        // raycast line calculations
    }
    function simulateGame() {
        if (players[selfId] != null && connected) {
            accum += delta;
            const before = window.performance.now();
            accum = runPhysics(accum);
            debug.updateTime += window.performance.now() - before;

            // sending like update
            const pos = [
                Math.round(players[selfId].x),
                Math.round(players[selfId].y),
                Math.round(players[selfId].z),
            ];
            if (lastSent[1] === null || lastSent[0] === null) {
                // to prevent sending right when u join
                lastSent[0] = pos[0];
                lastSent[1] = pos[1];
                if (!isNaN(pos[2])) {
                    lastSent[2] = pos[2];
                }
            }
            if (
                lastSent[0] !== pos[0] ||
                lastSent[1] !== pos[1] ||
                (pos[2] && lastSent[2] !== pos[2])
            ) {
                if (isNaN(pos[2])) {
                    pos.splice(2, 1);
                }
                send(pos);
                window.lastSent = pos;
                debug.sentTimes++;
            }
            // same thing for clones
            // commented out clones for now
            // for(let i in players[selfId].clones){
            //     /*console.log(cloneLastSent);
            //     let clone = players[selfId].clones[i];
            //     let cpos = [Math.round(clone.x * 10) / 10, Math.round(clone.y * 10) / 10];
            //     if(clone.lastSent === null || clone.lastSent === undefined){
            //         players[selfId].clones[i].lastSent[0] = players[selfId].clones[i].x;
            //         players[selfId].clones[i].lastSent[1] = players[selfId].clones[i].y;
            //     }*/
            //     // sending every frame for testing purposes ;-;
            //     send({ clonePos: [players[selfId].clones[i].x, players[selfId].clones[i].y, i] })
            // }

            if (lastRadius === null) {
                lastRadius = me().radius;
            }
            if (lastRadius !== me().radius) {
                lastRadius = me().radius;
                send({ radius: me().radius });
            }
            if (
                lastDeathTimer != me().deathTimer &&
                (me().deathTimer == undefined ||
                    Math.ceil(me().deathTimer) != Math.ceil(lastDeathTimer))
            ) {
                lastDeathTimer = me().deathTimer;
                const timer =
                    me().deathTimer == undefined
                        ? undefined
                        : Math.ceil(me().deathTimer);
                send({ deathTimer: timer, deathchange: true });
                //death change is just to check if the message is valid
                // since deathtimer might be undefined
            }
        }
    }

    window.runPhysics = function (accum) {
        // ;-; ill just add 1v1 obs in hub
        let count = 0;
        while (accum >= 1000 / updateRate) {
            // if (count > 60) break;
            const simulationDelta = 1 / updateRate;
            if (window.dimensions === 3) {
                simulate3D(
                    me(),
                    arena,
                    obstacles,
                    input,
                    simulationDelta,
                    players,
                    enemy,
                    safes,
                    npcs
                );
                return accum;
            }
            simulateOtherBullets(players, simulationDelta, enemy, me());
            if (me().powerups.dragon.state) {
                runDragonCollision(players, simulationDelta, me());
            }
            // lmao
            // why tf are we looping over all obs twice??
            // runObstaclePhysics(obstacles, simulationDelta, players, enemy);
            runEnemyPhysics(
                enemy,
                arena,
                simulationDelta,
                obstacles,
                me(),
                players
            );
            runPlayerPhysics(
                me(),
                arena,
                obstacles,
                input,
                simulationDelta,
                players,
                enemy,
                safes,
                npcs
            );
            // if (me().tagged) {
            //     runPlayerTagged(me(), players, simulationDelta);
            // }
            for (let i in players) {
                if (players[i].bullets != []) {
                    players[i].lastBullets = players[i].bullets;
                }
            }
            for (let c in me().clones) {
                runPlayerPhysics(
                    me().clones[c],
                    arena,
                    obstacles,
                    input,
                    simulationDelta,
                    players,
                    enemy,
                    safes,
                    npcs,
                );
            }
            viewingStory = runCollision(
                me(),
                enemy,
                [...obstacles, ...portals],
                safes,
                npcs,
                players
            );
            // viewingStory = runCollision(me(), enemy, [...portals], safes);
            for (let c in me().clones) {
                runCollision(
                    me().clones[c],
                    enemy,
                    [...obstacles, ...portals],
                    safes,
                    npcs
                );
            }

            frames++;
            count++;
			if (shouldUpdateTimer) {
				window.timer += 1/updateRate;
			}
            // laggy ;-; dont uncomment this unless u know what ur doing
            // states[simTick] = {
            //     // state
            //     player: me().packIntoState(),
            //     obstacles: JSON.parse(JSON.stringify(obstacles)),
            //     input: { ...input },
            // };
            while (
                Number(Object.keys(states)[0]) <
                simTick - updateRate * removeOldStateTime
            ) {
                delete states[Object.keys(states)[0]];
            }
            simTick++;
            accum -= 1000 / updateRate;
        }
        return accum;
    };

    requestAnimationFrame(run);
};

function deepEqual(object1, object2) {
    const keys1 = Object.keys(object1);
    const keys2 = Object.keys(object2);
    if (keys1.length !== keys2.length) {
        return false;
    }
    for (const key of keys1) {
        const val1 = object1[key];
        const val2 = object2[key];
        const areObjects = isObject(val1) && isObject(val2);
        if (
            (areObjects && !deepEqual(val1, val2)) ||
            (!areObjects && val1 !== val2)
        ) {
            return false;
        }
    }
    return true;
}

function isObject(val) {
    return val instanceof Object;
}
