// src/server/index.js

const setupServer = require('./setupServer.js');
const msgpack = require('msgpack-lite');
const stringToObject = require('./stringToObject.js');
const parseMap = require('./parser.js');
const parseAddedObs = require('./addedobsparser.js');
const Spawner = require('./spawner.js');
const {
    sendMessage,
    difficultyColors,
    normalWebhook,
    hardWebhook,
} = require('./webhooks.js');
const runEnemyCollision = require('./runenemycollision.js');
const SAT = require('sat');
const mongoose = require('mongoose');
const argon2 = require('argon2');
// const Filter = require('bad-words');
// const config = { cleanWith: '*' };
// const chatFilter = new Filter(config);
const fetch = require('node-fetch');
let bot;
// fetch('https://evade.zerotixdev.repl.co/physics.js')
//     .then((res) => res.text())
//     .then((res) => console.log(res));
// chatFilter.addWords(
//     ...[
//         'fuck',
//         'ass',
//         'bitch',
//         'cum',
//         'pussy',
//         'boobs',
//         'slut',
//         'buhdussy',
//         'hentai',
//         'loli',
//         'vore',
//         'dick',
//         'cock',
//         'breast',
//         'tit',
//         'sex',
//     ]
// );
const Account = require('./models/account.js');
let dbStart = Date.now();
mongoose
    .connect(process.env.databaseURI, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
    })
    .then((result) => {
        // start server basically
        console.log(`Connected to the database in ${Date.now() - dbStart}ms`);
        global.wss = setupServer();
        bot = require('./bot.js');
        wss.on('connection', (socket, req) => {
            const clientId = createId();
            clients[clientId] = socket;

            socket.on('message', (data) => {
                processMessage(decode(data), clientId);
            });

			socket.on('error', (data) => {
				console.log('errorData from server', data)
			})

            socket.on('close', (event) => {
                if (players[clientId]) {
                    const map = Maps[players[clientId].map];
                    let playersInMap = getPlayersInMap(map);
                    for (const player of playersInMap) {
                        send(player.id, {
                            removePlayer: true,
                            data: clientId,
                        });
                    }
                    if (playersInMap.length === 0) {
                        unloadMap(map);
                    }
                    //removeGhostPushers(clientId);
                }
                console.log(
                    `player [${players[clientId]?.name}] disconnect: code ${event}`
                );
				// console.log('disconnect data', socket);
                delete clients[clientId];
                delete players[clientId];
                broadcast({
                    leaderboardChanged: true,
                    ...packLeaderboard(),
                });
            });
        });
        setInterval(ServerTick, Math.round(1000 / tickRate));
        setInterval(() => {
            broadcast({
                serverFps: frames,
            });
            frames = 0;
        }, 1000);
    })
    .catch((err) => console.log(err));

global.clients = {};
global.players = {};
const tickRate = 60;
const updateRate = 120;
const betaKey = 'securebetakey';
const chatMessages = [];
const chatSaveTime = 15; // seocnds
//let ghostpushers = [];
let inDuels = false;
let accum = 0;
let duelsTimer = 0;
let closeDuelsTimer = 0;
let duelsEnemies = [];
let lastDuelsState = false;
let duelsTimer2 = 0;
let closeDuelsTimer2 = 0;
let inDuels2 = false;
let duelsEnemies2 = [];
let lastDuelsState2 = false;
let shouldLoadDuelsPortal2 = false;
let tagStarted = false;
let shouldLoadDuelsPortal = false;
let tagCooldown = 0;
let inSurvival = false;
let survivalTimer = 0;
let activeCrowdButtons = [];
let gunslingerCursors = [];
let frames = 0;
global.delta = 0;

let survivalWave = 0; // current survival wave
let survivalWaves = [
    {
        time: 1000,
        obstacles: [],
    },
    {
        time: 4000,
        obstacles: [
            {
                type: 'lavamove',
                currentPoint: 0,
                points: [
                    [2150, 2025],
                    [2150, 3225 - 100],
                ],
                speed: 160,
                collidable: false,
                x: 2150,
                y: 2025,
                w: 550,
                h: 100,
                id: 'survival',
            },
            {
                type: 'lavamove',
                currentPoint: 1,
                points: [
                    [2150 + 550, 2025],
                    [2150 + 550, 3225 - 100],
                ],
                speed: 160,
                collidable: false,
                x: 2150 + 550,
                y: 3225 - 100,
                w: 525,
                h: 100,
                id: 'survival',
                x: 2150 + 550,
                y: 3125,
                w: 525,
                h: 100,
                id: 'survival',
            },
        ],
    },
    {
        time: 3000,
        obstacles: [
            {
                type: 'rotate-lava',
                angle: 0,
                rotateSpeed: 150,
                distToPivot: 0,
                x: 2687.5,
                y: 2625,
                w: 1200,
                h: 50,
                id: 'survival',
            },
            {
                type: 'rotate-lava',
                angle: 0,
                rotateSpeed: -150,
                distToPivot: 0,
                x: 3100,
                y: 2150,
                w: 350,
                h: 25,
                id: 'survival',
            },
            {
                type: 'rotate-lava',
                angle: 0,
                rotateSpeed: -150,
                distToPivot: 0,
                x: 3100,
                y: 3100,
                w: 350,
                h: 25,
                id: 'survival',
            },
            {
                type: 'rotate-lava',
                angle: 0,
                rotateSpeed: -150,
                distToPivot: 0,
                x: 2250,
                y: 3100,
                w: 350,
                h: 25,
                id: 'survival',
            },
            {
                type: 'rotate-lava',
                angle: 0,
                rotateSpeed: -150,
                distToPivot: 0,
                x: 2275,
                y: 2150,
                w: 350,
                h: 25,
                id: 'survival',
            },
            {
                type: 'speed',
                speedInc: 2.4,
                x: 2150,
                y: 2025,
                w: 1075,
                h: 1200,
                id: 'survival',
            },
        ],
    },
    {
        time: 3900,
        obstacles: [
            {
                type: 'lavamove',
                currentPoint: 0,
                points: [
                    [2150, 2025],
                    [3125, 2025],
                ],
                speed: 97.5 / 4,
                collidable: false,
                x: 2150,
                y: 2025,
                w: 100,
                h: 1200,
                id: 'survival',
            },
            {
                type: 'lavamove',
                currentPoint: 0,
                points: [
                    [3125, 2025],
                    [2150, 2025],
                ],
                speed: 97.5 / 4,
                collidable: false,
                x: 3125,
                y: 2025,
                w: 100,
                h: 1200,
                id: 'survival',
            },
        ],
    },
    /*{
        time: 20000,
        obstacles: [{type:"typing", text: `The FitnessGram PACER Test is a multistage aerobic capacity test that progressively gets more difficult as it continues. The test is used to measure a student's aerobic capacity as part of the FitnessGram assessment. Students run back and forth as many times as they can, each lap signaled by a beep sound. The test get progressively faster as it continues until the student reaches their max lap score. The PACER Test score is combined in the FitnessGram software with scores for muscular strength, endurance, flexibility and body composition to determine whether a student is in the Healthy Fitness Zone or the Needs Improvement Zone.`, active: true,currentChar: 0}]
    }*/
];

let inCrusher = false;
let crusherTimer = 0;

const encode = (msg) => msgpack.encode(msg);
const decode = (msg) => msgpack.decode(msg);
const createId = require('./createId.js');

const Maps = require('./map.js');
const Player = require('./player.js');

let lastSnapshot = null;
let lastTs = Date.now();
let bots = [];

const defaultMap = Maps.Hub;
const loadedMaps = {};

function clearAccountDatabase() {
    // last resort
    Account.deleteMany()
        .then((e) => {
            console.log('Successfully deleted the entire account database');
        })
        .catch((err) => console.log(err));
}
async function validateHuman(token) {
    const secret = process.env.captcha_secret_key;
    const response = await fetch(
        `https://google.com/recaptcha/api/siteverify?secret=${secret}&response=${token}`,
        {
            method: 'POST',
        }
    );
    const data = await response.json();
    return data.success && data.score > 0.5;
}

function addPlayerToGame(name, clientId) {
    if (Object.keys(players).length === 0) {
        loadMap(defaultMap);
    }
    players[clientId] = new Player(
        name,
        clientId,
        defaultMap,
        clients[clientId].guest
    );
    clients[clientId].inGame = true;
    send(clientId, {
        joinGame: true,
        data: {
            selfId: clientId,
            ...packMap(defaultMap),
        },

        world: 'Hub',
    });

    for (const playerId of Object.keys(players)) {
        if (
            playerId !== clientId &&
            players[playerId].map === players[clientId].map
        ) {
            send(playerId, {
                newPlayer: true,
                data: getPlayerPack(clientId),
            });
        }
    }
    broadcast({
        leaderboardChanged: true,
        ...packLeaderboard(),
    });

    chatMessages.forEach((data) => {
        send(clientId, {
            chat: true,
            msg: data.msg,
            name: data.name,
            dev: data.dev,
            guest: data.guest,
            system: data.system,
            difficulty: data.difficulty,
        });
    });

    // if (ghostpushers[players[clientId].map]) {
    //     send(clientId, {
    //         setghostpushers: ghostpushers[players[clientId].map],
    //     });
    // }
}
function loadMap(map) {
    loadedMaps[map.name] = map;
    loadedMaps[map.name].enemy = [];

    loadedMaps[map.name].obstacles = loadedMaps[map.name].obstacles.filter(
        (obs) => obs.enemyChildId === undefined
    );

    loadedMaps[map.name].spawns.forEach((spawner) =>
        spawner.spawn(loadedMaps[map.name].enemy)
    );

    for (let enemy of loadedMaps[map.name].enemy) {
        if (enemy.type === 'enemyobstacle') {
            const id = Math.random();
            enemy.obstacle.enemyChildId = id;
            enemy.obstacleParentId = id;
            loadedMaps[map.name].obstacles.push(enemy.obstacle);
        }
    }
    
    /*loadedMaps[map.name].obstacles.forEach((obs, id) => {
        loadedMaps.[map.name].obstacles.splice(id, 1);
    });*/
    /*loadedMaps[map.name].enemy.forEach((enemy, j) => {
		// no?
		// like ok
		// a seperate array that has all the parents/childs
		// according to ids
		// so u reference from that
		// but this way
		// all the enemis will just be in enemy/ not
		// not nested
		// idk lets just get game working
		// seeems simple tho
		//
		// ye do that
		// also wouldn't that reuqire recoding the whole enemy systme?
        // how would u actually implement it given spawner.js tho?
        // ye i can just remove it idk
		
        if(enemy.childId){// its like something with parent not being able to be foudn i think like it cant see the enemy j
            for(let i in loadedMaps[map.name].enemy){
                if(enemy.childId == loadedMaps[map.name].enemy[i].parentId && loadedMaps[map.name].enemy[i].child == undefined){
                    loadedMaps[map.name].enemy[i].child = j;// cant see this enemy in the child
                    loadedMaps[map.name].enemy[j].parent = i;
                }
            }
        }
    })*/
    loadedMaps[map.name].firstLoadTime = Date.now();
}

function unloadMap(map) {
    //ghostpushers[map.name] = [];
    delete loadedMaps[map.name];
}

// function removeGhostPushers(id) {
//     if (!ghostpushers[players[id].map]) {
//         return;
//     }
//     for(const gpid of Object.keys(ghostpushers[players[id].map])){
//         if(ghostpushers[players[id].map][gpid].playerId === id){
//             delete ghostpushers[players[id].map][gpid];
//             for (const playerId of Object.keys(players)) {
//                 if (players[playerId].map === players[id].map) {
//                     send(playerId, {
//                         removeghostpusher: gpid,
//                     });
//                 }
//             }
//         }
//     }
// }

function getPlayersInMap(map) {
    // sends each player object that is i n that map
    let playersInMap = [];
    Object.keys(players).forEach((id) => {
        if (players[id].map === map.name) {
            playersInMap.push(players[id]);
        }
    });
    return playersInMap;
}

function packMap(map) {
    let playersInMap = [];
    Object.keys(players).forEach((id) => {
        // puts every pack() of a player inside that map
        if (players[id].map === map.name) {
            playersInMap.push(getPlayerPack(id));
        }
    });

    // if(map.addedObstacles != undefined){
    //     let obs = [...map.obstacles.map((ob) => ob.pack()), ...map.addedObstacles];
    // } else {
    //     let obs = [...map.obstacles.map((ob) => ob.pack()), []];
    // }
    const pack = {
        players: playersInMap,
        enemy: map.enemy.map((e) => packEnemy(e)),
        // it finally works
        safes: map.safes.map((safe) => safe.pack()),
        npcs: map.npcs != undefined ? map.npcs.map((npc) => npc.pack()) : [], // will work lol
        // cme popb
        // wait it doenst ;-;
        // map.npcs is undefined thats why
        //and when u do operation on .map it throws error
        // no ik why// i forgot to put texts[] in the json
        arena: map.arena,
        texts: map.texts.map((text) => text.pack()),
        obstacles: [...map.obstacles.map((o) => packObstacle(o))],
        addedobstacles: map.addedObstacles,
        mapDelta: Date.now() - map.firstLoadTime ?? 0,
        lighting: map.lighting || 0,
        renderRaycasting: map.renderRaycasting || false,
        bgColor: map.bgColor,
        tileColor: map.tileColor,
        safeColor: map.safeColor,
    };
    if (map.dimensions === 3) {
        const addPack = {
            dimensions: map.dimensions || 2,
            cameraZoom: map.cameraZoom || 1000,
            gravity: map.gravity,
        };
        for (let obj of Object.keys(addPack)) {
            pack[obj] = addPack[obj];
        }
    }
    return pack;
}

function packLeaderboard() {
    let playerData = [];
    // send { dead, name, map }
    // i can code server side btw
    Object.keys(players).forEach((id) => {
        // puts every pack() of a player inside that map
        let thisPlayerData = [];
        // console.log(players[id].map, 'a player map acronomy owner')
        thisPlayerData.push(id); //hmm
        // console.log(Maps[players[id].map])
        // dude
        // [mapname, name, dead, color, zone]
        thisPlayerData.push(Maps[players[id].map].longName);
        thisPlayerData.push(players[id].name);
        thisPlayerData.push(players[id].dead);
        thisPlayerData.push(difficultyColors[Maps[players[id].map].difficulty]);
        thisPlayerData.push(players[id].zone);
        playerData.push(thisPlayerData);
    });
    return {
        playerData: playerData,
    };
}

function packEnemy(e) {
    // adding parenting btw
    // enemies can like be "attached" to other enemies and thus follow them :>
    return {
        ...e.pack(),
        parentId: e.parentId,
        childId: e.childId,
        pushIndex: e.pushIndex,
        runCollision: e.runCollision,
        life: e.life,
        simulateBound: e.simulateBound,
    };
}

function packObstacle(o) {
    return {
        ...o.pack(),
        enemyChildId: o.enemyChildId,
    };
}

function processMessage(data, clientId) {
    if (data.world != undefined) {
        if (data.win == true) {
            let solo = true;
            let legit = players[clientId].legit != false;
            let message = `${players[clientId].name} has beaten ${
                Maps[players[clientId].map].longName
            } in ${data.time}!`;
            if (!legit) {
                message = `${players[clientId].name} has beaten ${
                    Maps[players[clientId].map].longName
                } in ${data.time}. [NOT LEGIT]`;
            }
            if (data.strokes) {
                message = `${players[clientId].name} has beaten ${
                    Maps[players[clientId].map].longName
                } in ${data.strokes} strokes!`;
            }
            chatMessages.push({
                msg: message,
                name: '',
                dev: false,
                guest: false,
                system: true,
                difficulty: Maps[players[clientId].map].difficulty,
                time: Date.now(),
            });
            broadcast({
                chat: true, // you have to format it like client? oh shit
                msg: message,
                name: '',
                dev: false,
                system: true,
                guest: false,
                difficulty: Maps[players[clientId].map].difficulty,
            });
            let difficulty = Maps[players[clientId].map].difficulty;
            if (
                difficulty == 'Agonizing' ||
                difficulty == 'Terrorizing' ||
                difficulty == 'Cataclysmic'
            ) {
                sendMessage(
                    players[clientId].name,
                    Maps[players[clientId].map].longName,
                    data.time,
                    difficulty,
                    hardWebhook,
                    solo,
                    legit
                );
            } else {
                sendMessage(
                    players[clientId].name,
                    Maps[players[clientId].map].longName,
                    data.time,
                    difficulty,
                    normalWebhook,
                    solo,
                    legit
                );
            }
        }
        if (Maps[data.world] === undefined) {
            data.world = 'Hub';
        }
        if (Maps[data.world] != undefined) {
            // console.log('the map exists!')
            const name = Maps[data.world].name;
            if (loadedMaps[name] === undefined) {
                loadMap(Maps[data.world]);
            }
            const playerName = players[clientId].name;
            const map = Maps[data.world];
            let playersInMap = getPlayersInMap(Maps[players[clientId].map]);
            for (const player of playersInMap) {
                if (player.id === clientId) continue;
                send(player.id, {
                    removePlayer: true,
                    data: clientId,
                });
            }
            if (playersInMap.length === 0) {
                unloadMap(Maps[players[clientId].map]);
            }
            //..removeGhostPushers(clientId);
            const dev = players[clientId].dev;
            const guest = players[clientId].guest;
            delete players[clientId];
            players[clientId] = new Player(
                playerName,
                clientId,
                Maps[data.world],
                guest
            );

            players[clientId].dev = dev;
            send(clientId, {
                nw: true,
                state: {
                    selfId: clientId,
                    ...packMap(Maps[data.world]),
                    bgColor: Maps[data.world].bgColor,
                    tileColor: Maps[data.world].tileColor,
                    safeColor: Maps[data.world].safeColor,
                },
                musicPath: Maps[data.world].musicPath,
                world: data.world,
            });
            send(clientId, {
                renderGlitch: false,
            });
            // if (ghostpushers[players[clientId].map]) {
            //     send(clientId, {
            //         setghostpushers: ghostpushers[players[clientId].map],
            //     });
            // }
            if (Maps[data.world].name == 'Minigames') {
                runMinigames1();
                packMinigames1(clientId);
            } else if (Maps[data.world].name == 'Minigames2') {
                packMinigames2(clientId);
            } else if (Maps[data.world].name == 'Minigames3') {
                packMinigames3(clientId);
            }
            for (const playerId of Object.keys(players)) {
                if (
                    playerId !== clientId &&
                    players[playerId].map === players[clientId].map
                ) {
                    send(playerId, {
                        newPlayer: true,
                        data: getPlayerPack(clientId),
                    });
                }
            }
            /*if(activeCrowdButtons.length > 0){
                send(clientId, {
                    crowdbuttons: activeCrowdButtons.map((cb) => function(cb){
                        return {id: cb.id, timer: cb.timer - (Date.now()-cb.timeSet)};
                    }),
                });
                console.log('cb sent!');
            }*/
            broadcast({
                leaderboardChanged: true,
                ...packLeaderboard(),
            });
        }
        return; // to prevent msgs that are sent at the same time like powerups being carried over to the clients in other maps ;-;
    }
    if (data.login != undefined && players[clientId] == null) {
        (async () => {
            const isHuman = await validateHuman(data.token);
            if (isHuman) {
                const account = await Account.findOne({
                    username: new RegExp(data.username, 'i'),
                });
                if (account) {
                    if (await argon2.verify(account.password, data.password)) {
                        // you are good to sign into the account!
                        console.log('Successfully logged into ', data.username);
                        send(clientId, {
                            loginSuccess: true,
                            name: data.username,
                        });
                        clients[clientId].name = data.username;
                        clients[clientId].guest = false;
                        // addPlayerToGame(data.username, clientId);
                    } else {
                        console.log(
                            'Tried to sign into',
                            data.username,
                            'but failed :(',
                            data.password
                        );
                    }
                }
            }
        })();
    }
    if (data.guest != undefined) {
        (async () => {
            const isHuman = await validateHuman(data.token);
            if (isHuman) {
                const guestName = `Guest${Math.round(
                    Math.random() * 10
                )}${Math.round(Math.random() * 10)}`;
                clients[clientId].name = guestName;
                clients[clientId].guest = true;
                send(clientId, {
                    loginSuccess: true,
                    name: guestName,
                });
            }
        })();
    }
    if (data.clear != undefined) {
        clearAccountDatabase(); // should be removed soon
    }
    if (data.register != undefined && players[clientId] == null) {
        (async () => {
            try {
                const isHuman = await validateHuman(data.token);
                if (isHuman) {
                    const usernameExists = await Account.findOne({
                        username: new RegExp(data.username, 'i'),
                    });
                    if (!usernameExists) {
                        const tests = (name) => {
                            return (
                                name.length >= 3 &&
                                name.length <= 16 &&
                                !/[^A-Za-z0-9]+/g.test(name) &&
                                !chatFilter.isProfane(name)
                            );
                        };
                        if (tests(data.username)) {
                            const hashedPassword = await argon2.hash(
                                data.password
                            );
                            const account = new Account({
                                username: data.username,
                                password: hashedPassword,
                                dateCreated: Date.now(),
                            });
                            account
                                .save()
                                .then((result) => {
                                    console.log(result);
                                    send(clientId, {
                                        registerSuccess: true,
                                    });
                                })
                                .catch((err) => console.log(err, account));
                        } else {
                            // failed test, send back response
                            let name = data.username;
                            let response = 'Failed to create account!';
                            if (name.length < 3) {
                                response = 'Username too short!';
                            }
                            if (name.length > 16) {
                                response = 'Username too long!';
                            }
                            if (/[^A-Za-z0-9]+/g.test(name)) {
                                response =
                                    'Username contains invalid characters!';
                            }
                            if (chatFilter.isProfane(name)) {
                                response = 'Username contains bad words!';
                            }
                            send(clientId, {
                                loginFailure: response,
                            });
                            console.log(response);
                        }
                    } else {
                        send(clientId, {
                            loginFailure: 'Account already exists!',
                        });
                        console.log('already exists');
                    }
                }
            } catch (err) {
                console.log(err, ': Error while creating an account!');
            }
        })();
    }
    if (data.betaKey !== undefined && players[clientId] == null) {
        if (data.betaKey.trim() === betaKey) {
            clients[clientId].verify = true;
            send(clientId, { type: 'verify' });
        }
    }
    if (data.tag != undefined && clients[data.id].inGame && players[data.id]) {
        players[data.id].tagged = data.tag;
    }
    if (
        data.enterGame &&
        players[clientId] == null &&
        clients[clientId].name != undefined
    ) {
        addPlayerToGame(clients[clientId].name, clientId);
    }
    if (
        data.joinGame &&
        players[clientId] == null &&
        clients[clientId].verify
    ) {
        if (data.name === '') {
            data.name = `Guest${Math.floor(Math.random() * 100)}`;
        }
        addPlayerToGame(data.name, clientId);
    }
    if (Array.isArray(data) && clients[clientId].inGame && players[clientId]) {
        // player update pos
        players[clientId].setData(data);
    }
    if (
        data.clonePos != undefined &&
        clients[clientId].inGame &&
        players[clientId]
    ) {
        // clone update pos
        players[clientId].setCloneData(data.clonePos);
    }
    if (
        data.powerups != undefined &&
        clients[clientId].inGame &&
        players[clientId]
    ) {
        // powerups update
        players[clientId].updatePowerups(data.powerups);
    }
    if (
        data.gsc != undefined &&
        clients[clientId].inGame &&
        players[clientId]
    ) {
        // powerups update
        //console.log(data.gsc);
        if (data.gsc == 'clear') {
            delete gunslingerCursors[clientId];
        } else {
            gunslingerCursors[clientId] = data.gsc;
        }
        for (const playerId of Object.keys(players)) {
            if (
                players[playerId].map === players[clientId].map &&
                playerId != clientId
            ) {
                send(playerId, {
                    gsc: data.gsc,
                    id: clientId,
                });
            }
        }
    }
    if (
        data.bounce != undefined &&
        clients[clientId].inGame &&
        players[clientId] &&
        clients[data.id]?.inGame &&
        players[data.id]
    ) {
        // powerups update
        send(data.id, {
            bounce: true,
            effect: data.effect,
            id: clientId,
        });
    }
    if (
        data.bullets != undefined &&
        clients[clientId].inGame &&
        players[clientId]
    ) {
        // powerups update
        players[clientId].updateBullets(
            data.bullets,
            clients[clientId].clientPing || 0
        );
        // lol not working somehow maybe ill rollback
    }
    if (
        data.tailbite != undefined &&
        clients[clientId].inGame &&
        players[clientId]
    ) {
        if (data.id != undefined && players[data.id]) {
            players[data.id].powerups.dragon.hp--;
            broadcast({
                id: data.id,
                tailbite: true,
            }); // we need to send the id tho
        }
    }
    /*if (data.pusher) {
        if (!ghostpushers[players[clientId].map]) {
            ghostpushers[players[clientId].map] = {};
        }
        ghostpushers[players[clientId].map][data.pusher.pusherId+clientId] = data.pusher;
        ghostpushers[players[clientId].map][data.pusher.pusherId+clientId].playerId = clientId;
        for (const playerId of Object.keys(players)) {
            if (
                players[playerId].map === players[clientId].map &&
                playerId !== clientId
            ) {
                send(playerId, {
                    ghostpusher: {
                        ...ghostpushers[players[clientId].map][
                            data.pusher.pusherId+clientId
                        ],
                        pusherId: data.pusher.pusherId,
                        playerId: clientId,
                    },
                });
            }
        }
    }
    if (data.removepusher){
        if(ghostpushers[players[clientId].map]){
            delete ghostpushers[players[clientId].map][data.removepusher+clientId];
            for (const playerId of Object.keys(players)) {
                if (players[playerId].map === players[clientId].map) {
                    send(playerId, {
                        removeghostpusher: data.removepusher+clientId,
                    });
                }
            }
        }
    }*/
    /*if (data.pong != undefined && clients[clientId].inGame && players[clientId]) {
        const last = loadedMaps['Minigames3'].obstacles.length-1;
        loadedMaps['Minigames3'].obstacles[last].x = data.pong.x;
        loadedMaps['Minigames3'].obstacles[last].y = data.pong.y;
        loadedMaps['Minigames3'].obstacles[last].xv = data.pong.xv;
        loadedMaps['Minigames3'].obstacles[last].yv = data.pong.yv;
        for (const playerId of Object.keys(players)) {
            if (players[playerId].map === 'Minigames3' && playerId != clientId) {
                send(playerId, {
                    pong: data.pong
                });
            }
        }
    }*/
    //send({ hatChange: true, hat: player.hat.src })
    // wont work; ill figure out a solution later ;c
    /*if(data.hatChange && clients[clientId].inGame && players[clientId]){
        if(!players[clientId].hat){
            players[clinetId].hat = new Image();
        }
        players[clientId].hat.src = 
    }*/
    /*crowdbutton: true, timer: obstacles[i].timer, id: obstacles[i].id*/
    /*if (data.crowdbutton && clients[clientId].inGame && players[clientId]) {
        let ind2remove = activeCrowdButtons.length;
        activeCrowdButtons.push({id: data.id, timer: data.timer, timeSet: Date.now()});
        setTimeout(() => {
          activeCrowdButtons.splice(ind2remove,1);
        }, data.timer*1000)
    }*/
    if (data.killEnemy && clients[clientId].inGame && players[clientId]) {
        for (const playerId of Object.keys(players)) {
            if (players[playerId].map === players[clientId].map) {
                send(playerId, {
                    killEnemy: true,
                    id: data.id,
                });
            }
        }
    }
    if (
        data.dead != undefined &&
        clients[clientId].inGame &&
        players[clientId]
    ) {
        if (data.id != undefined && data.type === 'pvp') {
            // kill that player
            players[data.id].die();
            send(data.id, {
                dead: true,
            });
            broadcast({
                leaderboardChanged: true,
                ...packLeaderboard(),
            });
        } else {
            if (data.dead) {
                players[clientId].die();
                broadcast({
                    leaderboardChanged: true,
                    ...packLeaderboard(),
                });
            } else if (!data.dead) {
                players[clientId].dead = false;
                send(clientId, {
                    revive: true,
                });
                broadcast({
                    leaderboardChanged: true,
                    ...packLeaderboard(),
                });
            }
        }
    }
    if (
        (data.ship || data.ship == false) &&
        clients[clientId].inGame &&
        players[clientId]
    ) {
        players[clientId].ship = data.ship;
    }
    if (data.add && clients[clientId].inGame && players[clientId]) {
        //try {
        // if(players[clientId].map == 'Mapmaker') {
        for (const playerId of Object.keys(players)) {
            if (players[playerId].map === players[clientId].map) {
                send(playerId, {
                    add: data.add,
                });
            }
        }
        // adding to global array for players that join late
        if (Maps[players[clientId].map].addedObstacles != undefined) {
            Maps[players[clientId].map].addedObstacles.push(data.add);
        }
        // }
        //} catch (e) {
        //console.log(data.add + ': invalid input');
        //}
    }
    if (data.del && clients[clientId].inGame && players[clientId]) {
        for (const playerId of Object.keys(players)) {
            if (players[playerId].map === players[clientId].map) {
                send(playerId, {
                    del: data.del,
                });
            }
        }
        if (Maps[players[clientId].map].addedObstacles != undefined) {
            // dude why the random -1?
            // lol idk it just worked xD
            Maps[players[clientId].map].addedObstacles.splice(data.del - 1, 1);
        }
    }
    if (data.delete && clients[clientId].inGame && players[clientId]) {
        //try {
        //if(players[clientId].map == 'Mapmaker') {
        for (const playerId of Object.keys(players)) {
            if (players[playerId].map === players[clientId].map) {
                send(playerId, {
                    remove: true,
                });
            }
        }
        // adding to global array for players that join late
        if (Maps[players[clientId].map].addedObstacles != undefined) {
            Maps[players[clientId].map].addedObstacles.pop();
        }
        //}
        //} catch (e) {
        //console.log(data.add + ': invalid input');
        //}
    }
    if (data.radius && clients[clientId].inGame && players[clientId]) {
        players[clientId].radius = data.radius;
    }
    if (data.deathchange && clients[clientId].inGame && players[clientId]) {
        players[clientId].deathTimer = data.deathTimer;
        players[clientId].deathchange = true;
    }
    if (
        data.zone != undefined &&
        clients[clientId].inGame &&
        players[clientId]
    ) {
        players[clientId].zone = data.zone;
        broadcast({
            leaderboardChanged: true,
            ...packLeaderboard(),
        });
        send(clientId, { zone: data.zone });
    }
    // send map to client

    if (data.ping != undefined) {
        send(clientId, {
            pung: data.ping,
        });
    }
    if (data.pingResult != undefined) {
        clients[clientId].clientPing = data.pingResult / 1000;
        players[clientId].ping = clients[clientId].clientPing;
    }
    if (data.checkpoint != undefined) {
        players[clientId].changeSpawn(data.checkpoint);
    }
    if (data.respawn && clients[clientId].inGame && players[clientId]) {
        players[clientId].legit = true;
        players[clientId].tagged = false;
        for (let i in players) {
            send(players[i], {
                tagged: false,
                id: clientId,
            });
        }
        players[clientId].respawn();
        if (players[clientId].is3D) {
            send(clientId, {
                respawned: true,
                x: players[clientId].clientX,
                y: players[clientId].clientY,
                z: players[clientId].clientZ,
            });
        } else {
            send(clientId, {
                respawned: true,
                x: players[clientId].clientX,
                y: players[clientId].clientY,
            });
        }
        let playersInMap = getPlayersInMap(Maps[players[clientId].map]);
        for (const player of playersInMap) {
            if (player.id !== clientId) {
                if (players[clientId].is3D) {
                    send(player.id, {
                        respawnId: clientId,
                        teleport: {
                            x: players[clientId].clientX,
                            y: players[clientId].clientY,
                            z: players[clientId].clientZ,
                        },
                    });
                } else {
                    send(player.id, {
                        respawnId: clientId,
                        teleport: {
                            x: players[clientId].clientX,
                            y: players[clientId].clientY,
                        },
                    });
                }
            }
        }
        broadcast({
            leaderboardChanged: true,
            ...packLeaderboard(),
        });
    }
    if (
        data.chat != undefined &&
        clients[clientId].inGame &&
        players[clientId]
    ) {
        const text = data.chat;
        if (text === '/deve') {
            players[clientId].dev = !players[clientId].dev;
        } else if (text === '/log_players') {
            console.log(players);
        } else if (text === '/wintest' && players[clientId].dev) {
            for (let i of [
                'Peaceful',
                'Moderate',
                'Difficult',
                'Hardcore',
                'Exhausting',
                'Relentless',
                'Agonizing',
                'Terrorizing',
                'Cataclysmic',
            ]) {
                broadcast({
                    chat: true,
                    msg: `TestPlayer has beaten Planet of Testing ${i}!`,
                    name: '',
                    dev: false,
                    guest: false,
                    system: true,
                    difficulty: i,
                });
                chatMessages.push({
                    msg: `TestPlayer has beaten Planet of Testing ${i}!`,
                    name: '',
                    dev: false,
                    guest: false,
                    system: true,
                    difficulty: i,
                    time: Date.now(),
                });
                if (['Agonizing', 'Terrorizing', 'Cataclysmic'].includes(i)) {
                    sendMessage(
                        'TestPlayer',
                        'Planet of Testing ' + i,
                        '03:28:01',
                        i,
                        hardWebhook,
                        true,
                        false
                    );
                } else {
                    sendMessage(
                        'TestPlayer',
                        'Planet of Testing ' + i,
                        '03:28:01',
                        i,
                        normalWebhook,
                        false,
                        true
                    );
                }
            }
        } else if (
            text.toLowerCase().trim() === '/restart' &&
            players[clientId].dev
        ) {
            // process.exit(1)
            setTimeout(function () {
                process.on('exit', function () {
                    console.log('restarting server....');
                    require('child_process').spawn(
                        process.argv.shift(),
                        process.argv,
                        {
                            cwd: process.cwd(),
                            detached: true,
                        }
                    );
                });
                process.exit();
            }, 0);
        } else if (text.toLowerCase().trim() === '/accounts') {
            const accounts = Account.find()
                .then((result) => {
                    const message = result.map((a) => a.username).toString();
                    chatMessages.push({
                        msg: message,
                        name: '',
                        dev: false,
                        system: true,
                        guest: false,
                        time: Date.now(),
                    });
                    broadcast({
                        chat: true, // you have to format it like client? oh shit
                        msg: message,
                        name: '',
                        guest: false,
                        dev: false,
                        system: true,
                    });
                })
                .catch((err) => console.log(err));
        } else if (text.toLowerCase().slice(0, 4) === '/map') {
            const jsonData = text.slice(5).trim(); // JSON DATA!!!
            // this will bereak on maps that werent made with map editor
            // loadedMaps is not an array, object
            const map = Maps[players[clientId].map];
            const newMap = parseMap(jsonData);
            // loadMap(newMap);
            // console.log('new map', newMap)
            if (loadedMaps[map.name] && newMap != undefined) {
                const playersInMap = getPlayersInMap(map);
                Maps[players[clientId].map] = newMap;
                loadMap(newMap);
                for (const player of playersInMap) {
                    send(player.id, {
                        mapChange: true,
                        state: {
                            ...packMap(newMap),
                            bgColor: newMap.bgColor,
                            tileColor: newMap.tileColor,
                            safeColor: newMap.safeColor,
                        },
                    });
                    // console.log('what im sending to player', {
                    // 	mapChange: true,
                    // 	state: {
                    // 		...packMap(newMap),
                    // 		bgColor: newMap.bgColor,
                    // 		tileColor: newMap.tileColor,
                    // 		safeColor: newMap.safeColor
                    // 	},
                    // })
                }
            }
        } else if (
            players[clientId].dev &&
            text.toLowerCase().slice(0, 5) === '/tpme'
        ) {
            const name = text.slice(6).trim();
            let playersInMap = getPlayersInMap(Maps[players[clientId].map]);
            for (const player of playersInMap) {
                if (player.id !== clientId) {
                    // console.log(name === player.name)
                    if (player.name === name) {
                        // console.log(player.id)
                        players[clientId].tp(
                            players[player.id].clientX,
                            players[player.id].clientY
                        );
                        send(clientId, {
                            respawned: true,
                            x: players[clientId].clientX,
                            y: players[clientId].clientY,
                        });
                        break;
                    }
                }
            }
        } else if (
            players[clientId].dev &&
            text.toLowerCase().slice(0, 3) === '/tp'
        ) {
            const name = text.slice(4).trim();
            let playersInMap = getPlayersInMap(Maps[players[clientId].map]);
            for (const player of playersInMap) {
                if (player.id !== clientId) {
                    // console.log(name === player.name)
                    if (player.name === name) {
                        // console.log(player.id)
                        players[player.id].tp(
                            players[clientId].clientX,
                            players[clientId].clientY
                        );
                        send(player.id, {
                            respawned: true,
                            x: players[player.id].clientX,
                            y: players[player.id].clientY,
                        });
                        break;
                    }
                }
            }
        } else if (
            players[clientId].dev &&
            text.toLowerCase().slice(0, 4) === '/die'
        ) {
            const name = text.slice(5).trim();
            let playersInMap = getPlayersInMap(Maps[players[clientId].map]);
            for (const player of playersInMap) {
                if (player.id !== clientId) {
                    // console.log(name === player.name)
                    if (player.name === name) {
                        // console.log(player.id)
                        players[player.id].dead = true;
                        send(player.id, {
                            dead: true,
                        });
                        break;
                    }
                }
            }
        } else if (text.toLowerCase() === '/bot') {
            if (true) {
                players[clientId].spawnedBot = true;
                // if (bots.length < 10) {
                for (let i = 0; i < 1; i++) {
                    let id = createId();
                    bots.push(id);
                    players[id] = new Player(
                        players[clientId].name + `'s Bot`,
                        id,
                        Maps[players[clientId].map],
                        false
                    );
                    for (const playerId of Object.keys(players)) {
                        if (
                            playerId !== id &&
                            players[playerId].map === players[id].map
                        ) {
                            send(playerId, {
                                newPlayer: true,
                                data: getPlayerPack(id),
                            });
                        }
                    }
                }
                broadcast({
                    leaderboardChanged: true,
                    ...packLeaderboard(),
                });
                // }
            }
        } else if (text.toLowerCase() === '/cb') {
            for (let i = 0; i < bots.length; i++) {
                const id = bots[i];
                if (players[id]) {
                    const map = Maps[players[id].map];
                    let playersInMap = getPlayersInMap(map);
                    for (const player of playersInMap) {
                        send(player.id, {
                            removePlayer: true,
                            data: id,
                        });
                    }
                    if (playersInMap.length === 0) {
                        unloadMap(map);
                    }
                }
                delete players[id];
            }
            bots = [];
            broadcast({
                leaderboardChanged: true,
                ...packLeaderboard(),
            });
        } else if (text === '/res' || text === '/r') {
            players[clientId].legit = false;
            players[clientId].dead = false;
            send(clientId, {
                revive: true,
            });
            broadcast({
                leaderboardChanged: true,
                ...packLeaderboard(),
            });
        } else if (text.toLowerCase() === '/god') {
            if (!players[clientId].dev) return;
            players[clientId].legit = false;
            players[clientId].god = !players[clientId].god;
            players[clientId].dead = false;
            send(clientId, {
                revive: true,
            });
            broadcast({
                leaderboardChanged: true,
                ...packLeaderboard(),
            });
        } else {
            let message = text;
            // let message;
            // try {
            //     let newMessage = chatFilter.clean(text);
            //     message = newMessage;
            // } catch (err) {
            //     console.log(err);
            //     message = text;
            // }
            chatMessages.push({
                msg: message,
                name: players[clientId].name,
                dev: players[clientId].dev,
                system: false,
                guest: players[clientId].guest,
                difficulty: undefined,
                time: Date.now(),
            });
            broadcast({
                chat: true,
                msg: message,
                name: players[clientId].name,
                dev: players[clientId].dev,
                guest: players[clientId].guest,
            });
        }
    }
}

// } else if (text.toLowerCase() === '/bot') {
//     if (true) {
//         players[clientId].spawnedBot = true;
//         if (bots.length < 10) {
//             for (let i = 0; i < 1; i++) {
//                 let id = createId();
//                 bots.push(id)
//                 players[id] = new Player(players[clientId].name + `'s Slave`, id, Maps[players[clientId].map]);
//                 for (const playerId of Object.keys(players)) {
//                     if (playerId !== id && players[playerId].map === players[id].map) {
//                         send(playerId, {
//                             newPlayer: true,
//                             data: getPlayerPack(id),
//                         })
//                     }
//                 }
//             }
//             broadcast({
//                 leaderboardChanged: true,
//                 ...packLeaderboard()
//             })
//         }
//     }
// sending things if in the universe 1 minigames

function packMinigames1(clientId) {
    // sending tag
    for (let p in players) {
        if (players[p].tagged == true) {
            send(clientId, {
                tagged: true,
                id: players[p].id,
            });
        }
    }
    // removing old duels enemies before adding new
    send(clientId, {
        addenemy: duelsEnemies,
    });

    if (mg1countdownRunning) {
        send(clientId, {
            mg1countdownStart: mg1countTimer,
        });
    }
    if (shouldLoadDuelsPortal) {
        send(clientId, {
            add: {
                x: 1850,
                y: 1850,
                w: 50,
                h: 125,
                type: 'tp',
                tpx: 500,
                tpy: 500,
                id: 'duelsTp',
            },
        });
        send(clientId, {
            add: {
                x: 1900,
                y: 1850,
                w: 75,
                h: 50,
                type: 'tp',
                tpx: 500,
                tpy: 500,
                id: 'duelsTp',
            },
        });
    } else {
        send(clientId, {
            removeById: 'duelsTp',
        });
        send(clientId, {
            removeById: 'duelsTp',
        });
    }

    if (inSurvival) {
        // buggy because of moving obs ;-; idk i think ill get it fixed by the time the game comes out lmfao
        /*send(clientId, {
            add: survivalWaves[survivalWave].obstacles
        });*/
    } else {
        send(clientId, {
            removeById: 'survival',
        });
        send(clientId, {
            removeById: 'survival',
        });
    }
}
function packMinigames2(clientId) {
    // removing old duels enemies before adding new
    send(clientId, {
        addenemy: duelsEnemies2,
    });
}
function packMinigames3(clientId) {
    // if needed
}

function getPlayerPack(id) {
    return {
        ...players[id].pack(),
        id,
    };
}

function broadcast(msg, except = null) {
    for (const id of Object.keys(clients)) {
        if (id === except || !clients[id].inGame) continue;
        send(id, msg);
    }
}

function send(id, msg) {
    if (clients[id]) {
        clients[id].send(encode(msg));
    }
}

function isDifferent(obj1, obj2) {
    for (const key of Object.keys(obj2)) {
        if (obj1[key] !== obj2[key]) {
            return true;
        }
    }
    return false;
}

function intersectingCircle(circle1, circle2) {
    return (
        (circle1.x - circle2.x) * (circle1.x - circle2.x) +
            (circle1.y - circle2.y) * (circle1.y - circle2.y) <
        (circle1.radius + circle2.radius) * (circle1.radius + circle2.radius)
    );
}

function intersectingCircleRect(circle, rect, genCircleSat = false) {
    const distX = Math.abs(circle.x - rect.x - rect.w / 2);
    const distY = Math.abs(circle.y - rect.y - rect.h / 2);
    if (
        distX < rect.w / 2 + circle.radius &&
        distY < rect.h / 2 + circle.radius
    ) {
        let circleSat;
        if (genCircleSat) {
            circleSat = new SAT.Circle(
                new SAT.Vector(circle.x, circle.y),
                circle.radius
            );
        } else {
            circleSat = circle.sat;
        }
        const res = new SAT.Response();
        const boxSat = new SAT.Box(
            new SAT.Vector(rect.x, rect.y),
            rect.w,
            rect.h
        ).toPolygon();
        const collision = SAT.testPolygonCircle(boxSat, circleSat, res);
        if (collision) {
            return true;
        }
    }
    return false;
}

function dist(x1, x2, y1, y2) {
    return Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
}

function include(array, value) {
    for (let i = 0; i < array.length; i++) {
        if (array[i] === value) return true;
    }
    return false;
}

function runPhysics() {
    for (const mapId of Object.keys(loadedMaps)) {
        const map = loadedMaps[mapId];
        let singleReset = false;

        map.obstacles.forEach((o, ind) => {
            if (o.type === 'enemyeffect') {
                o.simulate(1 / updateRate, map.enemy, ind);
            } else {
                o.simulate(1 / updateRate);
            }
        });

        map.enemy.forEach((e, ind) => {
            if (e.simulateBound) {
                let touching = false;
                for (const playerId of Object.keys(players)) {
                    const p = players[playerId];
                    if (intersectingCircleRect(p, e.simulateBound, true)) {
                        touching = true;
                        break;
                    }
                }
                if (!touching) {
                    return;
                }
            }
            if (
                e.type == 'selfcollide' ||
                e.type == 'rchange' ||
                e.type == 'repel' ||
                e.type == 'rotatearoundparent'
            ) {
                e.simulate(1 / updateRate, map.enemy);
                if (e.type == 'rchange') singleReset = true;
            } else if (e.type === 'spawn') {
                let obstacle = e.simulate(
                    1 / updateRate,
                    map.enemy,
                    map.obstacles
                );
                // for enemyobstacle enemies
                if (obstacle !== undefined) {
                    const id = Math.random();
                    obstacle.enemyChildId = id;
                    map.enemy[map.enemy.length - 1].obstacleParentId = id;
                    map.enemy[map.enemy.length - 1].obstacle.enemyChildId = id;
                    map.obstacles.push(obstacle);
                    for (const playerId of Object.keys(players)) {
                        if (players[playerId].map === map.name) {
                            send(playerId, {
                                add: [packObstacle(obstacle)],
                            });
                            send(playerId, {
                                addenemy: [
                                    packEnemy(map.enemy[map.enemy.length - 1]),
                                ],
                            });
                        }
                    }
                }
            } else if (e.type === 'enemyobstacle') {
                e.simulate(1 / updateRate, map.obstacles);
            } else if (e.type === 'followaxis') {
                e.simulate(1 / updateRate, players);
            } else {
                e.simulate(1 / updateRate);
            }
            if (e.childId) {
                for (let ene in map.enemy) {
                    if (
                        map.enemy[ene].parentId &&
                        map.enemy[ene].parentId == e.childId &&
                        map.enemy[ene].pushIndex == e.pushIndex
                    ) {
                        e.x = map.enemy[ene].x;
                        e.y = map.enemy[ene].y;
                    }
                }
            }
            if (!isNaN(e.life)) {
                e.life -= (accum * 30) / 1000;
                if (e.life <= 0) {
                    if (e.type === 'enemyobstacle') {
                        // remove obstacle
                        map.obstacles.forEach((o, ind) => {
                            if (o.enemyChildId === e.obstacleParentId) {
                                map.obstacles.splice(ind, 1);
                            }
                        });
                    }
                    map.enemy.splice(ind, 1);
                }
            }

            if (e.effectorIds) {
                // resetting enemy param mults
                for (let eid of e.effectorIds) {
                    const ob = map.obstacles[eid];
                    e[ob.effectParam] /= ob.multiply;
                }
                delete e.effectorIds;
            }
        });
        runEnemyCollision(
            [],
            map.enemy,
            map.obstacles,
            map.safes,
            map.npcs || []
        );
        if (singleReset) {
            // special case
            for (let j in map.enemy) {
                if (map.enemy[j].baseRadius != undefined) {
                    map.enemy[j].radius = map.enemy[j].baseRadius;
                    map.enemy[j].baseRadius = undefined;
                }
            }
        }
        // const keys = getPlayersInMap(map).map((player) => player.id);
        const keys = getPlayersInMap(map).map((player) => player.id);
        // bot simulate
        for (let ind = 0; ind < keys.length; ind++) {
            let i = keys[ind];
            // console.log(bots) //i fixed its includes bruh wth include is a funtion
            if (include(bots, i)) {
                let nid = null;
                let nearestDist = null;
                for (let jd = 0; jd < keys.length; jd++) {
                    let j = keys[jd];
                    // if (ind >= jd) continue;
                    if (include(bots, j)) continue;
                    // console.log('a real player', j)
                    if (
                        nid === null ||
                        dist(
                            players[i].x,
                            players[j].x,
                            players[i].y,
                            players[j].y
                        ) < nearestDist
                    ) {
                        // console.log(i, j, players[i], players[j])
                        nearestDist = dist(
                            players[i].x,
                            players[j].x,
                            players[i].y,
                            players[j].y
                        );
                        nid = j;
                    }
                }
                if (nid != null) {
                    // console.log(nearestDist)
                    const angle = Math.atan2(
                        players[nid].y - players[i].y,
                        players[nid].x - players[i].x
                    );
                    if (
                        players[i].xv === undefined ||
                        players[i].yv === undefined
                    ) {
                        players[i].xv = 0;
                        players[i].yv = 0;
                    }
                    players[i].xv += Math.cos(angle) * 0.3;
                    players[i].yv += Math.sin(angle) * 0.3;
                    players[i].xv *= 0.95;
                    players[i].yv *= 0.95;
                    players[i].clientX += players[i].xv;
                    players[i].clientY += players[i].yv;
                }
            }
        }
        // normal players
        for (let i = 0; i < keys.length; i++) {
            const player1 = players[keys[i]];
            for (let j = 0; j < keys.length; j++) {
                const player2 = players[keys[j]];
                if (!player1.powerups.amogus && !player2.powerups.amogus) {
                    if (i >= j) continue;
                } else if (i === j) {
                    continue;
                }
                if (player1.is3D) {
                    // axis are different in 3d
                    if (
                        !intersectingCircle(
                            { ...player1, y: player1.z },
                            { ...player2, y: player2.z }
                        )
                    )
                        continue;
                } else {
                    if (!intersectingCircle(player1, player2)) continue;
                }
                if (player1.map.startsWith('Minigames')) continue;
                if (player1.powerups.amogus || player2.powerups.amogus) {
                    if (player1.powerups.amogus) {
                        player2.die();
                        send(player2.id, {
                            dead: true,
                        });
                    }
                    if (player2.powerups.amogus) {
                        player1.die();
                        send(player1.id, {
                            dead: true,
                        });
                    }
                } else if (player1.dead || player2.dead) {
                    if (player1.dead && !player2.dead) {
                        send(keys[i], {
                            revive: true,
                        });
                        player1.dead = false;
                    } else if (player2.dead && !player1.dead) {
                        send(keys[j], {
                            revive: true,
                        });
                        player2.dead = false;
                    }
                    broadcast({
                        leaderboardChanged: true,
                        ...packLeaderboard(),
                    });
                } /*else if(intersectingCircle(player1, player2) && player1.map == 'Minigames') {
                    if(tagCooldown < 0){
                        tagCooldown = 500;
                        if(player1.tagged){
                            player1.tagged = false;
                            for(let j in players){
                                send(players[j].id, {
                                    tagged: false,
                                    id: player1.id,
                                });
                            }
                            player2.tagged = true;
                            for(let j in players){
                                send(players[j].id, {
                                    tagged: true,
                                    id: player2.id,
                                });
                            }
                        } else if(player2.tagged){
                            player1.tagged = true;
                            for(let j in players){
                                send(players[j].id, {
                                    tagged: true,
                                    id: player1.id,
                                });
                            }
                            player2.tagged = false;
                            for(let j in players){
                                send(players[j].id, {
                                    tagged: false,
                                    id: player2.id,
                                });
                            }
                        }
                    } else {
                        tagCooldown -= accum;
                    }
                }*/
            }
        }
    }
}

function ServerTick() {
    global.delta = Date.now() - lastTs;
    accum += Date.now() - lastTs;
    lastTs = Date.now();

    while (accum >= 1000 / updateRate) {
        runPhysics();
        accum -= 1000 / updateRate;
    }

    const toDel = [];
    for (let i = chatMessages.length - 1; i >= 0; i--) {
        const data = chatMessages[i];
        if ((Date.now() - data.time) / 1000 > chatSaveTime) {
            toDel.push(i);
        }
    }
    toDel.forEach((i) => {
        chatMessages.splice(i, 1);
    });

    for (const playerId of Object.keys(players)) {
        players[playerId].update();
    }

    // generate a state object for each world/map (outdated)
    // now i just use chan

    for (const mapId of Object.keys(loadedMaps)) {
        const map = loadedMaps[mapId];
        const keys = getPlayersInMap(map).map((player) => player.id);
        const changedPlayers = {};
        let deathChangeArr = [];
        for (const id of keys) {
            const player = players[id];
            if (
                lastSnapshot != undefined &&
                lastSnapshot.players[id] != undefined &&
                isDifferent(player.pack(), lastSnapshot.players[id])
            ) {
                const res = {
                    ...player.differencePack(lastSnapshot.players[id]),
                };
                if (player.deathchange) {
                    res.deathchange = true;
                }
                changedPlayers[id] = res;
            }

            player.deathchange = false;
        }
        if (Object.keys(changedPlayers).length > 0) {
            for (const id of keys) {
                send(id, {
                    u: true,
                    p: changedPlayers,
                });
            }
        }

        // getting all clones in all players
        let totalClones = [];
        for (let i in players) {
            totalClones.push(players[i].clones);
        }
        for (let i in players) {
            let sendclones = false;
            for (let clone of totalClones) {
                if (clone.length > 0) {
                    sendclones = true;
                    break;
                }
            }
            if (sendclones) {
                send(players[i].id, {
                    uc: true,
                    clonePos: totalClones.filter((c) => c.length > 0),
                });
            }
        }
    }
    if (loadedMaps['Minigames']) runMinigames1();
    if (loadedMaps['Minigames2']) runMinigames2();
    if (loadedMaps['Minigames3']) runMinigames3();
    lastSnapshot = {
        players: {},
    };
    Object.keys(players).forEach((id) => {
        lastSnapshot.players[id] = players[id].pack();
    });
    // poie noise
    if (loadedMaps['PoIE'] !== undefined) {
        for (let i in players) {
            if (players[i].map == 'PoIE') {
                if (
                    Math.round(players[i].x) == 4875 &&
                    Math.round(players[i].y) == 25
                ) {
                    send(players[i].id, {
                        renderNoise: true,
                    });
                } else if (players[i].y >= 3425) {
                    if (players[i].x > 9500) {
                        send(players[i].id, {
                            renderGlitch: 'hyper',
                        });
                    } else {
                        send(players[i].id, {
                            renderGlitch: true,
                        });
                    }
                }
            }
        }
    }
    frames++;
}

function runMinigames2(clientId) {
    // duels
    inDuels2 = false;
    let lastInCrusher = inCrusher;
    inCrusher = false;
    for (let i in players) {
        if (players[i].map == 'Minigames2' && !players[i].dead) {
            if (players[i].x > 2500 && players[i].y < 1500) {
                inDuels2 = true;
            } else if (players[i].x < 1250 && players[i].y > 2750) {
                inCrusher = true;
                if (lastInCrusher == false) {
                    // send crusher obs to all new players
                    for (let j in players) {
                        if (players[j].map == 'Minigames2') {
                            send(players[j].id, {
                                add: {
                                    x: 50,
                                    y: 2800,
                                    w: 100,
                                    h: 1150,
                                    type: 'lavamove',
                                    currentPoint: 0,
                                    points: [
                                        [50, 2800],
                                        [500, 2800],
                                    ],
                                    speed: 15,
                                    collidable: true,
                                    id: 'Crusher',
                                },
                            });
                            send(players[j].id, {
                                add: {
                                    x: 1100,
                                    y: 2800,
                                    w: 100,
                                    h: 1150,
                                    type: 'lavamove',
                                    currentPoint: 0,
                                    points: [
                                        [1100, 2800],
                                        [650, 2800],
                                    ],
                                    speed: 15,
                                    collidable: true,
                                    id: 'Crusher',
                                },
                            });
                            send(players[j].id, {
                                add: {
                                    x: 50,
                                    y: 2800,
                                    w: 1150,
                                    h: 100,
                                    type: 'lavamove',
                                    currentPoint: 0,
                                    points: [
                                        [50, 2800],
                                        [50, 3250],
                                    ],
                                    speed: 15,
                                    collidable: true,
                                    id: 'Crusher',
                                },
                            });
                            send(players[j].id, {
                                add: {
                                    x: 50,
                                    y: 3850,
                                    w: 1150,
                                    h: 100,
                                    type: 'lavamove',
                                    currentPoint: 0,
                                    points: [
                                        [50, 3850],
                                        [50, 3400],
                                    ],
                                    speed: 15,
                                    collidable: true,
                                    id: 'Crusher',
                                },
                            });
                        }
                    }
                }
            }
        }
    }

    if (loadedMaps['Minigames2'] !== undefined) {
        // random thing about resetting timer if player is in the center ;-;
        for (let i in players) {
            if (
                players[i].map == 'Minigames2' &&
                players[i].x > 1800 &&
                players[i].x < 2200 &&
                players[i].y > 1800 &&
                players[i].y < 2200
            ) {
                send(players[i].id, {
                    resetTimer: true,
                });
            } else if (players[i].map == 'Minigames2') {
                send(players[i].id, {
                    resetTimer: false,
                });
            }
        }
    }

    if (inDuels2) {
        lastDuelsState2 = true;
        duelsTimer2 -= 1 / tickRate;
        closeDuelsTimer2 += accum;
        if (duelsTimer2 < 0) {
            // duelsTimer += 1.5;
            duelsTimer2 += 3;
            new Spawner(2500, 0, 1500, 1500, {
                type: 'spawn',
                amount: 1,
                radius: 24,
                speed: Math.random() * 40 + 60,
                spawnTime: 1,
                spawnParams: {
                    type: 'normal',
                    radius: 12,
                    speed: 240,
                    life: 160,
                },
            }).spawn(duelsEnemies2);
            duelsEnemies2[duelsEnemies2.length - 1].angle =
                Math.random() * Math.PI * 2;
            duelsEnemies2[duelsEnemies2.length - 1].xv =
                Math.cos(duelsEnemies2[duelsEnemies2.length - 1].angle) *
                duelsEnemies2[duelsEnemies2.length - 1].speed;
            duelsEnemies2[duelsEnemies2.length - 1].yv =
                Math.sin(duelsEnemies2[duelsEnemies2.length - 1].angle) *
                duelsEnemies2[duelsEnemies2.length - 1].speed;
            let wallNum = Math.floor(Math.random() * 3);
            if (wallNum == 0) {
                duelsEnemies2[duelsEnemies2.length - 1].x =
                    2500 + duelsEnemies2[duelsEnemies2.length - 1].radius;
            } else if (wallNum == 1) {
                duelsEnemies2[duelsEnemies2.length - 1].x =
                    4000 - duelsEnemies2[duelsEnemies2.length - 1].radius;
            } else if (wallNum == 2) {
                duelsEnemies2[duelsEnemies2.length - 1].y =
                    duelsEnemies2[duelsEnemies2.length - 1].radius;
            } else {
                duelsEnemies2[duelsEnemies2.length - 1].y =
                    1500 - duelsEnemies2[duelsEnemies2.length - 1].radius;
            }
            loadedMaps['Minigames2'].enemy.push(
                duelsEnemies2[duelsEnemies2.length - 1]
            );
            for (let i in players) {
                if (players[i].map == 'Minigames2') {
                    send(players[i].id, {
                        addenemy: [duelsEnemies2[duelsEnemies2.length - 1]],
                    });
                }
            }
        }
    } else if (lastDuelsState2 == true) {
        // if we just closed duels
        closeDuelsTimer2 = 0;
        for (let i in players) {
            if (players[i].map == 'Minigames2') {
                send(players[i].id, {
                    removeallenemies: true,
                });
                send(players[i].id, {
                    removeallenemies: true,
                });
            }
        }
        loadedMaps['Minigames2'].enemy = [];
        duelsEnemies2 = [];
        lastDuelsState2 = false;
    }

    if (inCrusher) {
        crusherTimer += accum;
    } else if (lastInCrusher == true) {
        crusherTimer = 0;
        for (let i in players) {
            if (players[i].map == 'Minigames2') {
                send(players[i].id, {
                    removeById: 'Crusher',
                });
                send(players[i].id, {
                    removeById: 'Crusher',
                });
                send(players[i].id, {
                    removeById: 'Crusher',
                });
                send(players[i].id, {
                    removeById: 'Crusher',
                });
            }
        }
    }
}

let mg1countdownRunning = false;
let mg1waitTime = 10;
let mg1countTimer = 10;
let mg1raceBuffer = 0;

function runMinigames1() {
    // duels
    inDuels = false;
    for (let i in players) {
        if (
            players[i].map == 'Minigames' &&
            players[i].x < 1000 &&
            players[i].y < 1000 &&
            !players[i].dead
        ) {
            inDuels = true;
        }
    }

    //racing
    let playersWaiting = 0;
    let playerIds = [];
    for (const player of Object.values(players)) {
        if (
            player.map === 'Minigames' &&
            player.x > 3400 &&
            player.y > 0 &&
            player.x < 4000 &&
            player.y < 600
        ) {
            playersWaiting++;
            playerIds.push(player.id);
        }
    }
    if (playersWaiting >= 2 && !mg1countdownRunning) {
        mg1countdownRunning = true;
        mg1countTimer = mg1waitTime;
        const map = 'Minigames';
        for (const player of Object.values(players)) {
            if (player.map === map) {
                send(player.id, {
                    mg1countdownStart: mg1countTimer,
                });
            }
        }
    }
    if (mg1countdownRunning) {
        mg1countTimer -= global.delta / 1000;
        if (mg1countTimer <= -mg1raceBuffer) {
            mg1countdownRunning = false;
        }
    }

    if (loadedMaps['Minigames'] !== undefined) {
        let lastShouldLoadDuelsPortal = shouldLoadDuelsPortal;
        if (inDuels && closeDuelsTimer < 5000) {
            shouldLoadDuelsPortal = true;
        } else if (!inDuels) {
            shouldLoadDuelsPortal = true;
        } else {
            shouldLoadDuelsPortal = false;
        }
        if (lastShouldLoadDuelsPortal !== shouldLoadDuelsPortal) {
            if (shouldLoadDuelsPortal) {
                for (let i in players) {
                    if (players[i].map == 'Minigames') {
                        send(players[i].id, {
                            add: {
                                x: 1850,
                                y: 1850,
                                w: 50,
                                h: 125,
                                type: 'tp',
                                tpx: 500,
                                tpy: 500,
                                id: 'duelsTp',
                            },
                        });
                        send(players[i].id, {
                            add: {
                                x: 1900,
                                y: 1850,
                                w: 75,
                                h: 50,
                                type: 'tp',
                                tpx: 500,
                                tpy: 500,
                                id: 'duelsTp',
                            },
                        });
                    }
                }
            } else {
                for (let i in players) {
                    if (players[i].map == 'Minigames') {
                        send(players[i].id, {
                            removeById: 'duelsTp',
                        });
                        send(players[i].id, {
                            removeById: 'duelsTp',
                        });
                    }
                }
                //console.log('Duels Closed!');
            }
        }
        // random thing about resetting timer if player is in the center ;-;
        for (let i in players) {
            if (
                players[i].map == 'Minigames' &&
                players[i].x > 1900 &&
                players[i].x < 2100 &&
                players[i].y > 1900 &&
                players[i].y < 2100
            ) {
                send(players[i].id, {
                    resetTimer: true,
                });
            } else if (players[i].map == 'Minigames') {
                send(players[i].id, {
                    resetTimer: false,
                });
            }
        }
    }

    if (inDuels) {
        lastDuelsState = true;
        duelsTimer -= 1 / tickRate;
        closeDuelsTimer += accum;
        if (duelsTimer < 0) {
            // duelsTimer += 1.5;
            duelsTimer += 1;
            //loadedMaps['Minigames'].enemy.push(new Spawner(0, 0, 1000, 1000, { type: 'normal', amount: 1, radius: 12, speed: 80}).spawn(loadedMaps['Minigames'].enemy));
            new Spawner(0, 0, 1000, 1000, {
                type: 'accelerating',
                amount: 1,
                radius: 8 + Math.random() * 30,
                speed: Math.random() * 60 + 90,
                accelAmount: Math.random() * 1.2 + 1.2,
            }).spawn(duelsEnemies);
            duelsEnemies[duelsEnemies.length - 1].angle =
                Math.random() * Math.PI * 2; // <- creating enemies
            duelsEnemies[duelsEnemies.length - 1].xv =
                Math.cos(duelsEnemies[duelsEnemies.length - 1].angle) *
                duelsEnemies[duelsEnemies.length - 1].speed;
            duelsEnemies[duelsEnemies.length - 1].yv =
                Math.sin(duelsEnemies[duelsEnemies.length - 1].angle) *
                duelsEnemies[duelsEnemies.length - 1].speed;
            let wallNum = Math.floor(Math.random() * 3);
            if (wallNum == 0) {
                duelsEnemies[duelsEnemies.length - 1].x =
                    duelsEnemies[duelsEnemies.length - 1].radius;
            } else if (wallNum == 1) {
                duelsEnemies[duelsEnemies.length - 1].x =
                    1000 - duelsEnemies[duelsEnemies.length - 1].radius;
            } else if (wallNum == 2) {
                duelsEnemies[duelsEnemies.length - 1].y =
                    duelsEnemies[duelsEnemies.length - 1].radius;
            } else {
                duelsEnemies[duelsEnemies.length - 1].y =
                    1000 - duelsEnemies[duelsEnemies.length - 1].radius;
            }
            loadedMaps['Minigames'].enemy.push(
                duelsEnemies[duelsEnemies.length - 1]
            );
            for (let i in players) {
                if (players[i].map == 'Minigames') {
                    send(players[i].id, {
                        addenemy: [duelsEnemies[duelsEnemies.length - 1]],
                    });
                }
            }
        }
    } else if (lastDuelsState == true) {
        // if we just closed duels
        closeDuelsTimer = 0;
        for (let i in players) {
            if (players[i].map == 'Minigames') {
                send(players[i].id, {
                    removeallenemies: true,
                });
                send(players[i].id, {
                    removeallenemies: true,
                });
            }
        }
        loadedMaps['Minigames'].enemy = [];
        duelsEnemies = [];
        lastDuelsState = false;
    }

    // survival
    inSurvival = false;
    if (loadedMaps['Minigames'] !== undefined) {
        for (let i in players) {
            if (
                players[i].map == 'Minigames' &&
                players[i].x > 2150 &&
                players[i].y > 2000
            ) {
                inSurvival = true;
            }
        }
    }
    if (inSurvival) {
        survivalTimer += accum;
        if (survivalTimer >= survivalWaves[survivalWave].time) {
            let lastSurvivalWave = survivalWave;
            survivalTimer = 0;
            survivalWave++;
            if (survivalWave >= survivalWaves.length) {
                survivalWave = 0;
            }
            // new wave, so delete prev obstacles and send new ones :D
            for (let i in players) {
                if (players[i].map == 'Minigames') {
                    for (
                        let j = 0;
                        j < survivalWaves[lastSurvivalWave].obstacles.length;
                        j++
                    ) {
                        send(players[i].id, {
                            removeById: 'survival',
                        });
                    }
                    send(players[i].id, {
                        add: survivalWaves[survivalWave].obstacles,
                    });
                }
            }
        }
    } else {
        survivalWave = 0;
        survivalTimer = 0;
        for (let i in players) {
            if (players[i].map == 'Minigames') {
                send(players[i].id, {
                    removeById: 'survival',
                });
            }
        }
    }

    // tag
    if (loadedMaps['Minigames'] !== undefined) {
        if (!tagStarted) {
            for (let i in players) {
                if (
                    players[i].map == 'Minigames' &&
                    players[i].x < 1550 &&
                    players[i].y > 3150
                ) {
                    players[i].tagged = true;
                    for (let j in players) {
                        send(players[j].id, {
                            tagged: true,
                            id: i,
                        });
                    }
                    tagStarted = true;
                    return;
                }
            }
        } else {
            // starting tag over if needed
            let toRestartTag = true;
            for (let i in players) {
                if (players[i].tagged) {
                    toRestartTag = false;
                }
            }
            if (toRestartTag) {
                tagStarted = false;
            }
        }
    }
}

function runMinigames3() {
    // simulating collision for pong obs
    for (let i in players) {
        if (!clients[i]) continue;
        const pongObs =
            loadedMaps['Minigames3'].obstacles[
                loadedMaps['Minigames3'].obstacles.length - 1
            ];
        const pping = clients[i].clientPing || 0;
        if (!players[i].lastX) {
            players[i].lastX = players[i].x;
        }
        if (!global.lastDelta) {
            global.lastDelta = 0;
        }
        const xv = players[i].x - players[i].lastX;
        let predictedPlayer = {
            x: players[i].x + (pping * xv * global.delta) / global.lastDelta,
            y: players[i].y,
        };
        players[i].lastX = players[i].x;
        if (
            Math.sqrt(
                (predictedPlayer.x - pongObs.x) ** 2 +
                    (predictedPlayer.y - pongObs.y) ** 2
            ) <
            players[i].radius + pongObs.radius
        ) {
            if (players[i].y > 5700) {
                loadedMaps['Minigames3'].obstacles[
                    loadedMaps['Minigames3'].obstacles.length - 1
                ].yv = -Math.abs(pongObs.yv);
            } else {
                loadedMaps['Minigames3'].obstacles[
                    loadedMaps['Minigames3'].obstacles.length - 1
                ].yv = Math.abs(pongObs.yv);
            }
            for (const playerId of Object.keys(players)) {
                if (players[playerId].map === 'Minigames3') {
                    send(playerId, {
                        pong: {
                            x: pongObs.x,
                            y: pongObs.y,
                            xv: pongObs.xv,
                            yv: pongObs.yv,
                        },
                    });
                }
            }
        }
        global.lastDelta = global.delta;
    }
}

String.prototype.safe = function () {
    return this.replace(/&/g, '&amp;')
        .replace(/ /g, '&nbsp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
};


// src/client/game.js

function loadDifficultyImage(difficulty) {
    window.difficultyImages[difficulty] = new Image();
    window.difficultyImages[difficulty].src = `./gfx/${difficulty}.png`;
}

let leaderboard = undefined;

window.canvas = document.querySelector('.canvas');
window.ctx = canvas.getContext('2d');
window.shadowCanvas = document.createElement('canvas');
window.in3D = false;
// shadowCanvas.classList.add('canvas')
window.sctx = shadowCanvas.getContext('2d');

window.rayCanvas = document.createElement('canvas');
window.rctx = rayCanvas.getContext('2d');

window.gunslingerCursors = [];

window.ghostOpaq = 0.25;

window.dimensions = 2;
window.cameraZoom = 400;

if (ref.editorFrame) {
	ref.editorFrame._scaleMult = 0.9;
}

window.bgImg = new Image();
window.bgImg.src = './gfx/gameBackground.png';
window.backgroundPattern = ctx.createPattern(window.bgImg, 'repeat');

// document.body.appendChild(shadowCanvas)

// window.smokeCanvas = document.querySelector('.smokeCanvas')
// window.ctx2 = smokeCanvas.getContext('2d');
// let party = smokemachine(ctx2, [0, 0, 0])
//           // party.start()
//           party.setPreDrawCallback(function(dt){
// 	          party.addSmoke(Math.random() * innerWidth, Math.random() * innerHeight, 5)
//           })
// window.gameScale = 0;
window.scale = resize([
    canvas,
    window.shadowCanvas,
    ref.gui,
    rayCanvas,
    ref.editorFrame,
]);
window.mobile = checkMobile();

// submit function
if (mobile) {
    ref.chat.addEventListener('keyup', function (event) {
        event.preventDefault();
        if (event.keyCode === 13) {
            trackKeys(
                { repeat: false, code: 'Enter', type: 'keydown' },
                input,
                true
            );
        }
    });
}
window.useMouse = false;
window.timers = [];

window.muted = []; // muted players

window.shouldRender = false;
window.showHat = true;
// bro what
window.glitchEffects = [];
window.renderGlitch = false;

window.unreadpings = 0;

window.raycastvision = false;

window.videos = [];

window.upArrowImage = new Image();
window.upArrowImage.src = './gfx/upArrow.png';
window.downArrowImage = new Image();
window.downArrowImage.src = './gfx/downArrow.png';
window.leftArrowImage = new Image();
window.leftArrowImage.src = './gfx/leftArrow.png';
window.rightArrowImage = new Image();
window.rightArrowImage.src = './gfx/rightArrow.png';
window.nothingToSeeHere = new Image();
window.nothingToSeeHere.src = './gfx/shh.png';

// conveyor images
window.onload = function () {
    window.leftConveyorImage = generateConveyorImage(
        window.leftArrowImage,
        canvas
    );
    window.rightConveyorImage = generateConveyorImage(
        window.rightArrowImage,
        canvas
    );
    window.downConveyorImage = generateConveyorImage(
        window.downArrowImage,
        canvas
    );
    window.upConveyorImage = generateConveyorImage(window.upArrowImage, canvas);
    // window.backgroundPattern = ctx.createPattern(window.bgImg, 'repeat')
}; // hope it works D:
// ok
// still doenst work ;-;

window.skull = new Image();
window.skull.src = './gfx/skull.png';

window.bouncyImage = new Image();
window.bouncyImage.src = './gfx/bouncyEnemy.png';

window.noiseImage = new Image();
window.noiseImage.src = './gfx/red noise.png';
window.renderNoise = false;

window.difficultyImages = {};
loadDifficultyImage('Peaceful');
loadDifficultyImage('Moderate');
loadDifficultyImage('Difficult');
loadDifficultyImage('Hardcore');
loadDifficultyImage('Exhausting');
loadDifficultyImage('Relentless');
loadDifficultyImage('Agonizing');
loadDifficultyImage('Terrorizing');
loadDifficultyImage('Cataclysmic');
loadDifficultyImage('Grass');

window.scaleChanged = false;

window.recordInputs = false;
window.recordedInputs = [];

window.runGame = function (data) {
    // this is what happens when the player enters the game

    send({ ping: Date.now() });

    document.querySelector('.grecaptcha-badge').style.display = 'none';
    window.spectating = false;
    window.spectateId = null;
    window.showPos = false;

    window.fps = 60; // example fps
    window.times = [];

    window.showServer = false;
    //   window.speedhack = 1;
    window.loaded = false;
    document.fonts.ready.then(function () {
        console.log(
            'finished loading fonts in ',
            Math.round(window.performance.now()),
            'ms'
        );
        window.loaded = true;
    });

    window.lineWidth = 2;

    window.showMinimap = true;

    window.debug = {
        updateTime: 0,
        updateTimeD: 0,
        renderTime: 0,
        renderTimeD: 0,
        ping: undefined,
        rendered: 0,
        sentTimes: 0,
        sentTimeD: 0,
        fpsDisplay: fps,
        cTests: [0, 0],
        cTestRender: [0, 0],
        frameDisplay: 0,
        serverFps: 0,
    };
    window.backgroundColor = data.bgColor;
    window.tileColor = data.tileColor;
    // window.backgroundColor = '#1f2229';
    // window.tileColor = '#323645';
    // document.body.style.backgroundColor = backgroundColor//'black';
    window.debugMode = false;
    window.showTimer = false;
    window.selfId = data.selfId;
    window.players = {};
    window.enemy = [];
    window.safes = [];
    let npcs = [];
    let texts = [];
    window.obstacles = [];
    window.portals = [];
    window.chatOpen = false;
    window.ior = 1;
    window.iir = 1;
    window.io = 1;
    window.vc = { r: 0, g: 0, b: 0 };
    // akeraking test
    window.firstPointX = undefined;
    window.firstPointY = undefined;
    window.obsType = { type: 'normal' };
    window.snapDistance = 25;
    window.resetMusic = false;

    window.secondPointX = 100;
    window.secondPointY = 100;

    const updateRate = 120;
    window.accum = 0;
    window.renderScale = 1;

    window.ghostpushers = {};
    window.mypushers = [];
    window.lastpushers = [];

    let viewingStory = false;

    window.input = {
        down: false,
        left: false,
        up: false,
        right: false,
        shift: false,
        action: false,
        // 3d camera
        cup: false,
        cdown: false,
        cright: false,
        cleft: false,
    };
    console.log('initial data', data);

    for (const init of data.players) {
        players[init.id] = new Player(init);
    }

    for (const init of data.texts) {
        texts.push(init);
    }

    for (const init of data.enemy) {
        enemy.push(new Enemy(init));
    }

    for (const init of data.safes) {
        safes.push(new Safe(init));
    }

    for (const init of data.npcs) {
        npcs.push(new Npc(init));
    }

    for (const init of data.obstacles) {
        let obstacle = init;
        if (obstacle.type === 'portal') {
            portals.push(init);
        } else {
            obstacles.push(init);
        }
    }

    window.darkness = 0.5;

    window.lighting = 0; //.75;
    window.arena = { width: data.arena.width, height: data.arena.height };
    window.camera = { x: 0, y: 0 };
    window.xoff = 0;
    window.yoff = 0;
    window.mouse = { x: canvas.width / 2, y: canvas.height / 2 };

    window.time = 0;

    // what happens when the player joins the game

    window.offset = function (x, y) {
        return {
            x: x - camera.x + canvas.width / 2 + xoff,
            y: y - camera.y + canvas.height / 2 + yoff,
        };
    };

    window.inverseOffset = function (x, y) {
        return {
            x: x + camera.x - canvas.width / 2 - xoff,
            y: y + camera.y - canvas.height / 2 - yoff,
        };
    };

    window.offsetX = function (x) {
        return offset(x, 0).x;
    };

    window.offsetY = function (y) {
        return offset(0, y).y;
    };

    window.init = true;
    window.timer = 0;
    window.shouldUpdateTimer = false;
    // window.map = data.map;
    window.world = data.world;

    // zone animation stuff
    window.zoneT = 0;
    window.zoneAnim = false;

    window.otherClones = [];

    window.mg1countdownStart = false;
    window.mg1countTimer = 0;

    // computeLines()
    window.scale = resize([
        canvas,
        shadowCanvas,
        ref.gui,
        rayCanvas,
        ref.editorFrame,
    ]);

    ref.chatMessageDiv.addEventListener('mousedown', (e) => {
        e.stopPropagation();
    });

    window.processGameMessage = (data) => {
		console.log(data)
        if (data.leaderboardChanged) {
            leaderboard = data.playerData; // [ [id, map, name ] ]
            // render on leaderboard
            const maps = leaderboard.map((p) => p[1]);
            let uniqueMaps = {};
            maps.forEach((map, i) => {
                if (uniqueMaps[map] == undefined) {
                    uniqueMaps[map] = [leaderboard[i]];
                } else {
                    uniqueMaps[map].push(leaderboard[i]);
                }
            });
            //console.log(uniqueMaps);
            ref.lb.innerHTML = '';
            for (const map of Object.keys(uniqueMaps)) {
                let playerStr = '';
                for (const [id, _, name, dead, color, zone] of uniqueMaps[
                    map
                ]) {
                    playerStr += `
						<div>
							<span ${
                                dead ? `style="opacity: 0.4;"` : ''
                            }><span class="player-name">${name.safe()}</span> [<span class="player-zone">${zone}</span>]${
                        window.muted.includes(name.safe())
                            ? ' <span style="color: red; font-family: Inter-Thick;">[MUTED]</span>'
                            : ''
                    }</span>
						</div>
					`;
                }
                //console.log('color', uniqueMaps[map][0][4])
                ref.lb.innerHTML += `
					<div class="lb-group">
						<span class="lb-name" style="color: ${uniqueMaps[map][0][4]} !important;">${map}</span>
						<div class="lb-players">
							${playerStr}
						</div>
					</div>
				`;
            }
            window.lastpdata = data.playerData;
            // important for muting/ unmuting idk
        }
        if (data.resetTimer !== undefined) {
            if (!data.resetTimer) {
                if (me().dead) {
                    shouldUpdateTimer = false;
                } else {
                    shouldUpdateTimer = true;
                }
            } else {
                timer = 0;
                shouldUpdateTimer = false;
            }
        }
        if (data.zone != undefined) {
            // new zone animation
            // if (zoneT > 0 && zoneAnim) {
            // 	// oh no
            // 	console.log('oh no whats happening', zoneT, zoneAnim)
            // }
            zoneT = window.performance.now();
            zoneAnim = true;
            // console.log(data.zone, zoneT, zoneAnim)
        }
        if (data.removePlayer) {
            if (window.dimensions === 3) {
                console.log(data.data);
                remove3Dplayer(data.data);
            }
            delete players[data.data];
            if (gunslingerCursors[data.data])
                delete gunslingerCursors[data.data];
        }
        if (data.ghostpusher) {
            let obs;
            for (let o of obstacles) {
                if (
                    o.pusherId === data.ghostpusher.pusherId &&
                    (o.type === 'push' || o.type === 'pushbox')
                ) {
                    obs = o;
                }
            }
            if (obs !== null) {
                window.ghostpushers[data.ghostpusher.pusherId+data.ghostpusher.playerId] = { ...obs, ...data.ghostpusher };
            }
        }
        if (data.setghostpushers) {
            window.ghostpushers = {};
            for(let i of Object.keys(data.setghostpushers)){
                let obs;
                for (let o of obstacles) {
                    if (
                        o.pusherId === data.setghostpushers[i].pusherId &&
                        (o.type === 'push' || o.type === 'pushbox')
                    ) {
                        obs = o;
                    }
                }
                window.ghostpushers[i] = { ...obs, ...data.setghostpushers[i] };
            }
        }
        if (data.removeghostpusher){
            delete window.ghostpushers[data.removeghostpusher];
        }
        if (data.tailbite) {
            players[data.id].powerups.dragon.hp--;
            players[data.id].biteAnimTimer = 0.5;
            if (me().id == data.id) {
                if (me().powerups.dragon.hp <= 0) {
                    me().dead = true;
                    send({ dead: true });
                    send({ respawn: true });
                    me().powerups.dragon.state = false;
                    me().powerups.dragon.hp = 10; // max
                    send({ powerups: me().powerups });
                } else {
                    // knockback if it isnt fatal
                    let mouseAngle =
                        (Math.atan2(
                            mouse.y - canvas.height / 2,
                            mouse.x - canvas.width / 2
                        ) +
                            Math.PI / 2) %
                        (Math.PI * 2);
                    me().xv += Math.cos(mouseAngle) * 5;
                    me().yv += Math.sin(mouseAngle) * 5;
                }
            }
        }
        if (data.pong) {
            const last = obstacles.length - 1;
            obstacles[last].x = data.pong.x;
            obstacles[last].y = data.pong.y;
            obstacles[last].xv = data.pong.xv;
            obstacles[last].yv = data.pong.yv;
        }
        if (data.dead) {
            me().dead = true;
            send({ dead: true });
            me().powerups.gun.state = false;
            send({ powerups: me().powerups });
            me().powerups.gunslinger = false;
            send({ gsc: 'clear' });
        }
        if (data.bounce) {
            bouncePlayers(me(), players[data.id], data.effect);
        }
        if (data.renderNoise) {
            window.renderNoise = 1;
        }
        if (data.renderGlitch !== undefined) {
            window.renderGlitch = data.renderGlitch;
        }
        if (data.mg1countdownStart != undefined) {
            mg1countdownStart = true;
            mg1countTimer = data.mg1countdownStart - debug.ping / 1000;
        }
        if (data.killEnemy) {
            enemy[data.id].deadTimer = 3;
        }
        if (data.gsc) {
            if (data.gsc == 'clear') {
                delete gunslingerCursors[data.id];
            } else {
                gunslingerCursors[data.id] = data.gsc;
            }
        }
        if (data.respawned) {
            me().x = data.x;
            me().y = data.y;
            if (data.z) {
                me().z = data.z;
            }
            // me().xv = 0;
            // me().yv = 0;
            me().respawn();
            me().clones = [];
            send({ clonePos: [] });
            me().renderRadius = me().radius / 4;
            camera.x = data.x;
            camera.y = data.y;
            me().isTyping = false;
            me().currentChar = 0;
            me().ship = false;
            me().powerups = {
                inv: 0,
                gun: {
                    state: false,
                    angle: 0,
                    currentCooldown: 0.3,
                    maxCooldown: 0.3,
                    speed: 300,
                    radius: 30,
                    life: 3,
                    type: 'normal',
                },
                dragon: {
                    state: false,
                    hp: 10,
                    angle: 0,
                },
                amogus: false,
                gunslinger: false,
                grapple: {
                    direction: 0,
                    state: false,
                    grappling: false,
                    length: 0,
                    originalLength: 0,
                    x: 0,
                    y: 0,
                },
            };
            for (let o in obstacles) {
                if (obstacles[o].type == 'typing') {
                    obstacles[o].currentChar = 0;
                    obstacles[o].active = true;
                }
                if (obstacles[o].type == 'mashing') {
                    obstacles[o].currentNum = 0;
                    obstacles[o].active = true;
                }
            }
            console.log(`spawned at (${data.x}, ${data.y})`);
        }
        if (data.respawnId !== undefined && players[data.respawnId]) {
            players[data.respawnId].renderRadius =
                players[data.respawnId].radius / 4;
            players[data.respawnId].x = data.teleport.x;
            players[data.respawnId].y = data.teleport.y;
            if (data.teleport.z) {
                players[data.respawnId].z = data.teleport.z;
            }
            players[data.respawnId].renderX = data.teleport.x;
            players[data.respawnId].renderY = data.teleport.y;
            if (data.teleport.z) {
                players[data.respawnId].renderZ = data.teleport.z;
            }
        }
        if (data.revive) {
            me().dead = false;
            me().clones = [];
            send({ clonePos: [] });
        }
        if (data.add) {
            if (Array.isArray(data.add)) {
                obstacles.push(...data.add);
            } else {
                obstacles.push(data.add);
            }
        }
        /*if(data.crowdbuttons){
            console.log(data.crowdbuttons);
            console.log('cb data');
            for(let i in data.crowdbuttons){
                triggerButtonEffects(data.crowdbuttons[i].id,obstacles);
                for(let j in obstacles){
                    if(obstacles[j].type == 'crowdbutton' && obstacles[j].id == data.crowdbuttons[i].id){
                        obstacles[j].active = true;
                        obstacles[j].timer = data.crowdbuttons[i].timer;
                    }
                }
            }
        }*/
        if (data.del) {
            obstacles.splice(data.del - 1, 1);
        }
        if (data.addenemy) {
            for (const init of data.addenemy) {
                enemy.push(new Enemy(init));
            }
        }
        // .mapChange rn lol
        // k this is bsaically what im gonna do anyawys
        // yea lol just model it after this or
        /*
		
		what im sending to player {
  mapChange: true,
  state: {
    players: [ [Object], [Object] ],
    enemy: [],
    safes: [],
    arena: { width: 1000, height: 1000 },
    texts: [],
    obstacles: [
      [Object], [Object],
      [Object], [Object],
      [Object], [Object],
      [Object]
    ],
    bgColor: '#710505',
    tileColor: '#af0d0d',
    safeColor: undefined
  }
}

*/
        // when come back? lol its almost 10 for me
        //{"arena":{"width":1000,"height":1000},"enemy":[],"safes":[],"spawns":[],"playerSpawn":{"x":50,"y":50},"name":"ZMT","longName":"Zero Map Test","tileColor":"#af0d0d","bgColor":"#710505","difficulty":"Grass","texts":[],"obstacles":[{"x":300,"y":300,"w":200,"h":200,"type":"normal"},{"x":500,"y":600,"w":50,"h":50,"type":"normal"},{"x":200,"y":600,"w":50,"h":200,"type":"normal"},{"x":600,"y":500,"w":200,"h":100,"type":"normal"},{"x":600,"y":150,"w":200,"h":150,"type":"lava"},{"x":300,"y":100,"w":150,"h":50,"type":"lava"},{"x":900,"y":900,"w":100,"h":100,"type":"lava"}]}
        if (data.mapChange != undefined) {
            // cyu :c
            //console.log(data)
            window.backgroundColor = data.state.bgColor;
            document.body.style.backgroundColor = data.state.bgColor;
            window.tileColor = data.state.tileColor;
            window.safeColor = data.state.safeColor;
            window.lighting = data.state.lighting || 0;
            window.raycastvision = data.state.renderRaycasting || false;
            window.enemy = [];
            window.safes = [];
            npcs = [];
            texts = [];
            window.obstacles = [];
            window.portals = [];
            me().coins = 0;
            for (const init of data.state.texts) {
                texts.push(init);
            }

            for (const init of data.state.enemy) {
                enemy.push(new Enemy(init));
            }

            for (const init of data.state.safes) {
                safes.push(new Safe(init));
            }

            for (const init of data.state.npcs) {
                npcs.push(new Npc(init));
            }

            for (const init of data.state.obstacles) {
                let obstacle = init;
                if (obstacle.type === 'portal') {
                    portals.push(init);
                } else {
                    obstacles.push(init);
                }
            }
            // console.log('arena', data.state.arena )

            window.arena = {
                width: data.state.arena.width,
                height: data.state.arena.height,
            };
            if (window.raycastvision) computeLines();
        }
        if (data.removeduelenemies) {
            enemy.forEach((e, i) => {
                if (e.type === 'accelerating') {
                    enemy.splice(i, 1);
                }
                //console.log('enemy removed: ' + i)
            });
        }
        if (data.removeallenemies) {
            enemy = [];
        }
        if (data.remove) {
            obstacles.pop();
        }
        if (data.replaceAllObstacles) {
            window.obstacles = data.replaceAllObstacles;
        }
        if (data.removeById) {
            obstacles.forEach(function (obs, index) {
                if (
                    obs.id &&
                    obs.id == data.removeById &&
                    obs.id != 'duelsTp2'
                ) {
                    window.obstacles.splice(index, 1);
                }
            });
        }
        if (data.u) {
            // update
            for (const id of Object.keys(data.p)) {
                // console.log(pack.id)
                players[id].setData(data.p[id]);
            }
        }
        if (data.tagged) {
            players[data.id].tagged = data.tagged;
        }
        if (data.uc) {
            // update clones
            for (let i of data.clonePos) {
                // for every clone
                if (data.clonePos !== undefined && data.clonePos !== null) {
                    window.otherClones = data.clonePos;
                    //console.log(window.otherClones);
                }
            }
            /*
            for(let i in players){
                send(players[i].id, {
                    uc: true,
                    clonePos: players[i].clones,
                })
                console.log(players.clones);
            }
            */
        }
        if (data.chat) {
            if (!window.muted.includes(data.name)) {
                const div = document.createElement('div');
                if (!data.system) {
                    div.classList.add('chat-message');
                } else {
                    div.classList.add('system-message');
                    if (data.difficulty != undefined) {
                        div.classList.add(data.difficulty.toLowerCase());
                    }
                }
                div.innerHTML = `${
                    data.system
                        ? '<span class="rainbow">[SERVER]</span>'
                        : data.dev
                        ? '<span class="rainbow">[DEV]</span> '
                        : ''
                }${
                    data.guest ? '<span class="guest">' : ''
                }${data.name.safe()}: ${data.msg.safe()}${
                    data.guest ? '</span>' : ''
                }`;
                if (div.innerHTML.includes('@')) {
                    const inds = [];

                    for (let ind = 0; ind < div.innerHTML.length; ind++) {
                        if (div.innerHTML[ind] === '@') {
                            inds.push(ind);
                        }
                    }
                    for (let i in inds) {
                        let mentionIndex = inds[i] + 1;
                        if (
                            div.innerHTML
                                .slice(
                                    mentionIndex,
                                    mentionIndex + me().name.length
                                )
                                .toLowerCase() == me().name.toLowerCase()
                        ) {
                            div.classList.add('mention');
                            unreadpings++;
                        }
                    }
                }
                ref.chatMessageDiv.appendChild(div);
                ref.chatMessageDiv.scrollTop = ref.chatMessageDiv.scrollHeight;
            }
            if (unreadpings > 0) {
                document.title = `Evades X (${unreadpings})`;
                ref.favicon.href = './pings/ping.png';
            }
        }
        if (data.pung != undefined) {
            // dis
            const halfRRT = Math.round((Date.now() - data.pung) / 2);
            if (debug.ping == undefined) {
                // when we get something from server, we send a ping request and then
                // we run physics ahead the ping / 2
                // helps with syncin g a lot so its not too insane
                // acutally it makes u go more out of sync
                // but if u have two tabs open, its very identical
                // like 200 ping vs 0ms its more out of sync
                // leeme test with two tabs first
                let a = halfRRT; // but like why doesn't it work for my case? ;-;
                runPhysics(a);

                // now lets detect if the world we are in is hub, if so, then dont start timer
                if (init) {
                    fade(() => {
                        shouldRender = true;
                        ref.menu.classList.add('hidden');
                        ref.game.classList.remove('hidden');

                        ref.chat.onblur = () => {
                            if (!window.mobile) {
                                chatOpen = false;
                            }
                        };

                        bg.play();

                        window.onmousedown = (e) => {
                            if (!ref.editorFrame.classList.contains('hidden')) {
                                ref.editorFrame.blur();
                                ref.editorFrame.classList.add('hidden');
                            } else {
                                if (
                                    me().boostCooldown &&
                                    me().boostCooldown < 0
                                ) {
                                    const angle =
                                        (Math.atan2(
                                            mouse.y - canvas.height / 2,
                                            mouse.x - canvas.width / 2
                                        ) +
                                            Math.PI / 2) %
                                        (Math.PI * 2);
                                    me().boostCooldown = 1;
                                    me().xv += 6 * Math.sin(angle);
                                    me().yv -= 6 * Math.cos(angle);
                                } else {
                                    if (!window.mobile) {
                                        useMouse = !useMouse;
                                    }
                                    input.up = false;
                                    input.down = false;
                                    input.left = false;
                                    input.right = false;
                                }
                            }
                            // input.shift = false;
                            e.preventDefault();
                        };

                        window.onmousemove = (event) => {
                            if (window.usingController) {
                                return;
                            }
                            const bound = canvas.getBoundingClientRect();
                            mouse.x = Math.round(
                                (event.pageX - bound.left) / scale
                            );
                            mouse.y = Math.round(
                                (event.pageY - bound.top) / scale
                            );
                            // mouse.x = event.pageX;
                            // mouse.y = event.pageY;
                        };
                        window.ontouchmove = (event) => {
                            event.preventDefault();
                            const touch = event.changedTouches[0];
                            const bound = canvas.getBoundingClientRect();
                            // mouse movement
                            mouse.x = Math.round(
                                (touch.pageX - bound.left) / scale
                            );
                            mouse.y = Math.round(
                                (touch.pageY - bound.top) / scale
                            );
                        };
                        if (window.mobile) {
                            window.ontouchstart = (event) =>
                                onTouchStart(event);
                            window.ontouchend = (event) => onTouchEnd(event);
                            // lol ill figure it out eventually
                            /*window.onkeydown = event => function(){
                                alert(window.mobileTyping);
                                if(!window.mobileTyping){
                                    // creating a button to send the msg if u start typing
                                    let btn = document.createElement("button");
                                    btn.innerHTML = "Send Message";
                                    btn.onclick = function () {
                                        window.mobileTyping = false;
                                        trackKeys({repeat: false, code: 'Enter', type: 'keydown'}, input, true);
                                    };
                                    document.querySelector('.chat-div').appendChild(btn);   
                                }
                                window.mobileTyping = true;
                            }*/
                            //ref.chatMessageDiv.onselect = alert('focused')//trackKeys('Enter', input);

                            //window.onkeydown = event => function(){
                            //alert('chat :D');
                            /*if(chatOpen){
                                    alert(event.code);
                                    trackKeys(event, input)   
                                }*/
                            //};
                        } else {
                            window.onkeydown = (event) =>
                                trackKeys(event, input);
                            window.onkeyup = (event) => trackKeys(event, input);
                        }

                        window.onresize = () => {
                            if (window.dimensions === 3 && camera3D && renderer) {
                                const ratio =
                                    window.innerHeight / window.innerWidth;
                                camera3D.left = -window.cameraZoom / ratio;
                                camera3D.right = window.cameraZoom / ratio;
                                camera3D.top = window.cameraZoom;
                                camera3D.bottom = -window.cameraZoom;
                                camera3D.updateProjectionMatrix();
                                renderer.setSize(
                                    window.innerWidth,
                                    window.innerHeight
                                );
                            }
                            window.scale = resize([
                                canvas,
                                shadowCanvas,
                                ref.gui,
                                rayCanvas,
                                ref.editorFrame,
                            ]);
                        };
                    });
                    init = false;
                } else {
                    shouldRender = true;
                }
            }
            debug.ping = halfRRT;
            send({ pingResult: debug.ping });
        }
        if (data.newPlayer) {
            if (window.dimensions === 3) {
                remove3Dplayer(data.data.id);
            } else {
                delete players[data.data.id];
            }
            if (window.dimensions === 3) {
                players[data.data.id] = create3DPlayer({
                    ...data.data,
                    dimensions: 3,
                });
                render3D(arena);
            } else {
                players[data.data.id] = new Player(data.data);
            }
        }
        if (data.world != undefined) {
            window.world = data.world;
            if (data.world === 'Hub') {
                shouldUpdateTimer = false;
                timer = 0;
            } else if (data.world === 'Winroom') {
                shouldUpdateTimer = false;
            } else {
                timer = 0;
                shouldUpdateTimer = true;
            }
        }
        if (data.serverFps != undefined) {
            debug.serverFps = data.serverFps;
        }
        if (data.nw) {
            window.ghostpushers = {};
            window.mypushers = [];
            if (window.dimensions === 3) {
                disable3D();
            }
            console.log(data);
            if (data.musicPath != undefined) {
                if (bg.currentTime > 0) {
                    bg.currentTime = 0;
                }
                if (data.musicPath !== undefined) {
                    bg.src = data.musicPath;
                    if (data.musicPath === '/sounds/aiae.mp3') {
                        bg.volume = 0.3;
                    } else {
                        bg.volume = 0.7;
                    }
                } else {
                    bg.src = hubMusic;
                }
                bg.loop = true;
                bg.play();
            }
            // nw -> new world / change
            // data.state = everything
            // fade()
            window.renderScale = 1;
            window.dimensions = data.state.dimensions || 2;
            window.backgroundColor = data.state.bgColor;
            window.tileColor = data.state.tileColor;
            window.safeColor = data.state.safeColor;
            window.arena = {
                width: data.state.arena.width,
                height: data.state.arena.height,
            };
            if (window.dimensions === 3) {
                init3D(arena, data.state);
                for (const init of data.state.obstacles) {
                    obstacles.push(init);
                }
                initObstacles(obstacles);
                for (const init of data.state.players) {
                    remove3Dplayer(init.id);
                    players[init.id] = create3DPlayer(
                        {
                            ...init,
                            dimensions: 3,
                        },
                        data.state.cameraZoom
                    );
                }
                render3D(arena);
            } else {
                createTileImg(1);
                // window.map = data.map;
                // document.body.style.backgroundColor = data.state.bgColor;
                debug.ping = undefined;
                shouldRender = false;
                send({ ping: Date.now() }); // so client can speedup
                // set everything
                selfId = data.state.selfId;
                window.players = {};
                window.enemy = [];
                window.goingToNewWorld = false;
                window.safes = [];
                npcs = [];
                texts = [];
                window.obstacles = [];
                window.portals = [];
                window.lighting = data.state.lighting || 0;
                window.window.raycastvision =
                    data.state.renderRaycasting || false;
                for (const init of data.state.players) {
                    players[init.id] = new Player(init);
                }

                for (const init of data.state.texts) {
                    texts.push(init);
                }

                for (const init of data.state.enemy) {
                    enemy.push(new Enemy(init));
                }

                for (const init of data.state.safes) {
                    safes.push(new Safe(init));
                }

                for (const init of data.state.npcs) {
                    npcs.push(new Npc(init));
                }

                for (const init of data.state.obstacles) {
                    let obstacle = init;
                    if (obstacle.type === 'portal') {
                        portals.push(init);
                    } else {
                        obstacles.push(init);
                    }
                }
                if (data.state.addedobstacles != undefined) {
                    for (const init of data.state.addedobstacles) {
                        let obstacle = init;
                        if (obstacle.type === 'portal') {
                            portals.push(init);
                        } else {
                            if (
                                obstacle.type === 'lava' &&
                                obstacle.canCollide != true &&
                                obstacle.canCollide != false
                            ) {
                                init.canCollide = true;
                            }
                            obstacles.push(init);
                        }
                    }
                    console.log(data.state.mapDelta + ' Delta');
                    /*for(let s = 0; s <= 1000; s++){
    					runObstaclePhysics(data.state.addedobstacles,data.state.mapDelta/1000,me())
    				}*/
                }
                window.camera = { x: 0, y: 0 };
                window.xoff = 0;
                window.yoff = 0;
                window.mouse = { x: canvas.width / 2, y: canvas.height / 2 };
                if (window.raycastvision) computeLines();
            }
        }
    };

    window.fade = (func = () => {}) => {
        ref.overlay.classList.remove('fade-out');
        ref.overlay.classList.remove('fade-in');
        ref.overlay.classList.remove('hidden');
        ref.overlay.classList.add('fade-in');
        ref.overlay.onanimationend = () => {
            ref.overlay.classList.remove('fade-in');
            ref.overlay.classList.add('fade-out');
            func();
            ref.overlay.onanimationend = () => {
                ref.overlay.classList.add('hidden');
            };
        };
    };

    let lastTime = null;

    let frames = 0;

    function run(/*t = 0*/) {
        const t = window.performance.now();
        fpsTick(t);
        if (lastTime == null) {
            lastTime = t;
        }
        window.delta = t - lastTime;
        window.time += delta / 1000;
        window.delt = get_delta(delta);
        if (shouldUpdateTimer) {
            window.timer += delta / 1000; //* window.speedhack;
        }
        lastTime = t;
        if (connected) {
            update(delt);
        }
        if (shouldRender && loaded) {
            render();
        }
        if (unreadpings !== 0) {
            document.title = 'Evades X';
            ref.favicon.href = './favicon.png';
        }
        unreadpings = 0;
        // if (document.body.classList.contains('onMenu')) {
        // 	document.body.classList.remove('onMenu')
        // }
        if (
            document.body.style.backgroundColor !== backgroundColor &&
            ref.menu.classList.contains('hidden')
        ) {
            document.body.style.backgroundColor = backgroundColor;
            document.body.classList.remove('onMenu');
        }
        requestAnimationFrame(run);
    }
    window.onTab = true;
    document.addEventListener('visibilitychange', function (event) {
        if (document.hidden) {
            onTab = false;
        } else {
            onTab = true;
        }
    });

    setInterval(() => {
        if (!onTab) {
            window.delta = window.performance.now() - lastTime;
            lastTime = window.performance.now();
            if (shouldUpdateTimer) {
                window.timer += delta / 1000; // * window.speedhack;
            }
            if (mg1countdownStart) {
                mg1countTimer -= delta / 1000;
                if (mg1countTimer <= 0) {
                    send({ world: 'PoSR' });
                    mg1countdownStart = false;
                }
            }
            simulateGame();
        }
    }, 1000 / 60);

    setInterval(() => {
        // console.log(`${frames} Simulation Frames`);
        debug.frameDisplay = frames;
        frames = 0;
        debug.updateTimeD = debug.updateTime;
        debug.updateTime = 0;
        debug.renderTimeD = debug.renderTime;
        debug.renderTime = 0;
        debug.sentTimeD = debug.sentTimes;
        debug.sentTimes = 0;
        debug.fpsDisplay = fps;
        debug.cTestRender = [debug.cTests[0], debug.cTests[1]];
        debug.cTests[0] = 0;
        debug.cTests[1] = 0;
        upstreambytesR = upstreambytes;
        downstreambytesR = downstreambytes;
        upstreambytes = 0;
        downstreambytes = 0;
    }, 1000);

    setInterval(() => {
        send({ ping: Date.now() });
    }, 500);

    window.computeLines = function () {
        window.rayLines = [];
        const rectToLines = ({ x, y, w, h }) => {
            return [
                new Line(x, y, x + w, y),
                new Line(x, y + h, x + w, y + h),
                new Line(x, y, x, y + h),
                new Line(x + w, y, x + w, y + h),
            ];
        };
        for (const obj of obstacles) {
            if (obj.type === 'normal') {
                rectToLines(obj).forEach((line) => {
                    rayLines.push(line);
                });
            }
            if (obj.type.startsWith('poly')) {
                let lastIndex = obj.points.length - 1;
                obj.points.forEach(([x, y], i) => {
                    rayLines.push(
                        new Line(
                            x,
                            y,
                            obj.points[lastIndex][0],
                            obj.points[lastIndex][1]
                        )
                    );
                    lastIndex = i;
                });
            }
        }
        // for (const obj of portals) {
        // 	rectToLines(obj).forEach((line) => {
        // 		rayLines.push(line);
        // 	})
        // }
        const mapLines = [
            rectToLines({ x: 0, y: 0, w: arena.width, h: 1 }),
            rectToLines({ x: 0, y: 0, w: 1, h: arena.height }),
            rectToLines({ x: 0, y: arena.height, w: arena.width, h: 1 }),
            rectToLines({ x: arena.width, y: 0, w: 1, h: arena.height }),
        ];
        mapLines.forEach((lines) => {
            lines.forEach((line) => {
                rayLines.push(line);
            });
        });
        let points = [];
        rayLines.forEach((line) => {
            points.push(line.start.copy(), line.end.copy());
        });
        let pointSet = {};
        const maxDist = Infinity;
        window.uniqueRayPoints = points.filter((point) => {
            const key = `${point.x},${point.y}`;
            if (key in pointSet) {
                return false; // not unique
            } else if (
                Math.abs(me().renderX - point.x) < maxDist &&
                Math.abs(me().renderY - point.y) < maxDist
            ) {
                pointSet[key] = true;
                return true;
            } else {
                return false;
            }
        });
    };

    function renderGame() {
        // testing iso
        // ctx.setTransform(2,0.5,0,1,-canvas.width/2,-canvas.height/2)
        renderArena(arena);
        if (window.showGrid) {
            renderTiles(arena, camera);
        }
        debug.rendered = 0;

        // ctx.stroke()

        renderLinks(obstacles);
        renderSafes(safes, false);
        renderEnemy(enemy);

        renderObstacles(obstacles, window.ghostpushers);
        renderObstacles(portals);

        renderSafes(safes, true);
        renderTexts(texts, viewingStory);
        renderNpcs(npcs, me());

        // ctx.strokeStyle = 'black';
        // ctx.lineWidth = 2;
        // for (const line of rayLines) {
        // 	const s = offset(line.start.x, line.start.y);
        // 	const e = offset(line.end.x, line.end.y);
        // 	ctx.beginPath();
        // 	ctx.lineTo(s.x, s.y);
        // 	ctx.lineTo(e.x, e.y);
        // 	ctx.stroke()
        // }
        // ctx.fillStyle = 'red'
        // for (const { x, y } of uniqueRayPoints) {
        // 	ctx.beginPath();
        // 	const pos = offset(x, y);
        // 	ctx.arc(pos.x, pos.y, 5, 0, Math.PI * 2);
        // 	ctx.fill()
        // }
        if (debugMode) {
            ctx.strokeStyle = 'black';
            ctx.lineWidth = 2;
            ctx.beginPath();
            // points.push(points[0])
            for (const { x, y } of points) {
                const pos = offset(x, y);
                ctx.lineTo(pos.x, pos.y);
            }
            ctx.closePath();
            // ctx.fill();
            ctx.globalAlpha = 1;
            ctx.stroke();
        }
        debug.totalRender = [...obstacles, ...portals, ...enemy].length;
        renderPlayers(players);
        if (me().raycasting) {
            renderRaycasting(me());
        }
        // if (leaderboard !== undefined) {
        // 	drawLeaderboard(leaderboard, players);
        // }
        renderPreview();
        drawOverlay(me(), enemy);
        renderVideo(players);
        // rendering gunslinger cursors
        if (gunslingerCursors.length > 0) {
            for (let cursor of gunslingerCursors) {
                if (cursor !== undefined && cursor !== null) {
                    if (gunslingerCursors[me().id] != cursor) {
                        const coff = offset(cursor.x, cursor.y);
                        ctx.beginPath();
                        ctx.fillStyle = 'red';
                        ctx.arc(coff.x, coff.y, 20, 0, Math.PI * 2);
                        ctx.fill();
                        ctx.closePath();
                    } else if (
                        mouse.x != canvas.width / 2 &&
                        me().powerups.gunslinger
                    ) {
                        ctx.beginPath();
                        ctx.fillStyle = 'blue';
                        ctx.arc(mouse.x, mouse.y, 20, 0, Math.PI * 2);
                        ctx.fill();
                        ctx.closePath();
                    }
                    //const coff = offset(cursor.x, cursor.y);
                    //console.log(coff);
                }
            }
        }
    }

    function render() {
        if (window.dimensions === 3) {
            return;
        }
        if (me() && !window.spectating) {
            camera.x = me().renderX;
            camera.y = me().renderY;
        }
        if (me().cameraChange != undefined) {
            camera.x = me().cameraChange.x;
            camera.y = me().cameraChange.y;
        }
        if (window.spectating && players[window.spectateId]) {
            camera.x = linearLerp(
                camera.x,
                players[window.spectateId].renderX,
                (delta / 1000) * 10
            );
            camera.y = linearLerp(
                camera.y,
                players[window.spectateId].renderY,
                (delta / 1000) * 10
            );
        }
        // also lame no ads ver ;-;
        const before = window.performance.now();
        ctx.fillStyle = backgroundColor;
        // ctx.globalAlpha = 0. 1;
        //context.save(),
        // context.translate(-e.camera.x * fov, -e.camera.y * fov),
        // context.fillStyle = t,
        // context.fillRect(e.camera.x * fov, e.camera.y * fov, width, height),
        // "hsl" == e.datas.backgroundColor[0] ? context.fillStyle = "hsl(".concat(e.datas.backgroundColor[1], ", 75%, 40%)") : context.fillStyle = "rgba(".concat(e.datas.backgroundColor[0], ", ").concat(e.datas.backgroundColor[1], ", ").concat(e.datas.backgroundColor[2], ", ").concat(e.datas.backgroundColor[3], ")"),
        // context.fillRect(e.camera.x * fov, e.camera.y * fov, width, height),
        // context.restore(),

        ctx.fillRect(0, 0, canvas.width, canvas.height);
        if (window.backgroundPattern == null) {
            window.backgroundPattern = ctx.createPattern(
                window.bgImg,
                'repeat'
            );
            // window.bgImagePattern = document.createElement('canvas');
            // bgImagePattern.width = arena.width;
            // bgImagePattern.height = arena.height;
            // const bctx = bgImagePattern.getContext('2d');
            // window.backgroundPattern = bctx.createPattern(window.bgImg, 'repeat')
            // bctx.fillStyle = backgroundPattern;
            // bctx.fillRect(0, 0, arena.width, arena.height);
            console.log('generating background pattern');
        }
        // ctx.save()
        // ctx.translate(-camera.x, -camera.y);
        // // ctx.fillStyle = backgroundColor;
        // // ctx.fillRect(camera.x, camera.y, canvas.width, canvas.height);
        // ctx.fillStyle = backgroundPattern;
        // // ctx.globalAlpha = 0.5;
        // ctx.fillRect(camera.x, camera.y, canvas.width, canvas.height);
        // // ctx.globalAlpha = 1;

        // ctx.translate(camera.x, camera.y);
        // ctx.restore()
        // ctx.globalAlpha = 1;

        window.points = raycastvision
            ? Ray.getPoints(
                  new Vec(me().renderX, me().renderY),
                  uniqueRayPoints,
                  rayLines,
                  me().renderRadius
              )
            : [];

        // const points = Ray.getPoints(state.player.pos, uniquePoints, state.lines, state.player.radius);

        window.darkness = window.spectating ? 0.8 : 0.5;

        if (!connected) {
            window.darkness = 0.8;
        }

        // ctx.translate(canvas.width / 2 - (camera.x * gameScale), canvas.height / 2 - (camera.y * gameScale));
        // ctx.scale(gameScale, gameScale);
        ctx.save();
        ctx.setTransform(
            renderScale,
            0,
            0,
            renderScale,
            canvas.width / 2,
            canvas.height / 2
        );
        ctx.translate(-canvas.width / 2, -canvas.height / 2);

        renderGame();
        ctx.restore();
        if (renderScale >= 1 && showMinimap) {
            let mc = document.createElement('canvas');
            mc.width = canvas.width;
            mc.height = canvas.height;
            ctx = mc.getContext('2d');
            // ctx.filter = 'grayscale(100%)'
            ctx.fillStyle = backgroundColor;
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            let old = renderScale;
            renderScale *= 0.8;
            // renderScale = Math.max(renderScale * 0.7, 1)
            window.dontRenderPortalName = true;
            window.dontShowPlayerName = true;
            ctx.save();
            ctx.setTransform(
                renderScale,
                0,
                0,
                renderScale,
                canvas.width / 2,
                canvas.height / 2
            );
            ctx.translate(-canvas.width / 2, -canvas.height / 2);
            // renderGame()
            // altered render
            renderArena(arena);
            if (window.showGrid) {
                // renderTiles(arena, camera)
            }
            debug.rendered = 0;

            // ctx.stroke()

            // renderSafes(safes, false);
            // renderEnemy(enemy);
            // renderObstacles(obstacles);
            renderObstacles(portals);
            //       renderSafes(safes, true);
            // // renderTexts(texts, viewingStory);
            // renderNpcs(npcs, me());
            window.dontRenderPortalName = false;

            // ctx.strokeStyle = 'black';
            // ctx.lineWidth = 2;
            // for (const line of rayLines) {
            // 	const s = offset(line.start.x, line.start.y);
            // 	const e = offset(line.end.x, line.end.y);
            // 	ctx.beginPath();
            // 	ctx.lineTo(s.x, s.y);
            // 	ctx.lineTo(e.x, e.y);
            // 	ctx.stroke()
            // }
            // ctx.fillStyle = 'red'
            // for (const { x, y } of uniqueRayPoints) {
            // 	ctx.beginPath();
            // 	const pos = offset(x, y);
            // 	ctx.arc(pos.x, pos.y, 5, 0, Math.PI * 2);
            // 	ctx.fill()
            // }
            if (debugMode) {
                ctx.strokeStyle = 'black';
                ctx.lineWidth = 2;
                ctx.beginPath();
                // points.push(points[0])
                for (const { x, y } of points) {
                    const pos = offset(x, y);
                    ctx.lineTo(pos.x, pos.y);
                }
                ctx.closePath();
                // ctx.fill();
                ctx.globalAlpha = 1;
                ctx.stroke();
            }
            debug.totalRender = [...obstacles, ...portals, ...enemy].length;
            renderPlayers(players);
            window.dontShowPlayerName = false;
            if (me().raycasting) {
                renderRaycasting(me());
            }
            // drawOverlay(me(), enemy);
            ctx.restore();
            ctx = canvas.getContext('2d');

            ctx.drawImage(mc, 0, canvas.height - 180, 320, 180);
            renderScale = old;
        }

        // ctx.scale(1 / gameScale, 1 / gameScale);
        // ctx.translate(-(canvas.width / 2 - (camera.x * gameScale)), -(canvas.height / 2 - (camera.y * gameScale)));

        // renderMinimap(players, arena);
        renderTimer();
        renderTimers(); // timetraps and such
        if (debugMode) {
            renderDebug(debug);
        }
        // if (me() && !window.spectating) {
        // 	camera.x = me().renderX;
        // 	camera.y = me().renderY;
        // }
        //       if (me().cameraChange != undefined){
        //           camera.x = me().cameraChange.x;
        //           camera.y = me().cameraChange.y;
        //       }
        // if ((window.spectating && players[window.spectateId])) {
        // 	camera.x = linearLerp(camera.x, players[window.spectateId].renderX, (delta / 1000) * 10);
        // 	camera.y = linearLerp(camera.y, players[window.spectateId].renderY, (delta / 1000) * 10);
        // }
        debug.renderTime += window.performance.now() - before;
    }

    window.me = function () {
        return players[selfId];
    };

    window.lastSent = [null, null];
    window.cloneLastSent = null;

    window.rayLines = [];
    window.uniqueRayPoints = [];

    if (window.raycastvision) computeLines();

    let lastDeathTimer = undefined;
    let lastRadius = null;
    function update(delt) {
        if (zoneAnim) {
            if (window.performance.now() - zoneT >= 3000) {
                zoneAnim = false;
                // zoneT = 0;
            }
        }
        // zoom anim -> 1s go in, 2s stay, 1s go out

        if (mg1countdownStart) {
            mg1countTimer -= delta / 1000;
            if (mg1countTimer <= 0) {
                send({ world: 'PoSR' });
                mg1countdownStart = false;
            }
        }

        // this is where interpolation happens, put it heree?
        // isnt it globally in window..
        // ye ik
        // make another variable for it and interpolate to hpysics

        // global one is set in physics xD
        // but why can't we just do in physics and not have to worry about variable?
        // ik but we don;t have the 2 values to interpolate unless we want to define a new variabel
        simulateGame();

        if (shouldRender) {
            for (const playerId of Object.keys(players)) {
                players[playerId].update(delt);
            }
        }
        for (const e of enemy) {
            e.update(delt);
        }

        // raycast line calculations
    }
    function simulateGame() {
        if (players[selfId] != null && connected) {
            accum += delta;
            const before = window.performance.now();
            accum = runPhysics(accum);
            debug.updateTime += window.performance.now() - before;

            // sending like update
            const pos = [
                Math.round(players[selfId].x),
                Math.round(players[selfId].y),
                Math.round(players[selfId].z),
            ];
            if (lastSent[1] === null || lastSent[0] === null) {
                // to prevent sending right when u join
                lastSent[0] = pos[0];
                lastSent[1] = pos[1];
                if (!isNaN(pos[2])) {
                    lastSent[2] = pos[2];
                }
            }
            if (
                lastSent[0] !== pos[0] ||
                lastSent[1] !== pos[1] ||
                (pos[2] && lastSent[2] !== pos[2])
            ) {
                if (isNaN(pos[2])) {
                    pos.splice(2, 1);
                }
                send(pos);
                window.lastSent = pos;
                debug.sentTimes++;
            }
            // same thing for clones
            // commented out clones for now
            // for(let i in players[selfId].clones){
            //     /*console.log(cloneLastSent);
            //     let clone = players[selfId].clones[i];
            //     let cpos = [Math.round(clone.x * 10) / 10, Math.round(clone.y * 10) / 10];
            //     if(clone.lastSent === null || clone.lastSent === undefined){
            //         players[selfId].clones[i].lastSent[0] = players[selfId].clones[i].x;
            //         players[selfId].clones[i].lastSent[1] = players[selfId].clones[i].y;
            //     }*/
            //     // sending every frame for testing purposes ;-;
            //     send({ clonePos: [players[selfId].clones[i].x, players[selfId].clones[i].y, i] })
            // }
            // here is where u send stuff ;-;
            /*let changed = false;
            for (
                let i = 0;
                i < Math.max(lastpushers.length, mypushers.length);
                i++
            ) {
                let lp = window.lastpushers[i];
                let p = window.mypushers[i];
                if (lp === undefined || p === undefined) {
                    continue;
                }
                if (!deepEqual(lp, p)) {
                    changed = true;
                    break;
                }
            }
			if (
                changed &&
                (window.lastpushers.length > 0 || window.mypushers.length > 0)
            ) {
                send({ pusher: window.mypushers.map((p,i) => packPusher(p,i)) });
                console.log(window.mypushers.map((p,i) => packPusher(p,i)));
            }
            window.lastpushers = window.mypushers;*/

            if (lastRadius === null) {
                lastRadius = me().radius;
            }
            if (lastRadius !== me().radius) {
                lastRadius = me().radius;
                send({ radius: me().radius });
            }
            if (
                lastDeathTimer != me().deathTimer &&
                (me().deathTimer == undefined ||
                    Math.ceil(me().deathTimer) != Math.ceil(lastDeathTimer))
            ) {
                lastDeathTimer = me().deathTimer;
                const timer =
                    me().deathTimer == undefined
                        ? undefined
                        : Math.ceil(me().deathTimer);
                send({ deathTimer: timer, deathchange: true });
                //death change is just to check if the message is valid
                // since deathtimer might be undefined
            }
        }
    }

    function runPhysics(accum) {
        // ;-; ill just add 1v1 obs in hub
        let count = 0;
        while (accum >= 1000 / updateRate) {
            // if (count > 60) break;
            const simulationDelta = 1 / updateRate;
            if (window.dimensions === 3) {
                simulate3D(
                    me(),
                    arena,
                    obstacles,
                    input,
                    simulationDelta,
                    players,
                    enemy,
                    safes,
                    npcs
                );
                return accum;
            }
            simulateOtherBullets(players, simulationDelta, enemy, me());
            if (me().powerups.dragon.state) {
                runDragonCollision(players, simulationDelta, me());
            }
            if (!me().dead && !me().god) {
                window.mypushers = [];
            }
            // lmao
            runObstaclePhysics(obstacles, simulationDelta, players, enemy);
            runEnemyPhysics(
                enemy,
                arena,
                simulationDelta,
                obstacles,
                me(),
                players
            );
            runPlayerPhysics(
                me(),
                arena,
                obstacles,
                input,
                simulationDelta,
                players,
                enemy,
                safes,
                npcs
            );
            if (me().tagged) {
                runPlayerTagged(me(), players, simulationDelta);
            }
            for (let i in players) {
                if (players[i].bullets != []) {
                    players[i].lastBullets = players[i].bullets;
                }
            }
            for (let c in me().clones) {
                runPlayerPhysics(
                    me().clones[c],
                    arena,
                    obstacles,
                    input,
                    simulationDelta,
                    players,
                    enemy,
                    safes,
                    npcs
                );
            }
            //if(checkEnemyCollision){
            for (let ene of enemy) {
                if (!ene.runCollision) continue;
                runEnemyCollision(me(), ene, obstacles, safes, npcs, enemy);
            }
            //}
            viewingStory = runCollision(
                me(),
                enemy,
                [...obstacles, ...portals],
                safes,
                npcs
            );
            // viewingStory = runCollision(me(), enemy, [...portals], safes);
            for (let c in me().clones) {
                runCollision(
                    me().clones[c],
                    enemy,
                    [...obstacles, ...portals],
                    safes,
                    npcs
                );
            }

            frames++;
            count++;
            accum -= 1000 / updateRate;
        }
        return accum;
    }

    requestAnimationFrame(run);
};

function packPusher(p, i) {
    let pack = {};
    const lastPusher = window.lastpushers[i];
    if (!lastPusher) {
        return { x: p.x, y: p.y, index: i };
    }
    // buggy
    //if(p.x !== lastPusher.x){
    pack.x = Math.round(p.x * 10) / 10;
    //}
    //if(p.y !== lastPusher.y){
    pack.y = Math.round(p.y * 10) / 10;
    //}
    pack.pusherId = p.pusherId;
    return pack;
}

function deepEqual(object1, object2) {
    const keys1 = Object.keys(object1);
    const keys2 = Object.keys(object2);
    if (keys1.length !== keys2.length) {
        return false;
    }
    for (const key of keys1) {
        const val1 = object1[key];
        const val2 = object2[key];
        const areObjects = isObject(val1) && isObject(val2);
        if (
            (areObjects && !deepEqual(val1, val2)) ||
            (!areObjects && val1 !== val2)
        ) {
            return false;
        }
    }
    return true;
}

function isObject(val) {
    return val instanceof Object;
}

// src/client/index.js

window.ws = new WebSocket(location.origin.replace(/^http/, 'ws'));
const encode = (msg) => msgpack.encode(msg);
const decode = (msg) => msgpack.decode(new Uint8Array(msg));

let toSend = true;
setTimeout(() => {
    toSend = false;
}, 5000);
const send = (msg) => {
    // console.log(msg);
    const data = encode(msg);
    upstreambytes += data.byteLength;
    // console.log(msg, data.byteLength);
    ws.send(data);
};
window.upstreambytes = 0;
window.downstreambytes = 0;
window.upstreambytesR = 0;
window.downstreambytesR = 0;
ws.binaryType = 'arraybuffer';

let connected = false;
let extraLag = 0;

window.mg1countdownStart = false;

const _captchaKey = '6LcXTdogAAAAAJ-uDjOX6RJH3bEDJn4npV-ZenAG';

let newPlayer = localStorage.getItem('newPlayer');

// let savedName = localStorage.getItem('name');
let gridState = localStorage.getItem('gridState');
let lastShowGrid = true;
// if (savedName == undefined) {
//     savedName = '';
// }
if (gridState === undefined) {
    gridState = 'false';
}
if (gridState === 'false') {
    gridState = false;
} else {
    gridState = true;
}
let onBetaKey = true;
let __lastLoginAttempt = {
    name: '',
    password: '',
};
// ref.nameInput.value = savedName;

ref.loginForm.onsubmit = (event) => {
    event.preventDefault();
};

ref.playButton.addEventListener('mousedown', (event) => {
    ws.send(encode({ enterGame: true }));
});

ref.logoutButton.addEventListener('mousedown', (event) => {
    ref.loginForm.classList.remove('hidden');
    ref.loginSuccess.classList.add('hidden');
    ref.usernameInput.value = __lastLoginAttempt.name;
    ref.passwordInput.value = __lastLoginAttempt.password;
});

ref.guestButton.addEventListener('mousedown', (event) => {
    grecaptcha.ready(function () {
        grecaptcha
            .execute(_captchaKey, { action: 'submit' })
            .then(function (token) {
                ws.send(
                    encode({
                        guest: true,
                        token,
                    })
                );
            });
    });
});

ref.loginButton.addEventListener('mousedown', (event) => {
    const name = ref.usernameInput.value.trim();
    const password = ref.passwordInput.value.trim();
    const hashedPassword = SHA(password + 'ZeroTix');
    __lastLoginAttempt.name = name;
    __lastLoginAttempt.password = password;
    localStorage.setItem('username', name);
    localStorage.setItem('password', hashedPassword);
    console.log(name, password, hashedPassword, 'login');
    if (name.length > 0 && password.length > 0) {
        grecaptcha.ready(function () {
            grecaptcha
                .execute(_captchaKey, { action: 'submit' })
                .then(function (token) {
                    ws.send(
                        encode({
                            login: true,
                            username: name,
                            password: hashedPassword,
                            token,
                        })
                    );
                });
        });
    }
});

ref.registerButton.addEventListener('mousedown', (event) => {
    const name = ref.usernameInput.value.trim();
    const password = ref.passwordInput.value.trim();
    const hashedPassword = SHA(password + 'ZeroTix');
    console.log(name, password, hashedPassword, 'register');
    if (name.length > 0 && password.length > 0) {
        grecaptcha.ready(function () {
            grecaptcha
                .execute(_captchaKey, { action: 'submit' })
                .then(function (token) {
                    ws.send(
                        encode({
                            register: true,
                            username: name,
                            password: hashedPassword,
                            token,
                        })
                    );
                });
        });
    }
});

// gonna be annoying to uncomment
ref.nameForm.addEventListener('submit', (event) => {
    const name = ref.nameInput.value;
    ref.nameInput.value = '';
    //   localStorage.setItem("name", name);
    if (connected) {
        if (onBetaKey) {
            ws.send(encode({ betaKey: name }));
            localStorage.setItem('betaKey', name);
        } else {
            ws.send(encode({ joinGame: true, name }));
        }
    }
    //   if (newPlayer == undefined) {
    //     send({ world: 'PoPB' });
    //   }
    localStorage.setItem('newPlayer', false);
    event.preventDefault();
});

window.addEventListener('load', () => {
    console.log('assets loaded in', Math.round(window.performance.now()), 'ms');
});

ws.onopen = () => {
    //console.log('CONNECTED TO THE GAME SERVER SUCCESSFULLY')
    // ref.mainMenu.classList.remove('hidden');
    // ref.mainMenu.classList.add('unblur');
    // ref.evadeText.classList.add('eanim')
    console.log(
        'connected to server in',
        Math.round(window.performance.now()),
        'ms'
    );
    let savedBetaKey = localStorage.getItem('betaKey');
    if (savedBetaKey != undefined) {
        //   window.ws.addEventListener("open", () => {
        window.ws.send(encode({ betaKey: savedBetaKey }));
        //   })
    }

    connected = true;
    window.showGrid = gridState;
};

ws.onmessage = (msg) => {
    const data = decode(msg.data);
    downstreambytes += msg.data.byteLength;
    // console.log(data, msg.data.byteLength)
    if (data.joinGame) {
        // document.body.classList.remove('onMenu')
        setTimeout(() => {
            runGame(data.data);
        }, extraLag);
        return;
    }
    if (data.loginSuccess) {
        // name = account name
        ref.loginForm.classList.add('hidden');
        ref.loginSuccess.classList.remove('hidden');
        ref.loginData.innerText = `Logged in as ${data.name}`;
        return;
    }
    if (data.registerSuccess != undefined) {
        alert('Successfully created account!');
        return;
    }
    if (data.loginFailure != undefined) {
        alert(data.loginFailure);
        return;
    }
    if (data.type === 'verify') {
        // gave the right betaKey
        ref.beta.innerHTML = '';
        ref.evadeTitle.classList.remove('hidden');

        onBetaKey = false;
        // const params = new URLSearchParams(document.location.search);
        // if (params.get('name')) {
        //     ws.send(
        //         encode({
        //             joinGame: true,
        //             name:
        //                 params.get('name') +
        //                 (params.get('disc') != undefined
        //                     ? '#' + params.get('disc')
        //                     : ''),
        //         })
        //     );
        // }
        const name = localStorage.getItem('username');
        const password = localStorage.getItem('password');
        if (name != undefined && password != undefined) {
            grecaptcha.ready(function () {
                grecaptcha
                    .execute(_captchaKey, { action: 'submit' })
                    .then(function (token) {
                        ws.send(
                            encode({
                                login: true,
                                username: name,
                                password,
                                token,
                            })
                        );
                    });
            });
        }
        return;
    }
    setTimeout(() => {
        processGameMessage(data);
    }, extraLag); //You realize setTimeout with 0 still adds extra lag right
    if (showGrid != lastShowGrid) {
        lastShowGrid = showGrid;
        localStorage.setItem('gridState', showGrid);
    }
};

ws.onclose = (e) => {
    connected = false;
	console.log('closeData from websocket', e);
    //console.error('WEBSOSCKET CLOSED!!!')
};

ws.onerror = (e) => {
	console.log('errorData from websocket', e);
}

ws.addEventListener('error', event => {
    console.log('errorData from websocket', event);
})